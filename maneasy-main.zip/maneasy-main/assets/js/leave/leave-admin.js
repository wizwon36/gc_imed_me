'use strict';

var currentUser = null;
var myOrgMemberId = null;
var myUiPrefs = {}; // org_members.ui_prefs (지금은 안 쓰지만 향후 화면별 선호값 저장용으로 남겨둠)
var myClinicId = null; // 이 의원의 id (= currentUser.org_id, 별도 선택 UI 불필요)
var departments = [];
var overviewRows = []; // [{ member, balance }]
var typesCache = [];
var editingTypeId = null;
var LAW_STANDARD_POLICY = { basis: 'HIRE_DATE', first_year_monthly_days: 1, first_year_max_days: 11, base_annual_days: 15, increment_years: 2, increment_days: 1, max_annual_days: 25, carryover_mode: 'NONE', max_carryover_days: 0 };

function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v; }
function hideLoading() { var el = document.getElementById('globalLoading'); if (el) el.classList.remove('is-open'); }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.closeModal = closeModal;

/* ── init ── */
async function init() {
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'leave/leave-admin')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    var { data: meRow } = await supabaseClient.from('org_members').select('id, ui_prefs')
      .eq('id', currentUser.org_member_id).maybeSingle();
    myOrgMemberId = meRow ? meRow.id : null;
    myUiPrefs = (meRow && meRow.ui_prefs) || {};

    await loadClinic();
    await loadDepartments();
    bindUi();
    await loadOverview();
    hideLoading();
  } catch (e) {
    console.error('[leave-admin] 초기화 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 문제가 발생했습니다: ' + e.message);
  }
}

/** 이 의원의 id를 확보한다 — organizations/clinics 통합 이후로는 currentUser.org_id 자체가
 *  곧 이 의원(clinics)의 id라서, 별도 조회 없이 그대로 쓰면 된다. */
async function loadClinic() {
  myClinicId = currentUser.org_id;
}

async function loadDepartments() {
  var { data } = await supabaseClient.from('departments').select('id, dept_name').eq('org_id', currentUser.org_id).eq('is_platform_test', false).order('dept_name');
  departments = data || [];
  var sel = document.getElementById('overviewDeptFilter');
  sel.innerHTML = '<option value="">전체 부서</option>' +
    departments.map(function(d) { return '<option value="' + d.id + '">' + ts(d.dept_name) + '</option>'; }).join('');
}

/* ── UI 바인딩 ── */
function bindUi() {
  document.querySelectorAll('#adminMainTabs .tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() { switchMainTab(btn.dataset.tab); });
  });
  document.getElementById('overviewDeptFilter').addEventListener('change', loadOverview);
  document.getElementById('overviewSearch').addEventListener('input', renderOverviewList);
  document.getElementById('policyCarryoverMode').addEventListener('change', function() {
    document.getElementById('policyMaxCarryoverWrap').style.display = this.value === 'CAPPED' ? '' : 'none';
  });
  document.getElementById('savePolicyBtn').addEventListener('click', savePolicy);
  document.getElementById('addTypeBtn').addEventListener('click', openAddType);
  document.getElementById('typeSaveBtn').addEventListener('click', saveType);
}

function switchMainTab(tab) {
  document.querySelectorAll('#adminMainTabs .tab-btn').forEach(function(b) { b.classList.toggle('active', b.dataset.tab === tab); });
  document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
  document.getElementById('tab-' + tab).classList.add('active');

  // 숨겨진 탭 안에 있던 그리드를 재사용하면 ag-grid가 폭을 0으로 잰 채로 굳어버리는 문제가 있어서,
  // 탭을 열 때마다 그리드를 완전히 없애고 새로 만든다.
  if (tab === 'overview' && overviewGrid) { overviewGrid.destroy(); overviewGrid = null; document.getElementById('overviewList').innerHTML = ''; loadOverview(); }
  else if (tab === 'types') {
    if (typesGrid) { typesGrid.destroy(); typesGrid = null; document.getElementById('typesList').innerHTML = ''; }
    loadTypes();
  }
  else if (tab === 'policy') loadPolicy();
}

/* ── 전체 현황 ── */
async function loadOverview() {
  var list = document.getElementById('overviewList');
  try {
    var deptId = val('overviewDeptFilter');
    var q = supabaseClient.from('org_members_detail')
      .select('id, user_name, clinic_id, clinic_name, dept_id, dept_name, position_name, hire_date')
      .eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false);
    if (deptId) q = q.eq('dept_id', deptId);
    var { data, error } = await q.order('user_name');
    if (error) throw new Error(error.message);
    var members = data || [];

    var balances = await Promise.all(members.map(async function(m) {
      if (!m.hire_date) return { member: m, balance: null };
      var { data: b } = await supabaseClient.rpc('get_leave_balance', { p_org_member_id: m.id });
      return { member: m, balance: (b && b[0]) || null };
    }));
    overviewRows = balances;
    renderOverviewList();
  } catch (e) {
    console.error('[leave-admin] loadOverview 실패:', e);
    list.innerHTML = '<div class="apr-empty">' + ts(e.message) + '</div>';
  }
}

var overviewGrid = null;
function renderOverviewList() {
  var q = (document.getElementById('overviewSearch')?.value || '').trim().toLowerCase();
  var rows = overviewRows.filter(function(t) { return !q || (t.member.user_name || '').toLowerCase().indexOf(q) !== -1; })
    .map(function(t) {
      var m = t.member, b = t.balance;
      return {
        id: m.id, name: m.user_name,
        dept_name: m.dept_name || '', position_name: m.position_name || '',
        hire_date: m.hire_date || '',
        years: b ? b.years_of_service : null,
        entitlement: b ? b.entitlement_days : null, used: b ? b.used_days : null, remaining: b ? b.remaining_days : null,
      };
    });
  var cols = [
    { headerName: '이름', field: 'name', flex: 1, minWidth: 90, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' },
      cellRenderer: function(p) {
        var btn = document.createElement('button');
        btn.className = 'btn btn-sm'; btn.style.cssText = 'font-weight:600;padding:0;border:none;background:none;color:#2563eb;text-decoration:underline;';
        btn.textContent = p.value;
        btn.addEventListener('click', function() { goToHrLeaveTab(p.data.id); });
        return btn;
      }
    },
    { headerName: '부서', field: 'dept_name', flex: 1, minWidth: 100, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' }, valueFormatter: function(p) { return p.value || '-'; } },
    { headerName: '직책', field: 'position_name', flex: 0.8, minWidth: 80, valueFormatter: function(p) { return p.value || '-'; } },
    { headerName: '입사일', field: 'hire_date', flex: 0.9, minWidth: 95,
      cellRenderer: function(p) {
        var s = document.createElement('span');
        if (!p.value) { s.textContent = '미등록'; s.style.color = '#ef4444'; } else { s.textContent = p.value; }
        return s;
      } },
    { headerName: '근속연차', field: 'years', flex: 0.7, minWidth: 75, valueFormatter: function(p) { return p.value == null ? '-' : p.value + '년차'; } },
    { headerName: '발생', field: 'entitlement', flex: 0.6, minWidth: 60, valueFormatter: function(p) { return p.value == null ? '-' : p.value + '일'; } },
    { headerName: '사용', field: 'used', flex: 0.6, minWidth: 60, valueFormatter: function(p) { return p.value == null ? '-' : p.value + '일'; } },
    { headerName: '잔여', field: 'remaining', flex: 0.6, minWidth: 60,
      cellRenderer: function(p) { var s = document.createElement('span'); s.style.fontWeight = '700'; s.textContent = p.value == null ? '-' : p.value + '일'; return s; } },
  ];
  if (overviewGrid) {
    updateMgGrid(overviewGrid, rows);
  } else {
    overviewGrid = createMgGrid('overviewList', cols, rows, { noRowsText: '구성원이 없습니다.' });
  }
}

/** "상세" 클릭 시 — 예전엔 이 화면 안에서 모달을 띄웠지만, 이제 개별 신청내역 조회·취소·수동조정을
 *  전부 인사기록관리 쪽으로 모았으므로 거기로 바로 이동시킨다.
 *  from=leave-admin 을 같이 넘겨서, 상세 화면의 "목록으로" 버튼이 인사기록관리 목록이 아니라
 *  여기(연차정책 전체현황)로 돌아오도록 한다. */
function goToHrLeaveTab(memberId) {
  var target = 'hr/personal-info-detail?id=' + memberId + '&tab=leave&from=leave-admin';
  if (parent && typeof parent.shellNavigate === 'function') parent.shellNavigate(target);
  else location.href = '../hr/personal-info-detail.html?id=' + memberId + '&tab=leave&from=leave-admin';
}

/* ── 연차 유형 (이 의원 전용 — 별도 "공통 기본값" 개념이 필요 없다) ── */
async function loadTypes() {
  var q = supabaseClient.from('leave_types').select('*').eq('org_id', currentUser.org_id);
  q = myClinicId ? q.eq('clinic_id', myClinicId) : q.is('clinic_id', null);
  var { data, error } = await q.order('sort_order');
  if (error) { console.error('[leave-admin] loadTypes 실패:', error); typesCache = []; }
  else typesCache = data || [];
  renderTypesList();
}

var typesGrid = null;
function renderTypesList() {
  var cols = [
    { headerName: '유형명', field: 'name', flex: 1.2, minWidth: 100, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start', fontWeight: 600 } },
    { headerName: '차감 비율', field: 'deduction_ratio', flex: 0.8, minWidth: 90, valueFormatter: function(p) { return p.value == 0 ? '차감 없음(무급)' : p.value + '일'; } },
    { headerName: '순서', field: 'sort_order', flex: 0.5, minWidth: 60 },
    { headerName: '상태', field: 'active', flex: 0.6, minWidth: 70,
      cellRenderer: function(p) { return '<span style="color:' + (p.value ? '#059669' : '#9ca3af') + ';font-weight:600;">' + (p.value ? '활성' : '비활성') + '</span>'; } },
    { headerName: '', flex: 0, width: 130, sortable: false,
      cellRenderer: function(p) {
        var wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;';
        var e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정';
        e.addEventListener('click', function() { openEditType(p.data.id); });
        var d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제';
        d.addEventListener('click', function() { deleteType(p.data.id); });
        wrap.append(e, d);
        return wrap;
      } },
  ];
  if (typesGrid) {
    updateMgGrid(typesGrid, typesCache);
  } else {
    typesGrid = createMgGrid('typesList', cols, typesCache, { noRowsText: '등록된 유형이 없습니다.' });
  }
}

function openAddType() {
  editingTypeId = null;
  setVal('t_name', '');
  setVal('t_ratio', '1');
  setVal('t_sort_order', String(typesCache.length + 1));
  setVal('t_active', 'Y');
  document.getElementById('typeModalTitle').textContent = '연차 유형 추가';
  openModal('typeModal');
}

function openEditType(id) {
  var row = typesCache.find(function(r) { return r.id === id; });
  if (!row) return;
  editingTypeId = id;
  setVal('t_name', row.name);
  setVal('t_ratio', row.deduction_ratio);
  setVal('t_sort_order', row.sort_order);
  setVal('t_active', row.active ? 'Y' : 'N');
  document.getElementById('typeModalTitle').textContent = '연차 유형 수정';
  openModal('typeModal');
}

async function saveType() {
  var name = val('t_name').trim();
  if (!name) { alert('유형명은 필수입니다.'); return; }
  var payload = {
    name: name,
    deduction_ratio: parseFloat(val('t_ratio')) || 0,
    sort_order: parseInt(val('t_sort_order'), 10) || 0,
    active: val('t_active') === 'Y',
    updated_at: new Date().toISOString(),
  };
  try {
    var result;
    if (editingTypeId) {
      result = await supabaseClient.from('leave_types').update(payload).eq('id', editingTypeId);
    } else {
      payload.org_id = currentUser.org_id;
      payload.clinic_id = myClinicId;
      result = await supabaseClient.from('leave_types').insert(payload);
    }
    if (result.error) throw new Error(result.error.message);
    closeModal('typeModal');
    await loadTypes();
  } catch (e) {
    alert('저장 실패: ' + e.message);
  }
}

async function deleteType(id) {
  if (!confirm('이 연차 유형을 삭제하시겠습니까? 이미 신청된 건의 유형 표시는 유지됩니다.')) return;
  var { error } = await supabaseClient.from('leave_types').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  await loadTypes();
}

/* ── 정책 설정 (이 의원 전용) ── */
async function loadPolicy() {
  var q = supabaseClient.from('leave_policies').select('*').eq('org_id', currentUser.org_id);
  q = myClinicId ? q.eq('clinic_id', myClinicId) : q.is('clinic_id', null);
  var { data, error } = await q.maybeSingle();
  if (error) { console.error('[leave-admin] loadPolicy 실패:', error); return; }
  var p = data || LAW_STANDARD_POLICY;
  setVal('policyBasis', p.basis);
  setVal('policyFirstMonthly', p.first_year_monthly_days);
  setVal('policyFirstMax', p.first_year_max_days);
  setVal('policyBase', p.base_annual_days);
  setVal('policyIncYears', p.increment_years);
  setVal('policyIncDays', p.increment_days);
  setVal('policyMax', p.max_annual_days);
  setVal('policyCarryoverMode', p.carryover_mode || 'NONE');
  setVal('policyMaxCarryover', p.max_carryover_days || 0);
  document.getElementById('policyMaxCarryoverWrap').style.display = (p.carryover_mode === 'CAPPED') ? '' : 'none';
}

async function savePolicy() {
  var payload = {
    org_id: currentUser.org_id,
    clinic_id: myClinicId,
    basis: val('policyBasis'),
    first_year_monthly_days: parseFloat(val('policyFirstMonthly')) || 0,
    first_year_max_days: parseFloat(val('policyFirstMax')) || 0,
    base_annual_days: parseFloat(val('policyBase')) || 0,
    increment_years: parseInt(val('policyIncYears'), 10) || 1,
    increment_days: parseFloat(val('policyIncDays')) || 0,
    max_annual_days: parseFloat(val('policyMax')) || 0,
    carryover_mode: val('policyCarryoverMode'),
    max_carryover_days: parseFloat(val('policyMaxCarryover')) || 0,
    updated_at: new Date().toISOString(),
  };
  try {
    var q = supabaseClient.from('leave_policies').select('id').eq('org_id', currentUser.org_id);
    q = myClinicId ? q.eq('clinic_id', myClinicId) : q.is('clinic_id', null);
    var { data: existing } = await q.maybeSingle();
    var result;
    if (existing) result = await supabaseClient.from('leave_policies').update(payload).eq('id', existing.id);
    else result = await supabaseClient.from('leave_policies').insert(payload);
    if (result.error) throw new Error(result.error.message);
    alert('저장되었습니다.');
  } catch (e) {
    alert('저장 실패: ' + e.message);
  }
}

init();