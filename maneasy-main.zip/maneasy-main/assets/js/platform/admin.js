/**
 * assets/js/platform/admin.js
 * 플랫폼 관리자 전용 — 의원 생성/관리, 초대코드 발급
 */
'use strict';

let currentUser = null;
let orgCache = [];
let selectedOrgId = null;
let editingOrgId = null;

function ts(v) { return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.closeModal = closeModal;

/** 초대코드 랜덤 생성 (사람이 읽기 쉬운 형태: XXXX-XXXX) */
function genInviteCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 혼동되는 문자(0/O, 1/I) 제외
  function part(n) { let s = ''; for (let i = 0; i < n; i++) s += chars[Math.floor(Math.random() * chars.length)]; return s; }
  return part(4) + '-' + part(4);
}

/* ── 의원 목록 ── */
async function loadOrgs() {
  const { data, error } = await supabaseClient
    .from('clinics')
    .select('*, org_members!org_members_org_id_fkey(count)')
    .order('created_at', { ascending: false });
  if (error) { alert('의원 목록 로드 실패: ' + error.message); return; }
  orgCache = data || [];
  renderOrgList();
}

function renderOrgList() {
  const list = document.getElementById('paOrgList');
  if (!orgCache.length) {
    list.innerHTML = '<div class="pa-empty" style="padding:24px;">등록된 의원이 없습니다</div>';
    return;
  }
  list.innerHTML = orgCache.map(o => {
    const memberCount = o.org_members?.[0]?.count ?? 0;
    return `<div class="pa-org-row${o.id === selectedOrgId ? ' is-active' : ''}" data-org="${o.id}">
      <span class="name">${ts(o.org_name)}${!o.is_active ? '<span class="badge-inactive">비활성</span>' : ''}</span>
      <span class="meta">구성원 ${memberCount}명 · ${ts(o.created_at ? localDateStr(new Date(o.created_at)) : '')}</span>
    </div>`;
  }).join('');
  list.querySelectorAll('[data-org]').forEach(row => {
    row.addEventListener('click', () => selectOrg(row.dataset.org));
  });
}

/* ── 상세 ── */
async function selectOrg(orgId) {
  selectedOrgId = orgId;
  renderOrgList();
  const org = orgCache.find(o => o.id === orgId);
  if (!org) return;

  document.getElementById('paDetailTitle').textContent = org.org_name;
  document.getElementById('paDetailActions').style.display = 'flex';

  const toggleBtn = document.getElementById('paToggleActiveBtn');
  if (toggleBtn) {
    toggleBtn.innerHTML = org.is_active
      ? '<i class="ti ti-ban"></i> 정지'
      : '<i class="ti ti-circle-check"></i> 재활성화';
    toggleBtn.classList.toggle('btn-danger', !!org.is_active);
  }

  showGlobalLoading('의원 상세를 불러오는 중...');
  try {
    // 예전엔 organizations(조직)와 clinics(의원)가 분리돼있어서 둘을 따로 조회했는데,
    // 이제 clinics 하나로 합쳐졌으니 orgCache의 org 자체가 이미 그 정보를 다 갖고 있다.
    const [{ data: invites }, { data: members }] = await Promise.all([
      supabaseClient.from('org_invite_codes').select('*').eq('org_id', orgId).order('created_at', { ascending: false }),
      supabaseClient.from('org_members_detail').select('*').eq('org_id', orgId).eq('is_platform_system_account', false).order('role'),
    ]);

    const body = document.getElementById('paDetailBody');
    body.innerHTML = `
      <div class="pa-detail-section">
        <div class="pa-detail-section-title">의원 정보</div>
        <div class="pa-field-row">
          <div class="pa-field"><label>의원명</label><div style="font-size:13px;font-weight:700;">${ts(org.org_name)}</div></div>
          <div class="pa-field"><label>슬러그</label><div style="font-size:13px;">${ts(org.slug || '-')}</div></div>
        </div>
        <div class="pa-field-row">
          <div class="pa-field"><label>브랜드 컬러</label>
            <div style="display:flex;align-items:center;gap:6px;">
              <span style="width:16px;height:16px;border-radius:4px;background:${ts(org.primary_color)};display:inline-block;border:1px solid #e5e7eb;"></span>
              <span style="font-size:12px;">${ts(org.primary_color)}</span>
            </div>
          </div>
          <div class="pa-field"><label>상태</label><div style="font-size:13px;">${org.is_active ? '활성' : '비활성'}</div></div>
        </div>
        <div class="pa-field-row">
          <div class="pa-field"><label>AI 어시스턴트</label><div style="font-size:13px;">${org.feature_flags?.ai_assistant ? '<span style="color:#059669;font-weight:700;">사용 중</span>' : '<span style="color:#9ca3af;">미사용</span>'}</div></div>
          <div class="pa-field"><label>메신저</label><div style="font-size:13px;">${org.feature_flags?.messenger ? '<span style="color:#059669;font-weight:700;">사용 중</span>' : '<span style="color:#9ca3af;">미사용</span>'}</div></div>
        </div>
        <div class="pa-field-row">
          <div class="pa-field"><label>로고</label>
            <div style="width:36px;height:36px;border:1px solid #e5e7eb;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#f8fafc;">
              ${org.logo_url
                ? `<img src="${ts(org.logo_url)}" alt="" style="max-width:100%;max-height:100%;" />`
                : `<i class="ti ti-photo" style="color:#cbd5e1;font-size:16px;"></i>`}
            </div>
          </div>
        </div>
      </div>
      <div class="pa-detail-section">
        <div class="pa-detail-section-title">의원 상세정보 <span style="font-weight:600;color:#9ca3af;text-transform:none;">(플랫폼 관리자만 수정 가능)</span></div>
        <div class="pa-field-row">
          <div class="pa-field"><label>의원명</label><div style="font-size:13px;font-weight:700;">${ts(org.clinic_name)}</div></div>
          <div class="pa-field"><label>코드</label><div style="font-size:13px;">${ts(org.clinic_code)}</div></div>
        </div>
        <div class="pa-field-row">
          <div class="pa-field"><label>사업자번호</label><div style="font-size:13px;">${ts(org.business_no || '-')}</div></div>
          <div class="pa-field"><label>요양기관번호</label><div style="font-size:13px;">${ts(org.care_inst_no || '-')}</div></div>
        </div>
        <div class="pa-field"><label>주소</label><div style="font-size:13px;">${ts(org.address || '-')}</div></div>
      </div>
      <div class="pa-detail-section">
        <div class="pa-detail-section-title" style="display:flex;align-items:center;justify-content:space-between;">
          <span>구성원 (${(members||[]).length}명)</span>
          <button class="btn btn-sm" id="paAddExistingMemberBtn"><i class="ti ti-user-plus"></i> 기존 사용자 추가</button>
        </div>
        <table class="pa-invite-table">
          <thead><tr><th>이름</th><th>이메일</th><th>역할</th><th>상태</th></tr></thead>
          <tbody>
            ${(members||[]).length ? members.map(m => `
              <tr>
                <td>${ts(m.user_name)}</td>
                <td>${ts(m.email)}</td>
                <td>${ts(m.role)}</td>
                <td>${m.active ? '<span style="color:#059669;font-weight:700;">활성</span>' : '<span style="color:#9ca3af;">비활성</span>'}</td>
              </tr>`).join('') : `<tr><td colspan="4" style="text-align:center;color:#9ca3af;padding:16px;">구성원이 없습니다</td></tr>`}
          </tbody>
        </table>
      </div>
      <div class="pa-detail-section" style="border-bottom:none;">
        <div class="pa-detail-section-title">초대코드 (${(invites||[]).length}개)</div>
        <table class="pa-invite-table">
          <thead><tr><th>코드</th><th>역할</th><th>사용</th><th>만료</th><th>상태</th></tr></thead>
          <tbody>
            ${(invites||[]).length ? invites.map(iv => `
              <tr>
                <td><span class="pa-code-chip" data-code="${ts(iv.code)}" title="클릭하여 복사">${ts(iv.code)}</span></td>
                <td>${ts(iv.role)}</td>
                <td>${iv.used_count} / ${iv.max_uses}</td>
                <td>${iv.expires_at ? ts(localDateStr(new Date(iv.expires_at))) : '무제한'}</td>
                <td>${iv.active && iv.used_count < iv.max_uses ? '<span style="color:#059669;font-weight:700;">사용가능</span>' : '<span style="color:#9ca3af;">종료</span>'}</td>
              </tr>`).join('') : `<tr><td colspan="5" style="text-align:center;color:#9ca3af;padding:16px;">발급된 초대코드가 없습니다</td></tr>`}
          </tbody>
        </table>
      </div>`;

    body.querySelectorAll('.pa-code-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        navigator.clipboard?.writeText(chip.dataset.code);
        chip.textContent = '복사됨!';
        setTimeout(() => { chip.textContent = chip.dataset.code; }, 1000);
      });
    });
  } finally {
    hideGlobalLoading();
  }
}

/* ── 새 의원 / 정보 수정 ── */
function setOrgColor(hex) {
  const h = /^#[0-9a-fA-F]{6}$/.test(hex || '') ? hex : '#0a1e3d';
  setVal('paOrgColor', h);
  setVal('paOrgColorPicker', h);
}

// 스와치(컬러피커) 선택 → 텍스트 필드에 즉시 반영
document.getElementById('paOrgColorPicker')?.addEventListener('input', function() {
  setVal('paOrgColor', this.value);
});
// 텍스트로 직접 입력한 값이 올바른 hex면 스와치도 같이 갱신
document.getElementById('paOrgColor')?.addEventListener('input', function() {
  if (/^#[0-9a-fA-F]{6}$/.test(this.value)) setVal('paOrgColorPicker', this.value);
});

/* ── 의원 로고 업로드 ── */
function resetLogoUi() {
  setVal('paOrgLogoUrl', '');
  const img = document.getElementById('paOrgLogoPreview');
  const ph  = document.getElementById('paOrgLogoPlaceholder');
  const removeBtn = document.getElementById('paOrgLogoRemoveBtn');
  const status = document.getElementById('paOrgLogoStatus');
  const fileName = document.getElementById('paOrgLogoFileName');
  if (img) { img.src = ''; img.style.display = 'none'; }
  if (ph) ph.style.display = '';
  if (removeBtn) removeBtn.style.display = 'none';
  if (status) status.textContent = '';
  if (fileName) fileName.textContent = '선택된 파일 없음';
  const fileEl = document.getElementById('paOrgLogoFile');
  if (fileEl) fileEl.value = '';
}

function setLogoUiEnabled(enabled, note) {
  const fileEl = document.getElementById('paOrgLogoFile');
  const fileBtn = document.getElementById('paOrgLogoFileBtn');
  const status = document.getElementById('paOrgLogoStatus');
  if (fileEl) fileEl.disabled = !enabled;
  if (fileBtn) fileBtn.disabled = !enabled;
  if (status && note) status.textContent = note;
}

function showLogoPreview(url) {
  const img = document.getElementById('paOrgLogoPreview');
  const ph  = document.getElementById('paOrgLogoPlaceholder');
  const removeBtn = document.getElementById('paOrgLogoRemoveBtn');
  setVal('paOrgLogoUrl', url);
  if (img) { img.src = url; img.style.display = ''; }
  if (ph) ph.style.display = 'none';
  if (removeBtn) removeBtn.style.display = '';
}

document.getElementById('paOrgLogoFileBtn')?.addEventListener('click', function() {
  document.getElementById('paOrgLogoFile')?.click();
});

document.getElementById('paOrgLogoFile')?.addEventListener('change', async function() {
  const file = this.files?.[0];
  if (!file) return;
  const fileNameEl = document.getElementById('paOrgLogoFileName');
  if (fileNameEl) fileNameEl.textContent = file.name;
  if (!editingOrgId) { alert('의원을 먼저 저장한 뒤 로고를 추가해주세요.'); this.value = ''; return; }
  if (file.size > 2 * 1024 * 1024) { alert('로고 파일은 2MB 이하만 업로드할 수 있습니다.'); this.value = ''; return; }

  const status = document.getElementById('paOrgLogoStatus');
  if (status) status.textContent = '업로드 중...';
  try {
    const ext = (file.name.split('.').pop() || 'png').toLowerCase();
    const path = editingOrgId + '/logo.' + ext;
    const { error: upErr } = await supabaseClient.storage
      .from('org-logos').upload(path, file, { upsert: true, cacheControl: '3600' });
    if (upErr) throw new Error(upErr.message);

    const { data: pub } = supabaseClient.storage.from('org-logos').getPublicUrl(path);
    // 브라우저/CDN 캐시 우회용 쿼리스트링 (같은 파일명으로 덮어써도 바로 새 이미지가 보이도록)
    const freshUrl = pub.publicUrl + '?t=' + Date.now();

    const { error: dbErr } = await supabaseClient.from('clinics')
      .update({ logo_url: freshUrl }).eq('id', editingOrgId);
    if (dbErr) throw new Error(dbErr.message);

    showLogoPreview(freshUrl);
    if (status) status.textContent = '업로드 완료';
    const cachedOrg = orgCache.find(o => o.id === editingOrgId);
    if (cachedOrg) cachedOrg.logo_url = freshUrl;
  } catch (e) {
    if (status) status.textContent = '';
    alert('로고 업로드 실패: ' + e.message);
  } finally {
    this.value = '';
  }
});

document.getElementById('paOrgLogoRemoveBtn')?.addEventListener('click', async function() {
  if (!editingOrgId) return;
  if (!confirm('로고를 제거하시겠습니까?')) return;
  this.disabled = true;
  try {
    // clinics.logo_url은 NOT NULL(기본값 '')이라 null이 아니라 빈 문자열로 초기화해야 함 —
    // 다른 text 컬럼들(photo_url 등)과 동일하게 이 스키마는 "없음"을 ''로 표현하는 컨벤션을 씀.
    const { error } = await supabaseClient.from('clinics').update({ logo_url: '' }).eq('id', editingOrgId);
    if (error) throw new Error(error.message);
    resetLogoUi();
    const cachedOrg = orgCache.find(o => o.id === editingOrgId);
    if (cachedOrg) cachedOrg.logo_url = '';
  } catch (e) {
    alert('제거 실패: ' + e.message);
  } finally {
    this.disabled = false;
  }
});

document.getElementById('paNewOrgBtn')?.addEventListener('click', () => {
  editingOrgId = null;
  document.getElementById('paOrgModalTitle').textContent = '새 의원 만들기';
  setVal('paOrgName', ''); setVal('paOrgSlug', ''); setOrgColor('#0a1e3d');
  setVal('paClinicName', ''); setVal('paClinicBizNo', ''); setVal('paClinicCareNo', ''); setVal('paClinicAddress', '');
  const cs = document.getElementById('paClinicSection'); if (cs) cs.style.display = '';
  // 로고는 의원 id가 있어야 저장 경로(org-logos/<orgId>/...)를 만들 수 있어서,
  // 새 의원 생성 시점엔 업로드를 막고 "먼저 저장 후 다시 편집" 안내만 띄운다.
  resetLogoUi();
  setLogoUiEnabled(false, '의원을 먼저 저장한 뒤, 다시 "정보 수정"에서 로고를 추가할 수 있습니다.');
  openModal('paOrgModal');
});

document.getElementById('paEditOrgBtn')?.addEventListener('click', async () => {
  const org = orgCache.find(o => o.id === selectedOrgId);
  if (!org) return;
  editingOrgId = org.id;
  document.getElementById('paOrgModalTitle').textContent = '의원 정보 수정';
  setVal('paOrgName', org.org_name); setVal('paOrgSlug', org.slug); setOrgColor(org.primary_color);
  resetLogoUi();
  setLogoUiEnabled(true);
  if (org.logo_url) showLogoPreview(org.logo_url);

  const cs = document.getElementById('paClinicSection');
  if (cs) cs.style.display = '';
  setVal('paClinicName', org.clinic_name || '');
  setVal('paClinicBizNo', org.business_no || '');
  setVal('paClinicCareNo', org.care_inst_no || '');
  setVal('paClinicAddress', org.address || '');

  openModal('paOrgModal');
});

document.getElementById('paOrgSaveBtn')?.addEventListener('click', async function() {
  const name = val('paOrgName');
  if (!name) { alert('의원명을 입력해주세요.'); return; }
  if (!val('paClinicName')) { alert('의원명을 입력해주세요.'); return; }

  // organizations(조직)와 clinics(의원)가 분리돼 있던 걸 clinics 하나로 통합했다 —
  // "조직 생성 → 그 아래 의원 생성" 2단계 흐름 자체가 실제로 쓰인 적이 없어서
  // (항상 의원 1개 = 조직 1개로만 함께 생성됐음), 이제 한 번에 한 행만 다룬다.
  const payload = {
    org_name: name,
    slug: val('paOrgSlug') || null,
    primary_color: val('paOrgColor') || '#0a1e3d',
    clinic_name: val('paClinicName'),
    business_no: val('paClinicBizNo'),
    care_inst_no: val('paClinicCareNo'),
    address: val('paClinicAddress'),
  };
  this.disabled = true;
  showGlobalLoading('저장하는 중...');
  try {
    if (editingOrgId) {
      const { error } = await supabaseClient.from('clinics').update(payload).eq('id', editingOrgId);
      if (error) throw new Error(error.message);
    } else {
      payload.created_by = currentUser.id;
      // generate_clinic_code(p_org_id)는 그 의원 전용 채번 시퀀스 키로 org_id가 미리 있어야 하는데,
      // 이제 organizations 없이 clinics 하나만 insert하니 "행을 만들기 전엔 id가 없는" 문제가 생긴다 —
      // 그래서 id를 미리 클라이언트에서 만들어(uuid) 채번 키로 쓰고, insert할 때도 그 id를 그대로 쓴다.
      const newId = crypto.randomUUID();
      const { data: clinicCode, error: codeErr } = await supabaseClient.rpc('generate_clinic_code', { p_org_id: newId });
      if (codeErr) throw new Error('의원 코드 채번 실패: ' + codeErr.message);
      const { data: newClinic, error } = await supabaseClient
        .from('clinics').insert({ id: newId, ...payload, clinic_code: clinicCode }).select().single();
      if (error) throw new Error(error.message);
      selectedOrgId = newClinic.id;

      // 부서가 하나도 없으면 플랫폼 관리자가 "이 의원으로 앱 보기"에 들어가도
      // 발주요청/사용처리 등 "내 부서" 기준 화면이 전부 막혀서 테스트가 불가능해진다.
      // 그래서 최소한의 기본 부서 세트를 자동으로 함께 만들어둔다 (의원 admin이 나중에 수정/추가 가능).
      await seedDefaultDepartments(newClinic.id, newClinic.id);

      // 연차 정책/유형이 하나도 없으면 그 의원 소속 직원은 연차 조회·신청·조정이 전부 막힌다.
      // 공용 기본값에 기대지 않고, 의원 생성 시점에 이 의원 전용 기본값을 바로 심어둔다
      // (관리자가 나중에 마스터 관리 > 연차 전체 관리에서 자유롭게 수정 가능).
      await seedDefaultLeavePolicy(newClinic.id, newClinic.id);
      await seedDefaultLeaveTypes(newClinic.id, newClinic.id);
      await seedDefaultPositions(newClinic.id);
      await seedDefaultItemCategories(newClinic.id);

      // "이 의원으로 앱 보기"(미리보기) 때 실제 소속원처럼 동작할 가상 admin 계정을 미리 만들어둔다.
      // (처음 미리보기 진입 시에도 자동 생성되지만, 의원 생성 시점에 바로 만들어두면 더 확실하다.)
      const { error: acctErr } = await supabaseClient.rpc('ensure_org_admin_account', { p_org_id: newClinic.id });
      if (acctErr) console.warn('[platform/admin] 미리보기 계정 생성 실패(나중에 자동 재시도됨):', acctErr.message);
    }
    closeModal('paOrgModal');
    await loadOrgs();
    if (selectedOrgId) await selectOrg(selectedOrgId);
  } catch (e) {
    alert('저장 실패: ' + e.message);
  } finally {
    this.disabled = false;
    hideGlobalLoading();
  }
});

/** 신규 의원 생성 시 연차 정책 기본값을 심어둔다 — 근로기준법 기준(1년 미만 매월 1일·최대 11일,
 *  1년 이상 15일부터 2년마다 1일 가산·최대 25일, 입사일 기준, 이월 없음)을 그대로 쓰고,
 *  마스터 관리 > 연차 전체 관리 > 정책 설정에서 의원 admin이 자유롭게 수정할 수 있다. */
async function seedDefaultLeavePolicy(orgId, clinicId) {
  const { count } = await supabaseClient.from('leave_policies').select('id', { count: 'exact', head: true }).eq('org_id', orgId).eq('clinic_id', clinicId);
  if (count) return;
  const { error } = await supabaseClient.from('leave_policies').insert({
    org_id: orgId, clinic_id: clinicId, basis: 'HIRE_DATE',
    first_year_monthly_days: 1, first_year_max_days: 11,
    base_annual_days: 15, increment_years: 2, increment_days: 1, max_annual_days: 25,
    carryover_mode: 'NONE', max_carryover_days: 0,
  });
  if (error) console.warn('[seedDefaultLeavePolicy] 연차 정책 기본값 생성 실패:', error.message);
}

/** 신규 의원 생성 시 가장 기본적인 연차 유형 세트를 함께 만들어둔다(연차/오전·오후 반차/무급휴가).
 *  이게 하나도 없으면 전자결재 기안작성의 연차신청 자체가 막힌다. */
async function seedDefaultLeaveTypes(orgId, clinicId) {
  const { count } = await supabaseClient.from('leave_types').select('id', { count: 'exact', head: true }).eq('org_id', orgId).eq('clinic_id', clinicId);
  if (count) return;
  const defaults = [
    { name: '연차', ratio: 1, order: 1 },
    { name: '오전 반차', ratio: 0.5, order: 2 },
    { name: '오후 반차', ratio: 0.5, order: 3 },
    { name: '무급휴가', ratio: 0, order: 4 },
  ];
  for (const t of defaults) {
    const { error } = await supabaseClient.from('leave_types').insert({
      org_id: orgId, clinic_id: clinicId, name: t.name, deduction_ratio: t.ratio, sort_order: t.order, active: true,
    });
    if (error) console.warn('[seedDefaultLeaveTypes] 연차 유형 생성 실패:', t.name, error.message);
  }
}

/** 신규(또는 백필) 의원에 기본 직책 세트를 만들어둔다 — 직책 자체는 선택값(nullable)이지만
 *  하나도 없으면 구성원 등록/수정 화면에서 직책을 아예 고를 수 없어 사실상 기능이 막힌다. */
async function seedDefaultPositions(orgId) {
  const { count } = await supabaseClient.from('positions').select('id', { count: 'exact', head: true }).eq('org_id', orgId);
  if (count) return; // 이미 있으면 건드리지 않음(중복 생성 방지)
  const defaults = [{ name: '원장', order: 1 }, { name: '팀장', order: 2 }, { name: '사원', order: 3 }];
  for (const p of defaults) {
    const { error } = await supabaseClient.from('positions').insert({ org_id: orgId, name: p.name, sort_order: p.order, active: true });
    if (error) console.warn('[seedDefaultPositions] 직책 생성 실패:', p.name, error.message);
  }
}

/** 신규(또는 백필) 의원에 기본 자재 카테고리를 만들어둔다 — items.category가 NOT NULL이라
 *  카테고리가 하나도 없으면 자재 등록 자체가 막힌다(선택값이 아니라 필수값). */
async function seedDefaultItemCategories(orgId) {
  const { count } = await supabaseClient.from('item_categories').select('id', { count: 'exact', head: true }).eq('org_id', orgId);
  if (count) return;
  const defaults = ['소모품', '검사재료', '보호구', '의약품', '사무용품'];
  for (let i = 0; i < defaults.length; i++) {
    const { data: code, error: codeErr } = await supabaseClient.rpc('generate_category_code', { p_org_id: orgId });
    if (codeErr) { console.warn('[seedDefaultItemCategories] 카테고리 코드 채번 실패:', codeErr.message); continue; }
    const { error } = await supabaseClient.from('item_categories').insert({
      org_id: orgId, category_code: code, category_name: defaults[i], sort_order: i + 1, active: 'Y',
    });
    if (error) console.warn('[seedDefaultItemCategories] 카테고리 생성 실패:', defaults[i], error.message);
  }
}

/** 신규 의원 생성 시 최소한의 기본 부서 세트를 만들어둔다 — 부서가 하나도 없으면
 *  플랫폼 관리자의 "이 의원으로 앱 보기"에서 부서 기준 화면(발주요청/사용처리 등)이
 *  전부 막혀 테스트/버그 재현 자체가 불가능해지기 때문. 의원 admin이 나중에 자유롭게
 *  수정/추가/삭제할 수 있으므로 여기서는 최소한의 일반적인 구성만 넣는다. */
async function seedDefaultDepartments(orgId, clinicId) {
  const defaults = [
    { name: '원무팀', group: '행정' },
    { name: '진료팀', group: '진료' },
    { name: '간호팀', group: '진료지원' },
    { name: '약제팀', group: '진료지원' },
    { name: '총무팀', group: '행정' },
  ];
  for (let i = 0; i < defaults.length; i++) {
    const { data: deptCode, error: codeErr } = await supabaseClient.rpc('generate_dept_code', { p_org_id: orgId });
    if (codeErr) { console.warn('[seedDefaultDepartments] 부서코드 채번 실패:', codeErr.message); continue; }
    const { error } = await supabaseClient.from('departments').insert({
      org_id: orgId, clinic_id: clinicId, dept_code: deptCode,
      dept_name: defaults[i].name, team_group_code: defaults[i].group,
      sort_order: i + 1, active: 'Y',
    });
    if (error) console.warn('[seedDefaultDepartments] 부서 생성 실패:', defaults[i].name, error.message);
  }
}

/* ── 초대코드 발급 ── */
document.getElementById('paNewInviteBtn')?.addEventListener('click', () => {
  setVal('paInviteRole', 'user');
  setVal('paInviteMaxUses', '1');
  setVal('paInviteExpires', '');
  openModal('paInviteModal');
});

document.getElementById('paInviteSaveBtn')?.addEventListener('click', async function() {
  if (!selectedOrgId) return;
  this.disabled = true;
  showGlobalLoading('초대코드 발급 중...');
  try {
    // 예전엔 한 조직 아래 의원이 여러 개일 수 있어서 "이 조직의 의원"을 찾아 확인하는
    // 절차가 있었는데, 이제 clinics 자체가 최상위라 selectedOrgId가 곧 그 의원의 id다.
    const payload = {
      org_id: selectedOrgId,
      clinic_id: selectedOrgId,
      code: genInviteCode(),
      role: val('paInviteRole') || 'user',
      max_uses: Number(val('paInviteMaxUses')) || 1,
      expires_at: val('paInviteExpires') ? (val('paInviteExpires') + 'T23:59:59') : null,
      created_by: currentUser.id,
    };
    const { error } = await supabaseClient.from('org_invite_codes').insert(payload);
    if (error) throw new Error(error.message);
    closeModal('paInviteModal');
    await selectOrg(selectedOrgId);
  } catch (e) {
    alert('발급 실패: ' + e.message);
  } finally {
    this.disabled = false;
    hideGlobalLoading();
  }
});

/* ── 기존 사용자를 다른 의원에 추가 (MSO처럼 한 사람이 여러 의원을 오가야 하는 경우) ── */
document.getElementById('paAddMemberSaveBtn')?.addEventListener('click', async function() {
  if (!selectedOrgId) return;
  const email = val('paAddMemberEmail');
  if (!email) { alert('이메일을 입력해 주세요.'); return; }
  this.disabled = true;
  showGlobalLoading('추가하는 중...');
  try {
    // 여기도 마찬가지로 selectedOrgId가 곧 그 의원의 id라, 별도로 "이 조직의 의원" 조회가 필요 없다.
    const { data, error } = await supabaseClient.rpc('admin_add_existing_member', {
      p_org_id: selectedOrgId, p_email: email, p_role: val('paAddMemberRole') || 'user',
      p_clinic_id: selectedOrgId, p_dept_id: null,
    });
    if (error) throw new Error(error.message);
    if (!data || !data.success) throw new Error((data && data.error) || '추가 실패');
    closeModal('paAddMemberModal');
    await selectOrg(selectedOrgId);
  } catch (e) {
    alert('추가 실패: ' + e.message);
  } finally {
    this.disabled = false;
    hideGlobalLoading();
  }
});

/* ── 테스트 데이터 정리 ── */
document.getElementById('paPurgeTestDataBtn')?.addEventListener('click', async function() {
  const org = orgCache.find(o => o.id === selectedOrgId);
  if (!org) return;

  if (!confirm(`[${org.org_name}] 의원의 플랫폼 테스트용 가상 부서로 만든 데이터를 전부 정리하시겠습니까?\n(발주요청/발주/입고/재고/사인물·프로그램 요청/업무일정/장비 — 실제 운영 부서 데이터는 건드리지 않습니다)`)) return;

  this.disabled = true;
  showGlobalLoading('테스트 데이터를 정리하는 중...');
  try {
    const { data, error } = await supabaseClient.rpc('purge_platform_test_data', { p_org_id: org.id });
    if (error) throw new Error(error.message);
    alert(data?.message || '정리했습니다.');
  } catch (e) {
    alert('정리 실패: ' + e.message);
  } finally {
    this.disabled = false;
    hideGlobalLoading();
  }
});

/* ── 의원 정지/재활성화 ── */
document.getElementById('paToggleActiveBtn')?.addEventListener('click', async function() {
  const org = orgCache.find(o => o.id === selectedOrgId);
  if (!org) return;

  const willActivate = !org.is_active;
  const msg = willActivate
    ? `[${org.org_name}] 의원을 다시 활성화하시겠습니까?\n활성화하면 소속 사용자들이 다시 로그인할 수 있습니다.`
    : `[${org.org_name}] 의원을 정지하시겠습니까?\n정지하면 소속 사용자 전원이 로그인할 수 없게 됩니다. (데이터는 삭제되지 않으며 언제든 재활성화 가능합니다)`;
  if (!confirm(msg)) return;

  this.disabled = true;
  showGlobalLoading(willActivate ? '활성화하는 중...' : '정지하는 중...');
  try {
    const { error } = await supabaseClient.from('clinics').update({ is_active: willActivate }).eq('id', org.id);
    if (error) throw new Error(error.message);
    await loadOrgs();
    await selectOrg(org.id);
  } catch (e) {
    alert('처리 실패: ' + e.message);
  } finally {
    this.disabled = false;
    hideGlobalLoading();
  }
});

/* ── AI 어시스턴트 사용여부 ── */
/* ── 기능 설정 (부가/과금 기능) ──────────────────────────────
 * 새 과금 기능이 생기면 이 배열에 한 줄만 추가하면 된다 — HTML이나 별도 버튼을
 * 늘릴 필요 없이 "기능 설정" 모달 목록에 자동으로 나타난다. */
const FEATURE_DEFS = [
  { key: 'ai_assistant', label: 'AI 어시스턴트', desc: '챗봇으로 일정 등록·자재 검색 등을 자연어로 처리' },
  { key: 'approval', label: '전자결재 + 인사관리', desc: '기안/결재함/연차신청, 개인신상정보/연차현황', bundleWith: ['hr'] },
  { key: 'committee', label: '위원회·규정 관리', desc: '위원회/위원/회의록 관리, 규정 조항·버전 관리 및 출력' },
  { key: 'messenger', label: '메신저', desc: '조직원과의 1:1·그룹 채팅, 파일 전송 (Realtime·Storage 사용량 발생)' },
];

document.getElementById('paFeatureSettingsBtn')?.addEventListener('click', function() {
  const org = orgCache.find(o => o.id === selectedOrgId);
  if (!org) return;
  const flags = org.feature_flags || {};

  document.getElementById('paFeatureList').innerHTML = FEATURE_DEFS.map(f => `
    <label style="display:flex;align-items:center;gap:10px;padding:10px 4px;border-bottom:1px solid #f3f4f6;cursor:pointer;">
      <input type="checkbox" data-feature="${f.key}" ${flags[f.key] ? 'checked' : ''} style="width:16px;height:16px;flex-shrink:0;" />
      <span style="flex:1;">
        <div style="font-size:13px;font-weight:700;">${f.label}</div>
        <div style="font-size:11px;color:#9ca3af;">${f.desc}</div>
      </span>
    </label>`).join('');

  openModal('paFeatureModal');
});

document.getElementById('paFeatureSaveBtn')?.addEventListener('click', async function() {
  const org = orgCache.find(o => o.id === selectedOrgId);
  if (!org) return;

  const newFlags = { ...(org.feature_flags || {}) };
  document.querySelectorAll('#paFeatureList input[data-feature]').forEach(cb => {
    newFlags[cb.dataset.feature] = cb.checked;
    const def = FEATURE_DEFS.find(f => f.key === cb.dataset.feature);
    (def?.bundleWith || []).forEach(k => { newFlags[k] = cb.checked; });
  });

  this.disabled = true;
  showGlobalLoading('저장하는 중...');
  try {
    const { error } = await supabaseClient.from('clinics').update({ feature_flags: newFlags }).eq('id', org.id);
    if (error) throw new Error(error.message);
    closeModal('paFeatureModal');
    await loadOrgs();
    await selectOrg(org.id);
  } catch (e) {
    alert('저장 실패: ' + e.message);
  } finally {
    this.disabled = false;
    hideGlobalLoading();
  }
});

/* ── AI 명령어 요청 (검토용) ── */
let aiRequestCache = [];
let _paAiGrid = null;
let _paAiDetailId = null;
const AI_STATUS_LABEL = { NEW: '검토 대기', PLANNED: '구현 예정', IMPLEMENTED: '구현 완료', DISMISSED: '보류/제외' };

function switchPaView(view) {
  document.getElementById('paViewOrgs').style.display = view === 'orgs' ? 'flex' : 'none';
  document.getElementById('paViewAiRequests').style.display = view === 'ai' ? 'flex' : 'none';
  document.getElementById('paViewProgram').style.display = view === 'program' ? 'flex' : 'none';
  document.getElementById('paViewTabOrgs').classList.toggle('is-active', view === 'orgs');
  document.getElementById('paViewTabAi').classList.toggle('is-active', view === 'ai');
  document.getElementById('paViewTabProgram').classList.toggle('is-active', view === 'program');
  if (view === 'ai') loadAiRequests();
  if (view === 'program') loadProgramRequests();
}

async function refreshAiNewBadge() {
  const { count } = await supabaseClient
    .from('ai_unsupported_requests').select('id', { count: 'exact', head: true }).eq('status', 'NEW');
  const badge = document.getElementById('paAiNewBadge');
  if (!badge) return;
  if (count) { badge.textContent = String(count); badge.style.display = ''; }
  else { badge.style.display = 'none'; }
}

function initAiGrid() {
  _paAiGrid = createMgGrid('paAiRequestGrid', [
    { headerName: '의원', field: 'clinic_name', flex: 1, minWidth: 110,
      headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' },
      valueFormatter: function(p) { return p.value || '(의원명 없음)'; } },
    { headerName: '사용자', field: 'user_name', flex: 0.8, minWidth: 90,
      valueFormatter: function(p) { return p.value || '알 수 없음'; } },
    { headerName: '요약', field: 'summary', flex: 1.3, minWidth: 130,
      headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' },
      valueFormatter: function(p) { return p.value || '(요약 없음)'; } },
    { headerName: '요청 메시지', field: 'user_message', flex: 2, minWidth: 160,
      headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '상태', field: 'status', flex: 0.8, minWidth: 90,
      cellRenderer: function(p) {
        var color = { NEW:'#d97706', PLANNED:'#2563eb', IMPLEMENTED:'#059669', DISMISSED:'#6b7280' }[p.value] || '#6b7280';
        return '<span style="color:' + color + ';font-weight:600;">' + (AI_STATUS_LABEL[p.value] || p.value) + '</span>';
      } },
    { headerName: '요청일', field: 'created_at', flex: 0.9, minWidth: 90,
      valueFormatter: function(p) { return p.value ? formatDateTimeKRCompact(p.value) : ''; } },
    { headerName: '', field: '_actions', flex: 0, width: 70, sortable: false,
      cellRenderer: function(p) {
        var btn = document.createElement('button');
        btn.className = 'btn btn-sm'; btn.textContent = '상세';
        btn.addEventListener('click', function() { openAiDetail(p.data.id); });
        return btn;
      } },
  ], [], { noRowsText: '해당하는 요청이 없습니다.' });
}

async function loadAiRequests() {
  const statusFilter = document.getElementById('paAiStatusFilter').value;
  const keyword = document.getElementById('paAiKeyword').value.trim();
  const dateFrom = document.getElementById('paAiDateFrom').value;
  const dateTo = document.getElementById('paAiDateTo').value;
  let q = supabaseClient.from('ai_unsupported_requests').select('*').order('created_at', { ascending: false }).limit(500);
  if (statusFilter) q = q.eq('status', statusFilter);
  if (dateFrom) q = q.gte('created_at', dateFrom + 'T00:00:00');
  if (dateTo) q = q.lte('created_at', dateTo + 'T23:59:59');
  if (keyword) q = q.or(`clinic_name.ilike.%${escapeIlikeKeyword(keyword)}%,user_name.ilike.%${escapeIlikeKeyword(keyword)}%,summary.ilike.%${escapeIlikeKeyword(keyword)}%,user_message.ilike.%${escapeIlikeKeyword(keyword)}%`);
  const { data, error } = await q;
  if (error) { alert('조회 실패: ' + error.message); return; }
  aiRequestCache = data || [];
  if (!_paAiGrid) initAiGrid();
  updateMgGrid(_paAiGrid, aiRequestCache);
  refreshAiNewBadge();
}

function openAiDetail(id) {
  const r = aiRequestCache.find(x => x.id === id);
  if (!r) return;
  _paAiDetailId = id;
  document.getElementById('paAiDetailBody').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 16px;">
      ${field('의원', ts(r.clinic_name))}
      ${field('사용자', ts(r.user_name))}
      ${field('요청일', ts(formatDateTimeKRCompact(r.created_at)))}
    </div>
    ${field('요약', ts(r.summary))}
    ${field('요청 메시지', ts(r.user_message))}
    <div class="m-field">
      <label>상태</label>
      <select id="paAiDetailStatus" class="input">
        ${Object.keys(AI_STATUS_LABEL).map(k => `<option value="${k}"${k === r.status ? ' selected' : ''}>${AI_STATUS_LABEL[k]}</option>`).join('')}
      </select>
    </div>
    <div class="m-field">
      <label>메모</label>
      <textarea id="paAiDetailNote" class="input textarea" rows="2" placeholder="예: 다음 배포에 반영 예정">${ts(r.admin_note || '')}</textarea>
    </div>
  `;
  openModal('paAiDetailModal');
}

async function saveAiDetail() {
  if (!_paAiDetailId) return;
  const btn = document.getElementById('paAiSaveBtn');
  btn.disabled = true;
  const status = document.getElementById('paAiDetailStatus').value;
  const note = document.getElementById('paAiDetailNote').value;
  const patch = { status: status, admin_note: note || null };
  if (status === 'IMPLEMENTED' || status === 'DISMISSED') patch.resolved_at = new Date().toISOString();
  const { error } = await supabaseClient.from('ai_unsupported_requests').update(patch).eq('id', _paAiDetailId);
  btn.disabled = false;
  if (error) { alert('저장 실패: ' + error.message); return; }
  closeModal('paAiDetailModal');
  await loadAiRequests();
}

async function deleteAiDetail() {
  if (!_paAiDetailId) return;
  if (!confirm('이 요청을 목록에서 삭제하시겠습니까?')) return;
  const { error } = await supabaseClient.from('ai_unsupported_requests').delete().eq('id', _paAiDetailId);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  closeModal('paAiDetailModal');
  await loadAiRequests();
}

let programRequestCache = [];
let _paProgramGrid = null;
let _paProgramDetailId = null;
const PR_STATUS_LABEL = { REQUESTED:'접수', PROCESSING:'진행중', COMPLETED:'완료', REJECTED:'반려', CANCELLED:'취소' };
const PR_TYPE_LABEL = { FEATURE:'신규개발요청', BUGFIX:'오류수정요청' };

async function refreshProgramNewBadge() {
  const { count } = await supabaseClient
    .from('program_requests').select('id', { count: 'exact', head: true }).eq('status', 'REQUESTED');
  const badge = document.getElementById('paProgramNewBadge');
  if (!badge) return;
  if (count) { badge.textContent = String(count); badge.style.display = ''; }
  else { badge.style.display = 'none'; }
}

function initProgramGrid() {
  _paProgramGrid = createMgGrid('paProgramRequestGrid', [
    { headerName: '요청번호', field: 'request_no', flex: 1, minWidth: 130,
      headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '의원', field: '_orgLabel', flex: 1.2, minWidth: 120,
      headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '신청자', field: 'requester_name', flex: 0.8, minWidth: 90 },
    { headerName: '유형', field: 'request_type', flex: 0.8, minWidth: 100,
      cellRenderer: function(p) { return PR_TYPE_LABEL[p.value] || p.value; } },
    { headerName: '제목', field: 'request_title', flex: 2, minWidth: 150,
      headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '상태', field: 'status', flex: 0.8, minWidth: 80,
      cellRenderer: function(p) {
        var color = { REQUESTED:'#d97706', PROCESSING:'#2563eb', COMPLETED:'#059669', REJECTED:'#dc2626', CANCELLED:'#6b7280' }[p.value] || '#6b7280';
        return '<span style="color:' + color + ';font-weight:600;">' + (PR_STATUS_LABEL[p.value] || p.value) + '</span>';
      } },
    { headerName: '신청일', field: 'created_at', flex: 0.9, minWidth: 90,
      valueFormatter: function(p) { return p.value ? formatDateTimeKRCompact(p.value) : ''; } },
    { headerName: '', field: '_actions', flex: 0, width: 70, sortable: false,
      cellRenderer: function(p) {
        var btn = document.createElement('button');
        btn.className = 'btn btn-sm'; btn.textContent = '상세';
        btn.addEventListener('click', function() { openProgramDetail(p.data.id); });
        return btn;
      } },
  ], [], { noRowsText: '해당하는 요청이 없습니다.' });
}

async function loadProgramRequests() {
  const statusFilter = document.getElementById('paProgramStatusFilter').value;
  const keyword = document.getElementById('paProgramKeyword').value.trim();
  const dateFrom = document.getElementById('paProgramDateFrom').value;
  const dateTo = document.getElementById('paProgramDateTo').value;
  let q = supabaseClient.from('program_requests')
    .select('*, clinics!program_requests_org_id_fkey(org_name, clinic_name)')
    .order('created_at', { ascending: false }).limit(500);
  if (statusFilter) q = q.eq('status', statusFilter);
  if (dateFrom) q = q.gte('created_at', dateFrom + 'T00:00:00');
  if (dateTo) q = q.lte('created_at', dateTo + 'T23:59:59');
  if (keyword) q = q.or(`request_no.ilike.%${escapeIlikeKeyword(keyword)}%,requester_name.ilike.%${escapeIlikeKeyword(keyword)}%,request_title.ilike.%${escapeIlikeKeyword(keyword)}%`);
  const { data, error } = await q;
  if (error) { alert('조회 실패: ' + error.message); return; }
  programRequestCache = (data || []).map(r => ({
    ...r,
    _orgLabel: [r.clinics?.org_name, r.clinics?.clinic_name].filter(Boolean).join(' · ') || '(의원명 없음)',
  }));
  if (!_paProgramGrid) initProgramGrid();
  updateMgGrid(_paProgramGrid, programRequestCache);
  refreshProgramNewBadge();
}

function field(label, value) {
  return `<div class="m-field"><label>${label}</label><div style="padding:6px 0;font-size:13px;color:#111827;white-space:pre-wrap;word-break:break-word;">${value || '<span style="color:#c7ccd4;">-</span>'}</div></div>`;
}

function openProgramDetail(id) {
  const r = programRequestCache.find(x => x.id === id);
  if (!r) return;
  _paProgramDetailId = id;
  document.getElementById('paProgramDetailTitle').textContent = r.request_no + ' 상세';
  document.getElementById('paProgramDetailBody').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 16px;">
      ${field('의원', ts(r._orgLabel))}
      ${field('신청자', ts(r.requester_name))}
      ${field('연락처', ts(r.contact))}
      ${field('유형', PR_TYPE_LABEL[r.request_type] || ts(r.request_type))}
      ${field('대상 프로그램/화면', ts(r.target_program))}
      ${field('긴급 여부', r.is_urgent === 'Y' ? '<span style="color:#dc2626;font-weight:700;">긴급</span>' + (r.urgent_reason ? ' — ' + ts(r.urgent_reason) : '') : '아니오')}
    </div>
    ${field('제목', ts(r.request_title))}
    ${field('상세 내용', ts(r.description || r.program_detail))}
    ${field('재현 절차(오류수정요청인 경우)', ts(r.steps_to_reproduce))}
    ${field('기대 효과(신규개발요청인 경우)', ts(r.expected_benefit))}
    <div class="m-field">
      <label>상태</label>
      <select id="paProgramDetailStatus" class="input">
        ${Object.keys(PR_STATUS_LABEL).map(k => `<option value="${k}"${k === r.status ? ' selected' : ''}>${PR_STATUS_LABEL[k]}</option>`).join('')}
      </select>
    </div>
    <div class="m-field">
      <label>답변 <span style="font-weight:600;color:#9ca3af;">— 신청한 의원에게 보입니다</span></label>
      <textarea id="paProgramDetailReply" class="input textarea" rows="3" placeholder="처리 결과나 안내를 남기면 신청자가 볼 수 있어요">${ts(r.admin_reply || '')}</textarea>
    </div>
    <div class="m-field">
      <label>내부 메모 <span style="font-weight:600;color:#9ca3af;">— 신청 의원에는 안 보이는 내부용</span></label>
      <textarea id="paProgramDetailMemo" class="input textarea" rows="2" placeholder="예: 다음 배포에 반영 예정">${ts(r.admin_memo || '')}</textarea>
    </div>
  `;
  openModal('paProgramDetailModal');
}

async function saveProgramDetail() {
  if (!_paProgramDetailId) return;
  const btn = document.getElementById('paProgramSaveBtn');
  btn.disabled = true;
  const status = document.getElementById('paProgramDetailStatus').value;
  const reply = document.getElementById('paProgramDetailReply').value;
  const memo = document.getElementById('paProgramDetailMemo').value;
  const patch = {
    status: status,
    admin_reply: reply || null,
    admin_memo: memo || null,
    processed_by: currentUser?.id || null,
    processed_at: new Date().toISOString(),
  };
  const { error } = await supabaseClient.from('program_requests').update(patch).eq('id', _paProgramDetailId);
  btn.disabled = false;
  if (error) { alert('저장 실패: ' + error.message); return; }
  closeModal('paProgramDetailModal');
  await loadProgramRequests();
}

/* ── 초기화 ── */
async function init() {
  showGlobalLoading('권한을 확인하는 중...');
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (!session) { location.href = 'index.html'; return; }

  const { data: isAdmin } = await supabaseClient.rpc('is_platform_admin');
  if (!isAdmin) {
    hideGlobalLoading();
    document.getElementById('paDenied').style.display = 'flex';
    return;
  }

  currentUser = session.user;
  document.getElementById('paPage').style.display = 'flex';

  // 이벤트 위임: "기존 사용자 추가" 버튼은 selectOrg()가 재렌더링할 때마다 body.innerHTML로
  // 새로 그려지는 요소라, 매번 직접 addEventListener를 다시 붙이는 방식은 그 시점에 다른 코드가
  // 에러를 던지면 조용히 리스너가 안 붙는 문제가 있었다. 컨테이너에 한 번만 위임해두면
  // 재렌더링 횟수와 무관하게 항상 동작한다.
  // "기존 사용자 추가" 모달 — 이메일/이름으로 검색해서 골라 넣기
  (function initAddMemberSearch() {
    const input = document.getElementById('paAddMemberEmail');
    const results = document.getElementById('paAddMemberResults');
    if (!input || !results) return;
    let debounceHandle = null;

    function hideResults() { results.style.display = 'none'; results.innerHTML = ''; }

    input.addEventListener('input', () => {
      clearTimeout(debounceHandle);
      const q = input.value.trim();
      if (q.length < 2) { hideResults(); return; }
      debounceHandle = setTimeout(async () => {
        const { data, error } = await supabaseClient.rpc('admin_search_users', { p_query: q });
        if (error || !data || !data.length) { hideResults(); return; }
        results.innerHTML = data.map(u => `
          <div class="pa-user-search-row" data-email="${ts(u.email)}"
            style="padding:8px 12px;cursor:pointer;border-bottom:1px solid #f6f7f8;">
            <div style="font-size:13px;font-weight:700;color:#111827;">${ts(u.user_name)} <span style="font-weight:400;color:#9ca3af;">${ts(u.email)}</span></div>
            <div style="font-size:11px;color:#9ca3af;">${u.orgs ? '소속: ' + ts(u.orgs) : '소속된 의원 없음'}</div>
          </div>`).join('');
        results.querySelectorAll('.pa-user-search-row').forEach(row => {
          row.addEventListener('mouseenter', () => { row.style.background = '#f8fafc'; });
          row.addEventListener('mouseleave', () => { row.style.background = ''; });
          row.addEventListener('click', () => {
            input.value = row.dataset.email;
            hideResults();
          });
        });
        results.style.display = 'block';
      }, 250);
    });

    document.addEventListener('click', (e) => {
      if (e.target !== input && !results.contains(e.target)) hideResults();
    });
  })();

  document.getElementById('paDetailBody')?.addEventListener('click', (e) => {
    if (!e.target.closest('#paAddExistingMemberBtn')) return;
    if (!selectedOrgId) return;
    setVal('paAddMemberEmail', '');
    setVal('paAddMemberRole', 'user');
    openModal('paAddMemberModal');
  });

  document.getElementById('paGotoAppBtn')?.addEventListener('click', () => {
    if (!selectedOrgId) {
      alert('왼쪽 목록에서 먼저 의원을 선택해 주세요. (플랫폼 관리자는 소속 의원이 없어서, 어떤 의원으로 앱을 볼지 선택해야 합니다)');
      return;
    }
    const org = orgCache.find(o => o.id === selectedOrgId);
    document.getElementById('paImpersonateOrgName').textContent = org ? org.org_name : '';
    document.getElementById('paImpersonateReason').value = '';
    openModal('paImpersonateModal');
  });

  document.getElementById('paImpersonateStartBtn')?.addEventListener('click', async () => {
    const reason = document.getElementById('paImpersonateReason').value.trim();
    if (!reason) { alert('진입 사유를 입력해 주세요.'); return; }
    const btn = document.getElementById('paImpersonateStartBtn');
    btn.disabled = true;
    const record = await auth.startImpersonation(selectedOrgId, reason);
    btn.disabled = false;
    if (!record) { alert('세션 시작에 실패했습니다. 잠시 후 다시 시도해 주세요.'); return; }
    closeModal('paImpersonateModal');
    auth.setCurrentOrgId(selectedOrgId);
    location.href = 'app.html';
  });
  document.getElementById('paLogoutBtn')?.addEventListener('click', () => auth.logout());

  document.getElementById('paViewTabOrgs')?.addEventListener('click', () => switchPaView('orgs'));
  document.getElementById('paViewTabAi')?.addEventListener('click', () => switchPaView('ai'));
  document.getElementById('paAiSearchBtn')?.addEventListener('click', loadAiRequests);
  document.getElementById('paAiStatusFilter')?.addEventListener('change', loadAiRequests);
  document.getElementById('paAiKeyword')?.addEventListener('keydown', e => { if (e.key === 'Enter') loadAiRequests(); });
  document.getElementById('paAiSaveBtn')?.addEventListener('click', saveAiDetail);
  document.getElementById('paAiDeleteBtn')?.addEventListener('click', deleteAiDetail);
  document.getElementById('paViewTabProgram')?.addEventListener('click', () => switchPaView('program'));
  document.getElementById('paProgramSearchBtn')?.addEventListener('click', loadProgramRequests);
  document.getElementById('paProgramStatusFilter')?.addEventListener('change', loadProgramRequests);
  document.getElementById('paProgramKeyword')?.addEventListener('keydown', e => { if (e.key === 'Enter') loadProgramRequests(); });
  document.getElementById('paProgramSaveBtn')?.addEventListener('click', saveProgramDetail);

  // 두 화면 다 기본 조회 기간은 최근 1개월(전체 데이터가 계속 쌓이면 매번 다 불러오는 게
  // 느려지고, 어차피 최근 것부터 보는 경우가 대부분이라). 필요하면 직접 넓혀서 조회하면 된다.
  (function setDefaultDateRange() {
    var today = new Date();
    var monthAgo = new Date(today); monthAgo.setMonth(monthAgo.getMonth() - 1);
    var todayStr = localDateStr(today);
    var fromStr = localDateStr(monthAgo);
    ['paAiDateFrom', 'paProgramDateFrom'].forEach(function(id) { var el = document.getElementById(id); if (el) el.value = fromStr; });
    ['paAiDateTo', 'paProgramDateTo'].forEach(function(id) { var el = document.getElementById(id); if (el) el.value = todayStr; });
  })();
  await loadOrgs();
  await refreshAiNewBadge();
  await refreshProgramNewBadge();
  hideGlobalLoading();
}

document.addEventListener('DOMContentLoaded', init);