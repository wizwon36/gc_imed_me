/**
 * assets/js/contracts/form.js
 * 계약 등록·수정 폼 (기본정보 입력 전용)
 * 저장 테이블: contracts, contract_clinics
 * 저장 성공 시 contracts/detail?id=... (조회 전용 상세화면)로 이동해서
 * 첨부파일 업로드·수의계약 사유서 연결은 그쪽에서 처리한다.
 *
 * [mso_manage → 관리이지 이식 시 조정한 부분]
 *  - user_directory → org_members_detail (org_id로 스코핑), clinics/departments 조회도 전부
 *    org_id(auth.getCurrentOrgId())로 스코핑 — 원본은 단일조직 전제라 이 필터가 없었음.
 *  - currentUser.id(로그인 계정 id) 대신 currentUser.org_member_id(조직원 레코드 id)를 담당자/작성자로 사용.
 *  - created_by/updated_by/uploaded_by/deleted_by/owner_id는 관리이지 스키마에서 org_members(id)
 *    참조(uuid)로 통일했다 — 원본은 text(이메일/이름)였음.
 *  - next_doc_seq RPC가 관리이지에서는 p_org_id를 추가로 받는다.
 *  - PDF/이미지 압축 로직은 원본 그대로 유지 (pdfjs-dist/pdf-lib를 assets/libs/pdfjs/에 새로 추가).
 */
'use strict';

let currentUser = null;

let editingId    = null;
let originalContractSnapshot = null; // 수정 진입 시점의 DB 원본 row — 저장 시 변경 필드 diff 계산용(신규 등록 땐 null)
let hasPeriod    = true;
let isAffiliate  = false;
let autoRenew    = false;
let amountType   = 'TOTAL';
let bidType      = 'SOLE_SOURCE';
let canManage    = false;
let stagedFiles  = [];

let deptsList   = [];  // [{id, dept_code, dept_name, clinic_id}] — 관리이지는 의원 1개=조직 1개라 clinic_name은 항상 currentUser.clinic_name
let vendorsList = [];  // [{id, vendor_code, vendor_name, biz_no, ...}] — 거래처 마스터(사업자번호 기준). 계약의 거래상대방을 여기서 선택한다.
let ctVendorEditingId = null; // 거래처 등록/수정 모달에서 현재 수정 중인 vendor id (null이면 신규)
let usersList   = [];  // [{id, user_name, clinic_name, dept_name}]

function val(id) { const el = document.getElementById(id); return el ? (el.value || '').trim() : ''; }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
function rawAmount() { return val('val-amount').replace(/[^\d]/g, ''); }
function fmtAmountForInput(n) { if (n == null || n === '') return ''; return String(n).replace(/[^\d]/g, '').replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function fmtSize(n) { n = Number(n || 0); if (n < 1024) return n + 'B'; if (n < 1024*1024) return (n/1024).toFixed(1) + 'KB'; return (n/1024/1024).toFixed(1) + 'MB'; }

/* ══════════════════════════════════════════════
   계약 유형(기간형/단건형) 토글
══════════════════════════════════════════════ */
function setHasPeriod(flag) {
  hasPeriod = flag;
  document.querySelectorAll('.ct-toggle-btn.period-type').forEach(el => {
    el.classList.toggle('active', (el.dataset.period === 'Y') === flag);
  });

  const label = document.getElementById('periodFieldLabel');
  const rangeLabel = document.getElementById('periodRangeLabel');
  const hint = document.getElementById('periodFieldHint');
  const firstDateInput = document.getElementById('val-first-date');
  const startInput = document.getElementById('val-start');
  const endInput = document.getElementById('val-end');

  // 최초계약일/계약일 칸은 항상 그대로 두고 라벨만 바꾼다 — 기간형이든 단건형이든 항상 쓰는 값(계약이
  // 실제로 체결된 날짜)이라, 이 칸이 사라지거나 나타나면 옆 계약금액 칸과 짝이 계속 어긋나 보였다.
  label.textContent = flag ? '최초 계약일 *' : '계약일 *';
  firstDateInput.title = flag ? '최초 계약일 — 자동연장돼도 바뀌지 않습니다' : '계약(체결)일';

  // 계약기간(현재)은 단건형일 땐 숨기지 않고 흐리게 비활성화만 한다(레이아웃이 흔들리지 않게).
  rangeLabel.textContent = '계약기간(현재)' + (flag ? ' *' : '');
  hint.textContent = flag ? '현재 갱신 주기의 시작~종료일입니다.' : '단건형은 계약기간을 쓰지 않습니다.';
  startInput.disabled = !flag;
  endInput.disabled = !flag;
  if (!flag) { setVal('val-start', ''); setVal('val-end', ''); }

  // 자동연장도 단건형이면 칸을 숨기지 않고 흐리게 비활성화만 한다.
  document.getElementById('renew-no').classList.toggle('disabled', !flag);
  document.getElementById('renew-yes').classList.toggle('disabled', !flag);
  if (!flag) setAutoRenew(false);
}
window.setHasPeriod = setHasPeriod;

function setAffiliate(affiliate) {
  isAffiliate = affiliate;
  document.getElementById('aff-external').classList.toggle('active', affiliate === false);
  document.getElementById('aff-affiliate').classList.toggle('active', affiliate === true);
}
window.setAffiliate = setAffiliate;

function setAutoRenew(flag) {
  if (!hasPeriod) flag = false; // 단건형에서는 항상 "아니오" 고정
  autoRenew = flag;
  document.getElementById('renew-no').classList.toggle('active', flag === false);
  document.getElementById('renew-yes').classList.toggle('active', flag === true);
  document.getElementById('renewCycleWrap').style.display = flag ? '' : 'none';
}
window.setAutoRenew = setAutoRenew;

let hasWarranty = false;
function setHasWarranty(flag) {
  hasWarranty = flag;
  document.getElementById('warranty-no').classList.toggle('active', flag === false);
  document.getElementById('warranty-yes').classList.toggle('active', flag === true);
  document.getElementById('val-warranty-start').disabled = !flag;
  document.getElementById('val-warranty-end').disabled = !flag;
  if (!flag) { setVal('val-warranty-start', ''); setVal('val-warranty-end', ''); }
}
window.setHasWarranty = setHasWarranty;

function setAmountType(type) {
  amountType = type;
  document.querySelectorAll('.ct-toggle-btn.amount-type').forEach(el => {
    el.classList.toggle('active', el.dataset.amountType === type);
  });
  const label = document.getElementById('amountFieldLabel');
  if (label) label.textContent = (type === 'MONTHLY') ? '월 비용 (VAT+, 원/월)' : '계약금액 (VAT+, 원)';
}
window.setAmountType = setAmountType;

function setBidType(type) {
  bidType = type;
  document.querySelectorAll('.ct-toggle-btn.bid-type').forEach(el => {
    el.classList.toggle('active', el.dataset.bidType === type);
  });
}
window.setBidType = setBidType;

/* ══════════════════════════════════════════════
   마스터 데이터 로드 (의원 / 부서 / 사용자) — 전부 현재 조직(org_id)으로 스코핑
══════════════════════════════════════════════ */
async function loadMasterLists() {
  const orgId = auth.getCurrentOrgId();
  // departments.clinic_id와 departments.org_id 둘 다 clinics를 참조하고 있어서, clinics(...)로
  // 임베드하면 PostgREST가 어느 쪽 FK인지 몰라 에러가 난다(예전엔 에러를 안 잡아서 조용히
  // 빈 목록이 됐었음). 관리이지는 의원 1개=조직 1개라 부서의 "의원명"은 항상
  // currentUser.clinic_name과 같으므로, 애초에 clinics 임베드 자체가 필요 없다.
  const [{ data: depts, error: deptErr }, { data: users, error: userErr }, { data: vendors, error: vendorErr }] = await Promise.all([
    supabaseClient.from('departments').select('id, dept_code, dept_name, clinic_id').eq('org_id', orgId).eq('active', 'Y').order('sort_order'),
    supabaseClient.from('org_members_detail').select('id, user_name, clinic_name, dept_name').eq('org_id', orgId).eq('active', true).eq('is_platform_system_account', false).order('user_name'),
    supabaseClient.from('vendors').select('id, vendor_code, vendor_name, biz_no, ceo_name, phone, email, address, credit_terms, bank_name, account_number, active, is_current, memo').eq('org_id', orgId).eq('active', 'Y').order('vendor_name'),
  ]);
  if (deptErr) throw new Error('부서 목록 로드 실패: ' + deptErr.message);
  if (userErr) throw new Error('담당자 목록 로드 실패: ' + userErr.message);
  if (vendorErr) throw new Error('거래처 목록 로드 실패: ' + vendorErr.message);

  deptsList = (depts || []).map(d => ({ id: d.id, dept_code: d.dept_code, dept_name: d.dept_name, clinic_id: d.clinic_id, clinic_name: currentUser.clinic_name }));
  usersList = users || [];
  vendorsList = vendors || [];

  await loadContractTypes();
}

/* ══════════════════════════════════════════════
   계약구분 관리 (조직별로 자유롭게 추가/수정/삭제/순서변경)
══════════════════════════════════════════════ */
let contractTypesList = [];

async function loadContractTypes() {
  const { data, error } = await supabaseClient.from('contract_types')
    .select('*').eq('org_id', auth.getCurrentOrgId()).order('sort_order');
  if (error) { showMessage('계약구분 목록 로드 실패: ' + error.message, 'error'); return; }
  contractTypesList = data || [];
  renderTypeSelect();
}

function renderTypeSelect() {
  const sel = document.getElementById('val-type');
  const current = sel.value;
  sel.innerHTML = '<option value="">선택 안 함</option>' +
    contractTypesList.map(t => `<option value="${ts(t.name)}">${ts(t.name)}</option>`).join('');
  if (current && contractTypesList.some(t => t.name === current)) sel.value = current;
}

function renderTypeManageList() {
  const wrap = document.getElementById('ctTypeManageList');
  if (!contractTypesList.length) { wrap.innerHTML = '<div style="color:#9ca3af; font-size:12.5px; padding:10px 2px;">등록된 계약구분이 없습니다.</div>'; return; }
  wrap.innerHTML = contractTypesList.map((t, i) => `
    <div style="display:flex; align-items:center; gap:6px; padding:6px 8px; border:1px solid #e5e7eb; border-radius:6px;" data-id="${t.id}">
      <div class="ord-btn-group">
        <button type="button" class="ord-btn" data-action="up" data-id="${t.id}" ${i === 0 ? 'disabled' : ''}><i class="ti ti-chevron-up"></i></button>
        <button type="button" class="ord-btn" data-action="down" data-id="${t.id}" ${i === contractTypesList.length - 1 ? 'disabled' : ''}><i class="ti ti-chevron-down"></i></button>
      </div>
      <input type="text" class="input" data-action="rename" data-id="${t.id}" value="${ts(t.name)}" style="flex:1; height:28px; font-size:12px;" />
      <button type="button" class="tbl-btn" data-action="delete" data-id="${t.id}" style="color:#dc2626; border-color:#fecaca;">삭제</button>
    </div>
  `).join('');

  wrap.querySelectorAll('input[data-action="rename"]').forEach(input => {
    input.addEventListener('change', () => renameContractType(input.dataset.id, input.value.trim()));
  });
  wrap.querySelectorAll('button[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', () => deleteContractType(btn.dataset.id));
  });
  wrap.querySelectorAll('button[data-action="up"]').forEach(btn => {
    btn.addEventListener('click', () => moveContractType(btn.dataset.id, -1));
  });
  wrap.querySelectorAll('button[data-action="down"]').forEach(btn => {
    btn.addEventListener('click', () => moveContractType(btn.dataset.id, 1));
  });
}

async function addContractType() {
  const input = document.getElementById('ctTypeNewInput');
  const name = input.value.trim();
  if (!name) return;
  if (contractTypesList.some(t => t.name === name)) { showMessage('이미 있는 계약구분입니다.', 'warning'); return; }
  const nextOrder = contractTypesList.length ? Math.max(...contractTypesList.map(t => t.sort_order)) + 1 : 1;
  const { error } = await supabaseClient.from('contract_types').insert({ org_id: auth.getCurrentOrgId(), name, sort_order: nextOrder });
  if (error) { showMessage('추가 실패: ' + error.message, 'error'); return; }
  input.value = '';
  await loadContractTypes();
  renderTypeManageList();
}

async function renameContractType(id, newName) {
  const t = contractTypesList.find(x => x.id === id);
  if (!t || !newName || t.name === newName) { renderTypeManageList(); return; }
  const oldName = t.name;
  showGlobalLoading('계약구분 이름 변경 중...');
  try {
    const { error } = await supabaseClient.from('contract_types').update({ name: newName }).eq('id', id);
    if (error) throw new Error(error.message);
    // 이 이름을 쓰고 있던 기존 계약들도 함께 갱신
    await supabaseClient.from('contracts').update({ contract_type: newName })
      .eq('org_id', auth.getCurrentOrgId()).eq('contract_type', oldName);
    await loadContractTypes();
    renderTypeManageList();
    showMessage('이름이 변경되었습니다. 이미 저장된 계약들의 계약구분도 함께 갱신했습니다.', 'success');
  } catch (e) {
    showMessage('이름 변경 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function deleteContractType(id) {
  const t = contractTypesList.find(x => x.id === id);
  if (!t) return;
  if (!confirm('"' + t.name + '" 계약구분을 삭제하시겠습니까?\n이미 저장된 계약의 계약구분 값은 그대로 남습니다(목록에서만 없어짐).')) return;
  const { error } = await supabaseClient.from('contract_types').delete().eq('id', id);
  if (error) { showMessage('삭제 실패: ' + error.message, 'error'); return; }
  await loadContractTypes();
  renderTypeManageList();
}

async function moveContractType(id, dir) {
  const idx = contractTypesList.findIndex(t => t.id === id);
  const swapIdx = idx + dir;
  if (idx < 0 || swapIdx < 0 || swapIdx >= contractTypesList.length) return;
  const a = contractTypesList[idx], b = contractTypesList[swapIdx];
  await Promise.all([
    supabaseClient.from('contract_types').update({ sort_order: b.sort_order }).eq('id', a.id),
    supabaseClient.from('contract_types').update({ sort_order: a.sort_order }).eq('id', b.id),
  ]);
  await loadContractTypes();
  renderTypeManageList();
}

function bindTypeManage() {
  document.getElementById('ctTypeManageBtn').addEventListener('click', () => {
    renderTypeManageList();
    openModal('ctTypeModal');
  });
  document.getElementById('ctTypeAddBtn').addEventListener('click', addContractType);
  document.getElementById('ctTypeNewInput').addEventListener('keydown', e => { if (e.key === 'Enter') addContractType(); });
}

/* ══════════════════════════════════════════════
   담당부서 검색 콤보박스
══════════════════════════════════════════════ */
function findDeptById(id) { return deptsList.find(d => d.id === id); }
function findDeptByCode(code) { return code ? deptsList.find(d => d.dept_code === code) : null; }
function deptLabel(d) { return d.clinic_name + ' · ' + d.dept_name; }

function renderDeptComboList(query) {
  const list = document.getElementById('deptComboList');
  const q = (query || '').trim().toLowerCase();
  const filtered = !q ? deptsList : deptsList.filter(d => d.dept_name.toLowerCase().includes(q) || d.clinic_name.toLowerCase().includes(q));
  if (!filtered.length) {
    list.innerHTML = '<div class="ct-combo-empty">검색 결과가 없습니다.</div>';
  } else {
    list.innerHTML = filtered.slice(0, 50).map(d => `<div class="ct-combo-item" data-id="${d.id}">${ts(deptLabel(d))}</div>`).join('');
    list.querySelectorAll('.ct-combo-item').forEach(item => {
      item.addEventListener('mousedown', e => {
        e.preventDefault();
        const d = findDeptById(item.dataset.id);
        if (!d) return;
        setVal('val-dept', d.id);
        document.getElementById('val-dept-search').value = deptLabel(d);
        list.style.display = 'none';
      });
    });
  }
  list.style.display = 'block';
}

function bindDeptCombo() {
  const input = document.getElementById('val-dept-search');
  input.addEventListener('focus', () => renderDeptComboList(input.value));
  input.addEventListener('input', () => {
    setVal('val-dept', '');
    renderDeptComboList(input.value);
  });
  input.addEventListener('blur', () => {
    setTimeout(() => { document.getElementById('deptComboList').style.display = 'none'; }, 150);
  });
}

function setDept(deptId) {
  const d = findDeptById(deptId);
  setVal('val-dept', d ? d.id : '');
  document.getElementById('val-dept-search').value = d ? deptLabel(d) : '';
}

/* ══════════════════════════════════════════════
   담당자 검색 콤보박스
══════════════════════════════════════════════ */
function findUserById(id) { return usersList.find(u => u.id === id); }
function ownerLabel(u) {
  const ctx = [u.clinic_name, u.dept_name].filter(Boolean).join(' · ');
  return u.user_name + (ctx ? ' (' + ctx + ')' : '');
}

function renderOwnerComboList(query) {
  const list = document.getElementById('ownerComboList');
  const q = (query || '').trim().toLowerCase();
  const filtered = !q ? usersList : usersList.filter(u => u.user_name.toLowerCase().includes(q));
  if (!filtered.length) {
    list.innerHTML = '<div class="ct-combo-empty">검색 결과가 없습니다.</div>';
  } else {
    list.innerHTML = filtered.slice(0, 50).map(u => `<div class="ct-combo-item" data-id="${u.id}">${ts(ownerLabel(u))}</div>`).join('');
    list.querySelectorAll('.ct-combo-item').forEach(item => {
      item.addEventListener('mousedown', e => {
        e.preventDefault();
        const u = findUserById(item.dataset.id);
        if (!u) return;
        setVal('val-owner', u.id);
        document.getElementById('val-owner-search').value = ownerLabel(u);
        list.style.display = 'none';
      });
    });
  }
  list.style.display = 'block';
}

function bindOwnerCombo() {
  const input = document.getElementById('val-owner-search');
  input.addEventListener('focus', () => renderOwnerComboList(input.value));
  input.addEventListener('input', () => {
    setVal('val-owner', '');
    renderOwnerComboList(input.value);
  });
  input.addEventListener('blur', () => {
    setTimeout(() => { document.getElementById('ownerComboList').style.display = 'none'; }, 150);
  });
}

function setOwner(userId) {
  const u = findUserById(userId);
  setVal('val-owner', u ? u.id : '');
  document.getElementById('val-owner-search').value = u ? ownerLabel(u) : '';
}

/* ══════════════════════════════════════════════
   폼 초기화 / 신규
══════════════════════════════════════════════ */
function resetForm() {
  editingId = null;
  originalContractSnapshot = null; // 신규 등록은 비교할 원본이 없음
  document.getElementById('ctNewBtn').style.display = '';
  isAffiliate = false;
  setVal('val-title', ''); setVal('val-type', '');
  setVendor('');
  document.getElementById('ctVendorLegacyNotice').style.display = 'none';
  setVal('val-amount', ''); setVal('val-first-date', ''); setVal('val-start', ''); setVal('val-end', '');
  setVal('val-status', 'ACTIVE'); setVal('val-notes', '');
  document.getElementById('aff-external').classList.add('active');
  document.getElementById('aff-affiliate').classList.remove('active');
  document.getElementById('ctDocNoTag').textContent = '';
  document.getElementById('ctFormTitle').textContent = '계약 등록';

  setHasPeriod(true);
  const myDept = currentUser ? findDeptByCode(currentUser.team_code) : null;
  setDept(myDept ? myDept.id : '');
  setOwner(currentUser ? currentUser.org_member_id : '');
  setAutoRenew(false);
  setVal('val-renew-cycle', '12');
  setHasWarranty(false);
  setVal('val-warranty-start', '');
  setVal('val-warranty-end', '');
  setAmountType('TOTAL');
  setBidType('SOLE_SOURCE');
  updateFileSectionUi();
}

/* ══════════════════════════════════════════════
   저장 페이로드 / 저장
══════════════════════════════════════════════ */
function collectPayload() {
  const ownerUser = findUserById(val('val-owner'));
  const deptOpt = findDeptById(val('val-dept'));
  const vendor = findVendorById(val('val-vendor'));

  const payload = {
    org_id: auth.getCurrentOrgId(),
    vendor_id: vendor ? vendor.id : null,
    counterparty_name: vendor ? vendor.vendor_name : val('val-vendor-search'),
    counterparty_biz_no: vendor ? (vendor.biz_no || null) : null,
    contract_title: val('val-title'),
    contract_type: val('val-type') || null,
    is_affiliate: isAffiliate ? 'Y' : 'N',
    contract_amount: rawAmount() ? Number(rawAmount()) : null,
    amount_type: amountType,
    bid_type: bidType,
    has_period: hasPeriod ? 'Y' : 'N',
    contract_start: hasPeriod ? (val('val-start') || null) : (val('val-first-date') || null),
    contract_end: hasPeriod ? (val('val-end') || null) : null,
    first_contract_date: val('val-first-date') || (hasPeriod ? val('val-start') : null),
    has_warranty: hasWarranty,
    warranty_start: hasWarranty ? (val('val-warranty-start') || null) : null,
    warranty_end: hasWarranty ? (val('val-warranty-end') || null) : null,
    status: val('val-status') || 'ACTIVE',
    dept_id: val('val-dept') || null,
    dept_name: deptOpt ? deptOpt.dept_name : null,
    owner_id: val('val-owner') || null,
    owner_name: ownerUser ? ownerUser.user_name : null,
    notes: val('val-notes') || null,
    updated_by: currentUser.org_member_id,
    // 관리이지는 의원 1개=조직 1개 구조라 "적용 의원" 선택 UI 자체가 없다 — 소속 의원으로 고정.
    clinic_id: auth.getCurrentOrgId(),
    clinic_name: currentUser.clinic_name,
    clinic_names_display: currentUser.clinic_name,
    clinic_scope: 'SINGLE',
    auto_renew: (hasPeriod && autoRenew) ? 'Y' : 'N',
    auto_renew_cycle_months: (hasPeriod && autoRenew) ? Number(val('val-renew-cycle')) : null,
  };

  return payload;
}

async function genDocNo() {
  const year = new Date().getFullYear();
  const { data, error } = await supabaseClient.rpc('next_doc_seq', { p_org_id: auth.getCurrentOrgId(), p_prefix: 'CT', p_year: year });
  if (error || data == null) return 'CT-' + year + '-' + Date.now().toString().slice(-6);
  return 'CT-' + year + '-' + String(data).padStart(6, '0');
}

/* ══════════════════════════════════════════════
   수정 시 필드별 변경 이력을 시스템 로그에 상세 기록
   (mso_manage 계약관리에서 이식한 패턴) — 수정 진입 시점 원본을
   originalContractSnapshot에 스냅샷해두고, 저장 직전 payload와 비교해
   "무엇이 어떤 값에서 어떤 값으로" 바뀌었는지 로그 description/meta에 남긴다.
══════════════════════════════════════════════ */
const CT_FIELD_LABELS = {
  counterparty_name: '거래상대방',
  contract_title: '계약 건명',
  contract_type: '계약구분',
  is_affiliate: '내부거래 여부',
  contract_amount: '계약금액',
  amount_type: '금액 유형',
  bid_type: '입찰방식',
  has_period: '계약유형',
  contract_start: '계약기간 시작일',
  contract_end: '계약기간 종료일',
  first_contract_date: '최초 계약일',
  has_warranty: '유지보수기간 여부',
  warranty_start: '유지보수 시작일',
  warranty_end: '유지보수 종료일',
  status: '상태',
  dept_name: '담당부서',
  owner_name: '담당자',
  notes: '비고',
  auto_renew: '자동연장 여부',
  auto_renew_cycle_months: '자동연장 주기(개월)',
};

function ctFieldDisplayValue(field, v) {
  if (v === null || v === undefined || v === '') return '(없음)';
  switch (field) {
    case 'is_affiliate':  return v === 'Y' ? '내부거래' : '외부거래';
    case 'amount_type':   return v === 'MONTHLY' ? '월 단위' : '총액';
    case 'bid_type':      return v === 'COMPETITIVE' ? '경쟁입찰' : '수의계약';
    case 'has_period':    return v === 'Y' ? '기간형' : '단건형';
    case 'has_warranty':  return (v === true || v === 'true') ? '있음' : '없음'; // 관리이지는 boolean 컬럼
    case 'auto_renew':    return v === 'Y' ? '자동연장' : '수동';
    case 'status':        return { ACTIVE: '진행중', EXPIRED: '만료', TERMINATED: '해지' }[v] || v;
    case 'contract_amount': { const n = Number(v); return isNaN(n) ? String(v) : n.toLocaleString('ko-KR') + '원'; }
    default: return String(v);
  }
}

// before(원본 row 또는 null) vs after(저장 payload)를 비교해 바뀐 필드만 [{field, label, before, after}]로 반환.
// 타입 혼용(숫자/문자/boolean, null/'') 가능성이 있어 문자열로 정규화한 뒤 비교한다.
function buildContractChangeDiff(before, after) {
  const diffs = [];
  Object.keys(CT_FIELD_LABELS).forEach(field => {
    const bv = before ? (before[field] ?? null) : null;
    const av = (after[field] ?? null);
    const bn = (bv === null || bv === undefined || bv === '') ? null : String(bv);
    const an = (av === null || av === undefined || av === '') ? null : String(av);
    if (bn !== an) {
      diffs.push({ field, label: CT_FIELD_LABELS[field], before: ctFieldDisplayValue(field, bv), after: ctFieldDisplayValue(field, av) });
    }
  });
  return diffs;
}

// 변경 필드 목록을 시스템 로그 description에 넣을 한 줄 요약으로 만든다(너무 길어지지 않게 최대 6개까지만 나열).
function formatContractChangeSummary(diffs) {
  const MAX = 6;
  const shown = diffs.slice(0, MAX).map(d => d.label + ': ' + d.before + ' → ' + d.after);
  if (diffs.length > MAX) shown.push('외 ' + (diffs.length - MAX) + '건');
  return shown.join(', ');
}

/* ══════════════════════════════════════════════
   거래상대방(거래처) 검색 콤보박스 — 담당부서/담당자와 동일한 패턴.
   자유텍스트 대신 vendors(사업자번호 기준) 마스터에서 골라서 선택한다.
   목록에 없으면 "+" 버튼으로 그 자리에서 등록해서 바로 선택할 수 있다.
   (mso_manage 이식 시 조정: generate_vendor_code RPC는 org_id를 받는 버전이라 그것만 맞췄다.)
══════════════════════════════════════════════ */
function findVendorById(id) { return vendorsList.find(v => v.id === id); }
function vendorLabel(v) {
  return v.vendor_name + (v.biz_no ? ' (' + v.biz_no + ')' : '') + (v.is_current !== 'Y' ? ' / 구 상호' : '');
}

function renderVendorComboList(query) {
  const list = document.getElementById('vendorComboList');
  const q = (query || '').trim().toLowerCase();
  const filtered = !q ? vendorsList : vendorsList.filter(v =>
    v.vendor_name.toLowerCase().includes(q) || (v.biz_no || '').replace(/-/g, '').includes(q.replace(/-/g, ''))
  );
  if (!filtered.length) {
    list.innerHTML = '<div class="ct-combo-empty">검색 결과가 없습니다. "+" 버튼으로 등록해 주세요.</div>';
  } else {
    // 대표 상호(is_current='Y')를 먼저 보여주고, 구 상호명은 그 아래에 참고용으로 노출한다.
    const sorted = filtered.slice().sort((a, b) => (b.is_current === 'Y') - (a.is_current === 'Y'));
    list.innerHTML = sorted.slice(0, 50).map(v => `<div class="ct-combo-item" data-id="${v.id}">${ts(vendorLabel(v))}</div>`).join('');
    // 구 상호명을 선택해도 현재 대표 상호로 자동 전환하지 않는다 — 계약서를 실제로 그 옛날
    // 이름으로 작성한 경우엔 그 이름 그대로 연결해두는 게 맞다(계약서 원문과 일치).
    list.querySelectorAll('.ct-combo-item').forEach(item => {
      item.addEventListener('mousedown', e => {
        e.preventDefault();
        setVendor(item.dataset.id);
        list.style.display = 'none';
      });
    });
  }
  list.style.display = 'block';
}

function bindVendorCombo() {
  const input = document.getElementById('val-vendor-search');
  input.addEventListener('focus', () => renderVendorComboList(input.value));
  input.addEventListener('input', () => {
    setVal('val-vendor', ''); // 직접 입력만 하고 목록에서 다시 선택하기 전까지는 확정된 거래처가 아님
    document.getElementById('ctVendorEditBtn').style.display = 'none';
    document.getElementById('ctVendorBizNoHint').textContent = '';
    renderVendorComboList(input.value);
  });
  input.addEventListener('blur', () => {
    setTimeout(() => { document.getElementById('vendorComboList').style.display = 'none'; }, 150);
  });
  document.getElementById('ctVendorNewBtn').addEventListener('click', () => openCtVendorModal('new'));
  document.getElementById('ctVendorEditBtn').addEventListener('click', () => openCtVendorModal('edit'));
  document.getElementById('ctVendorSaveBtn').addEventListener('click', saveCtVendorQuick);
  bindBizNoAutoDash('cv_biz_no');
}

function setVendor(vendorId) {
  const v = findVendorById(vendorId);
  setVal('val-vendor', v ? v.id : '');
  document.getElementById('val-vendor-search').value = v ? vendorLabel(v) : '';
  document.getElementById('ctVendorEditBtn').style.display = v ? '' : 'none';
  document.getElementById('ctVendorBizNoHint').textContent = v && !v.biz_no ? '⚠ 사업자번호가 등록되지 않은 거래처입니다.' : '';
  if (v) document.getElementById('ctVendorLegacyNotice').style.display = 'none';
}

// 기존 계약 불러오기(수정) 시 거래처 선택 상태를 복원한다.
// - vendor_id가 있고 현재 활성 목록에 있으면 그대로 선택.
// - vendor_id는 있는데 목록엔 없으면(비활성화 등) 그 거래처만 따로 불러와 보여준다.
// - vendor_id 자체가 없으면(거래처 연동 이전에 등록된 계약) 텍스트만 있던 예전 자료이므로,
//   자동으로 아무 거래처나 추측해서 매칭하지 않고 안내문구만 띄워 사용자가 직접 다시 선택하게 한다.
async function applyVendorFromRecord(r) {
  document.getElementById('ctVendorLegacyNotice').style.display = 'none';
  if (r.vendor_id) {
    let v = findVendorById(r.vendor_id);
    if (!v) {
      const { data } = await supabaseClient.from('vendors').select('id, vendor_code, vendor_name, biz_no, ceo_name, phone, email, address, credit_terms, bank_name, account_number, active, is_current, memo').eq('id', r.vendor_id).maybeSingle();
      if (data) { vendorsList = vendorsList.concat([data]); v = data; }
    }
    if (v) { setVendor(v.id); return; }
  }
  // vendor_id가 없거나(레거시) 연결된 거래처를 더 이상 찾을 수 없는 경우
  setVendor('');
  if (r.counterparty_name) {
    document.getElementById('val-vendor-search').value = '';
    const notice = document.getElementById('ctVendorLegacyNotice');
    notice.textContent = `⚠ 예전 방식(텍스트)으로 저장된 거래상대방입니다: "${r.counterparty_name}". 사업자번호 기준으로 다시 연결하려면 위 검색창에서 같은 거래처를 선택하거나, 없으면 "+"로 등록해주세요.`;
    notice.style.display = '';
  }
}

/* ── 거래처 등록/수정 모달 (master/supply.js의 거래처 모달과 같은 vendors 테이블) ── */
function openCtVendorModal(mode) {
  if (mode === 'edit') {
    const v = findVendorById(val('val-vendor'));
    if (!v) return;
    ctVendorEditingId = v.id;
    document.getElementById('ctVendorModalTitle').innerHTML = '<i class="ti ti-building-store"></i> 거래처 수정';
    setVal('cv_vendor_name', v.vendor_name);
    setVal('cv_biz_no', v.biz_no);
    setVal('cv_ceo_name', v.ceo_name);
    setVal('cv_phone', v.phone);
  } else {
    ctVendorEditingId = null;
    document.getElementById('ctVendorModalTitle').innerHTML = '<i class="ti ti-building-store"></i> 거래처 등록';
    // 검색창에 입력해둔 텍스트가 있으면(목록에 없어서 "+"를 누른 경우) 거래처명 초안으로 채워준다
    const draft = document.getElementById('val-vendor-search').value.trim();
    setVal('cv_vendor_name', draft);
    setVal('cv_biz_no', ''); setVal('cv_ceo_name', ''); setVal('cv_phone', '');
  }
  openModal('ctVendorModal');
}
window.openCtVendorModal = openCtVendorModal;

// 사업자번호 입력 중 자동으로 "000-00-00000" 형태로 하이픈을 넣어준다.
function bindBizNoAutoDash(inputId) {
  const el = document.getElementById(inputId);
  if (!el) return;
  el.addEventListener('input', () => {
    const digits = el.value.replace(/[^0-9]/g, '').slice(0, 10);
    let formatted = digits;
    if (digits.length > 5) formatted = digits.slice(0, 3) + '-' + digits.slice(3, 5) + '-' + digits.slice(5);
    else if (digits.length > 3) formatted = digits.slice(0, 3) + '-' + digits.slice(3);
    el.value = formatted;
  });
}

async function saveCtVendorQuick() {
  const vendorName = val('cv_vendor_name');
  if (!vendorName) { showMessage('거래처명을 입력해주세요.', 'warning'); return; }
  const bizNo = val('cv_biz_no');
  if (!bizNo) { showMessage('사업자번호를 입력해주세요.', 'warning'); return; }

  const btn = document.getElementById('ctVendorSaveBtn');
  btn.disabled = true;
  try {
    // 같은 사업자번호를 쓰는 다른 거래처가 이미 있는지 확인 — 검색에서 못 찾고 실수로
    // "+"를 눌러 중복 등록하는 경우, 확인 없이 그냥 저장되면 기존 거래처가 조용히
    // 구 상호(is_current=N)로 밀려나 버린다(아래 대표상호 정리 로직). active와 무관하게
    // 전체를 대상으로 확인하고(비활성/구 상호까지), 수정 중인 자기 자신은 제외한다.
    let dupQuery = supabaseClient.from('vendors').select('id, vendor_name, is_current, active').eq('org_id', auth.getCurrentOrgId()).eq('biz_no', bizNo);
    if (ctVendorEditingId) dupQuery = dupQuery.neq('id', ctVendorEditingId);
    const { data: dupRows } = await dupQuery;
    if (dupRows && dupRows.length) {
      const dup = dupRows.find(v => v.is_current === 'Y') || dupRows[0];
      const proceed = confirm(
        `이미 등록된 사업자번호입니다: "${dup.vendor_name}"(${bizNo}).\n\n` +
        `상호가 바뀐 것이 맞다면 계속 진행해 새 이름을 대표 상호로 등록할 수 있습니다(기존 "${dup.vendor_name}"은(는) 구 상호로 자동 전환됩니다).\n` +
        `사업자번호를 잘못 입력했거나 이미 있는 거래처를 찾는 것이라면 취소하고 검색창에서 다시 선택해주세요.\n\n` +
        `계속 등록하시겠습니까?`
      );
      if (!proceed) { btn.disabled = false; return; }
    }

    const payload = {
      vendor_name: vendorName,
      biz_no: bizNo,
      ceo_name: val('cv_ceo_name'),
      phone: val('cv_phone'),
      updated_at: new Date().toISOString(),
    };

    let vendorId = ctVendorEditingId;
    if (ctVendorEditingId) {
      // 여기 모달엔 없는 필드(주소/여신조건/계좌정보 등)는 원본 값을 그대로 유지한 채 4개 필드만 갱신
      const { error } = await supabaseClient.from('vendors').update(payload).eq('id', ctVendorEditingId);
      if (error) throw new Error(error.message);
      systemLog('VENDOR_UPDATE', '거래처 수정(계약등록 화면) — ' + vendorName, { target_type: 'vendors', target_id: ctVendorEditingId }).catch(() => {});
    } else {
      const { data: codeData } = await supabaseClient.rpc('generate_vendor_code', { p_org_id: auth.getCurrentOrgId() });
      const insertPayload = Object.assign({
        org_id: auth.getCurrentOrgId(),
        vendor_code: codeData || 'VEND-' + Date.now().toString().slice(-6),
        active: 'Y', is_current: 'Y',
      }, payload);
      const { data: inserted, error } = await supabaseClient.from('vendors').insert(insertPayload).select('id').single();
      if (error) throw new Error(error.message);
      vendorId = inserted.id;
      systemLog('VENDOR_CREATE', '거래처 등록(계약등록 화면) — ' + vendorName, { target_type: 'vendors', target_id: vendorId }).catch(() => {});
    }

    // 같은 사업자번호를 쓰는 다른 거래처가 있으면 이 건을 대표 상호명(Y)으로 정리 — master/supply.js와 동일 규칙
    if (payload.biz_no) {
      await supabaseClient.from('vendors').update({ is_current: 'N' }).eq('org_id', auth.getCurrentOrgId()).eq('biz_no', payload.biz_no).neq('id', vendorId);
    }

    await loadMasterLists(); // vendorsList 새로고침
    setVendor(vendorId);
    closeModal('ctVendorModal');
  } catch (e) {
    showMessage(e.message || '거래처 저장 실패', 'error');
  } finally {
    btn.disabled = false;
  }
}
window.saveCtVendorQuick = saveCtVendorQuick;

async function saveContract() {
  if (!val('val-vendor-search').trim()) { showMessage('거래상대방을 입력해주세요.', 'warning'); return; }
  if (!val('val-title'))        { showMessage('계약 건명을 입력해주세요.', 'warning'); return; }
  if (hasPeriod && !val('val-start'))  { showMessage('계약기간 시작일을 입력해주세요.', 'warning'); return; }
  if (!hasPeriod && !val('val-first-date')) { showMessage('계약일을 입력해주세요.', 'warning'); return; }
  if (!val('val-owner'))        { showMessage('담당자를 선택해주세요.', 'warning'); return; }

  const btn = document.getElementById('ctSaveBtn');
  btn.disabled = true;
  showGlobalLoading('저장 중...');
  try {
    const payload = collectPayload();
    const isEdit = !!editingId; // insert 분기에서 contractId가 새로 채워지므로 로그 분기용으로 미리 기억
    const changeDiffs = isEdit ? buildContractChangeDiff(originalContractSnapshot, payload) : [];
    let contractId = editingId;
    if (contractId) {
      const { error } = await supabaseClient.from('contracts').update(payload).eq('id', contractId);
      if (error) throw new Error(error.message);
    } else {
      payload.doc_no = await genDocNo();
      payload.created_by = currentUser.org_member_id;
      const { data, error } = await supabaseClient.from('contracts').insert(payload).select().single();
      if (error) throw new Error(error.message);
      contractId = data.id;

      await flushStagedFiles(contractId);
    }

    try {
      if (isEdit) {
        const desc = changeDiffs.length
          ? '계약 수정: ' + val('val-title') + ' — ' + formatContractChangeSummary(changeDiffs)
          : '계약 저장(변경된 항목 없음): ' + val('val-title');
        await systemLog('CONTRACT_UPDATE', desc, {
          target_type: 'contracts', target_id: contractId,
          meta: { changes: changeDiffs, doc_no: (originalContractSnapshot && originalContractSnapshot.doc_no) || null },
        });
      } else {
        await systemLog('CONTRACT_CREATE', '계약 등록: ' + val('val-title'), { target_type: 'contracts', target_id: contractId });
      }
    } catch (e) {}

    parent.shellNavigate && parent.shellNavigate('contracts/detail?id=' + contractId);
  } catch (e) {
    showMessage(e.message || '저장 실패', 'error');
    btn.disabled = false;
    hideGlobalLoading();
  }
}

async function loadContract(id) {
  showGlobalLoading('불러오는 중...');
  try {
    const { data: r, error } = await supabaseClient.from('contracts').select('*').eq('id', id).single();
    if (error) throw new Error(error.message);
    originalContractSnapshot = r; // 저장 시 변경사항 비교용 원본 스냅샷

    const canEditOthers = window.PagePerms.atLeast(currentUser, 'contracts/form', 'edit');
    const isOwn = (r.owner_id && r.owner_id === currentUser.org_member_id) ||
      (r.created_by && r.created_by === currentUser.org_member_id);
    if (!canEditOthers && !isOwn) {
      alert('본인이 작성한 계약만 수정할 수 있습니다.');
      parent.shellNavigate?.('contracts/detail?id=' + id);
      return;
    }

    editingId = r.id;
    document.getElementById('ctNewBtn').style.display = 'none';
    document.getElementById('ctDocNoTag').textContent = r.doc_no || '';
    document.getElementById('ctFormTitle').textContent = '계약 수정';
    setHasPeriod(r.has_period !== 'N');
    await applyVendorFromRecord(r);
    setVal('val-title', r.contract_title);
    setVal('val-type', r.contract_type);
    setVal('val-amount', fmtAmountForInput(r.contract_amount));
    setAmountType(r.amount_type === 'MONTHLY' ? 'MONTHLY' : 'TOTAL');
    setVal('val-first-date', r.first_contract_date || r.contract_start || '');
    setVal('val-start', r.has_period === 'N' ? '' : r.contract_start);
    setVal('val-end', r.has_period === 'N' ? '' : r.contract_end);
    setVal('val-status', r.status || 'ACTIVE');
    setVal('val-notes', r.notes);
    setDept(r.dept_id || '');
    if (r.dept_id && !findDeptById(r.dept_id)) {
      document.getElementById('val-dept-search').value = r.dept_name || '';
      setVal('val-dept', r.dept_id);
    }
    setOwner(r.owner_id || '');
    if (r.owner_id && !findUserById(r.owner_id)) {
      document.getElementById('val-owner-search').value = r.owner_name || '';
      setVal('val-owner', r.owner_id);
    }
    setAffiliate(r.is_affiliate === 'Y');
    setBidType(r.bid_type === 'COMPETITIVE' ? 'COMPETITIVE' : 'SOLE_SOURCE');
    setAutoRenew(r.auto_renew === 'Y');
    setVal('val-renew-cycle', String(r.auto_renew_cycle_months || 12));
    setHasWarranty(!!r.has_warranty);
    setVal('val-warranty-start', r.warranty_start || '');
    setVal('val-warranty-end', r.warranty_end || '');

    updateFileSectionUi();
    await loadFiles();
  } catch (e) {
    showMessage(e.message || '불러오기 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   첨부파일
══════════════════════════════════════════════ */
function updateFileSectionUi() {
  const drop = document.getElementById('ctFileDrop');
  const topDesc = document.getElementById('ctFormTopDesc');
  if (!drop) return;
  document.getElementById('ctFileDesc').textContent = '';
  if (editingId) {
    if (topDesc) topDesc.textContent = '첨부파일은 아래에서 바로 추가할 수 있습니다. 수의계약 사유서 연결은 상세화면에서 할 수 있습니다.';
  } else {
    if (topDesc) topDesc.textContent = '여기서 첨부한 파일은 저장 시 자동으로 계약에 연결됩니다. 수의계약 사유서 연결은 저장 후 상세화면에서 할 수 있습니다.';
    stagedFiles = [];
    renderStagedFileList();
  }
}

function renderStagedFileList() {
  const wrap = document.getElementById('ctFileList');
  if (!wrap) return;
  if (!stagedFiles.length) { wrap.innerHTML = '<div class="ct-file-empty">첨부할 파일을 선택하세요. 계약을 저장하면 자동으로 첨부됩니다.</div>'; return; }
  wrap.innerHTML = stagedFiles.map(sf => `
    <div class="ct-file-item" data-local-id="${sf.localId}">
      <i class="ti ti-file"></i>
      <span class="name">${ts(sf.file.name)}</span>
      <span class="size">${fmtSize(sf.file.size)}</span>
      <div class="actions">
        <span style="font-size:10.5px; color:#d97706; font-weight:700; white-space:nowrap;">저장 대기중</span>
        <button type="button" class="tbl-btn" data-action="remove-staged" data-local-id="${sf.localId}">제거</button>
      </div>
    </div>
  `).join('');
  wrap.querySelectorAll('button[data-action="remove-staged"]').forEach(btn => {
    btn.addEventListener('click', () => {
      stagedFiles = stagedFiles.filter(sf => sf.localId !== btn.dataset.localId);
      renderStagedFileList();
    });
  });
}

function renderFileList(files) {
  const wrap = document.getElementById('ctFileList');
  if (!files.length) { wrap.innerHTML = '<div class="ct-file-empty">첨부된 파일이 없습니다.</div>'; return; }
  wrap.innerHTML = files.map(f => `
    <div class="ct-file-item" data-id="${f.id}">
      <i class="ti ti-file"></i>
      <span class="name">${ts(f.file_name)}</span>
      <span class="size">${fmtSize(f.file_size)}</span>
      <div class="actions">
        <button type="button" class="tbl-btn" data-action="download" data-path="${ts(f.storage_path)}" data-name="${ts(f.file_name)}">다운로드</button>
        ${canManage || f.uploaded_by === currentUser.org_member_id
          ? `<button type="button" class="tbl-btn" data-action="delete" data-id="${f.id}" data-path="${ts(f.storage_path)}">삭제</button>` : ''}
      </div>
    </div>
  `).join('');

  wrap.querySelectorAll('button[data-action="download"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const url = await db.getSignedUrl('contract-files', btn.dataset.path, 3600);
      if (!url) { showMessage('다운로드 링크 생성에 실패했습니다.', 'error'); return; }
      try {
        const res = await fetch(url);
        const blob = await res.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = btn.dataset.name || 'download';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      } catch (e) {
        showMessage('다운로드 실패: ' + e.message, 'error');
      }
    });
  });
  wrap.querySelectorAll('button[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('파일을 삭제하시겠습니까?')) return;
      showGlobalLoading('삭제 중...');
      try {
        await db.deleteFile('contract-files', btn.dataset.path);
        await supabaseClient.from('contract_files').delete().eq('id', btn.dataset.id);
        await loadFiles();
      } catch (e) {
        showMessage('삭제 실패: ' + e.message, 'error');
      } finally {
        hideGlobalLoading();
      }
    });
  });
}

async function loadFiles() {
  if (!editingId) return;
  const { data, error } = await supabaseClient.from('contract_files').select('*')
    .eq('contract_id', editingId).is('deleted_at', null).order('sort_order');
  if (error) { showMessage('파일 목록 로드 실패: ' + error.message, 'error'); return; }
  renderFileList(data || []);
}

const ALLOWED_FILE_EXT = ['pdf','doc','docx','xls','xlsx','ppt','pptx','hwp','hwpx','jpg','jpeg','png','gif','txt','zip'];

let _pdfWorkerReady = false;
function ensurePdfWorker() {
  if (_pdfWorkerReady || !window.pdfjsLib) return;
  window.pdfjsLib.GlobalWorkerOptions.workerSrc = '../../assets/libs/pdfjs/pdf.worker.min.js';
  _pdfWorkerReady = true;
}

async function compressPdfFile(file, opts) {
  opts = opts || {};
  const scale = opts.scale || 1.35;
  const quality = opts.quality || 0.55;

  if (!window.pdfjsLib || !window.PDFLib) throw new Error('PDF 압축 라이브러리를 불러오지 못했습니다.');
  ensurePdfWorker();

  const arrayBuf = await file.arrayBuffer();
  const pdf = await window.pdfjsLib.getDocument({ data: arrayBuf }).promise;
  const { PDFDocument } = window.PDFLib;
  const newPdf = await PDFDocument.create();

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext('2d');
    await page.render({ canvasContext: ctx, viewport }).promise;

    const jpegDataUrl = canvas.toDataURL('image/jpeg', quality);
    const jpegBytes = await (await fetch(jpegDataUrl)).arrayBuffer();
    const jpegImage = await newPdf.embedJpg(jpegBytes);

    const newPage = newPdf.addPage([canvas.width, canvas.height]);
    newPage.drawImage(jpegImage, { x: 0, y: 0, width: canvas.width, height: canvas.height });

    canvas.width = 0; canvas.height = 0;
  }

  const bytes = await newPdf.save();
  return new File([bytes], file.name, { type: 'application/pdf' });
}

async function compressImageFile(file, opts) {
  opts = opts || {};
  const maxDim = opts.maxDim || 1920;
  const quality = opts.quality || 0.72;

  const bitmap = await createImageBitmap(file);
  let { width, height } = bitmap;
  if (width > maxDim || height > maxDim) {
    const ratio = Math.min(maxDim / width, maxDim / height);
    width = Math.round(width * ratio);
    height = Math.round(height * ratio);
  }

  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0, width, height);
  if (bitmap.close) bitmap.close();

  const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
  canvas.width = 0; canvas.height = 0;
  if (!blob) throw new Error('이미지 압축 결과를 생성하지 못했습니다.');

  const newName = file.name.replace(/\.[a-zA-Z0-9]+$/, '') + '.jpg';
  return new File([blob], newName, { type: 'image/jpeg' });
}

const MAX_SINGLE_FILE = 10 * 1024 * 1024;

async function processFileForUpload(f) {
  const ext = (f.name.split('.').pop() || '').toLowerCase();
  if (!ALLOWED_FILE_EXT.includes(ext)) {
    showMessage('허용되지 않는 파일 형식입니다: ' + f.name + ' (허용: ' + ALLOWED_FILE_EXT.join(', ') + ')', 'warning');
    return null;
  }

  const isCompressible = ext === 'pdf' || ext === 'jpg' || ext === 'jpeg' || ext === 'png';
  if (isCompressible) {
    const _glText = document.getElementById('globalLoadingText');
    try {
      if (_glText) _glText.textContent = (ext === 'pdf' ? 'PDF' : '이미지') + ' 압축 중... (' + f.name + ')';
      const compressed = ext === 'pdf' ? await compressPdfFile(f) : await compressImageFile(f);
      if (compressed.size < f.size) {
        showMessage(f.name + ' 압축 완료: ' + fmtSize(f.size) + ' → ' + fmtSize(compressed.size), 'success');
        f = compressed;
      }
    } catch (e) {
      console.warn('압축 실패, 원본으로 업로드:', e);
      showMessage(f.name + ' 압축에 실패해 원본으로 업로드합니다.', 'warning');
    } finally {
      if (_glText) _glText.textContent = '파일 업로드 중...';
    }
  }

  if (f.size > MAX_SINGLE_FILE) {
    showMessage('파일당 최대 10MB: ' + f.name + ' (현재 ' + fmtSize(f.size) + ')', 'warning');
    return null;
  }
  return f;
}

// 검증·압축이 끝난 File을 스토리지에 올린다. db.uploadFile은 jpg/png를 한 번 더 자체 압축하지만
// (300KB 이상일 때) 이미 위에서 충분히 줄인 뒤라 실질적으로 다시 줄어드는 일은 거의 없다.
async function uploadOneFileToContract(f, contractId) {
  const up = await db.uploadFile('contract-files', f, contractId);
  const { error } = await supabaseClient.from('contract_files').insert({
    contract_id: contractId, file_category: 'ATTACH',
    file_name: up.name, storage_path: up.path, file_size: up.size,
    uploaded_by: currentUser.org_member_id,
  });
  if (error) throw new Error(error.message);
}

async function uploadFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;

  showGlobalLoading(editingId ? '파일 업로드 중...' : '파일 확인 중...');
  try {
    for (let i = 0; i < files.length; i++) {
      const processed = await processFileForUpload(files[i]);
      if (!processed) continue;

      if (editingId) {
        await uploadOneFileToContract(processed, editingId);
      } else {
        stagedFiles.push({
          localId: 'tmp_' + Date.now() + '_' + i + '_' + Math.random().toString(36).slice(2),
          file: processed,
        });
      }
    }
    if (editingId) await loadFiles();
    else renderStagedFileList();
  } catch (e) {
    showMessage('업로드 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function flushStagedFiles(contractId) {
  if (!stagedFiles.length) return;
  showGlobalLoading('첨부파일 업로드 중...');
  const failed = [];
  for (const sf of stagedFiles) {
    try {
      await uploadOneFileToContract(sf.file, contractId);
    } catch (e) {
      failed.push(sf.file.name);
    }
  }
  hideGlobalLoading();
  stagedFiles = [];
  if (failed.length) {
    showMessage('일부 파일 첨부에 실패했습니다(' + failed.join(', ') + '). 상세화면에서 다시 첨부해주세요.', 'warning');
  }
}

function bindFileUpload() {
  const drop = document.getElementById('ctFileDrop');
  const input = document.getElementById('ctFileInput');
  if (!drop || !input) return;
  drop.addEventListener('click', () => input.click());
  input.addEventListener('change', e => { uploadFiles(e.target.files); input.value = ''; });
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.style.borderColor = '#93c5fd'; });
  drop.addEventListener('dragleave', () => { drop.style.borderColor = ''; });
  drop.addEventListener('drop', e => {
    e.preventDefault(); drop.style.borderColor = '';
    uploadFiles(e.dataTransfer.files);
  });
}

/* ══════════════════════════════════════════════
   초기화
══════════════════════════════════════════════ */
async function init() {
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'contracts/form')) {
    alert('이 페이지에 접근할 권한이 없습니다.');
    parent.shellNavigate?.('home/home');
    return;
  }
  canManage = window.PagePerms.atLeast(currentUser, 'contracts/form', 'manager');

  // 날짜 인풋을 연/월/일 3분할 커스텀 컴포넌트로 교체. mountCustomDateInput은 원본 id를
  // 그대로 남겨두고 .value/.disabled만 프록시하므로, val()/setVal() 등 아래 코드는 그대로 쓴다.
  ['val-first-date', 'val-start', 'val-end', 'val-warranty-start', 'val-warranty-end'].forEach(mountCustomDateInput);

  bindVendorCombo();
  bindOwnerCombo();
  bindDeptCombo();
  bindFileUpload();
  bindTypeManage();
  document.getElementById('ctSaveBtn').addEventListener('click', saveContract);
  document.getElementById('ctListBtn').addEventListener('click', () => {
    parent.shellNavigate && parent.shellNavigate('contracts/list');
  });
  document.getElementById('ctNewBtn').addEventListener('click', () => {
    resetForm();
    history.replaceState(null, '', location.pathname + (location.search.includes('shell=1') ? '?shell=1' : ''));
  });

  document.getElementById('val-amount')?.addEventListener('input', function() {
    const raw = this.value.replace(/[^\d]/g, '');
    this.value = raw ? raw.replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '';
  });

  document.getElementById('val-start')?.addEventListener('input', function() {
    if (!editingId && !val('val-first-date')) setVal('val-first-date', this.value);
  });

  showGlobalLoading('정보를 불러오는 중...');
  try {
    await loadMasterLists();
  } catch (e) {
    showMessage('초기화 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }

  resetForm();

  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if (id) {
    await loadContract(id);
  }
}

document.addEventListener('DOMContentLoaded', init);