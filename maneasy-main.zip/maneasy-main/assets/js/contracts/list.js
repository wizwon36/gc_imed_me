/**
 * assets/js/contracts/list.js
 * 계약목록 — 조회 전용 화면. "상세"는 contracts/detail(조회), "수정"은 contracts/form(등록·수정)으로 이동.
 * contracts/list 권한레벨이 manager 이상인 사용자만 '내 담당만' 토글이 노출된다.
 *
 * [mso_manage → 관리이지 이식 시 조정한 부분]
 *  - currentUser.id는 관리이지에서 "로그인 계정 id"라 담당자 비교엔 currentUser.org_member_id를 쓴다.
 *  - created_by/owner_id/deleted_by는 관리이지 스키마에서 org_members(id) 참조(uuid)로 통일했다
 *    (원본은 text로 이메일/이름을 저장했음) — 비교 로직이 그만큼 단순해졌다.
 *  - 관리이지는 의원 1개 = 조직 1개 구조라 "적용 의원" 필터 자체를 뺐다(의미가 없음).
 */
'use strict';

function _localDateStr(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

var ctState = { loading: false, statusFilter: '', affiliateFilter: '', typeFilter: '', scope: 'all' };
var _ctListGrid = null;
var currentUser = null;
var canManage = false;

var STATUS_LABEL = { ACTIVE: '진행중', EXPIRED: '만료', TERMINATED: '해지' };
var STATUS_BADGE = { ACTIVE: 'badge-active-contract', EXPIRED: 'badge-expired', TERMINATED: 'badge-terminated' };

function ts(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function fmtN(n) { return Number(n || 0).toLocaleString('ko-KR'); }
function fmtMoney(n) { return (n == null || n === '') ? '-' : fmtN(n) + '원'; }
function fmtDate(v) { return v ? _localDateStr(new Date(v)) : '-'; }
function badgeStatus(s) { return '<span class="' + (STATUS_BADGE[s] || 'badge-active-contract') + '">' + (STATUS_LABEL[s] || ts(s)) + '</span>'; }
function badgeAffiliate(y) { return y === 'Y' ? '<span class="badge-affiliate">내부거래</span>' : '<span class="badge-external">외부거래</span>'; }
function badgeBidType(v) { return v === 'COMPETITIVE' ? '<span class="badge-bidtype-competitive">경쟁입찰</span>' : '<span class="badge-bidtype-sole">수의계약</span>'; }

function computeCanManage(user) {
  return window.PagePerms ? window.PagePerms.atLeast(user, 'contracts/list', 'manager') : false;
}
function computeCanDelete(user) {
  return window.PagePerms ? window.PagePerms.atLeast(user, 'contracts/form', 'admin') : false;
}
function computeCanEdit(user) {
  return window.PagePerms ? window.PagePerms.canAccess(user, 'contracts/form') : false;
}
function computeCanEditOthers(user) {
  return window.PagePerms ? window.PagePerms.atLeast(user, 'contracts/form', 'edit') : false;
}
var canDelete = false;
var canEdit = false;
var canEditOthers = false;

function openDetail(id) {
  parent.shellNavigate && parent.shellNavigate('contracts/detail?id=' + id);
}
function openForm(id) {
  parent.shellNavigate && parent.shellNavigate('contracts/form' + (id ? ('?id=' + id) : ''));
}

// 계약 삭제 — 완전삭제가 아니라 소프트 삭제(숨김 처리).
async function deleteContract(id, title) {
  if (!confirm('"' + (title || '이 계약') + '"을(를) 삭제하시겠습니까?\n완전히 삭제되지 않고 목록에서만 숨겨지며, 필요시 관리자가 복구할 수 있습니다.')) return;
  showGlobalLoading('삭제 중...');
  try {
    const { error } = await supabaseClient.from('contracts').update({
      deleted_at: new Date().toISOString(),
      deleted_by: currentUser.org_member_id,
    }).eq('id', id);
    if (error) throw new Error(error.message);

    try { await systemLog('CONTRACT_DELETE', '계약 삭제(숨김): ' + (title || id), { target_type: 'contracts', target_id: id }); } catch (e) {}

    return true;
  } catch (e) {
    alert('삭제 실패: ' + e.message);
    return false;
  } finally {
    hideGlobalLoading();
  }
}

function initCtListGrid() {
  var cols = [
    { headerName: '거래상대방', field: 'counterparty_name', width: 150,
      headerClass: 'ag-left-header', cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' },
      valueFormatter: function (p) { return p.value || '-'; }
    },
    { headerName: '구분', field: 'is_affiliate', width: 90, cellRenderer: function (p) { return badgeAffiliate(p.value); } },
    { headerName: '계약형태', field: 'bid_type', width: 100, cellRenderer: function (p) { return badgeBidType(p.value); } },
    { headerName: '계약 건명', field: 'contract_title', flex: 1, minWidth: 180,
      headerClass: 'ag-left-header', cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' },
      valueFormatter: function (p) { return p.value || '-'; }
    },
    { headerName: '담당자', field: 'owner_name', width: 90, valueFormatter: function (p) { return p.value || '-'; } },
    { headerName: '계약구분', field: 'contract_type', width: 100, valueFormatter: function (p) { return p.value || '-'; } },
    { headerName: '부서', field: 'dept_name', width: 110, valueFormatter: function (p) { return p.value || '-'; } },
    { headerName: '계약기간', field: '_period', width: 190 },
    { headerName: '계약금액', field: 'contract_amount', width: 135,
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-end' },
      valueFormatter: function (p) {
        var m = fmtMoney(p.value);
        return (m !== '-' && p.data && p.data.amount_type === 'MONTHLY') ? (m + '/월') : m;
      }
    },
    { headerName: '상태', field: 'status', width: 100, cellRenderer: function (p) {
        var s = document.createElement('span');
        s.innerHTML = badgeStatus(p.value) + (p.data.auto_renew === 'Y' ? ' <span class="badge-auto-renew">자동연장</span>' : '');
        return s;
      } },
    { headerName: '', flex: 0, width: 140, sortable: false,
      cellRenderer: function (p) {
        var wrap = document.createElement('div');
        wrap.style.cssText = 'display:flex; gap:4px; align-items:center;';
        var detailBtn = document.createElement('button');
        detailBtn.className = 'tbl-btn'; detailBtn.textContent = '상세';
        detailBtn.onclick = function (e) { e.stopPropagation(); openDetail(p.data.id); };
        wrap.appendChild(detailBtn);
        // user 레벨은 본인이 작성(created_by)한 계약만 수정 가능, edit 이상은 전체 수정 가능
        var isOwn = (p.data.owner_id && p.data.owner_id === currentUser.org_member_id) ||
          (p.data.created_by && p.data.created_by === currentUser.org_member_id);
        if (canEdit && (canEditOthers || isOwn)) {
          var editBtn = document.createElement('button');
          editBtn.className = 'tbl-btn tbl-btn--primary'; editBtn.textContent = '수정';
          editBtn.onclick = function (e) { e.stopPropagation(); openForm(p.data.id); };
          wrap.appendChild(editBtn);
        }
        if (canDelete) {
          var delBtn = document.createElement('button');
          delBtn.className = 'tbl-btn'; delBtn.textContent = '삭제';
          delBtn.style.color = '#dc2626'; delBtn.style.borderColor = '#fecaca';
          delBtn.onclick = async function (e) {
            e.stopPropagation();
            var ok = await deleteContract(p.data.id, p.data.contract_title);
            if (ok) loadCtList();
          };
          wrap.appendChild(delBtn);
        }
        return wrap;
      }
    },
  ];

  _ctListGrid = createMgGrid('ctGrid', cols, [], {
    fit: true, noRowsText: '조건에 맞는 계약이 없습니다.',
  });
}

// PostgREST 1000행 제한 대응 — range() 반복 조회 루프
async function loadCtList() {
  if (ctState.loading) return;
  ctState.loading = true;
  showGlobalLoading('목록을 불러오는 중...');
  try {
    var keyword = val('ctKeyword');

    function buildQuery() {
      var q = supabaseClient.from('contracts').select('*', { count: 'exact' })
        .eq('org_id', auth.getCurrentOrgId())
        .is('deleted_at', null)
        .order('created_at', { ascending: false });
      if (ctState.scope === 'mine') q = q.eq('owner_id', currentUser.org_member_id);
      if (ctState.statusFilter) q = q.eq('status', ctState.statusFilter);
      if (ctState.affiliateFilter) q = q.eq('is_affiliate', ctState.affiliateFilter);
      if (ctState.typeFilter) q = q.eq('contract_type', ctState.typeFilter);
      if (keyword) {
        q = q.or('contract_title.ilike.%' + escapeIlikeKeyword(keyword) + '%,counterparty_name.ilike.%' + escapeIlikeKeyword(keyword) + '%,doc_no.ilike.%' + escapeIlikeKeyword(keyword) + '%');
      }
      return q;
    }

    var PAGE_SIZE = 1000;
    var all = [];
    var page = 0;
    var total = 0;
    while (true) {
      var from = page * PAGE_SIZE;
      var to = from + PAGE_SIZE - 1;
      var res = await buildQuery().range(from, to);
      if (res.error) throw new Error(res.error.message);
      total = res.count || 0;
      all = all.concat(res.data || []);
      if (!res.data || res.data.length < PAGE_SIZE || all.length >= total) break;
      page++;
    }

    all.forEach(function (r) {
      r._period = r.contract_end
        ? (fmtDate(r.contract_start) + ' ~ ' + fmtDate(r.contract_end))
        : (r.contract_start ? fmtDate(r.contract_start) + (r.has_period === 'N' ? ' (단건)' : '') : '-');
    });

    var label = document.getElementById('ctCountLabel');
    if (label) label.textContent = '총 ' + total + '건';

    updateMgGrid(_ctListGrid, all);
  } catch (e) {
    alert('목록 로드 실패: ' + e.message);
  } finally {
    ctState.loading = false;
    hideGlobalLoading();
  }
}

function initStatusTabs() {
  document.querySelectorAll('#ctStatusTabs .sh-status-tab').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('#ctStatusTabs .sh-status-tab').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      ctState.statusFilter = btn.dataset.status || '';
      loadCtList();
    });
  });
}

async function initTypeFilter() {
  const sel = document.getElementById('ctTypeFilter');
  const { data, error } = await supabaseClient.from('contract_types')
    .select('name').eq('org_id', auth.getCurrentOrgId()).order('sort_order');
  if (error) return;
  sel.innerHTML = '<option value="">계약구분 전체</option>' +
    (data || []).map(t => '<option value="' + ts(t.name) + '">' + ts(t.name) + '</option>').join('');
  sel.addEventListener('change', function () {
    ctState.typeFilter = this.value;
    loadCtList();
  });
}

function initAffiliateToggle() {
  document.querySelectorAll('#ctAffiliateToggle button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('#ctAffiliateToggle button').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      ctState.affiliateFilter = btn.dataset.affiliate || '';
      loadCtList();
    });
  });
}

function initScopeToggle() {
  if (!canManage) return;
  document.getElementById('ctScopeToggle').style.display = '';
  document.querySelectorAll('#ctScopeToggle button').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('#ctScopeToggle button').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      ctState.scope = btn.dataset.scope;
      document.getElementById('ctCardTitle').textContent = ctState.scope === 'mine' ? '내 담당 계약 목록' : '전체 계약 목록';
      loadCtList();
    });
  });
}

async function init() {
  var session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();
  canManage = computeCanManage(currentUser);
  canEdit = computeCanEdit(currentUser);
  canEditOthers = computeCanEditOthers(currentUser);
  canDelete = computeCanDelete(currentUser);

  document.getElementById('ctCardTitle').textContent = canManage ? '전체 계약 목록' : '계약 목록';
  ctState.scope = 'all';

  initStatusTabs();
  initAffiliateToggle();
  initScopeToggle();
  initTypeFilter();
  initCtListGrid();

  document.getElementById('ctSearchBtn')?.addEventListener('click', function () { loadCtList(); });
  document.getElementById('ctKeyword')?.addEventListener('keydown', function (e) { if (e.key === 'Enter') loadCtList(); });
  document.getElementById('ctNewBtn')?.addEventListener('click', function () {
    parent.shellNavigate && parent.shellNavigate('contracts/form');
  });

  await loadCtList();
}

document.addEventListener('DOMContentLoaded', init);
