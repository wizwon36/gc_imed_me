/**
 * assets/js/contracts/detail.js
 * 계약 상세 — 조회 전용. 필드 수정은 contracts/form 페이지에서만 한다.
 * 이 페이지에서 가능한 상호작용: 첨부파일 업로드/다운로드/삭제, 관련 계약 연결/해제.
 *
 * [mso_manage → 관리이지 이식 시 조정한 부분]
 *  - "수의계약 사유서" 연결 기능은 뺐다 — sole_source_justifications 모듈 자체가
 *    관리이지에 없음(README에도 별도 모듈이라 명시돼 있었음).
 *  - "적용의원" 정보 표시도 뺐다 — 관리이지는 의원 1개=조직 1개라 의미 없음(form.js와 동일 결정).
 *  - currentUser.id(로그인 계정 id) 대신 currentUser.org_member_id를 담당자/작성자 비교에 사용.
 *  - created_by/uploaded_by/deleted_by는 org_members(id) 참조(uuid)라 이메일/이름 비교가 필요 없다.
 */
'use strict';

let currentUser = null;
let canEdit = false;
let canEditOthers = false;
let canManage = false;
let canDelete = false;

let contractId = null;
let contractRow = null;

function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function fmtMoney(n) { return (n == null || n === '') ? '-' : Number(n).toLocaleString('ko-KR') + '원'; }
function fmtSize(n) { n = Number(n || 0); if (n < 1024) return n + 'B'; if (n < 1024*1024) return (n/1024).toFixed(1) + 'KB'; return (n/1024/1024).toFixed(1) + 'MB'; }
function fmtDate(v) { if (!v) return '-'; const d = new Date(v); return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); }

const STATUS_LABEL = { ACTIVE:'진행중', EXPIRED:'만료', TERMINATED:'해지' };
const CYCLE_LABEL = { 1:'매월', 3:'분기', 6:'반기', 12:'매년', 24:'2년', 36:'3년', 48:'4년', 60:'5년' };

function renderBasicInfo(r) {
  const isSingle = r.has_period === 'N';
  const period = (r.contract_start ? fmtDate(r.contract_start) : '-') + ' ~ ' + (r.contract_end ? fmtDate(r.contract_end) : '-');
  const affiliateBadge = r.is_affiliate === 'Y'
    ? '<span class="badge-affiliate">내부거래(계열사)</span>' : '<span class="badge-external">외부거래</span>';
  const bidTypeLabel = r.bid_type === 'COMPETITIVE' ? '경쟁입찰' : '수의계약';
  const bidTypeBadge = r.bid_type === 'COMPETITIVE'
    ? '<span class="badge-bidtype-competitive">' + bidTypeLabel + '</span>' : '<span class="badge-bidtype-sole">' + bidTypeLabel + '</span>';
  const autoRenewText = r.auto_renew === 'Y'
    ? '예 · ' + (CYCLE_LABEL[r.auto_renew_cycle_months] || (r.auto_renew_cycle_months + '개월')) + '마다'
    : '아니오';
  const autoRenewBadgeHtml = r.auto_renew === 'Y'
    ? '<span class="badge-auto-renew">예</span> · ' + (CYCLE_LABEL[r.auto_renew_cycle_months] || (r.auto_renew_cycle_months + '개월')) + '마다'
    : '아니오';
  const warrantyText = r.has_warranty
    ? '예 (' + fmtDate(r.warranty_start) + ' ~ ' + fmtDate(r.warranty_end) + ')'
    : '아니오';

  document.getElementById('dtTitle').textContent = r.contract_title || '(계약 건명 없음)';
  document.getElementById('dtSub').innerHTML =
    '<b>' + ts(r.counterparty_name || '-') + '</b>' + (r.counterparty_biz_no ? ' (' + ts(r.counterparty_biz_no) + ')' : '') +
    (r.contract_type ? ' · ' + ts(r.contract_type) : '') +
    (isSingle ? ' · <span style="color:#9ca3af;">단건 계약</span>' : '');

  const isMonthlyAmount = r.amount_type === 'MONTHLY';
  document.getElementById('dtAmountLabel').textContent = isMonthlyAmount ? '월 비용 (VAT+)' : '계약금액 (VAT+)';
  const amountText = fmtMoney(r.contract_amount);
  const amountDisplay = (isMonthlyAmount && amountText !== '-') ? (amountText + '/월') : amountText;
  document.getElementById('dtAmount').textContent = amountDisplay;

  // KPI 카드 4개는 계약유형과 상관없이 항상 그대로 두고(폭이 밑의 3단 본문과 어긋나던
  // 문제의 원인이었음), 단건형일 때는 내용만 그 유형에 맞게 채운다.
  document.getElementById('dtPeriodLabel').textContent = isSingle ? '계약일' : '계약기간(현재)';
  document.getElementById('dtPeriod').textContent = isSingle ? fmtDate(r.contract_start) : period;
  document.getElementById('dtFirstDateLabel').textContent = isSingle ? '유지(하자)보수' : '최초 계약일';
  document.getElementById('dtFirstDate').textContent = isSingle
    ? (r.has_warranty ? (fmtDate(r.warranty_start) + ' ~ ' + fmtDate(r.warranty_end)) : '아니오')
    : fmtDate(r.first_contract_date || r.contract_start);
  document.getElementById('dtAutoRenew').innerHTML = isSingle ? '해당없음' : autoRenewBadgeHtml;

  document.getElementById('dtAffiliate').innerHTML = affiliateBadge + bidTypeBadge;

  // 기본정보 카드 — KPI에 있는 내용을 포함해 전부 한눈에 볼 수 있게 다시 표기
  document.getElementById('dtInfoStatus').textContent = STATUS_LABEL[r.status] || r.status || '-';
  document.getElementById('dtInfoBidType').textContent = bidTypeLabel;
  document.getElementById('dtInfoAmount').textContent = amountDisplay;
  document.getElementById('dtInfoPeriodLabel').textContent = isSingle ? '계약일' : '계약기간';
  document.getElementById('dtInfoPeriod').textContent = isSingle ? fmtDate(r.contract_start) : period;
  document.getElementById('dtDept').textContent = r.dept_name || '-';
  document.getElementById('dtOwner').textContent = r.owner_name || '-';
  document.getElementById('dtWarranty').textContent = warrantyText;
  document.getElementById('dtInfoAutoRenew').textContent = isSingle ? '해당없음(단건 계약)' : autoRenewText;

  document.getElementById('dtNotes').textContent = r.notes || '작성된 비고가 없습니다.';
  document.getElementById('dtNotes').classList.toggle('muted', !r.notes);
}

function renderHeader(r) {
  document.getElementById('ctDocNoTag').textContent = r.doc_no || '';
  const badge = document.getElementById('ctStatusBadge');
  badge.textContent = STATUS_LABEL[r.status] || r.status;
  badge.className = 'status-badge status-' + r.status;
}

function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }

async function loadRelatedContracts() {
  const wrap = document.getElementById('relLinkList');
  const [{ data: asA, error: e1 }, { data: asB, error: e2 }] = await Promise.all([
    supabaseClient.from('contract_relations').select('id, note, related_contract_id').eq('contract_id', contractId),
    supabaseClient.from('contract_relations').select('id, note, contract_id').eq('related_contract_id', contractId),
  ]);
  if (e1 || e2) { wrap.innerHTML = '<div class="ssj-link-empty">목록 로드 실패</div>'; return; }

  const rels = [
    ...(asA || []).map(r => ({ relId: r.id, note: r.note, otherId: r.related_contract_id })),
    ...(asB || []).map(r => ({ relId: r.id, note: r.note, otherId: r.contract_id })),
  ];

  if (!rels.length) {
    wrap.innerHTML = '<div class="ssj-link-empty">연결된 계약이 없습니다.' + (canEdit ? ' "계약 연결" 버튼으로 추가하세요.' : '') + '</div>';
    return;
  }

  const { data: others } = await supabaseClient.from('contracts')
    .select('id, doc_no, counterparty_name, contract_title, status').in('id', rels.map(r => r.otherId));
  const byId = {};
  (others || []).forEach(o => { byId[o.id] = o; });

  wrap.innerHTML = rels.map(r => {
    const c = byId[r.otherId];
    if (!c) return '';
    return `
      <div class="ssj-link-row">
        <div class="rel-link-main" data-contract-id="${c.id}" style="display:flex; align-items:center; gap:10px; cursor:pointer; min-width:0; overflow:hidden;">
          <code style="font-size:11px; flex-shrink:0;">${ts(c.doc_no || '-')}</code>
          <span style="font-size:12px; color:#374151; flex-shrink:0;">${ts(c.counterparty_name || '-')}</span>
          <span style="font-size:12px; color:#0f172a; font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${ts(c.contract_title || '-')}</span>
          ${r.note ? `<span style="font-size:11px; color:#9ca3af; flex-shrink:0;">· ${ts(r.note)}</span>` : ''}
        </div>
        <div style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
          <span class="status-badge status-${ts(c.status)}">${STATUS_LABEL[c.status] || ts(c.status)}</span>
          ${canEdit ? `<button type="button" class="tbl-btn rel-unlink-btn" data-rel-id="${r.relId}">연결 해제</button>` : ''}
        </div>
      </div>`;
  }).join('');

  wrap.querySelectorAll('.rel-link-main').forEach(el => {
    el.addEventListener('click', () => {
      parent.shellNavigate && parent.shellNavigate('contracts/detail?id=' + el.dataset.contractId);
    });
  });
  wrap.querySelectorAll('.rel-unlink-btn').forEach(btn => {
    btn.addEventListener('click', e => { e.stopPropagation(); unlinkRelatedContract(btn.dataset.relId); });
  });
}

async function unlinkRelatedContract(relId) {
  if (!confirm('이 계약과의 연결을 해제하시겠습니까? (양쪽 계약 모두 삭제되지 않습니다)')) return;
  showGlobalLoading('연결 해제 중...');
  try {
    const { error } = await supabaseClient.from('contract_relations').delete().eq('id', relId);
    if (error) throw new Error(error.message);
    await loadRelatedContracts();
    showMessage('연결이 해제되었습니다.', 'success');
  } catch (e) {
    showMessage('연결 해제 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

let _relPickGrid = null;
let _relPickTarget = null;

function initRelPickGrid() {
  const cols = [
    { headerName: '문서번호', field: 'doc_no', width: 150,
      headerClass: 'ag-left-header', cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start' },
      cellRenderer: p => '<code style="font-size:11px;">' + ts(p.value || '-') + '</code>' },
    { headerName: '거래상대방', field: 'counterparty_name', width: 150,
      headerClass: 'ag-left-header', cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start' },
      valueFormatter: p => p.value || '-' },
    { headerName: '계약 건명', field: 'contract_title', flex: 1, minWidth: 160,
      headerClass: 'ag-left-header', cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start' },
      valueFormatter: p => p.value || '-' },
    { headerName: '상태', field: 'status', width: 90, valueFormatter: p => STATUS_LABEL[p.value] || p.value || '-' },
    { headerName: '', width: 80, sortable: false, cellRenderer: p => {
        const btn = document.createElement('button');
        btn.className = 'tbl-btn'; btn.textContent = '연결';
        btn.onclick = e => { e.stopPropagation(); openRelNoteModal(p.data); };
        return btn;
      } },
  ];
  _relPickGrid = createMgGrid('relPickGrid', cols, [], {
    fit: true, noRowsText: '연결 가능한 계약이 없습니다.',
    onRowClick: data => openRelNoteModal(data),
  });
}

async function searchRelPick(keyword) {
  const [{ data: asA }, { data: asB }] = await Promise.all([
    supabaseClient.from('contract_relations').select('related_contract_id').eq('contract_id', contractId),
    supabaseClient.from('contract_relations').select('contract_id').eq('related_contract_id', contractId),
  ]);
  const excludeIds = new Set([contractId, ...(asA || []).map(r => r.related_contract_id), ...(asB || []).map(r => r.contract_id)]);

  let q = supabaseClient.from('contracts').select('id, doc_no, counterparty_name, contract_title, status')
    .eq('org_id', auth.getCurrentOrgId())
    .is('deleted_at', null)
    .order('created_at', { ascending: false }).limit(50);
  if (keyword) q = q.or('contract_title.ilike.%' + escapeIlikeKeyword(keyword) + '%,counterparty_name.ilike.%' + escapeIlikeKeyword(keyword) + '%,doc_no.ilike.%' + escapeIlikeKeyword(keyword) + '%');
  const { data, error } = await q;
  if (error) { showMessage('검색 실패: ' + error.message, 'error'); return; }
  updateMgGrid(_relPickGrid, (data || []).filter(c => !excludeIds.has(c.id)));
}

function openRelNoteModal(row) {
  _relPickTarget = row;
  document.getElementById('relNoteTargetLabel').textContent =
    (row.doc_no || '-') + ' · ' + (row.counterparty_name || '-') + ' · ' + (row.contract_title || '-');
  document.getElementById('relNoteInput').value = '';
  closeModal('relPickModal');
  openModal('relNoteModal');
  setTimeout(() => document.getElementById('relNoteInput').focus(), 50);
}

async function confirmLinkRelatedContract() {
  if (!_relPickTarget) return;
  showGlobalLoading('연결 중...');
  try {
    const { error } = await supabaseClient.from('contract_relations').insert({
      contract_id: contractId, related_contract_id: _relPickTarget.id,
      note: document.getElementById('relNoteInput').value.trim() || null,
      created_by: currentUser.org_member_id,
    });
    if (error) throw new Error(error.message);
    closeModal('relNoteModal');
    await loadRelatedContracts();
    showMessage('연결되었습니다.', 'success');
  } catch (e) {
    showMessage('연결 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

function bindRelPicker() {
  if (!_relPickGrid) initRelPickGrid();
  document.getElementById('relPickBtn').addEventListener('click', () => {
    openModal('relPickModal');
    document.getElementById('relPickSearch').value = '';
    searchRelPick('');
    setTimeout(() => document.getElementById('relPickSearch').focus(), 50);
  });
  let debounceTimer;
  document.getElementById('relPickSearch').addEventListener('input', function() {
    clearTimeout(debounceTimer);
    const kw = this.value;
    debounceTimer = setTimeout(() => searchRelPick(kw), 250);
  });
  document.getElementById('relPickSearch').addEventListener('keydown', e => {
    if (e.key === 'Enter') { clearTimeout(debounceTimer); searchRelPick(e.target.value); }
  });
  document.getElementById('relPickSearchBtn').addEventListener('click', () => {
    searchRelPick(document.getElementById('relPickSearch').value);
  });
  document.getElementById('relNoteConfirmBtn').addEventListener('click', confirmLinkRelatedContract);
}

function renderFileList(files) {
  const wrap = document.getElementById('ctFileList');
  if (!files.length) { wrap.innerHTML = '<div class="ct-file-empty">첨부된 파일이 없습니다.</div>'; return; }
  wrap.innerHTML = files.map(f => `
    <div class="ct-file-item" data-id="${f.id}">
      <i class="ti ti-file"></i>
      <span class="name">${ts(f.file_name)}</span>
      <span class="size">${fmtSize(f.file_size)}</span>
      <div class="actions">
        <button type="button" class="tbl-btn" data-action="download" data-path="${ts(f.storage_path)}" data-name="${ts(f.file_name)}">다운로드</button>
        ${canEdit && (canManage || f.uploaded_by === currentUser.org_member_id)
          ? `<button type="button" class="tbl-btn" data-action="delete" data-id="${f.id}" data-path="${ts(f.storage_path)}">삭제</button>` : ''}
      </div>
    </div>
  `).join('');

  wrap.querySelectorAll('button[data-action="download"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const url = await db.getSignedUrl('contract-files', btn.dataset.path, 3600);
      if (!url) { showMessage('다운로드 링크 생성에 실패했습니다.', 'error'); return; }
      try {
        const res = await fetch(url);
        const blob = await res.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = btn.dataset.name || 'download';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      } catch (e) {
        showMessage('다운로드 실패: ' + e.message, 'error');
      }
    });
  });
  wrap.querySelectorAll('button[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('파일을 삭제하시겠습니까?')) return;
      showGlobalLoading('삭제 중...');
      try {
        await db.deleteFile('contract-files', btn.dataset.path);
        await supabaseClient.from('contract_files').delete().eq('id', btn.dataset.id);
        await loadFiles();
      } catch (e) {
        showMessage('삭제 실패: ' + e.message, 'error');
      } finally {
        hideGlobalLoading();
      }
    });
  });
}

async function loadFiles() {
  document.getElementById('ctFileDesc').textContent = canEdit ? '' : '조회 권한만 있어 업로드/삭제는 할 수 없습니다.';
  document.getElementById('ctFileDrop').style.display = canEdit ? '' : 'none';
  const { data, error } = await supabaseClient.from('contract_files').select('*')
    .eq('contract_id', contractId).is('deleted_at', null).order('sort_order');
  if (error) { showMessage('파일 목록 로드 실패: ' + error.message, 'error'); return; }
  renderFileList(data || []);
}

const ALLOWED_FILE_EXT = ['pdf','doc','docx','xls','xlsx','ppt','pptx','hwp','hwpx','jpg','jpeg','png','gif','txt','zip'];

let _pdfWorkerReady = false;
function ensurePdfWorker() {
  if (_pdfWorkerReady || !window.pdfjsLib) return;
  window.pdfjsLib.GlobalWorkerOptions.workerSrc = '../../assets/libs/pdfjs/pdf.worker.min.js';
  _pdfWorkerReady = true;
}

async function compressPdfFile(file, opts) {
  opts = opts || {};
  const scale = opts.scale || 1.35;
  const quality = opts.quality || 0.55;

  if (!window.pdfjsLib || !window.PDFLib) throw new Error('PDF 압축 라이브러리를 불러오지 못했습니다.');
  ensurePdfWorker();

  const arrayBuf = await file.arrayBuffer();
  const pdf = await window.pdfjsLib.getDocument({ data: arrayBuf }).promise;
  const { PDFDocument } = window.PDFLib;
  const newPdf = await PDFDocument.create();

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext('2d');
    await page.render({ canvasContext: ctx, viewport }).promise;

    const jpegDataUrl = canvas.toDataURL('image/jpeg', quality);
    const jpegBytes = await (await fetch(jpegDataUrl)).arrayBuffer();
    const jpegImage = await newPdf.embedJpg(jpegBytes);

    const newPage = newPdf.addPage([canvas.width, canvas.height]);
    newPage.drawImage(jpegImage, { x: 0, y: 0, width: canvas.width, height: canvas.height });

    canvas.width = 0; canvas.height = 0;
  }

  const bytes = await newPdf.save();
  return new File([bytes], file.name, { type: 'application/pdf' });
}

async function compressImageFile(file, opts) {
  opts = opts || {};
  const maxDim = opts.maxDim || 1920;
  const quality = opts.quality || 0.72;

  const bitmap = await createImageBitmap(file);
  let { width, height } = bitmap;
  if (width > maxDim || height > maxDim) {
    const ratio = Math.min(maxDim / width, maxDim / height);
    width = Math.round(width * ratio);
    height = Math.round(height * ratio);
  }

  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0, width, height);
  if (bitmap.close) bitmap.close();

  const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
  canvas.width = 0; canvas.height = 0;
  if (!blob) throw new Error('이미지 압축 결과를 생성하지 못했습니다.');

  const newName = file.name.replace(/\.[a-zA-Z0-9]+$/, '') + '.jpg';
  return new File([blob], newName, { type: 'image/jpeg' });
}

async function uploadFiles(fileList) {
  if (!canEdit) return;
  const MAX_SINGLE = 10 * 1024 * 1024;
  const files = Array.from(fileList || []);
  if (!files.length) return;

  showGlobalLoading('파일 업로드 중...');
  try {
    for (let i = 0; i < files.length; i++) {
      let f = files[i];
      const ext = (f.name.split('.').pop() || '').toLowerCase();
      if (!ALLOWED_FILE_EXT.includes(ext)) {
        showMessage('허용되지 않는 파일 형식입니다: ' + f.name + ' (허용: ' + ALLOWED_FILE_EXT.join(', ') + ')', 'warning');
        continue;
      }

      const isCompressible = ext === 'pdf' || ext === 'jpg' || ext === 'jpeg' || ext === 'png';
      if (isCompressible) {
        const _glText = document.getElementById('globalLoadingText');
        try {
          if (_glText) _glText.textContent = (ext === 'pdf' ? 'PDF' : '이미지') + ' 압축 중... (' + f.name + ')';
          const compressed = ext === 'pdf' ? await compressPdfFile(f) : await compressImageFile(f);
          if (compressed.size < f.size) {
            showMessage(f.name + ' 압축 완료: ' + fmtSize(f.size) + ' → ' + fmtSize(compressed.size), 'success');
            f = compressed;
          }
        } catch (e) {
          console.warn('압축 실패, 원본으로 업로드:', e);
          showMessage(f.name + ' 압축에 실패해 원본으로 업로드합니다.', 'warning');
        } finally {
          if (_glText) _glText.textContent = '파일 업로드 중...';
        }
      }

      if (f.size > MAX_SINGLE) { showMessage('파일당 최대 10MB: ' + f.name + ' (현재 ' + fmtSize(f.size) + ')', 'warning'); continue; }

      const up = await db.uploadFile('contract-files', f, contractId);
      const { error } = await supabaseClient.from('contract_files').insert({
        contract_id: contractId, file_category: 'ATTACH',
        file_name: up.name, storage_path: up.path, file_size: up.size,
        uploaded_by: currentUser.org_member_id,
      });
      if (error) throw new Error(error.message);
    }
    await loadFiles();
  } catch (e) {
    showMessage('업로드 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

function bindFileUpload() {
  const drop = document.getElementById('ctFileDrop');
  const input = document.getElementById('ctFileInput');
  drop.addEventListener('click', () => input.click());
  input.addEventListener('change', e => { uploadFiles(e.target.files); input.value = ''; });
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.style.borderColor = '#93c5fd'; });
  drop.addEventListener('dragleave', () => { drop.style.borderColor = ''; });
  drop.addEventListener('drop', e => {
    e.preventDefault(); drop.style.borderColor = '';
    uploadFiles(e.dataTransfer.files);
  });
}

async function deleteContract() {
  if (!canDelete) return;
  const title = contractRow?.contract_title || '이 계약';
  if (!confirm('"' + title + '"을(를) 삭제하시겠습니까?\n완전히 삭제되지 않고 목록에서만 숨겨지며, 필요시 복구할 수 있습니다.')) return;

  showGlobalLoading('삭제 중...');
  try {
    const { error } = await supabaseClient.from('contracts').update({
      deleted_at: new Date().toISOString(),
      deleted_by: currentUser.org_member_id,
    }).eq('id', contractId);
    if (error) throw new Error(error.message);

    try { await systemLog('CONTRACT_DELETE', '계약 삭제(숨김): ' + title, { target_type: 'contracts', target_id: contractId }); } catch (e) {}

    alert('계약이 삭제(숨김 처리)되었습니다.');
    parent.shellNavigate?.('contracts/list');
  } catch (e) {
    showMessage('삭제 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function restoreContract() {
  if (!canDelete) return;
  if (!confirm('이 계약을 복구하시겠습니까? 복구하면 다시 목록에 표시됩니다.')) return;
  showGlobalLoading('복구 중...');
  try {
    const { error } = await supabaseClient.from('contracts').update({
      deleted_at: null, deleted_by: null,
    }).eq('id', contractId);
    if (error) throw new Error(error.message);
    try { await systemLog('CONTRACT_RESTORE', '계약 복구: ' + (contractRow?.contract_title || contractId), { target_type: 'contracts', target_id: contractId }); } catch (e) {}
    showMessage('복구되었습니다.', 'success');
    await loadContract();
  } catch (e) {
    showMessage('복구 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function loadContract() {
  showGlobalLoading('불러오는 중...');
  try {
    const { data: r, error } = await supabaseClient.from('contracts').select('*').eq('id', contractId).single();
    if (error) throw new Error(error.message);
    contractRow = r;
    renderHeader(r);
    renderBasicInfo(r);
    renderDeletedBanner(r);

    const isOwn = (r.owner_id && r.owner_id === currentUser.org_member_id) ||
      (r.created_by && r.created_by === currentUser.org_member_id);
    document.getElementById('ctEditBtn').style.display = (canEdit && (canEditOthers || isOwn)) ? '' : 'none';
    await loadFiles();
    await loadRelatedContracts();

    try { await systemLog('CONTRACT_VIEW', '계약 열람: ' + (r.contract_title || r.doc_no || contractId), { target_type: 'contracts', target_id: contractId }); } catch (e) {}
  } catch (e) {
    showMessage(e.message || '불러오기 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

function renderDeletedBanner(r) {
  const el = document.getElementById('ctDeletedBanner');
  if (!el) return;
  if (!r.deleted_at) { el.style.display = 'none'; return; }
  el.style.display = 'flex';
  document.getElementById('ctDeletedInfo').textContent =
    '삭제됨 · ' + fmtDate(r.deleted_at) + (r.deleted_by ? ' · ' + r.deleted_by : '');
}

async function init() {
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'contracts/detail')) {
    alert('이 페이지에 접근할 권한이 없습니다.');
    parent.shellNavigate?.('home/home');
    return;
  }

  contractId = new URLSearchParams(location.search).get('id');
  if (!contractId) {
    alert('잘못된 접근입니다. 계약목록으로 이동합니다.');
    parent.shellNavigate?.('contracts/list');
    return;
  }

  canEdit = window.PagePerms.canAccess(currentUser, 'contracts/form');
  canEditOthers = window.PagePerms.atLeast(currentUser, 'contracts/form', 'edit');
  canManage = window.PagePerms.atLeast(currentUser, 'contracts/form', 'manager');
  canDelete = window.PagePerms.atLeast(currentUser, 'contracts/form', 'admin');

  bindFileUpload();

  document.getElementById('ctListBtn').addEventListener('click', () => {
    parent.shellNavigate && parent.shellNavigate('contracts/list');
  });

  const editBtn = document.getElementById('ctEditBtn');
  editBtn.addEventListener('click', () => {
    parent.shellNavigate && parent.shellNavigate('contracts/form?id=' + contractId);
  });

  const deleteBtn = document.getElementById('ctDeleteBtn');
  if (canDelete) {
    deleteBtn.style.display = '';
    deleteBtn.addEventListener('click', deleteContract);
    document.getElementById('ctRestoreBtn').addEventListener('click', restoreContract);
  }

  if (canEdit) {
    document.getElementById('relPickBtn').style.display = '';
    bindRelPicker();
  }

  await loadContract();
}

document.addEventListener('DOMContentLoaded', init);
