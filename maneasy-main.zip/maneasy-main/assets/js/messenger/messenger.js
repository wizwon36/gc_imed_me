'use strict';

/**
 * assets/js/messenger/messenger.js
 * 메신저 — 대화 목록 / 채팅방 / 새 대화(조직도 선택) / 파일 첨부 / 메시지별 안읽음 표시.
 * 세션·존재하는 파일 규칙은 다른 페이지(notice.js, resource-booking.js)와 동일한 패턴을 따른다.
 */

var currentUser = null;
var myMemberId = null;

var conversations = [];      // [{ id, is_group, name, custom_name, created_at, participants, messages:[], lastMessage, unreadCount, loadedSince, reachedStart, loadingOlder }]
var memberMap = {};          // org_member_id -> { user_name, position_name }
var activeId = null;
var selectedNewIds = [];
var realtimeChannel = null;
var WEEK_MS = 7 * 24 * 60 * 60 * 1000;

function esc(v) { return escapeHtml(v); }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.closeModal = closeModal;

function fmtTime(iso) {
  var d = new Date(iso);
  var today = new Date();
  if (localDateStr(d) === localDateStr(today)) {
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }
  return (d.getMonth() + 1) + '/' + d.getDate();
}

/* 메시지 옆에 붙는 시간 — 날짜는 구분선이 따로 있으니 항상 HH:MM만 */
function fmtHM(iso) {
  var d = new Date(iso);
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

/* 날짜 구분선 텍스트 — 오늘/어제는 상대 표기, 그 외엔 전체 날짜 */
function fmtDateDivider(iso) {
  var d = new Date(iso);
  var today = new Date();
  var yst = new Date(today); yst.setDate(today.getDate() - 1);
  if (localDateStr(d) === localDateStr(today)) return '오늘';
  if (localDateStr(d) === localDateStr(yst)) return '어제';
  var dow = ['일', '월', '화', '수', '목', '금', '토'][d.getDay()];
  return d.getFullYear() + '년 ' + (d.getMonth() + 1) + '월 ' + d.getDate() + '일 (' + dow + ')';
}

function getConv(id) { return conversations.find(function (c) { return c.id === id; }); }

/* ── 대화 표시 이름 ─────────────────────────── */
function displayName(conv) {
  if (conv.custom_name) return conv.custom_name;
  if (conv.is_group) return (conv.name || '그룹 대화') + ' (' + conv.participants.length + ')';
  var other = conv.participants.find(function (p) { return p.id !== myMemberId; });
  return other ? (memberMap[other.id]?.user_name || '(알 수 없음)') : '(알 수 없음)';
}

function initials(name) {
  return String(name || '').slice(0, 2);
}

/* ── 조직 멤버 캐시 로드 (표시 이름 + 새 대화 조직도용) ─────────── */
async function loadMemberMap() {
  var { data, error } = await supabaseClient
    .from('org_members_detail')
    .select('id, user_name, clinic_name, dept_name, position_name, active')
    .eq('org_id', currentUser.org_id)
    .eq('is_platform_system_account', false);
  if (error) { console.error('[messenger] 멤버 조회 실패:', error); return; }
  memberMap = {};
  (data || []).forEach(function (m) { memberMap[m.id] = m; });
}

/* ── 대화 목록 로드 ─────────────────────────────────────────────
 * 마지막 메시지 미리보기와 안읽음 수는 정확도가 중요해서 전체 메시지 기준으로
 * 계산한다 (1주일 페이징은 채팅방을 열었을 때 본문 로딩에만 적용). */
async function loadConversations() {
  var { data: mine, error } = await supabaseClient
    .from('conversation_participants')
    .select('conversation_id, custom_name, last_read_at, conversations(id, is_group, name, created_at)')
    .eq('org_member_id', myMemberId);
  if (error) { showMessage('대화 목록을 불러오지 못했습니다: ' + error.message, 'error'); return; }

  var ids = (mine || []).map(function (r) { return r.conversation_id; });
  if (!ids.length) { conversations = []; renderConvList(); return; }

  var { data: allParticipants } = await supabaseClient
    .from('conversation_participants')
    .select('conversation_id, org_member_id, last_read_at, left_at')
    .in('conversation_id', ids)
    .is('left_at', null);

  var { data: allMessages } = await supabaseClient
    .from('messages')
    .select('*')
    .in('conversation_id', ids)
    .order('created_at', { ascending: true });

  conversations = mine.map(function (row) {
    var conv = row.conversations;
    var participants = (allParticipants || [])
      .filter(function (p) { return p.conversation_id === conv.id; })
      .map(function (p) { return { id: p.org_member_id, last_read_at: p.last_read_at }; });
    var msgs = (allMessages || []).filter(function (m) { return m.conversation_id === conv.id; });
    var last = msgs[msgs.length - 1] || null;
    var myLastRead = row.last_read_at;
    var unread = msgs.filter(function (m) { return m.sender_id !== myMemberId && m.created_at > myLastRead; }).length;
    return {
      id: conv.id, is_group: conv.is_group, name: conv.name, created_at: conv.created_at,
      custom_name: row.custom_name, participants: participants,
      messages: [], lastMessage: last, unreadCount: unread,
      loadedSince: null, reachedStart: false, loadingOlder: false,
    };
  });

  conversations.sort(function (a, b) {
    var ta = a.lastMessage ? a.lastMessage.created_at : a.created_at;
    var tb = b.lastMessage ? b.lastMessage.created_at : b.created_at;
    return tb.localeCompare(ta);
  });

  renderConvList();
}

function renderConvList() {
  var box = document.getElementById('msgConvList');
  var empty = document.getElementById('msgConvEmpty');
  if (!conversations.length) { box.innerHTML = ''; box.appendChild(empty); return; }
  box.innerHTML = conversations.map(function (c) {
    var name = displayName(c);
    var lastText = c.lastMessage
      ? (c.lastMessage.message_type === 'sticker' ? '[스티커]' : (c.lastMessage.content || (c.lastMessage.attachment_name ? '[파일] ' + c.lastMessage.attachment_name : '')))
      : '대화를 시작해보세요';
    var time = c.lastMessage ? fmtTime(c.lastMessage.created_at) : '';
    var badge = c.unreadCount > 0 ? '<span class="msg-unread-badge">' + (c.unreadCount > 99 ? '99+' : c.unreadCount) + '</span>' : '';
    return '<div class="msg-conv-row' + (c.id === activeId ? ' active' : '') + '" data-id="' + c.id + '">' +
      '<div class="msg-avatar">' + esc(initials(name)) + '</div>' +
      '<div class="msg-conv-body">' +
        '<div class="msg-conv-top"><p class="msg-conv-name">' + esc(name) + '</p><span class="msg-conv-time">' + time + '</span></div>' +
        '<p class="msg-conv-last">' + esc(lastText) + '</p>' +
      '</div>' + badge +
    '</div>';
  }).join('');
  box.querySelectorAll('.msg-conv-row').forEach(function (row) {
    row.addEventListener('click', function () { openConversation(row.dataset.id); });
  });
}

/* ── 채팅방 열기 ────────────────────────────── */
async function openConversation(id) {
  activeId = id;
  document.getElementById('msgThreadEmpty').style.display = 'none';
  document.getElementById('msgThread').style.display = 'flex';

  var conv = getConv(id);
  document.getElementById('msgThreadName').textContent = displayName(conv);

  // 읽음 처리 — 클라이언트 시각이 아니라 DB 서버 시각(now())으로 기록한다.
  // 두 사람 컴퓨터 시계가 어긋나 있으면 "방금 읽었는데도 안읽음으로 남는" 버그가
  // 생길 수 있어서, 서버 시각 기준으로 통일했다.
  await supabaseClient.rpc('mark_conversation_read', { p_conversation_id: id });
  conv.unreadCount = 0;
  renderConvList();
  updateElectronBadge();

  // 처음 여는 방이면 최근 1주일치만 불러온다. 이미 열어둔 적 있으면 캐시 그대로 사용.
  if (conv.loadedSince === null) {
    conv.loadedSince = new Date(Date.now() - WEEK_MS).toISOString();
    var { data, error } = await supabaseClient.from('messages').select('*')
      .eq('conversation_id', id).gte('created_at', conv.loadedSince)
      .order('created_at', { ascending: true });
    if (error) { showMessage('메시지를 불러오지 못했습니다: ' + error.message, 'error'); return; }
    conv.messages = data || [];
    conv.reachedStart = conv.loadedSince <= conv.created_at;
  }

  renderThreadBody(conv, { preserveScroll: false });
}

/* 스크롤을 맨 위로 올리면 이전 1주일치를 이어서 불러온다 */
async function loadOlderMessages(conv) {
  if (conv.loadingOlder || conv.reachedStart) return;
  conv.loadingOlder = true;
  var newSince = new Date(new Date(conv.loadedSince).getTime() - WEEK_MS).toISOString();
  var boundedSince = newSince < conv.created_at ? conv.created_at : newSince;
  var { data, error } = await supabaseClient.from('messages').select('*')
    .eq('conversation_id', conv.id).gte('created_at', boundedSince).lt('created_at', conv.loadedSince)
    .order('created_at', { ascending: true });
  conv.loadingOlder = false;
  if (error) { showMessage('이전 메시지를 불러오지 못했습니다: ' + error.message, 'error'); return; }
  conv.messages = (data || []).concat(conv.messages);
  conv.loadedSince = boundedSince;
  conv.reachedStart = boundedSince <= conv.created_at;
  if (conv.id === activeId) renderThreadBody(conv, { preserveScroll: true });
}

function renderThreadBody(conv, opts) {
  opts = opts || {};
  var box = document.getElementById('msgThreadBody');
  var prevHeight = box.scrollHeight, prevScrollTop = box.scrollTop;
  var others = conv.participants.filter(function (p) { return p.id !== myMemberId; });

  var startNotice = conv.reachedStart ? '<p class="msg-empty" style="padding:8px 0;">대화의 시작입니다.</p>' : '';
  var html = startNotice;
  var lastDateStr = null;

  conv.messages.forEach(function (m) {
    var dateStr = localDateStr(new Date(m.created_at));
    if (dateStr !== lastDateStr) {
      html += '<div class="msg-date-divider"><span>' + esc(fmtDateDivider(m.created_at)) + '</span></div>';
      lastDateStr = dateStr;
    }

    var isOut = m.sender_id === myMemberId;
    var senderName = conv.is_group && !isOut ? '<p class="msg-sender">' + esc(memberMap[m.sender_id]?.user_name || '') + '</p>' : '';
    var unread = isOut ? others.filter(function (p) { return !p.last_read_at || p.last_read_at < m.created_at; }).length : 0;
    var metaHtml = '<div class="msg-meta">' +
      (unread > 0 ? '<span class="msg-count">' + unread + '</span>' : '') +
      '<span class="msg-time">' + fmtHM(m.created_at) + '</span></div>';
    var bodyHtml;
    if (m.message_type === 'sticker') {
      bodyHtml = '<div class="msg-sticker-bubble"><img src="' + stickerSrc(m.content) + '" alt="스티커" /></div>';
    } else if (m.attachment_url) {
      bodyHtml = '<div class="msg-file-bubble" data-path="' + esc(m.attachment_url) + '"><i class="ti ti-file-text"></i><span>' + esc(m.attachment_name) + '</span></div>';
    } else {
      bodyHtml = '<div class="msg-bubble' + (isOut ? ' out' : '') + '">' + esc(m.content) + '</div>';
    }
    var rowInner = isOut ? (metaHtml + bodyHtml) : (bodyHtml + metaHtml);
    html += '<div class="msg-line' + (isOut ? ' out' : '') + '">' + senderName + '<div class="msg-row">' + rowInner + '</div></div>';
  });

  box.innerHTML = html;
  box.querySelectorAll('.msg-file-bubble').forEach(function (el) {
    el.addEventListener('click', async function () {
      var url = await db.getSignedUrl('messenger-files', el.dataset.path);
      if (url) window.open(url, '_blank');
    });
  });

  if (opts.preserveScroll) {
    // 위쪽에 메시지를 끼워넣은 것이므로, 늘어난 높이만큼 스크롤 위치를 보정해서
    // 화면에 보이던 메시지가 그대로 같은 자리에 있는 것처럼 보이게 한다.
    box.scrollTop = box.scrollHeight - prevHeight + prevScrollTop;
  } else {
    box.scrollTop = box.scrollHeight;
  }
}

/* ── 이모지 ─────────────────────────────────── */
var EMOJIS = [
  '😀','😁','😂','🤣','😅','😊','😍','😘','😉','😎',
  '🥳','😇','🤗','🤔','😐','😴','😪','😭','😢','😡',
  '😱','😳','🥺','🙄','😬','😷','🤒','🤧','🥶','🥵',
  '👍','👎','👏','🙌','🙏','💪','🤝','✌️','🤞','👋',
  '❤️','🧡','💛','💚','💙','💜','🖤','💔','💯','✨',
  '🎉','🎊','🔥','⭐','☀️','🌙','☕','🍀','👏','🙇',
];

function renderEmojiPanel() {
  var box = document.getElementById('msgEmojiPanel');
  box.innerHTML = EMOJIS.map(function (e) {
    return '<span class="msg-emoji-item">' + e + '</span>';
  }).join('');
  box.querySelectorAll('.msg-emoji-item').forEach(function (el) {
    el.addEventListener('click', function () { insertAtCursor(el.textContent); });
  });
}

function toggleEmojiPanel() {
  document.getElementById('msgStickerPanel').style.display = 'none';
  var box = document.getElementById('msgEmojiPanel');
  box.style.display = box.style.display === 'none' ? 'flex' : 'none';
}

function insertAtCursor(text) {
  var input = document.getElementById('msgInput');
  var start = input.selectionStart || input.value.length;
  var end = input.selectionEnd || input.value.length;
  input.value = input.value.slice(0, start) + text + input.value.slice(end);
  var pos = start + text.length;
  input.focus();
  input.setSelectionRange(pos, pos);
}

/* ── 스티커 (오리지널 캐릭터 이모티콘, Storage 업로드 없이 클라이언트 번들 이미지 사용) ── */
var STICKERS = [
  { key: 'wave', label: '안녕' },
  { key: 'thumbsup', label: '좋아요' },
  { key: 'heart', label: '고마워' },
  { key: 'laugh', label: 'ㅋㅋㅋ' },
  { key: 'sad', label: '미안' },
  { key: 'surprised', label: '헐' },
  { key: 'sleepy', label: '졸림' },
  { key: 'clap', label: '축하' },
];
function stickerSrc(key) { return '../../assets/images/stickers/' + key + '.png'; }

function renderStickerPanel() {
  var box = document.getElementById('msgStickerPanel');
  box.innerHTML = STICKERS.map(function (s) {
    return '<span class="msg-sticker-item" data-key="' + s.key + '" title="' + esc(s.label) + '">' +
      '<img src="' + stickerSrc(s.key) + '" alt="' + esc(s.label) + '" /></span>';
  }).join('');
  box.querySelectorAll('.msg-sticker-item').forEach(function (el) {
    el.addEventListener('click', function () { sendSticker(el.dataset.key); });
  });
}

function toggleStickerPanel() {
  document.getElementById('msgEmojiPanel').style.display = 'none';
  var box = document.getElementById('msgStickerPanel');
  box.style.display = box.style.display === 'none' ? 'flex' : 'none';
}

async function sendSticker(key) {
  if (!activeId) return;
  document.getElementById('msgStickerPanel').style.display = 'none';
  var { data, error } = await supabaseClient.from('messages').insert({
    conversation_id: activeId, sender_id: myMemberId, content: key, message_type: 'sticker',
  }).select().single();
  if (error) { showMessage('전송 실패: ' + error.message, 'error'); return; }
  handleNewMessage(data);
}


async function sendMessage() {
  if (!activeId) return;
  var input = document.getElementById('msgInput');
  var content = input.value.trim();
  if (!content) return;
  input.value = '';
  var { data, error } = await supabaseClient.from('messages').insert({
    conversation_id: activeId, sender_id: myMemberId, content: content,
  }).select().single();
  if (error) { showMessage('전송 실패: ' + error.message, 'error'); return; }
  // 실시간 이벤트를 기다리지 않고 바로 화면에 반영한다 — 나중에 realtime으로 같은
  // 메시지가 다시 들어와도 handleNewMessage의 중복 방지 체크가 걸러준다.
  handleNewMessage(data);
}

async function attachFile() {
  if (!activeId) return;
  var input = document.getElementById('msgFileInput');
  var file = input.files[0];
  input.value = '';
  if (!file) return;
  if (file.size > 25 * 1024 * 1024) { showMessage('파일은 25MB 이하만 첨부할 수 있습니다.', 'warning'); return; }
  showGlobalLoading('파일 업로드 중...');
  try {
    var uploaded = await db.uploadFile('messenger-files', file, activeId);
    var { data, error } = await supabaseClient.from('messages').insert({
      conversation_id: activeId, sender_id: myMemberId,
      attachment_url: uploaded.path, attachment_name: uploaded.name,
      attachment_type: file.type || 'application/octet-stream', file_size: uploaded.size,
    }).select().single();
    if (error) throw error;
    handleNewMessage(data);
  } catch (e) {
    showMessage('파일 전송 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ── 대화 이름 변경 (나에게만 적용) ──────────────── */
async function renameConversation() {
  if (!activeId) return;
  var conv = getConv(activeId);
  var next = prompt('대화 이름 (나에게만 보입니다)', displayName(conv));
  if (next === null) return;
  next = next.trim();
  var { error } = await supabaseClient.from('conversation_participants')
    .update({ custom_name: next || null })
    .eq('conversation_id', activeId).eq('org_member_id', myMemberId);
  if (error) { showMessage('변경 실패: ' + error.message, 'error'); return; }
  conv.custom_name = next || null;
  document.getElementById('msgThreadName').textContent = displayName(conv);
  renderConvList();
}

/* ── 채팅방 나가기 ────────────────────────────── */
async function leaveConversation() {
  if (!activeId) return;
  var conv = getConv(activeId);
  var msg = conv.is_group
    ? '"' + displayName(conv) + '" 대화방에서 나가시겠습니까?\n나가면 이 목록에서 사라지고, 남은 대화 내용은 다시 초대받기 전까지 볼 수 없습니다.'
    : '"' + displayName(conv) + '" 님과의 대화방에서 나가시겠습니까?\n나가면 이 목록에서 사라지지만, 다음에 이 사람과 다시 대화를 시작하면 지금까지의 내용이 그대로 이어집니다.';
  if (!confirm(msg)) return;
  var { error } = await supabaseClient.rpc('leave_conversation', { p_conversation_id: activeId });
  if (error) { showMessage('나가기 실패: ' + error.message, 'error'); return; }
  conversations = conversations.filter(function (c) { return c.id !== activeId; });
  activeId = null;
  document.getElementById('msgThread').style.display = 'none';
  document.getElementById('msgThreadEmpty').style.display = 'flex';
  renderConvList();
}

/* ── 왼쪽 조직도 패널 (상시 노출) — 탭하면 바로 1:1 시작/열기 ──────── */
function renderOrgPane() {
  var box = document.getElementById('msgOrgPaneTree');
  if (!box) return;
  var members = Object.keys(memberMap)
    .map(function (id) { return Object.assign({ id: id }, memberMap[id]); })
    .filter(function (m) { return m.id !== myMemberId && m.active !== false; })
    .sort(function (a, b) {
      return (a.clinic_name || '').localeCompare(b.clinic_name || '') ||
        (a.dept_name || '').localeCompare(b.dept_name || '') ||
        (a.user_name || '').localeCompare(b.user_name || '');
    });

  var html = '';
  var lastClinic = null, lastDept = null;
  members.forEach(function (m) {
    if (m.clinic_name !== lastClinic) { html += '<div class="msg-org-clinic"><i class="ti ti-building"></i> ' + esc(m.clinic_name || '소속 없음') + '</div>'; lastClinic = m.clinic_name; lastDept = null; }
    if (m.dept_name !== lastDept) { html += '<div class="msg-org-dept">' + esc(m.dept_name || '') + '</div>'; lastDept = m.dept_name; }
    html += '<div class="msg-org-member" data-id="' + m.id + '"><span>' + esc(m.user_name) + '</span><span class="msg-org-pos">' + esc(m.position_name || '') + '</span></div>';
  });
  box.innerHTML = html || '<p style="font-size:12px;color:#9ca3af;">조직원이 없습니다.</p>';
  box.querySelectorAll('.msg-org-member').forEach(function (el) {
    el.addEventListener('click', function () { startDirectConversation(el.dataset.id); });
  });
}

/* 조직도에서 사람을 탭하면 그 사람과의 1:1 대화방을 열거나(있으면 재사용) 새로 만든다 */
async function startDirectConversation(memberId) {
  var { data, error } = await supabaseClient.rpc('create_conversation', {
    p_org_id: currentUser.org_id, p_is_group: false, p_name: null, p_participant_ids: [memberId],
  });
  if (error) { showMessage('대화 시작 실패: ' + error.message, 'error'); return; }
  await loadConversations();
  openConversation(data);
}

/* ── 새 대화 (조직도에서 선택) ──────────────────── */
function openNewConversationModal() {
  selectedNewIds = [];
  var box = document.getElementById('msgOrgTree');
  var members = Object.keys(memberMap)
    .map(function (id) { return Object.assign({ id: id }, memberMap[id]); })
    .filter(function (m) { return m.id !== myMemberId && m.active !== false; })
    .sort(function (a, b) {
      return (a.clinic_name || '').localeCompare(b.clinic_name || '') ||
        (a.dept_name || '').localeCompare(b.dept_name || '') ||
        (a.user_name || '').localeCompare(b.user_name || '');
    });

  var html = '';
  var lastClinic = null, lastDept = null;
  members.forEach(function (m) {
    if (m.clinic_name !== lastClinic) { html += '<div class="msg-org-clinic"><i class="ti ti-building"></i> ' + esc(m.clinic_name || '소속 없음') + '</div>'; lastClinic = m.clinic_name; lastDept = null; }
    if (m.dept_name !== lastDept) { html += '<div class="msg-org-dept">' + esc(m.dept_name || '') + '</div>'; lastDept = m.dept_name; }
    html += '<div class="msg-org-member" data-id="' + m.id + '"><span>' + esc(m.user_name) + '</span><span class="msg-org-pos">' + esc(m.position_name || '') + '</span></div>';
  });
  box.innerHTML = html || '<p style="font-size:12px;color:#9ca3af;">선택 가능한 조직원이 없습니다.</p>';
  box.querySelectorAll('.msg-org-member').forEach(function (el) {
    el.addEventListener('click', function () {
      var id = el.dataset.id;
      var idx = selectedNewIds.indexOf(id);
      if (idx >= 0) { selectedNewIds.splice(idx, 1); el.classList.remove('sel'); }
      else { selectedNewIds.push(id); el.classList.add('sel'); }
    });
  });
  openModal('msgNewModal');
}

async function startNewConversation() {
  if (!selectedNewIds.length) { showMessage('대화 상대를 선택해주세요.', 'warning'); return; }
  var isGroup = selectedNewIds.length > 1;
  var groupName = null;
  if (isGroup) {
    var names = selectedNewIds.map(function (id) { return memberMap[id]?.user_name || ''; });
    groupName = names.length > 2 ? (names.slice(0, 2).join(', ') + ' 외 ' + (names.length - 2) + '명') : names.join(', ');
  }
  showGlobalLoading('대화방 만드는 중...');
  var { data, error } = await supabaseClient.rpc('create_conversation', {
    p_org_id: currentUser.org_id, p_is_group: isGroup, p_name: groupName, p_participant_ids: selectedNewIds,
  });
  hideGlobalLoading();
  if (error) { showMessage('대화방 생성 실패: ' + error.message, 'error'); return; }
  closeModal('msgNewModal');
  await loadConversations();
  openConversation(data);
}

/* ── 실시간 구독 ────────────────────────────── */
function subscribeRealtime() {
  realtimeChannel = supabaseClient.channel('messenger-' + myMemberId)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, function (payload) {
      handleNewMessage(payload.new);
    })
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'conversation_participants' }, function (payload) {
      handleParticipantUpdate(payload.new);
    })
    .subscribe();
}

function handleNewMessage(msg) {
  var conv = getConv(msg.conversation_id);
  if (!conv) return; // 내가 참여 중인 대화가 아니면 무시
  if (conv.messages.some(function (m) { return m.id === msg.id; })) return; // 이미 반영된 메시지(낙관적 업데이트 + realtime 에코 중복) 무시
  conv.messages.push(msg);
  conv.lastMessage = msg;
  if (msg.sender_id !== myMemberId && msg.conversation_id !== activeId) conv.unreadCount += 1;
  conversations.sort(function (a, b) {
    var ta = a.lastMessage ? a.lastMessage.created_at : '0';
    var tb = b.lastMessage ? b.lastMessage.created_at : '0';
    return tb.localeCompare(ta);
  });
  renderConvList();
  notifyElectron(conv, msg);
  if (msg.conversation_id === activeId) {
    if (msg.sender_id !== myMemberId) {
      supabaseClient.rpc('mark_conversation_read', { p_conversation_id: activeId });
    }
    renderThreadBody(conv);
  }
}

/* ── Electron 전용 훅 (electronAPI가 없으면 그냥 아무 일도 안 함, 웹에는 영향 없음) ── */
function updateElectronBadge() {
  if (!window.electronAPI) return;
  var total = conversations.reduce(function (sum, c) { return sum + c.unreadCount; }, 0);
  window.electronAPI.setBadgeCount(total);
}

function notifyElectron(conv, msg) {
  if (!window.electronAPI || msg.sender_id === myMemberId) return;
  updateElectronBadge();
  var senderName = conv.is_group ? (memberMap[msg.sender_id]?.user_name || '') + ' (' + displayName(conv) + ')' : displayName(conv);
  var body = msg.message_type === 'sticker' ? '[스티커]' : (msg.content || (msg.attachment_name ? '[파일] ' + msg.attachment_name : '새 메시지'));
  window.electronAPI.notify(senderName, body, conv.id);
}

function handleParticipantUpdate(row) {
  var conv = getConv(row.conversation_id);

  if (row.org_member_id === myMemberId) {
    if (row.left_at) {
      // 다른 기기에서 내가 이 방을 나간 경우 — 목록/화면에서 같이 제거
      if (conv) {
        conversations = conversations.filter(function (c) { return c.id !== row.conversation_id; });
        if (activeId === row.conversation_id) {
          activeId = null;
          document.getElementById('msgThread').style.display = 'none';
          document.getElementById('msgThreadEmpty').style.display = 'flex';
        }
        renderConvList();
      }
      return;
    }
    if (!conv) {
      // 다른 기기에서 재참여해서 로컬 목록엔 아직 없는 대화 — 통째로 새로고침
      loadConversations();
      return;
    }
  }
  if (!conv) return;

  if (row.org_member_id === myMemberId && row.custom_name !== undefined) {
    conv.custom_name = row.custom_name;
    if (row.conversation_id === activeId) document.getElementById('msgThreadName').textContent = displayName(conv);
  }

  var p = conv.participants.find(function (x) { return x.id === row.org_member_id; });
  if (row.left_at) {
    conv.participants = conv.participants.filter(function (x) { return x.id !== row.org_member_id; }); // 상대가 나감
  } else if (p) {
    p.last_read_at = row.last_read_at;
  } else {
    conv.participants.push({ id: row.org_member_id, last_read_at: row.last_read_at }); // 상대가 재참여
  }

  renderConvList();
  if (row.conversation_id === activeId) renderThreadBody(conv);
}

/* ── 초기화 ─────────────────────────────────── */
async function init() {
  var session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'messenger/messenger')) {
    hideGlobalLoading();
    alert('이 페이지에 접근할 권한이 없습니다.');
    location.replace('../home/home.html');
    return;
  }
  myMemberId = currentUser.org_member_id;

  await loadMemberMap();
  renderOrgPane();
  await loadConversations();
  subscribeRealtime();

  document.getElementById('msgNewBtn').addEventListener('click', openNewConversationModal);
  document.getElementById('msgStartBtn').addEventListener('click', startNewConversation);
  document.getElementById('msgSendBtn').addEventListener('click', sendMessage);
  document.getElementById('msgInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') sendMessage(); });
  document.getElementById('msgAttachBtn').addEventListener('click', function () { document.getElementById('msgFileInput').click(); });
  document.getElementById('msgFileInput').addEventListener('change', attachFile);
  document.getElementById('msgEmojiBtn').addEventListener('click', toggleEmojiPanel);
  document.getElementById('msgStickerBtn').addEventListener('click', toggleStickerPanel);
  renderEmojiPanel();
  renderStickerPanel();
  document.getElementById('msgRenameBtn').addEventListener('click', renameConversation);
  document.getElementById('msgLeaveBtn').addEventListener('click', leaveConversation);
  document.getElementById('msgThreadBody').addEventListener('scroll', function (e) {
    if (e.target.scrollTop < 60 && activeId) loadOlderMessages(getConv(activeId));
  });
  if (window.electronAPI) {
    window.electronAPI.onNotificationClick(function (conversationId) { openConversation(conversationId); });
    updateElectronBadge();
  }

  hideGlobalLoading();
}

document.addEventListener('DOMContentLoaded', init);
window.addEventListener('beforeunload', function () { if (realtimeChannel) supabaseClient.removeChannel(realtimeChannel); });
