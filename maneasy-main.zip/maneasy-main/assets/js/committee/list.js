/**
 * assets/js/committee/list.js
 * 위원회 관리 — 목록 조회 + 등록/수정 (삭제는 상세 화면에서, 등록 이력 보호 목적)
 * maneasy는 단일 의원 운영이라 clinic 구분 없음 (mso_manage 버전에서 그 로직만 제거).
 */

let currentUser = null;
let canEdit = false;
let committeeCache = [];
let editingCommitteeId = null;

function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }

async function loadCommittees() {
  const { data, error } = await supabaseClient
    .from('committees')
    .select('*, committee_members(count), committee_regulations(count), committee_meetings(count)')
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

let _committeeGridApi = null;

function renderCommittees(list, keyword) {
  const kw = (keyword || '').toLowerCase();
  const filtered = kw ? list.filter(c => (c.name || '').toLowerCase().includes(kw)) : list;
  const rows = filtered.map((c, idx) => ({ ...c, _idx: idx }));

  const colDefs = [
    { headerName: '위원회명', field: 'name', width: 180, headerClass: 'ag-left-header',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', fontWeight: 700 } },
    { headerName: '설명', field: 'description', flex: 1, minWidth: 200, headerClass: 'ag-left-header',
      valueFormatter: p => p.value || '-',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', color: '#6b7280' } },
    { headerName: '코드', field: 'code', width: 150, cellStyle: { fontFamily: 'Consolas, monospace', fontSize: '11px', color: '#6b7280' } },
    { headerName: '위원 수', width: 90, valueGetter: p => p.data.committee_members?.[0]?.count ?? 0 },
    { headerName: '연결 규정', width: 90, valueGetter: p => p.data.committee_regulations?.[0]?.count ?? 0 },
    { headerName: '회의록', width: 90, valueGetter: p => p.data.committee_meetings?.[0]?.count ?? 0 },
    { headerName: '상태', width: 90,
      cellRenderer: p => {
        const s = document.createElement('span');
        if (p.data.active === 'Y') { s.className = 'badge badge-green'; s.textContent = '활성'; }
        else { s.className = 'badge'; s.textContent = '비활성'; }
        return s;
      } },
    { headerName: '관리', width: 90, sortable: false,
      cellRenderer: p => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-sm';
        btn.textContent = '조회';
        btn.onclick = () => { parent.shellNavigate?.('committee/detail?id=' + encodeURIComponent(p.data.id)); };
        return btn;
      } },
  ];

  if (!_committeeGridApi) {
    _committeeGridApi = createMgGrid('committeeGrid', colDefs, rows, {
      noRowsText: '등록된 위원회가 없습니다.',
    });
  } else {
    updateMgGrid(_committeeGridApi, rows);
  }
}

function applyFilter() {
  renderCommittees(committeeCache, val('keyword'));
}

/* ── 등록/수정 모달 ── */
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }

function openAddCommittee() {
  editingCommitteeId = null;
  document.getElementById('committeeModalTitle').textContent = '위원회 등록';
  setVal('cf_name', '');
  setVal('cf_code', '');
  setVal('cf_description', '');
  setVal('cf_active', 'Y');
  openModal('committeeModal');
}
window.openAddCommittee = openAddCommittee;

async function saveCommittee() {
  const name = val('cf_name');
  const code = val('cf_code').toUpperCase().replace(/[^A-Z0-9_-]/g, '');
  if (!name) { showMessage('위원회명은 필수입니다.', 'warning'); return; }
  if (!code) { showMessage('코드는 필수입니다 (영문/숫자).', 'warning'); return; }

  const payload = {
    name,
    code,
    description: val('cf_description'),
    active: val('cf_active') || 'Y',
    updated_at: new Date().toISOString(),
  };

  try {
    showGlobalLoading('저장 중...');
    if (editingCommitteeId) {
      const { error } = await supabaseClient.from('committees').update(payload).eq('id', editingCommitteeId);
      if (error) throw new Error(error.message);
      systemLog('COMMITTEE_UPDATE', '위원회 수정 — ' + name, { target_type: 'committees', target_id: editingCommitteeId }).catch(() => {});
    } else {
      payload.sort_order = committeeCache.length + 1;
      const { data, error } = await supabaseClient.from('committees').insert(payload).select().single();
      if (error) throw new Error(error.message);
      systemLog('COMMITTEE_CREATE', '위원회 등록 — ' + name, { target_type: 'committees', target_id: data?.id }).catch(() => {});
    }
    closeModal('committeeModal');
    await refresh();
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장에 실패했습니다.', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function refresh() {
  committeeCache = await loadCommittees();
  applyFilter();
}

async function init() {
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'committee/list')) {
    showMessage('이 페이지에 접근할 권한이 없습니다.', 'error');
    parent.shellNavigate?.('home/home');
    return;
  }
  canEdit = window.PagePerms.atLeast(currentUser, 'committee/list', 'manager');

  if (canEdit) {
    document.getElementById('addCommitteeBtn').style.display = '';
    document.getElementById('addCommitteeBtn').addEventListener('click', openAddCommittee);
  }

  document.getElementById('searchForm')?.addEventListener('submit', e => { e.preventDefault(); applyFilter(); });
  document.getElementById('resetFilterBtn')?.addEventListener('click', () => { setVal('keyword', ''); applyFilter(); });
  document.getElementById('committeeModalClose')?.addEventListener('click', () => closeModal('committeeModal'));
  document.getElementById('committeeModalCancel')?.addEventListener('click', () => closeModal('committeeModal'));
  document.getElementById('committeeModalSave')?.addEventListener('click', saveCommittee);

  showGlobalLoading('불러오는 중...');
  try {
    await refresh();
  } catch (e) {
    showMessage(e.message || '조회에 실패했습니다.', 'error');
  } finally {
    hideGlobalLoading();
  }
}

document.addEventListener('DOMContentLoaded', init);