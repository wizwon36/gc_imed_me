/**
 * assets/js/committee/detail.js
 * 위원회 상세 — 규정(조항+버전관리) / 위원 / 회의록(본문+첨부파일) 3개 탭
 */

const BUCKET = 'committee-meeting-files';

let currentUser = null;
let canEdit = false;      // manager 이상 — 규정/위원/회의록 전체 등록·수정
let canDelete = false;    // admin — 삭제
let canAddMeeting = false; // canEdit이거나, 이 위원회의 간사로 연동된 계정

let committeeId = null;
let committee = null;
let linkedRegulations = [];
let members = [];
let meetings = [];

function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.openModal = openModal;
window.closeModal = closeModal;

function getCommitteeIdFromUrl() {
  return new URLSearchParams(location.search).get('id');
}

/* ══════════════════════════════════════════════
   위원회 기본 정보
══════════════════════════════════════════════ */
async function loadCommittee() {
  const { data, error } = await supabaseClient.from('committees').select('*').eq('id', committeeId).single();
  if (error) throw new Error(error.message);
  return data;
}

function renderCommitteeHead() {
  document.getElementById('cmteName').textContent = committee.name;
  const badge = document.getElementById('cmteStatusBadge');
  badge.textContent = committee.active === 'Y' ? '활성' : '비활성';
  badge.classList.toggle('is-in-use', committee.active === 'Y');
  document.title = committee.name + ' · 위원회 상세';
}

function openEditCommittee() {
  setVal('cf_name', committee.name);
  setVal('cf_description', committee.description || '');
  setVal('cf_active', committee.active || 'Y');
  openModal('committeeModal');
}

async function saveCommitteeInfo() {
  const name = val('cf_name');
  if (!name) { showMessage('위원회명은 필수입니다.', 'warning'); return; }
  try {
    showGlobalLoading('저장 중...');
    const payload = { name, description: val('cf_description'), active: val('cf_active') || 'Y', updated_at: new Date().toISOString() };
    const { error } = await supabaseClient.from('committees').update(payload).eq('id', committeeId);
    if (error) throw new Error(error.message);
    systemLog('COMMITTEE_UPDATE', '위원회 정보 수정 — ' + name, { target_type: 'committees', target_id: committeeId }).catch(() => {});
    committee = await loadCommittee();
    renderCommitteeHead();
    closeModal('committeeModal');
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   탭 전환
══════════════════════════════════════════════ */
function initTabs() {
  document.querySelectorAll('.det-tabs .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.det-tabs .tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.cmte-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('panel-' + btn.dataset.tab)?.classList.add('active');
      updateActionbarForTab(btn.dataset.tab);

      // ag-grid는 숨겨진(display:none) 컨테이너에서 생성하면 폭을 0으로 측정해서 컬럼이
      // 찌그러진다. 그래서 위원/회의록 그리드는 페이지 로드 시 미리 만들지 않고, 해당 탭을
      // 처음 열 때(지금 이 시점, 컨테이너가 막 보이게 된 뒤) 생성한다 — render 함수 자체가
      // "없으면 생성, 있으면 갱신"이라 다시 불러도 안전하다.
      if (btn.dataset.tab === 'members') renderMembers();
      if (btn.dataset.tab === 'meetings') renderMeetings();
    });
  });
}

/** 탭마다 다른 등록 버튼(규정 연결/위원 추가/회의록 작성)을 액션바에 하나씩만 보여준다 —
 * 탭 전용 툴바를 따로 두면 화면 세로 공간을 한 줄 더 차지하게 되므로, 상단 액션바에
 * 얹어서 탭에 따라 내용만 바뀌게 한다. */
function updateActionbarForTab(tab) {
  const linkRegulationBtn = document.getElementById('linkRegulationBtn');
  const addMemberBtn = document.getElementById('addMemberBtn');
  const addMeetingBtn = document.getElementById('addMeetingBtn');
  linkRegulationBtn.style.display = (tab === 'regulation' && canEdit) ? '' : 'none';
  addMemberBtn.style.display = (tab === 'members' && canEdit) ? '' : 'none';
  addMeetingBtn.style.display = (tab === 'meetings' && canAddMeeting) ? '' : 'none';
}

/* ══════════════════════════════════════════════
   규정 탭
══════════════════════════════════════════════ */
/* ══════════════════════════════════════════════
   규정 탭 — 이 위원회에 연결된 규정 목록 (연결/해제만, 편집은 규정 상세 페이지에서)
══════════════════════════════════════════════ */
async function loadLinkedRegulations() {
  const { data, error } = await supabaseClient
    .from('committee_regulations')
    .select('id, regulations(id, code, name, description, active, regulation_sections(count))')
    .eq('committee_id', committeeId);
  if (error) throw new Error(error.message);
  return (data || []).filter(r => r.regulations).map(r => ({ linkId: r.id, ...r.regulations }));
}

let _regulationGridApi = null;

function renderLinkedRegulations() {
  const rows = linkedRegulations.map((r, idx) => ({ ...r, _idx: idx }));

  const colDefs = [
    { headerName: '규정명', field: 'name', width: 200, headerClass: 'ag-left-header',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', fontWeight: 700 } },
    { headerName: '설명', field: 'description', flex: 1, minWidth: 200, headerClass: 'ag-left-header',
      valueFormatter: p => p.value || '-',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', color: '#6b7280' } },
    { headerName: '조항 수', width: 90, valueGetter: p => p.data.regulation_sections?.[0]?.count ?? 0 },
    { headerName: '상태', width: 90,
      cellRenderer: p => {
        const s = document.createElement('span');
        if (p.data.active === 'Y') { s.className = 'badge badge-green'; s.textContent = '활성'; }
        else { s.className = 'badge'; s.textContent = '비활성'; }
        return s;
      } },
    { headerName: '관리', width: 150, sortable: false,
      cellRenderer: p => {
        const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;';
        const viewBtn = document.createElement('button'); viewBtn.className = 'btn btn-sm'; viewBtn.textContent = '보기';
        viewBtn.onclick = () => { parent.shellNavigate?.('regulation/detail?id=' + encodeURIComponent(p.data.id)); };
        wrap.append(viewBtn);
        if (canEdit) {
          const unlinkBtn = document.createElement('button'); unlinkBtn.className = 'btn btn-sm'; unlinkBtn.textContent = '연결 해제';
          unlinkBtn.onclick = () => unlinkRegulation(linkedRegulations[p.data._idx]);
          wrap.append(unlinkBtn);
        }
        return wrap;
      } },
  ];

  if (!_regulationGridApi) {
    _regulationGridApi = createMgGrid('regulationGrid', colDefs, rows, { noRowsText: '연결된 규정이 없습니다.' });
  } else {
    updateMgGrid(_regulationGridApi, rows);
  }
}

async function unlinkRegulation(reg) {
  if (!confirm(`"${reg.name}" 규정 연결을 해제하시겠습니까? (규정 자체는 삭제되지 않습니다)`)) return;
  try {
    showGlobalLoading('처리 중...');
    const { error } = await supabaseClient.from('committee_regulations').delete().eq('id', reg.linkId);
    if (error) throw new Error(error.message);
    systemLog('COMMITTEE_REGULATION_UNLINK', '규정 연결 해제 — ' + committee.name + ' / ' + reg.name, {
      target_type: 'committee_regulations', target_id: reg.linkId,
    }).catch(() => {});
    linkedRegulations = await loadLinkedRegulations();
    renderLinkedRegulations();
    showMessage('연결을 해제했습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '처리 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

function openLinkRegulationModal() {
  setVal('lr_search', '');
  document.getElementById('lr_search_results').innerHTML = '';
  openModal('linkRegulationModal');
}

async function searchRegulationsToLink() {
  const kw = val('lr_search').toLowerCase();
  const resultsEl = document.getElementById('lr_search_results');
  resultsEl.innerHTML = '<div style="font-size:12px;color:#9ca3af;padding:6px 0;">검색 중...</div>';
  try {
    const { data, error } = await supabaseClient.from('regulations').select('id, name, code, active').order('sort_order');
    if (error) throw new Error(error.message);
    const linkedIds = new Set(linkedRegulations.map(r => r.id));
    const filtered = (data || []).filter(r => {
      if (linkedIds.has(r.id)) return false;
      if (!kw) return true;
      return (r.name || '').toLowerCase().includes(kw) || (r.code || '').toLowerCase().includes(kw);
    });

    if (!filtered.length) {
      resultsEl.innerHTML = '<div style="font-size:12px;color:#9ca3af;padding:6px 0;">연결 가능한 규정이 없습니다.</div>';
      return;
    }
    resultsEl.innerHTML = filtered.map(r => `
      <div style="display:flex;align-items:center;gap:8px;padding:8px;border-bottom:1px solid #f1f5f9;font-size:12px;">
        <span style="font-weight:700;flex:1;">${ts(r.name)}</span>
        <span style="color:#9ca3af;font-family:Consolas,monospace;font-size:11px;">${ts(r.code)}</span>
        <button type="button" class="btn btn-sm js-link-reg" data-id="${r.id}" data-name="${ts(r.name)}">연결</button>
      </div>`).join('');
    resultsEl.querySelectorAll('.js-link-reg').forEach(btn => {
      btn.addEventListener('click', () => linkRegulation(btn.dataset.id, btn.dataset.name));
    });
  } catch (e) {
    resultsEl.innerHTML = `<div style="font-size:12px;color:#dc2626;">${ts(e.message || '검색 실패')}</div>`;
  }
}

async function linkRegulation(regulationId, regulationName) {
  try {
    showGlobalLoading('연결 중...');
    const who = currentUser?.email || currentUser?.user_name || '';
    const { error } = await supabaseClient.from('committee_regulations').insert({
      committee_id: committeeId, regulation_id: regulationId, linked_by: who,
    });
    if (error) throw new Error(error.message);
    systemLog('COMMITTEE_REGULATION_LINK', '규정 연결 — ' + committee.name + ' / ' + regulationName, {
      target_type: 'committee_regulations',
    }).catch(() => {});
    linkedRegulations = await loadLinkedRegulations();
    renderLinkedRegulations();
    closeModal('linkRegulationModal');
    showMessage('연결되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '연결 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   위원 탭
══════════════════════════════════════════════ */
async function loadMembers() {
  const { data, error } = await supabaseClient
    .from('committee_members')
    .select('*')
    .eq('committee_id', committeeId).order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  const rows = data || [];

  // committee_members.user_id는 auth.users(id)를 직접 참조라서(org_members 경유가 아님)
  // Supabase의 자동 관계 임베딩(select 안에서 테이블명 붙이기)을 못 쓴다 — 연동된 계정이
  // 있는 행들만 모아서 org_members_detail에서 이름을 따로 찾아 붙인다.
  const linkedUserIds = [...new Set(rows.filter(m => m.user_id).map(m => m.user_id))];
  let nameByUserId = {};
  if (linkedUserIds.length) {
    const { data: users } = await supabaseClient
      .from('org_members_detail').select('user_id, user_name').in('user_id', linkedUserIds);
    (users || []).forEach(u => { nameByUserId[u.user_id] = u.user_name; });
  }
  return rows.map(m => ({ ...m, _linkedLabel: m.user_id ? (nameByUserId[m.user_id] || '') : '' }));
}

let _memberGridApi = null;

function renderMembers() {
  // 규정 그리드와 동일한 이유 — 탭이 안 보이는 상태에서 최초 생성하면 폭이 0으로 찌그러짐.
  if (!_memberGridApi && !document.getElementById('panel-members').classList.contains('active')) return;
  const rows = members.map((m, idx) => ({ ...m, _idx: idx }));

  const colDefs = [
    { headerName: '이름', field: 'member_name', flex: 1, minWidth: 140, headerClass: 'ag-left-header',
      cellRenderer: p => {
        const wrap = document.createElement('span');
        wrap.style.cssText = 'font-weight:700;';
        wrap.textContent = p.value;
        if (p.data.user_id) {
          const badge = document.createElement('span');
          badge.className = 'timeline-badge';
          badge.style.cssText = 'margin-left:6px;font-size:9px;';
          badge.innerHTML = '<i class="ti ti-link"></i> 계정연동';
          wrap.appendChild(badge);
        }
        return wrap;
      } },
    { headerName: '직책', field: 'position', width: 100 },
    { headerName: '임기 시작', field: 'term_start', width: 120, valueFormatter: p => p.value || '-' },
    { headerName: '임기 종료', field: 'term_end', width: 120, valueFormatter: p => p.value || '-' },
    { headerName: '관리', width: 100, sortable: false,
      cellRenderer: p => {
        const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;';
        if (canEdit) {
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정';
          e.onclick = () => openMemberEdit(members[p.data._idx]);
          wrap.append(e);
        }
        if (canDelete) {
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제';
          d.onclick = () => deleteMember(members[p.data._idx]);
          wrap.append(d);
        }
        return wrap;
      } },
  ];

  if (!_memberGridApi) {
    _memberGridApi = createMgGrid('memberGrid', colDefs, rows, { noRowsText: '등록된 위원이 없습니다.' });
  } else {
    updateMgGrid(_memberGridApi, rows);
  }
}

let _editingMemberId = null;
let _linkedUserId = null;
let _linkedUserLabel = '';

function renderLinkedAccountBox() {
  const box = document.getElementById('mf_linked_account');
  if (!_linkedUserId) { box.innerHTML = '<span style="color:#9ca3af;">연동된 계정 없음</span>'; return; }
  box.innerHTML = `<span class="badge badge-green"><i class="ti ti-link"></i> ${ts(_linkedUserLabel)}</span> ` +
    `<button type="button" class="btn btn-sm" id="mf_unlink_btn" style="margin-left:6px;">연결 해제</button>`;
  document.getElementById('mf_unlink_btn')?.addEventListener('click', () => {
    _linkedUserId = null; _linkedUserLabel = '';
    renderLinkedAccountBox();
  });
}

function openMemberAdd() {
  _editingMemberId = null;
  _linkedUserId = null; _linkedUserLabel = '';
  document.getElementById('memberModalTitle').textContent = '위원 추가';
  setVal('mf_name', ''); setVal('mf_position', '위원'); setVal('mf_term_start', ''); setVal('mf_term_end', '');
  setVal('mf_user_search', '');
  document.getElementById('mf_user_search_results').innerHTML = '';
  renderLinkedAccountBox();
  openModal('memberModal');
}
function openMemberEdit(m) {
  _editingMemberId = m.id;
  _linkedUserId = m.user_id || null;
  _linkedUserLabel = m.user_id ? (m._linkedLabel || m.member_name) : '';
  document.getElementById('memberModalTitle').textContent = '위원 정보 수정';
  setVal('mf_name', m.member_name); setVal('mf_position', m.position);
  setVal('mf_term_start', m.term_start || ''); setVal('mf_term_end', m.term_end || '');
  setVal('mf_user_search', '');
  document.getElementById('mf_user_search_results').innerHTML = '';
  renderLinkedAccountBox();
  openModal('memberModal');
}

async function searchMemberUsers() {
  const kw = val('mf_user_search').toLowerCase();
  const resultsEl = document.getElementById('mf_user_search_results');
  if (!kw) { resultsEl.innerHTML = '<div style="font-size:12px;color:#9ca3af;">검색어를 입력하세요.</div>'; return; }

  resultsEl.innerHTML = '<div style="font-size:12px;color:#9ca3af;">검색 중...</div>';
  try {
    const { data, error } = await supabaseClient
      .from('org_members_detail')
      .select('user_id, user_name, email, dept_name, clinic_name')
      .eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false)
      .or(`user_name.ilike.%${escapeIlikeKeyword(kw)}%,email.ilike.%${escapeIlikeKeyword(kw)}%`)
      .limit(10);
    if (error) throw new Error(error.message);

    if (!data || !data.length) {
      resultsEl.innerHTML = '<div style="font-size:12px;color:#9ca3af;">검색 결과가 없습니다.</div>';
      return;
    }
    resultsEl.innerHTML = data.map(u => `
      <div style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-bottom:1px solid #f1f5f9;font-size:12px;">
        <span style="font-weight:700;">${ts(u.user_name || '')}</span>
        <span style="color:#9ca3af;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${ts(u.email)}</span>
        <span style="color:#9ca3af;">${ts(u.dept_name || u.clinic_name || '')}</span>
        <button type="button" class="btn btn-sm js-link-user" data-id="${u.user_id}" data-label="${ts(u.user_name || u.email)}">연결</button>
      </div>`).join('');
    resultsEl.querySelectorAll('.js-link-user').forEach(btn => {
      btn.addEventListener('click', () => {
        _linkedUserId = btn.dataset.id;
        _linkedUserLabel = btn.dataset.label;
        renderLinkedAccountBox();
        resultsEl.innerHTML = '';
        setVal('mf_user_search', '');
      });
    });
  } catch (e) {
    resultsEl.innerHTML = `<div style="font-size:12px;color:#dc2626;">${ts(e.message || '검색 실패')}</div>`;
  }
}

async function saveMember() {
  const name = val('mf_name');
  if (!name) { showMessage('이름은 필수입니다.', 'warning'); return; }
  const payload = {
    member_name: name, position: val('mf_position') || '위원',
    term_start: val('mf_term_start') || null, term_end: val('mf_term_end') || null,
    user_id: _linkedUserId || null,
    updated_at: new Date().toISOString(),
  };
  try {
    showGlobalLoading('저장 중...');
    if (_editingMemberId) {
      const { error } = await supabaseClient.from('committee_members').update(payload).eq('id', _editingMemberId);
      if (error) throw new Error(error.message);
      systemLog('COMMITTEE_MEMBER_UPDATE', '위원 정보 수정 — ' + committee.name + ' / ' + name, { target_type: 'committee_members', target_id: _editingMemberId }).catch(() => {});
    } else {
      payload.committee_id = committeeId;
      payload.sort_order = members.length + 1;
      const { data, error } = await supabaseClient.from('committee_members').insert(payload).select().single();
      if (error) throw new Error(error.message);
      systemLog('COMMITTEE_MEMBER_CREATE', '위원 추가 — ' + committee.name + ' / ' + name, { target_type: 'committee_members', target_id: data?.id }).catch(() => {});
    }
    closeModal('memberModal');
    members = await loadMembers();
    renderMembers();
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function deleteMember(m) {
  if (!confirm(`"${m.member_name}" 위원을 삭제하시겠습니까?`)) return;
  try {
    showGlobalLoading('삭제 중...');
    const { error } = await supabaseClient.from('committee_members').delete().eq('id', m.id);
    if (error) throw new Error(error.message);
    systemLog('COMMITTEE_MEMBER_DELETE', '위원 삭제 — ' + committee.name + ' / ' + m.member_name, { target_type: 'committee_members', target_id: m.id }).catch(() => {});
    members = await loadMembers();
    renderMembers();
    showMessage('삭제되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '삭제 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   회의록 탭
══════════════════════════════════════════════ */
async function loadMeetings() {
  const { data, error } = await supabaseClient
    .from('committee_meetings').select('*, committee_meeting_files(*)')
    .eq('committee_id', committeeId).order('meeting_date', { ascending: false });
  if (error) throw new Error(error.message);
  return data || [];
}

let _meetingGridApi = null;

function renderMeetings() {
  if (!_meetingGridApi && !document.getElementById('panel-meetings').classList.contains('active')) return;
  const rows = meetings.map((m, idx) => ({ ...m, _idx: idx }));

  const colDefs = [
    { headerName: '회의일자', field: 'meeting_date', width: 110, valueFormatter: p => p.value || '-' },
    { headerName: '회차', field: 'meeting_no', width: 70, valueFormatter: p => p.value ? p.value + '회' : '-' },
    { headerName: '제목', field: 'agenda', flex: 1, minWidth: 200, headerClass: 'ag-left-header',
      valueFormatter: p => p.value || '(제목 없음)',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', fontWeight: 700 } },
    { headerName: '장소', field: 'location', width: 140, valueFormatter: p => p.value || '-' },
    { headerName: '첨부', width: 70,
      valueGetter: p => (p.data.committee_meeting_files || []).length || '-' },
    { headerName: '관리', width: 90, sortable: false,
      cellRenderer: p => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-sm';
        btn.textContent = '조회';
        btn.onclick = () => openMeetingView(meetings[p.data._idx]);
        return btn;
      } },
  ];

  if (!_meetingGridApi) {
    _meetingGridApi = createMgGrid('meetingGrid', colDefs, rows, {
      noRowsText: '등록된 회의록이 없습니다.',
    });
  } else {
    updateMgGrid(_meetingGridApi, rows);
  }
}

let _editingMeetingId = null;
let _pendingMeetingFiles = [];

function openMeetingAdd() {
  _editingMeetingId = null;
  _pendingMeetingFiles = [];
  document.getElementById('meetingModalTitle').textContent = '회의록 작성';
  setVal('mtf_meeting_date', ''); setVal('mtf_meeting_no', ''); setVal('mtf_location', '');
  setVal('mtf_attendees', ''); setVal('mtf_agenda', ''); setVal('mtf_content', '');
  document.getElementById('mtf_files').value = '';
  document.getElementById('mtf_existing_files').innerHTML = '';
  openModal('meetingModal');
}

function openMeetingEditForm(m) {
  _editingMeetingId = m.id;
  document.getElementById('meetingModalTitle').textContent = '회의록 수정';
  setVal('mtf_meeting_date', m.meeting_date || '');
  setVal('mtf_meeting_no', m.meeting_no || '');
  setVal('mtf_location', m.location || '');
  setVal('mtf_attendees', m.attendees || '');
  setVal('mtf_agenda', m.agenda || '');
  setVal('mtf_content', m.content_html || '');
  document.getElementById('mtf_files').value = '';
  const files = m.committee_meeting_files || [];
  document.getElementById('mtf_existing_files').innerHTML = files.length
    ? '<div style="font-size:11px;color:#6b7280;margin-bottom:2px;">기존 첨부 (새 파일을 추가로 첨부할 수 있어요):</div>' +
      files.map(f => `<span class="cmte-file-chip"><i class="ti ti-paperclip"></i>${ts(f.file_name)}</span>`).join('')
    : '';
  openModal('meetingModal');
}

async function openMeetingView(m) {
  const filesHtml = (m.committee_meeting_files || []).length
    ? await Promise.all(m.committee_meeting_files.map(async f => {
        const url = await db.getSignedUrl(BUCKET, f.storage_path, 3600, f.file_name);
        return `<div style="margin-top:4px;"><i class="ti ti-paperclip"></i> ${ts(f.file_name)} ${url ? `<a href="${url}" target="_blank" class="btn btn-sm" style="margin-left:6px;"><i class="ti ti-download"></i></a>` : ''}</div>`;
      })).then(arr => arr.join(''))
    : '<span style="color:#9ca3af;">첨부파일 없음</span>';

  const viewHtml = `
    <div style="padding:4px 0;">
      <div style="margin-bottom:10px;">
        <strong>${ts(m.meeting_date)}</strong> ${m.meeting_no ? '· ' + m.meeting_no + '회' : ''}
        ${m.location ? ' · ' + ts(m.location) : ''}
      </div>
      ${m.agenda ? `<div style="margin-bottom:8px;"><strong>제목</strong>: ${ts(m.agenda)}</div>` : ''}
      ${m.attendees ? `<div style="margin-bottom:8px;"><strong>참석자</strong>: ${ts(m.attendees)}</div>` : ''}
      <div class="cmte-meeting-body">${ts(m.content_html || '')}</div>
      <div style="margin-top:12px;padding-top:10px;border-top:1px solid #f1f5f9;">${filesHtml}</div>
    </div>`;

  openMeetingDetailModal(m, viewHtml);
}

function openMeetingDetailModal(m, bodyHtml) {
  // 간단한 동적 모달 구성 (별도 static modal 재사용)
  let dyn = document.getElementById('meetingViewModal');
  if (!dyn) {
    dyn = document.createElement('div');
    dyn.id = 'meetingViewModal';
    dyn.className = 'det-modal';
    dyn.innerHTML = `
      <div class="det-modal-backdrop" onclick="closeModal('meetingViewModal')"></div>
      <div class="det-modal-dialog det-modal-dialog--wide">
        <div class="det-modal-head">
          <div class="det-modal-head-left">
            <div class="det-modal-icon det-modal-icon--history"><i class="ti ti-notes"></i></div>
            <div><div class="det-modal-title" id="meetingViewTitle">회의록 상세</div></div>
          </div>
          <button type="button" class="det-modal-close" onclick="closeModal('meetingViewModal')"><i class="ti ti-x"></i></button>
        </div>
        <div class="det-modal-body" id="meetingViewBody"></div>
        <div class="det-modal-foot">
          <button type="button" class="btn btn-sm" id="meetingViewEditBtn" style="margin-right:auto;display:none;">수정</button>
          <button type="button" class="btn btn-sm btn-danger" id="meetingViewDeleteBtn" style="display:none;">삭제</button>
          <button type="button" class="btn btn-sm btn-primary" onclick="closeModal('meetingViewModal')">닫기</button>
        </div>
      </div>`;
    document.body.appendChild(dyn);
  }
  document.getElementById('meetingViewTitle').textContent = (m.meeting_no ? m.meeting_no + '회 · ' : '') + (m.agenda || '회의록 상세');
  document.getElementById('meetingViewBody').innerHTML = bodyHtml;

  const editBtn = document.getElementById('meetingViewEditBtn');
  const delBtn = document.getElementById('meetingViewDeleteBtn');
  editBtn.style.display = canAddMeeting ? '' : 'none';
  editBtn.onclick = () => { closeModal('meetingViewModal'); openMeetingEditForm(m); };
  delBtn.style.display = canDelete ? '' : 'none';
  delBtn.onclick = () => { closeModal('meetingViewModal'); deleteMeeting(m); };

  openModal('meetingViewModal');
}

async function saveMeeting() {
  const meetingDate = val('mtf_meeting_date');
  if (!meetingDate) { showMessage('회의일자는 필수입니다.', 'warning'); return; }

  const payload = {
    meeting_date: meetingDate,
    meeting_no: val('mtf_meeting_no') ? Number(val('mtf_meeting_no')) : null,
    location: val('mtf_location'),
    attendees: val('mtf_attendees'),
    agenda: val('mtf_agenda'),
    content_html: val('mtf_content'),
    updated_at: new Date().toISOString(),
  };

  try {
    showGlobalLoading('저장 중...');
    let meetingId = _editingMeetingId;

    if (meetingId) {
      const { error } = await supabaseClient.from('committee_meetings').update(payload).eq('id', meetingId);
      if (error) throw new Error(error.message);
      systemLog('COMMITTEE_MEETING_UPDATE', '회의록 수정 — ' + committee.name + ' / ' + meetingDate, { target_type: 'committee_meetings', target_id: meetingId }).catch(() => {});
    } else {
      payload.committee_id = committeeId;
      payload.created_by = currentUser?.email || currentUser?.user_name || '';
      const { data, error } = await supabaseClient.from('committee_meetings').insert(payload).select().single();
      if (error) throw new Error(error.message);
      meetingId = data.id;
      systemLog('COMMITTEE_MEETING_CREATE', '회의록 작성 — ' + committee.name + ' / ' + meetingDate, { target_type: 'committee_meetings', target_id: meetingId }).catch(() => {});
    }

    // 첨부파일 업로드
    const fileInput = document.getElementById('mtf_files');
    const files = fileInput.files ? Array.from(fileInput.files) : [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const up = await db.uploadFile(BUCKET, f, meetingId);
      await supabaseClient.from('committee_meeting_files').insert({
        meeting_id: meetingId, file_name: up.name, storage_path: up.path, file_size: up.size, sort_order: i,
      });
    }

    closeModal('meetingModal');
    meetings = await loadMeetings();
    renderMeetings();
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function deleteMeeting(m) {
  if (!confirm('이 회의록을 삭제하시겠습니까? 첨부파일도 함께 삭제됩니다.')) return;
  try {
    showGlobalLoading('삭제 중...');
    for (const f of (m.committee_meeting_files || [])) {
      await db.deleteFile(BUCKET, f.storage_path);
    }
    const { error } = await supabaseClient.from('committee_meetings').delete().eq('id', m.id);
    if (error) throw new Error(error.message);
    systemLog('COMMITTEE_MEETING_DELETE', '회의록 삭제 — ' + committee.name + ' / ' + m.meeting_date, { target_type: 'committee_meetings', target_id: m.id }).catch(() => {});
    meetings = await loadMeetings();
    renderMeetings();
    showMessage('삭제되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '삭제 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   리치텍스트 툴바 (규정 조항 편집기)
══════════════════════════════════════════════ */
/* ══════════════════════════════════════════════
   초기화
══════════════════════════════════════════════ */
async function init() {
  ['mf_term_start', 'mf_term_end', 'mtf_meeting_date'].forEach(mountCustomDateInput);
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'committee/list')) {
    showMessage('이 페이지에 접근할 권한이 없습니다.', 'error');
    parent.shellNavigate?.('home/home');
    return;
  }
  canEdit = window.PagePerms.atLeast(currentUser, 'committee/list', 'manager');
  canDelete = window.PagePerms.atLeast(currentUser, 'committee/list', 'admin');

  committeeId = getCommitteeIdFromUrl();
  if (!committeeId) { showMessage('위원회 ID가 없습니다.', 'error'); return; }

  initTabs();

  if (canEdit) {
    document.getElementById('editCommitteeBtn').style.display = '';
    document.getElementById('editCommitteeBtn').addEventListener('click', openEditCommittee);
  }
  document.getElementById('linkRegulationBtn').addEventListener('click', openLinkRegulationModal);
  document.getElementById('addMemberBtn').addEventListener('click', openMemberAdd);
  document.getElementById('addMeetingBtn').addEventListener('click', openMeetingAdd);

  document.getElementById('committeeModalSave')?.addEventListener('click', saveCommitteeInfo);
  document.getElementById('lr_search_btn')?.addEventListener('click', searchRegulationsToLink);
  document.getElementById('lr_search')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchRegulationsToLink(); } });
  document.getElementById('memberModalSave')?.addEventListener('click', saveMember);
  document.getElementById('mf_user_search_btn')?.addEventListener('click', searchMemberUsers);
  document.getElementById('mf_user_search')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchMemberUsers(); } });
  document.getElementById('meetingModalSave')?.addEventListener('click', saveMeeting);

  showGlobalLoading('불러오는 중...');
  try {
    committee = await loadCommittee();
    renderCommitteeHead();
    [linkedRegulations, members, meetings] = await Promise.all([loadLinkedRegulations(), loadMembers(), loadMeetings()]);

    // 이 위원회에 간사로 연동된 계정이면, 전체 manager 권한이 없어도 회의록은 등록·수정할 수 있다.
    const isSecretary = members.some(m => m.position === '간사' && m.user_id === currentUser.id);
    canAddMeeting = canEdit || isSecretary;
    updateActionbarForTab('regulation'); // 기본 활성 탭에 맞춰 액션바 버튼 노출 (규정 연결만 보임)

    renderLinkedRegulations();
    renderMembers();
    renderMeetings();
  } catch (e) {
    showMessage(e.message || '조회 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

document.addEventListener('DOMContentLoaded', init);