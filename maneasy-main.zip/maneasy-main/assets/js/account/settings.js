'use strict';

var currentUser = null;
var ROLE_LABEL = { user: '일반', manager: '팀장급', admin: '관리자' };

function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ''; }
function setText(id, v) { var el = document.getElementById(id); if (el) el.textContent = v ?? '-'; }

async function loadProfile() {
  setVal('prof_name', currentUser.user_name);
  setVal('prof_phone', currentUser.phone);
  setVal('prof_email', currentUser.email);
  setText('info_org', currentUser.org_name || '-');
  setText('info_dept', currentUser.department || '-');
  setText('info_role', ROLE_LABEL[currentUser.role] || currentUser.role || '-');
}

async function saveProfile() {
  var name = val('prof_name');
  if (!name) { alert('이름을 입력해 주세요.'); return; }
  var btn = document.getElementById('profSaveBtn');
  btn.disabled = true;
  try {
    var { error } = await supabaseClient
      .from('profiles')
      .update({ user_name: name, phone: val('prof_phone') || null })
      .eq('id', currentUser.id);
    if (error) throw new Error(error.message);
    alert('저장되었습니다.');
  } catch (e) {
    alert('저장 실패: ' + e.message);
  } finally {
    btn.disabled = false;
  }
}

async function changePassword() {
  var pw1 = val('pw_new'), pw2 = val('pw_confirm');
  if (!pw1 || pw1.length < 8) { alert('비밀번호는 8자 이상이어야 합니다.'); return; }
  if (pw1 !== pw2) { alert('두 비밀번호가 서로 다릅니다.'); return; }
  var btn = document.getElementById('pwSaveBtn');
  btn.disabled = true;
  try {
    var { error } = await supabaseClient.auth.updateUser({ password: pw1 });
    if (error) throw new Error(error.message);
    setVal('pw_new', ''); setVal('pw_confirm', '');
    alert('비밀번호가 변경되었습니다. 다음 로그인부터 새 비밀번호를 사용해 주세요.');
  } catch (e) {
    alert('변경 실패: ' + e.message);
  } finally {
    btn.disabled = false;
  }
}

async function init() {
  var session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'account/settings')) {
    hideGlobalLoading();
    alert('이 페이지에 접근할 권한이 없습니다.');
    location.replace('../home/home.html');
    return;
  }

  await loadProfile();

  document.getElementById('profSaveBtn')?.addEventListener('click', saveProfile);
  document.getElementById('pwSaveBtn')?.addEventListener('click', changePassword);

  hideGlobalLoading();
}

document.addEventListener('DOMContentLoaded', init);