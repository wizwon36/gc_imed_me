import { createRichEditor, insertTablePreset as _insertTablePreset } from '../core/rich-editor.js';

'use strict';

var currentUser = null;
var myOrgMemberId = null;
var myClinicId = null, myDeptId = null;
var editor = null;
var currentDocId = null;          // 편집 중인 문서 id (null이면 아직 저장 전 신규)
var currentTemplateId = null;     // 현재 작성 화면에 적용된 양식 id
var templates = [];
var docCategories = [];
var personalLines = [];
var manualSteps = [];             // [{ decision_rule, step_type, approvers:[{id,name}] }]
var watchers = [];                // [{ id, name, type:'REF'|'CIRCULATE' }]
var orgMembers = [];              // 결재선 수동 지정용 전체 구성원 목록
var myDocuments = [];
var currentStatusFilter = '';
var collapsedGroups = {}; // 그룹 헤더 접힘 상태 저장(카테고리 id 또는 'uncategorized' 기준)
var leaveMode = false;            // true면 현재 작성 화면이 "연차 신청" 모드
var leaveTypes = [];               // 신청 가능한(활성) 연차 유형 목록

/* ── 첨부파일 ── */
var MAX_ATTACH_SINGLE = 10 * 1024 * 1024; // 파일당 10MB
var MAX_ATTACH_TOTAL  = 20 * 1024 * 1024; // 전체 20MB
var pendingFiles  = []; // 아직 서버에 안 올라간 파일 — [{ file }]. 저장(임시저장/상신) 시점에 업로드된다.
var existingFiles = []; // 이미 DB/스토리지에 올라가 있는 첨부 — [{ id, file_name, storage_path, file_size }]

function fmtAttachSize(b) { return b < 1024 * 1024 ? (b / 1024).toFixed(0) + 'KB' : (b / (1024 * 1024)).toFixed(1) + 'MB'; }

function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v; }
function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function showLoading(text) {
  var el = document.getElementById('globalLoading');
  var t = document.getElementById('globalLoadingText');
  if (t && text) t.textContent = text;
  if (el) el.classList.add('is-open');
}
function hideLoading() {
  var el = document.getElementById('globalLoading');
  if (el) el.classList.remove('is-open');
}

var STATUS_LABEL = { DRAFT: '임시저장', IN_PROGRESS: '결재중', APPROVED: '승인완료', REJECTED: '반려', CANCELED: '취소' };
var STATUS_BADGE = { DRAFT: 'badge-blue', IN_PROGRESS: 'badge-yellow', APPROVED: 'badge-green', REJECTED: 'badge-red', CANCELED: 'badge-blue' };

/* ── init ── */
async function init() {
  ['aprLeaveStart', 'aprLeaveEnd', 'aprDocDateFrom', 'aprDocDateTo'].forEach(mountCustomDateInput);
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'approval/draft')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    await resolveMyContext();
    if (!myOrgMemberId) {
      hideLoading();
      document.querySelector('.master-page').innerHTML =
        '<div class="m-card" style="text-align:center;color:#6b7280;font-size:13px;padding:40px;">' +
        (currentUser.is_preview
          ? '플랫폼 관리자의 "의원 미리보기" 모드에서는 전자결재를 사용할 수 없습니다.<br>실제 소속 구성원 계정으로 로그인해주세요.'
          : '소속 구성원 정보를 확인할 수 없어 전자결재를 사용할 수 없습니다.<br>관리자에게 문의해주세요.') +
        '</div>';
      return;
    }
    await loadCategories();
    await Promise.all([loadTemplates(), loadPersonalLines(), loadOrgMembers(), loadLeaveTypesForDraft()]);
    setDefaultDocDateRange();
    bindUi();
    await loadMyDocuments();
    hideLoading();

    // 문서 상세 페이지(doc-detail.html)에서 "목록으로"/"이어서 작성"으로 돌아왔을 때 처리
    var params = new URLSearchParams(location.search);
    var continueId = params.get('continue');
    if (continueId) {
      await continueDraft(continueId);
    } else if (params.get('resubmit')) {
      await resubmitFrom(params.get('resubmit'));
    } else if (params.get('new') === 'leave') {
      startNewLeaveDoc(params.get('start'));
    } else if (params.get('tab') === 'mydocs') {
      switchMainTab('mydocs');
    }
  } catch (e) {
    console.error('[approval/draft] 초기화 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 문제가 발생했습니다: ' + e.message);
  }
}

/** org_members.id(PK) 및 clinic_id/dept_id(uuid) 확보 — getSession()엔 코드값만 있어서 별도 조회 필요.
 *  플랫폼 관리자가 "의원 미리보기"로 들어온 경우엔 실제 org_members 행이 없어서 못 찾는 게 정상이다. */
async function resolveMyContext() {
  if (!currentUser.org_member_id) { console.warn('[approval/draft] org_member_id 없음'); return; }
  var { data, error } = await supabaseClient
    .from('org_members')
    .select('id, clinic_id, dept_id')
    .eq('id', currentUser.org_member_id)
    .maybeSingle();
  if (error) { console.error('[approval/draft] resolveMyContext 조회 오류:', error); return; }
  if (!data) { console.warn('[approval/draft] org_members 행 없음 — 미리보기 계정일 수 있음 (is_preview=' + currentUser.is_preview + ')'); return; }
  myOrgMemberId = data.id;
  myClinicId = data.clinic_id;
  myDeptId = data.dept_id;
}

var tplDeptMap = {}; // template_id -> [dept_id, ...] (approval_doc_template_departments)

async function loadTemplates() {
  var query = supabaseClient
    .from('approval_doc_templates')
    .select('id, name, content_html, doc_type, category_id, clinic_id')
    .eq('org_id', currentUser.org_id).eq('active', true);
  // 양식은 이제 항상 특정 의원 소속이라, 내 의원 것만 서버 단에서 걸러서 가져온다.
  // myClinicId가 없는 경우(플랫폼 관리자의 "의원 미리보기" 등 org_members 행이 없는 계정)는
  // 필터를 걸지 않고 조직 내 전체를 보여준다.
  if (myClinicId) query = query.eq('clinic_id', myClinicId);
  var { data, error } = await query.order('name');
  if (error) { console.error('[approval/draft] approval_doc_templates 조회 실패:', error); templates = []; }
  else templates = data || [];

  tplDeptMap = {};
  if (templates.length) {
    var ids = templates.map(function(t) { return t.id; });
    var { data: links, error: linkErr } = await supabaseClient
      .from('approval_doc_template_departments')
      .select('template_id, dept_id')
      .in('template_id', ids);
    if (linkErr) console.error('[approval/draft] approval_doc_template_departments 조회 실패:', linkErr);
    (links || []).forEach(function(l) {
      if (!tplDeptMap[l.template_id]) tplDeptMap[l.template_id] = [];
      tplDeptMap[l.template_id].push(l.dept_id);
    });
  }
  renderTemplateList();
}

async function loadCategories() {
  var { data, error } = await supabaseClient
    .from('approval_doc_categories')
    .select('id, parent_id, name, sort_order')
    .eq('org_id', currentUser.org_id).eq('active', true)
    .order('sort_order');
  if (error) { console.error('[approval/draft] approval_doc_categories 조회 실패:', error); docCategories = []; }
  else docCategories = data || [];
  // 페이지 진입 시엔 목록을 접은 상태로 보여준다 — 사용자가 펼친 뒤로는 그 상태를 유지.
  docCategories.forEach(function(c) { collapsedGroups[c.id] = true; });
  collapsedGroups['uncategorized'] = true;
}

/** 내가 볼 수 있는 양식만 필터(양식은 이미 내 의원 것만 불러온 상태 — 여기선 부서만 확인) + 검색어 필터 */
function myVisibleTemplates() {
  var q = (document.getElementById('aprTemplateSearch')?.value || '').trim().toLowerCase();
  return templates.filter(function(t) {
    var deptIds = tplDeptMap[t.id];
    var scopeOk = !deptIds || !deptIds.length || deptIds.indexOf(myDeptId) !== -1; // 지정된 부서가 없으면 전체 공개
    var searchOk = !q || (t.name || '').toLowerCase().indexOf(q) !== -1;
    return scopeOk && searchOk;
  });
}

function renderTemplateList() {
  var list = document.getElementById('aprTemplateList');
  var visible = myVisibleTemplates();
  if (!visible.length) { list.innerHTML = '<div class="apr-empty" style="padding:20px 8px;">등록된 결재 양식이 없습니다.<br>관리자에게 문의해주세요.</div>'; return; }

  function templateItemHtml(t, depth) {
    return '<div class="apr-list-item' + (t.id === currentTemplateId ? ' active' : '') + '" data-id="' + t.id + '" style="padding-left:' + (20 + depth * 10) + 'px;">' +
      '<div class="name">' + ts(t.name) + '</div>' +
    '</div>';
  }

  function renderNode(cat, depth) {
    var children = docCategories.filter(function(c) { return c.parent_id === cat.id; });
    var myTemplates = visible.filter(function(t) { return t.category_id === cat.id; });
    if (!children.length && !myTemplates.length) return ''; // 빈 분류는 안 보여줌
    var collapsed = !!collapsedGroups[cat.id];
    var header = '<div class="apr-group-header" data-group="' + cat.id + '" style="padding-left:' + (12 + depth * 10) + 'px;">' +
      '<span><span class="apr-group-arrow">' + (collapsed ? '▸' : '▾') + '</span> ' + ts(cat.name) + ' <span class="count">(' + myTemplates.length + ')</span></span>' +
    '</div>';
    var body = '<div class="apr-group-children" data-group-children="' + cat.id + '" style="display:' + (collapsed ? 'none' : '') + ';">' +
      children.map(function(c) { return renderNode(c, depth + 1); }).join('') +
      myTemplates.map(function(t) { return templateItemHtml(t, depth); }).join('') +
    '</div>';
    return header + body;
  }

  var topCategories = docCategories.filter(function(c) { return !c.parent_id; });
  var uncategorized = visible.filter(function(t) { return !t.category_id; });

  var html = topCategories.map(function(c) { return renderNode(c, 0); }).join('');
  if (uncategorized.length) {
    if (topCategories.length) {
      var uCollapsed = !!collapsedGroups['uncategorized'];
      html += '<div class="apr-group-header" data-group="uncategorized">' +
        '<span><span class="apr-group-arrow">' + (uCollapsed ? '▸' : '▾') + '</span> 미분류 <span class="count">(' + uncategorized.length + ')</span></span>' +
      '</div>' +
      '<div class="apr-group-children" data-group-children="uncategorized" style="display:' + (uCollapsed ? 'none' : '') + ';">' +
        uncategorized.map(function(t) { return templateItemHtml(t, 0); }).join('') +
      '</div>';
    } else {
      html += uncategorized.map(function(t) { return templateItemHtml(t, 0); }).join('');
    }
  }
  list.innerHTML = html;
  list.querySelectorAll('.apr-group-header').forEach(function(h) {
    h.addEventListener('click', function() {
      var gid = h.dataset.group;
      collapsedGroups[gid] = !collapsedGroups[gid];
      renderTemplateList();
    });
  });
  list.querySelectorAll('.apr-list-item').forEach(function(item) {
    item.addEventListener('click', function() { onTemplateClick(item.dataset.id); });
  });
}

function onTemplateClick(templateId) {
  var composing = document.getElementById('aprComposeWrap').style.display !== 'none';
  if (composing && !leaveMode && currentTemplateId === templateId) return; // 이미 선택된 양식 재클릭 — 아무 것도 안 함(내용 보존)
  if (composing && (leaveMode || (currentTemplateId && currentTemplateId !== templateId))) {
    if (!confirm('다른 양식을 선택하면 현재 작성 중인 내용이 새 양식으로 교체됩니다. 계속할까요?')) return;
  }
  startNewDoc(templateId);
}

async function loadOrgMembers() {
  var { data, error } = await supabaseClient.from('org_members_detail').select('id, user_name, role, clinic_id, dept_id, clinic_name, dept_name').eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false);
  if (error) { console.error('[approval/draft] org_members_detail 조회 실패:', error); orgMembers = []; return; }
  orgMembers = data || [];
}

/** 연차신청 모드 — 신청 가능한(활성) 연차 유형 목록. 소속 의원 전용 유형이 있으면 그걸, 없으면 공통 유형을 쓴다. */
async function loadLeaveTypesForDraft() {
  try {
    var { data, error } = await supabaseClient.from('leave_types').select('*').eq('org_id', currentUser.org_id).eq('active', true);
    if (error) throw new Error(error.message);
    var all = data || [];
    var scoped = myClinicId ? all.filter(function(t) { return t.clinic_id === myClinicId; }) : [];
    leaveTypes = (scoped.length ? scoped : all.filter(function(t) { return !t.clinic_id; })).sort(function(a, b) { return a.sort_order - b.sort_order; });
  } catch (e) {
    console.error('[approval/draft] loadLeaveTypesForDraft 실패:', e);
    leaveTypes = [];
  }
}

/* ── 리치 에디터(Tiptap) ── */
async function initEditor(initialData) {
  if (editor) { editor.setData(initialData || ''); return; }
  editor = await createRichEditor(document.getElementById('aprEditor'), initialData);
}

function insertTablePreset(key) { _insertTablePreset(editor, key); }
function bindUi() {
  document.querySelectorAll('#aprMainTabs button').forEach(function(btn) {

    btn.addEventListener('click', function() { switchMainTab(btn.dataset.tab); });
  });

  document.getElementById('aprSaveDraftBtn').addEventListener('click', function() { saveDraft(false); });
  document.getElementById('aprSubmitBtn').addEventListener('click', submitCurrentDoc);
  bindAttachInput();
  document.getElementById('aprNewLeaveBtn').addEventListener('click', function() {
    var composing = document.getElementById('aprComposeWrap').style.display !== 'none';
    if (composing && leaveMode) return; // 이미 연차신청 모드 — 그대로 둠
    if (composing && !confirm('다른 양식을 선택하면 현재 작성 중인 내용이 새 양식으로 교체됩니다. 계속할까요?')) return;
    startNewLeaveDoc();
  });
  ['aprLeaveType', 'aprLeaveStart', 'aprLeaveEnd'].forEach(function(id) {
    document.getElementById(id).addEventListener('change', updateLeaveDraftDaysPreview);
  });
  document.querySelectorAll('.apr-table-presets button[data-preset]').forEach(function(b) {
    b.addEventListener('click', function() { insertTablePreset(b.dataset.preset); });
  });
  document.getElementById('aprPersonalLineSelect').addEventListener('change', function() {
    if (this.value) applyPersonalLine(this.value);
    this.value = '';
  });
  document.getElementById('aprSavePersonalLineBtn').addEventListener('click', savePersonalLineAs);
  document.getElementById('aprManagePersonalLineBtn').addEventListener('click', openPersonalLineModal);

  // 사람 선택 피커
  document.getElementById('aprPersonPickerCloseBtn').addEventListener('click', closePersonPicker);
  document.getElementById('aprPersonPickerConfirmBtn').addEventListener('click', confirmPersonPickerMulti);
  document.getElementById('aprPersonSearch').addEventListener('input', function() { renderPersonTree(this.value); });

  document.querySelectorAll('#aprStatusTabs button').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('#aprStatusTabs button').forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      currentStatusFilter = btn.dataset.status;
      loadMyDocuments();
    });
  });

  document.getElementById('aprTemplateSearch').addEventListener('input', renderTemplateList);
  document.getElementById('aprDocSearch').addEventListener('input', function() {
    if (myDocsGrid) myDocsGrid.setGridOption('quickFilterText', this.value);
  });
  document.getElementById('aprDocDateFrom').addEventListener('change', renderMyDocuments);
  document.getElementById('aprDocDateTo').addEventListener('change', renderMyDocuments);
  document.getElementById('aprDocSearchBtn').addEventListener('click', renderMyDocuments);
}

/** 문서함 날짜 필터 기본값 — 최근 1주일 */
function setDefaultDocDateRange() {
  var today = new Date();
  var weekAgo = new Date(today);
  weekAgo.setDate(today.getDate() - 7);
  document.getElementById('aprDocDateFrom').value = localDateStr(weekAgo);
  document.getElementById('aprDocDateTo').value = localDateStr(today);
}

function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.closeModal = closeModal; // 모달 배경/닫기 버튼의 inline onclick="closeModal(...)"에서 사용 (이 파일은 type="module"이라 전역에 명시적으로 노출해야 함)

function switchMainTab(tab) {
  document.querySelectorAll('#aprMainTabs button').forEach(function(b) { b.classList.toggle('active', b.dataset.tab === tab); });
  document.getElementById('tab-compose').classList.toggle('active', tab === 'compose');
  document.getElementById('tab-mydocs').classList.toggle('active', tab === 'mydocs');
  if (tab === 'mydocs') loadMyDocuments();
}

// updateLineSummary()/updateWatcherSummary()는 "결재선: ..." 요약 문구를 모달 밖에 접어서
// 보여주던 시절의 함수였다 — 이제 결재선/참조·회람을 화면에 항상 펼쳐두므로 별도 요약이
// 필요 없어져 제거했다(호출부는 그대로 남겨도 안전하도록 no-op으로 유지).
function updateLineSummary() {}
function updateWatcherSummary() {}

/* ── 사람 검색/선택 피커 (결재자·참조·회람 공용) ── */
var personPickerOnSelect = null;
var personPickerExcludeIds = [];
var personPickerMulti = false;
var personPickerSelected = []; // 다중선택 모드에서 지금까지 고른 id 목록

/** multi=true면 체크박스로 여러 명 골라서 "선택 완료"로 한 번에 넘긴다(onSelect가 배열을 받음).
 *  생략(단일선택, 기존과 동일)이면 클릭 즉시 한 명만 넘기고 모달이 닫힌다. */
function openPersonPicker(title, onSelect, excludeIds, multi) {
  document.getElementById('aprPersonPickerTitle').innerHTML = '<i class="ti ti-users"></i>' + ts(title);
  personPickerOnSelect = onSelect;
  personPickerExcludeIds = excludeIds || [];
  personPickerMulti = !!multi;
  personPickerSelected = [];
  document.getElementById('aprPersonSearch').value = '';
  document.getElementById('aprPersonPickerFoot').style.display = personPickerMulti ? 'flex' : 'none';
  updatePersonPickerCount();
  renderPersonTree('');
  openModal('aprPersonPickerModal');
  document.getElementById('aprPersonSearch').focus();
}
function closePersonPicker() {
  closeModal('aprPersonPickerModal');
  personPickerOnSelect = null;
  personPickerSelected = [];
}
function pickPerson(memberId) {
  if (personPickerMulti) {
    var i = personPickerSelected.indexOf(memberId);
    if (i === -1) personPickerSelected.push(memberId); else personPickerSelected.splice(i, 1);
    renderPersonTree(document.getElementById('aprPersonSearch').value);
    updatePersonPickerCount();
    return;
  }
  var cb = personPickerOnSelect;
  closePersonPicker();
  if (cb) cb(memberId);
}
function updatePersonPickerCount() {
  var el = document.getElementById('aprPersonPickerCount');
  if (el) el.textContent = personPickerSelected.length ? personPickerSelected.length + '명 선택됨' : '';
}
function confirmPersonPickerMulti() {
  var cb = personPickerOnSelect;
  var ids = personPickerSelected.slice();
  closePersonPicker();
  if (cb && ids.length) cb(ids);
}

function renderPersonTree(filterText) {
  var box = document.getElementById('aprPersonTree');
  var q = (filterText || '').trim().toLowerCase();
  var pool = orgMembers.filter(function(m) { return personPickerExcludeIds.indexOf(m.id) === -1; });
  var matched = q ? pool.filter(function(m) { return (m.user_name || '').toLowerCase().indexOf(q) !== -1; }) : pool;

  function personRow(m) {
    var selected = personPickerMulti && personPickerSelected.indexOf(m.id) !== -1;
    var checkbox = personPickerMulti
      ? '<input type="checkbox" class="apr-person-check" ' + (selected ? 'checked' : '') + ' />'
      : '';
    return '<div class="apr-person-row' + (selected ? ' is-selected' : '') + '" data-id="' + m.id + '">' + checkbox + ts(m.user_name) +
      (m.role ? '<span class="role-tag">' + ts(m.role) + '</span>' : '') + '</div>';
  }

  var html;
  if (q) {
    // 검색 중엔 트리 없이 매칭 결과만 평평하게 보여준다.
    html = matched.length
      ? matched.map(personRow).join('')
      : '<div class="apr-empty" style="padding:16px;">검색 결과가 없습니다.</div>';
  } else {
    // 의원 > 부서 트리로 묶어서 보여준다.
    var clinicNames = [...new Set(matched.map(function(m) { return m.clinic_name || '(소속 없음)'; }))];
    html = clinicNames.map(function(clinicName) {
      var clinicMembers = matched.filter(function(m) { return (m.clinic_name || '(소속 없음)') === clinicName; });
      var deptNames = [...new Set(clinicMembers.map(function(m) { return m.dept_name || '(부서 없음)'; }))];
      var deptHtml = deptNames.map(function(deptName) {
        var deptMembers = clinicMembers.filter(function(m) { return (m.dept_name || '(부서 없음)') === deptName; });
        return '<details class="apr-tree-group" open><summary>' + ts(deptName) + '</summary>' +
          '<div class="apr-tree-children">' + deptMembers.map(personRow).join('') + '</div></details>';
      }).join('');
      return '<details class="apr-tree-group" open><summary>' + ts(clinicName) + '</summary>' +
        '<div class="apr-tree-children">' + deptHtml + '</div></details>';
    }).join('') || '<div class="apr-empty" style="padding:16px;">선택 가능한 사람이 없습니다.</div>';
  }

  box.innerHTML = html;
  box.querySelectorAll('.apr-person-row').forEach(function(row) {
    row.addEventListener('click', function() { pickPerson(row.dataset.id); });
  });
}

/* ── 새 기안서 시작 (양식 선택 시 호출) ── */
function startNewDoc(templateId) {
  currentDocId = null;
  currentTemplateId = templateId;
  leaveMode = false;
  manualSteps = defaultManualSteps();
  watchers = [];
  pendingFiles = [];
  existingFiles = [];
  renderAttachChips();
  setVal('aprTitle', '');
  var tpl = templates.find(function(t) { return t.id === templateId; });
  document.getElementById('aprComposeEmptyMsg').style.display = 'none';
  document.getElementById('aprComposeWrap').style.display = '';
  document.getElementById('aprComposeHeaderActions').style.display = 'flex';
  document.getElementById('aprGeneralFieldsWrap').style.display = '';
  document.getElementById('aprLeaveFieldsWrap').style.display = 'none';
  document.getElementById('aprSaveDraftBtn').style.display = '';
  document.getElementById('aprSubmitBtn').innerHTML = '<i class="ti ti-send"></i> 상신';
  document.getElementById('aprNewLeaveBtn').classList.remove('active');
  initEditor(tpl ? tpl.content_html : '');
  renderTemplateList();
  renderManualSteps();
  renderWatchers();
  updateLineSummary();
  updateWatcherSummary();
}

/** 연차신청 모드 — 기안 화면을 그대로 쓰되, 본문 에디터 대신 구조화된 연차 입력 폼을 보여준다.
 *  결재선(수동 지정)/참조·회람 패널, 상신 로직은 일반 기안과 동일하게 재사용한다. */
function startNewLeaveDoc(prefillStart) {
  currentDocId = null;
  currentTemplateId = null;
  leaveMode = true;
  manualSteps = defaultManualSteps();
  watchers = [];

  document.getElementById('aprComposeEmptyMsg').style.display = 'none';
  document.getElementById('aprComposeWrap').style.display = '';
  document.getElementById('aprComposeHeaderActions').style.display = 'flex';
  document.getElementById('aprGeneralFieldsWrap').style.display = 'none';
  document.getElementById('aprLeaveFieldsWrap').style.display = '';
  document.getElementById('aprSaveDraftBtn').style.display = 'none';
  document.getElementById('aprSubmitBtn').innerHTML = '<i class="ti ti-send"></i> 신청';

  var typeSel = document.getElementById('aprLeaveType');
  if (!leaveTypes.length) {
    typeSel.innerHTML = '<option value="">사용 가능한 연차 유형이 없습니다 — 관리자에게 문의하세요</option>';
  } else {
    typeSel.innerHTML = leaveTypes.map(function(t) {
      return '<option value="' + t.id + '">' + ts(t.name) + (t.deduction_ratio === 0 ? ' (차감 없음)' : t.deduction_ratio < 1 ? ' (' + t.deduction_ratio + '일 차감)' : '') + '</option>';
    }).join('');
  }
  var today = prefillStart || localDateStr(new Date());
  setVal('aprLeaveStart', today);
  setVal('aprLeaveEnd', today);
  setVal('aprLeaveReason', '');
  updateLeaveDraftDaysPreview();

  renderTemplateList();
  renderManualSteps();
  renderWatchers();
  updateLineSummary();
  updateWatcherSummary();
  document.getElementById('aprNewLeaveBtn').classList.add('active');
}

function selectedLeaveTypeForDraft() {
  var id = val('aprLeaveType');
  return leaveTypes.find(function(t) { return t.id === id; }) || null;
}

function computeLeaveDraftDays() {
  var start = val('aprLeaveStart'), end = val('aprLeaveEnd');
  var type = selectedLeaveTypeForDraft();
  if (!start || !end || !type) return null;
  // 반차/반반차 등(0 < ratio < 1)만 단일일 제한 — 무급휴가처럼 ratio가 0인 유형은
  // 차감이 없을 뿐 여러 날짜에 걸쳐 신청할 수 있어야 한다.
  if (type.deduction_ratio > 0 && type.deduction_ratio < 1) return start === end ? type.deduction_ratio : null;
  var d1 = new Date(start), d2 = new Date(end);
  if (d2 < d1) return null;
  var calendarDays = Math.round((d2 - d1) / 86400000) + 1;
  return calendarDays * type.deduction_ratio;
}

function updateLeaveDraftDaysPreview() {
  var days = computeLeaveDraftDays();
  var el = document.getElementById('aprLeaveDaysPreview');
  var type = selectedLeaveTypeForDraft();
  if (!el) return;
  if (days == null) el.textContent = (type && type.deduction_ratio > 0 && type.deduction_ratio < 1) ? '이 유형은 시작일과 종료일이 같아야 합니다.' : '날짜를 확인해주세요.';
  else el.textContent = days === 0 ? '연차 차감 없음(무급)' : '차감될 연차: ' + days + '일';
}

/** 직접 지정 기본값: 1단계=기안자 본인(자동, 상신 시 자동 승인), 2단계=빈칸 */
function defaultManualSteps() {
  var me = orgMembers.find(function(o) { return o.id === myOrgMemberId; });
  var myName = me ? me.user_name : (currentUser.user_name || '나');
  return [
    { decision_rule: 'ALL', step_type: 'APPROVE', approvers: [{ id: myOrgMemberId, name: myName }] },
    { decision_rule: 'ALL', step_type: 'APPROVE', approvers: [] },
  ];
}

/* ── 결재선: 수동 지정 ── */
/** atIndex 생략 시 맨 끝에 추가, 지정하면 그 위치에 끼워넣는다 */
function addManualStep(atIndex) {
  var idx = (atIndex == null) ? manualSteps.length : atIndex;
  manualSteps.splice(idx, 0, { decision_rule: 'ALL', step_type: 'APPROVE', approvers: [] });
  renderManualSteps(idx);
}
function renderManualSteps(focusIdx) {
  var wrap = document.getElementById('aprManualSteps');

  var colsHtml = '';
  manualSteps.forEach(function(step, idx) {
    // "잠금(고정)" 칸 = 1단계이면서 결재자가 기안자 본인 1명뿐인 경우 — 자동 배정된
    // 기안자 칸으로 보고 삭제/재지정을 막는다(상신 시 자동 승인 로직과 짝을 이룸).
    var locked = idx === 0 && step.approvers.length === 1 && step.approvers[0].id === myOrgMemberId;

    var chips = step.approvers.map(function(a, ai) {
      return '<div class="apr-line-approver-chip' + (locked ? ' locked' : '') + '">' + ts(a.name) +
        (locked ? '' : '<button data-step="' + idx + '" data-ai="' + ai + '" class="apr-chip-del">&times;</button>') +
      '</div>';
    }).join('');
    // 한 칸에 한 명 — 비어있으면 그 자리에 "결재자 선택" 버튼을, 있으면 칩을 보여준다(둘 다
    // body 안에서 자리를 대신하는 관계라, 채워지든 비어있든 칸 높이가 그대로 유지된다).
    var addBtn = '<button type="button" class="apr-add-approver-btn" data-step="' + idx + '"><i class="ti ti-plus"></i> 결재자 선택</button>';
    var body = chips || (locked ? '<div class="apr-line-empty-hint">결재자를 선택해주세요</div>' : addBtn);

    colsHtml += '<div class="apr-line-col' + (locked ? ' apr-line-col-locked' : '') + '" data-col-idx="' + idx + '">' +
      '<div class="apr-line-col-head"><b>' + (idx + 1) + '단계' + (locked ? ' · 기안자' : '') + '</b>' +
        (locked ? '' : '<button type="button" class="apr-step-del" data-step="' + idx + '" title="단계 삭제"><i class="ti ti-trash"></i></button>') +
      '</div>' +
      '<select class="apr-type-select type-' + (step.step_type === 'CONSULT' ? 'consult' : 'approve') + '" data-step="' + idx + '"' + (locked ? ' disabled' : '') + '>' +
        '<option value="APPROVE"' + (step.step_type === 'APPROVE' ? ' selected' : '') + '>결재</option>' +
        '<option value="CONSULT"' + (step.step_type === 'CONSULT' ? ' selected' : '') + '>협의</option>' +
      '</select>' +
      '<div class="apr-line-col-body">' + body + '</div>' +
    '</div>';

    // 마지막 칸이 아니면, 다음 칸과의 사이에 "끼워넣기" 지점을 하나 둔다(평소엔 화살표, 호버하면 +).
    if (idx < manualSteps.length - 1) {
      colsHtml += '<div class="apr-line-arrow-insert" data-insert-at="' + (idx + 1) + '" title="여기에 단계 끼워넣기">' +
        '<i class="ti ti-chevron-right chevron"></i><i class="ti ti-plus plus"></i></div>';
    }
  });

  // 아래 "결재 단계 추가" 버튼 대신, 마지막 칸 옆에 점선 칸 + "+"로 단계를 추가한다.
  var addStepCol = '<div class="apr-line-col-add" id="aprAddStepCol" title="결재 단계 추가"><i class="ti ti-plus"></i></div>';
  wrap.innerHTML = '<div class="apr-line-cols">' + colsHtml +
    (colsHtml ? '<div class="apr-line-arrow"><i class="ti ti-chevron-right"></i></div>' : '') +
    addStepCol + '</div>';

  var addCol = document.getElementById('aprAddStepCol');
  if (addCol) addCol.addEventListener('click', function() { addManualStep(); updateLineSummary(); });

  wrap.querySelectorAll('.apr-line-arrow-insert').forEach(function(a) {
    a.addEventListener('click', function() { addManualStep(Number(a.dataset.insertAt)); updateLineSummary(); });
  });

  // 방금 추가/삽입된 칸이 있으면 그쪽으로 스크롤 — 칸이 많아져 가로 스크롤이 생겨도
  // 화면이 그대로 있어서 "추가된 건지 아닌지" 헷갈리는 문제를 없앤다.
  if (focusIdx != null) {
    var focusEl = wrap.querySelector('.apr-line-col[data-col-idx="' + focusIdx + '"]');
    if (focusEl) focusEl.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  }

  wrap.querySelectorAll('.apr-step-del').forEach(function(b) {
    b.addEventListener('click', function() { manualSteps.splice(Number(b.dataset.step), 1); renderManualSteps(); updateLineSummary(); });
  });
  wrap.querySelectorAll('.apr-type-select:not([disabled])').forEach(function(s) {
    s.addEventListener('change', function() {
      manualSteps[Number(s.dataset.step)].step_type = s.value;
      s.className = 'apr-type-select type-' + (s.value === 'CONSULT' ? 'consult' : 'approve');
    });
  });
  wrap.querySelectorAll('.apr-chip-del').forEach(function(b) {
    b.addEventListener('click', function() {
      manualSteps[Number(b.dataset.step)].approvers.splice(Number(b.dataset.ai), 1);
      renderManualSteps();
      updateLineSummary();
    });
  });
  wrap.querySelectorAll('.apr-add-approver-btn').forEach(function(b) {
    b.addEventListener('click', function() {
      var step = manualSteps[Number(b.dataset.step)];
      openPersonPicker('결재자 선택', function(memberId) {
        var m = orgMembers.find(function(o) { return o.id === memberId; });
        if (m) step.approvers = [{ id: m.id, name: m.user_name }]; // 한 칸에 한 명 — 선택하면 바로 채움
        renderManualSteps();
        updateLineSummary();
      }, step.approvers.map(function(a) { return a.id; }));
    });
  });
}

/* ── 결재선: 개인 저장(즐겨찾기) ── */
async function loadPersonalLines() {
  var { data, error } = await supabaseClient
    .from('approval_personal_lines')
    .select('id, name, steps')
    .eq('org_member_id', myOrgMemberId)
    .order('created_at', { ascending: false });
  if (error) { console.error('[approval/draft] approval_personal_lines 조회 실패:', error); personalLines = []; }
  else personalLines = data || [];
  var sel = document.getElementById('aprPersonalLineSelect');
  sel.innerHTML = '<option value="">불러오기...</option>' +
    personalLines.map(function(l) { return '<option value="' + l.id + '">' + ts(l.name) + '</option>'; }).join('');
}

function applyPersonalLine(id) {
  var line = personalLines.find(function(l) { return l.id === id; });
  if (!line) return;
  manualSteps = (line.steps || []).map(function(s) {
    return {
      decision_rule: s.decision_rule || 'ALL',
      step_type: s.step_type || 'APPROVE',
      approvers: (s.approvers || []).map(function(a) {
        var m = orgMembers.find(function(o) { return o.id === a.org_member_id; });
        return { id: a.org_member_id, name: m ? m.user_name : '(알 수 없음 — 의원에서 제외된 사용자)' };
      }),
    };
  });
  renderManualSteps();
  updateLineSummary();
}

async function savePersonalLineAs() {
  if (!manualSteps.length || manualSteps.some(function(s) { return !s.approvers.length; })) {
    alert('저장할 결재 단계가 없거나, 결재자가 없는 단계가 있습니다.');
    return;
  }
  var name = prompt('이 결재선을 어떤 이름으로 저장할까요? (예: 100만원 미만)');
  if (!name || !name.trim()) return;
  var stepsJson = manualSteps.map(function(s) {
    return { decision_rule: s.decision_rule, step_type: s.step_type, approvers: s.approvers.map(function(a) { return { org_member_id: a.id }; }) };
  });
  try {
    const { error } = await supabaseClient.from('approval_personal_lines').insert({ org_member_id: myOrgMemberId, name: name.trim(), steps: stepsJson });
    if (error) throw new Error(error.message);
    await loadPersonalLines();
    alert('저장되었습니다.');
  } catch (e) {
    alert('저장 실패: ' + e.message);
  }
}

/** 결재선 관리 페이지 대신, 개인별로 저장해둔 결재선(즐겨찾기)만 관리하는 모달 */
function openPersonalLineModal() {
  renderPersonalLineModalList();
  openModal('aprPersonalLineModal');
}

function renderPersonalLineModalList() {
  var box = document.getElementById('aprPersonalLineModalList');
  if (!personalLines.length) {
    box.innerHTML = '<div class="apr-pline-empty">저장해둔 결재선이 없습니다.<br>기안 작성 화면에서 결재선을 만든 뒤 "현재 결재선 저장"으로 추가해주세요.</div>';
    return;
  }
  box.innerHTML = personalLines.map(function(l) {
    return '<div class="apr-pline-row" data-id="' + l.id + '">' +
      '<span class="apr-pline-name">' + ts(l.name) + '</span>' +
      '<button type="button" class="btn btn-sm" data-act="apply">적용</button>' +
      '<button type="button" class="btn btn-sm btn-danger" data-act="delete"><i class="ti ti-trash"></i></button>' +
    '</div>';
  }).join('');
  box.querySelectorAll('.apr-pline-row').forEach(function(row) {
    var id = row.dataset.id;
    row.querySelector('[data-act="apply"]').addEventListener('click', function() {
      applyPersonalLine(id);
      closeModal('aprPersonalLineModal');
    });
    row.querySelector('[data-act="delete"]').addEventListener('click', async function() {
      if (!confirm('"' + (personalLines.find(function(l) { return l.id === id; }) || {}).name + '" 결재선을 삭제하시겠습니까?')) return;
      const { error } = await supabaseClient.from('approval_personal_lines').delete().eq('id', id);
      if (error) { alert('삭제 실패: ' + error.message); return; }
      await loadPersonalLines();
      renderPersonalLineModalList();
    });
  });
}

/* ── 참조 / 회람 ── */
function renderWatchers() {
  var wrap = document.getElementById('aprWatcherCols');
  var typeDefs = [{ type: 'REF', label: '참조' }, { type: 'CIRCULATE', label: '회람' }];

  wrap.innerHTML = typeDefs.map(function(def) {
    var list = watchers.filter(function(w) { return w.type === def.type; });
    var chips = list.map(function(w) {
      var i = watchers.indexOf(w);
      return '<div class="apr-line-approver-chip">' + ts(w.name) +
        '<button data-i="' + i + '" class="apr-watcher-del">&times;</button></div>';
    }).join('');
    var body = chips || '<div class="apr-line-empty-hint">지정된 대상이 없습니다</div>';

    return '<div class="apr-line-col">' +
      '<div class="apr-line-col-head"><b>' + def.label + '</b>' +
        '<button type="button" class="apr-watcher-add" data-type="' + def.type + '" title="' + def.label + ' 추가"><i class="ti ti-plus"></i></button>' +
      '</div>' +
      '<div class="apr-line-col-body">' + body + '</div>' +
    '</div>';
  }).join('');

  wrap.querySelectorAll('.apr-watcher-del').forEach(function(b) {
    b.addEventListener('click', function() { watchers.splice(Number(b.dataset.i), 1); renderWatchers(); updateWatcherSummary(); });
  });
  wrap.querySelectorAll('.apr-watcher-add').forEach(function(b) {
    b.addEventListener('click', function() {
      var type = b.dataset.type;
      var label = type === 'REF' ? '참조' : '회람';
      openPersonPicker(label + ' 대상 선택(여러 명 가능)', function(memberIds) {
        memberIds.forEach(function(id) { addWatcher(id, type); });
      }, watchers.filter(function(w) { return w.type === type; }).map(function(w) { return w.id; }), true);
    });
  });
  updateWatcherSummary();
}

function addWatcher(memberId, type) {
  var m = orgMembers.find(function(o) { return o.id === memberId; });
  if (!m) return;
  if (watchers.some(function(w) { return w.id === memberId && w.type === type; })) return;
  watchers.push({ id: memberId, name: m.user_name, type: type });
  renderWatchers();
}

/** 화면에서 고른 참조/회람 목록을 문서에 반영 — 결재 단계와 동일하게 지우고 다시 넣는 방식 */
async function applyWatchersToDoc(docId) {
  await supabaseClient.from('approval_document_watchers').delete().eq('document_id', docId);
  if (!watchers.length) return;
  var rows = watchers.map(function(w) { return { document_id: docId, org_member_id: w.id, watcher_type: w.type }; });
  var { error } = await supabaseClient.from('approval_document_watchers').insert(rows);
  if (error) throw new Error('참조/회람 저장 실패: ' + error.message);
}

/* ── 저장 / 결재선 반영 / 상신 ── */
/* ── 첨부파일 로직 ──
 * pendingFiles: 아직 스토리지에 안 올라간, 로컬에서 고른 파일 (저장 시점에 업로드)
 * existingFiles: 이미 approval_document_files 테이블 + 스토리지에 올라가 있는 첨부
 * 두 목록을 합쳐서 하나의 칩 목록으로 그린다. */
function bindAttachInput() {
  var input = document.getElementById('aprFileInput');
  if (!input) return;
  input.addEventListener('change', function(e) {
    Array.from(e.target.files || []).forEach(function(file) {
      if (file.size > MAX_ATTACH_SINGLE) { alert('파일당 최대 10MB까지 첨부할 수 있습니다: ' + file.name); return; }
      var total = pendingFiles.reduce(function(a, f) { return a + f.file.size; }, 0)
                + existingFiles.reduce(function(a, f) { return a + (f.file_size || 0); }, 0);
      if (total + file.size > MAX_ATTACH_TOTAL) { alert('첨부파일은 전체 20MB 이하만 가능합니다.'); return; }
      pendingFiles.push({ file: file });
    });
    renderAttachChips();
    input.value = '';
  });
}

function renderAttachChips() {
  var wrap = document.getElementById('aprAttachInline');
  if (!wrap) return;
  // 파일 선택 버튼(label)만 남기고 기존 칩은 지운 뒤 다시 그린다.
  wrap.querySelectorAll('.apr-attach-chip').forEach(function(el) { el.remove(); });
  var btn = wrap.querySelector('.apr-attach-btn');

  existingFiles.forEach(function(f) {
    var chip = document.createElement('div');
    chip.className = 'apr-attach-chip';
    chip.innerHTML =
      '<span class="apr-attach-chip-name">' + ts(f.file_name) + '</span>' +
      '<span class="apr-attach-chip-size">' + fmtAttachSize(f.file_size || 0) + '</span>' +
      '<button type="button" title="삭제"><i class="ti ti-x"></i></button>';
    chip.querySelector('button').addEventListener('click', function() { removeExistingFile(f); });
    wrap.insertBefore(chip, btn);
  });
  pendingFiles.forEach(function(f, idx) {
    var chip = document.createElement('div');
    chip.className = 'apr-attach-chip';
    chip.innerHTML =
      '<span class="apr-attach-chip-name">' + ts(f.file.name) + '</span>' +
      '<span class="apr-attach-chip-size">' + fmtAttachSize(f.file.size) + '</span>' +
      '<button type="button" title="삭제"><i class="ti ti-x"></i></button>';
    chip.querySelector('button').addEventListener('click', function() { pendingFiles.splice(idx, 1); renderAttachChips(); });
    wrap.insertBefore(chip, btn);
  });
}

/** 문서가 이미 저장돼 있으면 즉시 스토리지+DB에서 삭제, 그 자리에서 바로 반영한다
 *  (임시저장 이전에 다시 다운/취소해도 지저분한 상태가 안 남도록). */
async function removeExistingFile(f) {
  if (!confirm('"' + f.file_name + '" 파일을 삭제할까요?')) return;
  try {
    await db.deleteFile('approval-files', f.storage_path);
    var { error } = await supabaseClient.from('approval_document_files').delete().eq('id', f.id);
    if (error) throw new Error(error.message);
    existingFiles = existingFiles.filter(function(x) { return x.id !== f.id; });
    renderAttachChips();
  } catch (e) {
    alert('파일 삭제 실패: ' + e.message);
  }
}

/** saveDraft()에서 docId가 확정된 뒤 호출 — pendingFiles를 스토리지에 올리고
 *  approval_document_files 행을 만든 다음, existingFiles로 옮겨 화면을 갱신한다. */
async function uploadPendingFiles(docId) {
  if (!pendingFiles.length) return;
  var startOrder = existingFiles.length;
  for (var i = 0; i < pendingFiles.length; i++) {
    var file = pendingFiles[i].file;
    var up = await db.uploadFile('approval-files', file, docId);
    var payload = {
      org_id: currentUser.org_id, document_id: docId,
      file_name: up.name, storage_path: up.path, file_size: up.size,
      sort_order: startOrder + i, uploaded_by: myOrgMemberId,
    };
    var { data, error } = await supabaseClient.from('approval_document_files').insert(payload).select().single();
    if (error) throw new Error('첨부파일 저장 실패: ' + error.message);
    existingFiles.push(data);
  }
  pendingFiles = [];
  renderAttachChips();
}

/** continueDraft() / resubmitFrom()에서 기존 문서를 불러올 때 첨부 목록도 같이 불러온다. */
async function loadAttachments(docId) {
  pendingFiles = [];
  existingFiles = [];
  if (docId) {
    var { data, error } = await supabaseClient
      .from('approval_document_files').select('*').eq('document_id', docId).order('sort_order');
    if (error) console.error('[approval/draft] approval_document_files 조회 실패:', error);
    existingFiles = data || [];
  }
  renderAttachChips();
}

async function saveDraft(silent) {
  var title = val('aprTitle').trim();
  if (!title) { alert('제목을 입력해주세요.'); return null; }
  var contentHtml = editor ? editor.getData() : '';

  try {
    var docId = currentDocId;
    if (!docId) {
      var docNo = await genDocNo('AP');
      var payload = {
        org_id: currentUser.org_id, doc_no: docNo, doc_type: 'GENERAL', title: title,
        drafter_member_id: myOrgMemberId, clinic_id: myClinicId, dept_id: myDeptId,
        template_id: currentTemplateId || null, content_html: contentHtml, status: 'DRAFT',
      };
      var { data, error } = await supabaseClient.from('approval_documents').insert(payload).select().single();
      if (error) throw new Error(error.message);
      docId = data.id;
      currentDocId = docId;
    } else {
      var { error: upErr } = await supabaseClient.from('approval_documents')
        .update({ title: title, content_html: contentHtml, template_id: currentTemplateId || null, updated_at: new Date().toISOString() })
        .eq('id', docId);
      if (upErr) throw new Error(upErr.message);
    }

    await applyLineToDoc(docId);
    await applyWatchersToDoc(docId);
    await uploadPendingFiles(docId);
    if (!silent) alert('임시저장되었습니다.');
    return docId;
  } catch (e) {
    alert('저장 실패: ' + e.message);
    return null;
  }
}

/** 화면에서 고른 결재선(직접 지정)을 문서에 반영 */
async function applyLineToDoc(docId) {
  if (!manualSteps.length || manualSteps.some(function(s) { return !s.approvers.length; })) {
    throw new Error('모든 결재 단계에 결재자를 1명 이상 지정해주세요.');
  }
  await supabaseClient.from('approval_steps').delete().eq('document_id', docId);
  for (var i = 0; i < manualSteps.length; i++) {
    var step = manualSteps[i];
    var { data: stepRow, error: stepErr } = await supabaseClient
      .from('approval_steps')
      .insert({ document_id: docId, step_no: i + 1, decision_rule: step.decision_rule, step_type: step.step_type || 'APPROVE', status: 'PENDING' })
      .select().single();
    if (stepErr) throw new Error('결재선 저장 실패: ' + stepErr.message);
    var approverRows = step.approvers.map(function(a) { return { step_id: stepRow.id, org_member_id: a.id }; });
    var { error: apErr } = await supabaseClient.from('approval_step_approvers').insert(approverRows);
    if (apErr) throw new Error('결재자 저장 실패: ' + apErr.message);
  }
}

async function submitCurrentDoc() {
  if (leaveMode) return submitLeaveDoc();
  if (!confirm('기안을 상신하시겠습니까? 상신 후에는 결재선을 바꿀 수 없습니다.')) return;
  try {
    var docId = await saveDraft(true);
    if (!docId) return;
    var { error } = await supabaseClient.rpc('submit_approval_document', { p_doc_id: docId });
    if (error) throw new Error(error.message);
    systemLog('APPROVAL_SUBMIT', '기안 상신', { target_type: 'approval_document', target_id: docId }).catch(() => {});
    alert('상신되었습니다.');
    resetComposeArea();
    switchMainTab('mydocs');
  } catch (e) {
    alert('상신 실패: ' + e.message);
  }
}

/** 연차신청 모드 상신 — 일반 문서처럼 임시저장 없이, submit_leave_request RPC 한 번으로
 *  leave_requests 행 + approval_documents 행(결재선 포함)을 함께 만들고 바로 상신까지 마친다. */
async function submitLeaveDoc() {
  var type = selectedLeaveTypeForDraft();
  var start = val('aprLeaveStart'), end = val('aprLeaveEnd');
  var reason = val('aprLeaveReason').trim();
  var days = computeLeaveDraftDays();
  if (!type) { alert('연차 유형을 선택해주세요.'); return; }
  if (!start || !end || days == null) { alert('입력값을 확인해주세요.'); return; }
  if (!manualSteps.length || manualSteps.some(function(s) { return !s.approvers.length; })) {
    alert('모든 결재 단계에 결재자를 1명 이상 지정해주세요.');
    return;
  }
  if (!confirm('연차를 신청하시겠습니까? 상신 후에는 결재선을 바꿀 수 없습니다.')) return;

  var manualStepsPayload = manualSteps.map(function(s) {
    return { step_type: s.step_type, decision_rule: s.decision_rule, approver_ids: s.approvers.map(function(a) { return a.id; }) };
  });

  try {
    var { error } = await supabaseClient.rpc('submit_leave_request', {
      p_org_member_id: myOrgMemberId, p_clinic_id: myClinicId, p_dept_id: myDeptId,
      p_start_date: start, p_end_date: end, p_leave_type_id: type.id, p_days_count: days,
      p_reason: reason || null, p_line_template_id: null, p_manual_steps: manualStepsPayload,
    });
    if (error) throw new Error(error.message);
    systemLog('APPROVAL_SUBMIT', '연차 신청 상신 (' + start + ' ~ ' + end + ')', { target_type: 'leave_request' }).catch(() => {});
    alert('연차가 신청되었습니다.');
    resetComposeArea();
    switchMainTab('mydocs');
  } catch (e) {
    alert('신청 실패: ' + e.message);
  }
}

function resetComposeArea() {
  currentDocId = null;
  currentTemplateId = null;
  leaveMode = false;
  pendingFiles = [];
  existingFiles = [];
  renderAttachChips();
  document.getElementById('aprComposeWrap').style.display = 'none';
  document.getElementById('aprComposeEmptyMsg').style.display = '';
  document.getElementById('aprComposeHeaderActions').style.display = 'none';
  document.getElementById('aprGeneralFieldsWrap').style.display = '';
  document.getElementById('aprLeaveFieldsWrap').style.display = 'none';
  document.getElementById('aprSaveDraftBtn').style.display = '';
  document.getElementById('aprSubmitBtn').innerHTML = '<i class="ti ti-send"></i> 상신';
  document.getElementById('aprNewLeaveBtn').classList.remove('active');
  renderTemplateList();
}

async function genDocNo(prefix) {
  var year = new Date().getFullYear();
  var { data, error } = await supabaseClient.rpc('next_doc_seq', { p_org_id: currentUser.org_id, p_prefix: prefix, p_year: year });
  if (error || data == null) return prefix + '-' + year + '-' + Date.now().toString().slice(-6);
  return prefix + '-' + year + '-' + String(data).padStart(6, '0');
}

/* ── 내 문서함 ── */
async function loadMyDocuments() {
  var q = supabaseClient.from('approval_documents')
    .select('id, doc_no, title, status, current_step_no, created_at, submitted_at, completed_at')
    .eq('drafter_member_id', myOrgMemberId)
    .order('created_at', { ascending: false });
  if (currentStatusFilter) q = q.eq('status', currentStatusFilter);
  var { data, error } = await q;
  if (error) { console.error('[approval/draft] approval_documents 조회 실패:', error); myDocuments = []; }
  else myDocuments = data || [];
  renderMyDocuments();
}

var myDocsGrid = null;

function renderMyDocuments() {
  var dateFrom = currentStatusFilter === 'DRAFT' ? '' : document.getElementById('aprDocDateFrom').value;
  var dateTo = currentStatusFilter === 'DRAFT' ? '' : document.getElementById('aprDocDateTo').value;
  var rows = myDocuments.filter(function(d) {
    var date = d.created_at ? localDateStr(new Date(d.created_at)) : '';
    if (dateFrom && date && date < dateFrom) return false;
    if (dateTo && date && date > dateTo) return false;
    return true;
  });

  var cols = [
    { headerName: '문서번호', field: 'doc_no', flex: 1, minWidth: 110, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '제목', field: 'title', flex: 2, minWidth: 140, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start', fontWeight: 600 } },
    { headerName: '상태', field: 'status', flex: 1, minWidth: 90,
      cellRenderer: function(p) {
        var color = { DRAFT: '#6b7280', IN_PROGRESS: '#d97706', APPROVED: '#059669', REJECTED: '#dc2626', CANCELED: '#6b7280' }[p.value] || '#6b7280';
        var s = document.createElement('span');
        s.style.cssText = 'color:' + color + ';font-weight:600;';
        s.textContent = STATUS_LABEL[p.value] || p.value;
        return s;
      } },
    { headerName: '작성일', field: 'created_at', flex: 1, minWidth: 90, valueFormatter: function(p) { return p.value ? localDateStr(new Date(p.value)) : ''; } },
    { headerName: '', field: '_actions', flex: 0, width: 90, sortable: false,
      cellRenderer: function(p) {
        var btn = document.createElement('button');
        btn.className = 'btn btn-sm';
        btn.textContent = p.data.status === 'DRAFT' ? '이어작성' : '상세';
        btn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (p.data.status === 'DRAFT') continueDraft(p.data.id);
          else location.href = 'doc-detail.html?id=' + encodeURIComponent(p.data.id);
        });
        return btn;
      } },
  ];
  if (!myDocsGrid) {
    myDocsGrid = createMgGrid('aprDocList', cols, rows, {
      noRowsText: '문서가 없습니다.',
    });
  } else {
    updateMgGrid(myDocsGrid, rows);
  }
}

/** 임시저장 문서를 "기안 작성" 탭으로 불러와 이어서 작성 */
async function continueDraft(docId) {
  var { data: full, error } = await supabaseClient.from('approval_documents').select('*').eq('id', docId).single();
  if (error) { alert('문서를 불러오지 못했습니다: ' + error.message); return; }

  currentDocId = docId;
  currentTemplateId = full.template_id || null;
  setVal('aprTitle', full.title);
  document.getElementById('aprComposeEmptyMsg').style.display = 'none';
  document.getElementById('aprComposeWrap').style.display = '';
  document.getElementById('aprComposeHeaderActions').style.display = 'flex';
  await initEditor(full.content_html);
  renderTemplateList();
  await loadAttachments(docId);

  var { data: watcherRows, error: watcherErr } = await supabaseClient
    .from('approval_document_watchers').select('org_member_id, watcher_type').eq('document_id', docId);
  if (watcherErr) console.error('[approval/draft] approval_document_watchers 조회 실패:', watcherErr);
  watchers = (watcherRows || []).map(function(w) {
    var m = orgMembers.find(function(o) { return o.id === w.org_member_id; });
    return { id: w.org_member_id, name: m ? m.user_name : '(알 수 없음)', type: w.watcher_type };
  });
  renderWatchers();

  var { data: existingSteps, error: stepsErr } = await supabaseClient.from('approval_steps').select('id').eq('document_id', docId);
  if (stepsErr) console.error('[approval/draft] approval_steps 조회 실패:', stepsErr);

  if (existingSteps && existingSteps.length) {
    var { data: stepsFull, error: stepsFullErr } = await supabaseClient
      .from('approval_steps')
      .select('step_no, decision_rule, step_type, approval_step_approvers(org_member_id)')
      .eq('document_id', docId).order('step_no');
    if (stepsFullErr) console.error('[approval/draft] approval_steps(상세) 조회 실패:', stepsFullErr);
    manualSteps = (stepsFull || []).map(function(s) {
      return {
        decision_rule: s.decision_rule,
        step_type: s.step_type || 'APPROVE',
        approvers: (s.approval_step_approvers || []).map(function(a) {
          var m = orgMembers.find(function(o) { return o.id === a.org_member_id; });
          return { id: a.org_member_id, name: m ? m.user_name : '(알 수 없음)' };
        }),
      };
    });
  } else {
    manualSteps = defaultManualSteps();
  }
  renderManualSteps();

  switchMainTab('compose');
  updateLineSummary();
  updateWatcherSummary();
}

/** 반려된 문서를 복사해서 새 문서로 재기안한다 — continueDraft()와 로직은 거의 같지만,
 *  currentDocId를 비워서(=새 문서) 저장되게 하는 게 핵심 차이. 원래 반려됐던 문서는
 *  그대로 이력에 남고, 이건 완전히 별개의 새 문서로 상신된다. */
async function resubmitFrom(sourceDocId) {
  var { data: full, error } = await supabaseClient.from('approval_documents').select('*').eq('id', sourceDocId).single();
  if (error) { alert('문서를 불러오지 못했습니다: ' + error.message); return; }

  currentDocId = null; // 핵심: 새 문서로 저장
  currentTemplateId = full.template_id || null;
  setVal('aprTitle', full.title);
  document.getElementById('aprComposeEmptyMsg').style.display = 'none';
  document.getElementById('aprComposeWrap').style.display = '';
  document.getElementById('aprComposeHeaderActions').style.display = 'flex';
  await initEditor(full.content_html);
  renderTemplateList();
  pendingFiles = []; existingFiles = []; renderAttachChips(); // 새 문서이므로 첨부는 빈 상태로 시작(원본 파일을 그대로 옮기진 않음)

  var { data: watcherRows } = await supabaseClient
    .from('approval_document_watchers').select('org_member_id, watcher_type').eq('document_id', sourceDocId);
  watchers = (watcherRows || []).map(function(w) {
    var m = orgMembers.find(function(o) { return o.id === w.org_member_id; });
    return { id: w.org_member_id, name: m ? m.user_name : '(알 수 없음)', type: w.watcher_type };
  });
  renderWatchers();

  var { data: stepsFull } = await supabaseClient
    .from('approval_steps')
    .select('step_no, decision_rule, step_type, approval_step_approvers(org_member_id)')
    .eq('document_id', sourceDocId).order('step_no');
  manualSteps = (stepsFull && stepsFull.length) ? stepsFull.map(function(s) {
    return {
      decision_rule: s.decision_rule,
      step_type: s.step_type || 'APPROVE',
      approvers: (s.approval_step_approvers || []).map(function(a) {
        var m = orgMembers.find(function(o) { return o.id === a.org_member_id; });
        return { id: a.org_member_id, name: m ? m.user_name : '(알 수 없음)' };
      }),
    };
  }) : defaultManualSteps();
  renderManualSteps();

  switchMainTab('compose');
  updateLineSummary();
  updateWatcherSummary();
}

init();