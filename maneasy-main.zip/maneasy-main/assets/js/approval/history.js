'use strict';

var currentUser = null;
var allDocs = []; // 필터(상태/구분/날짜) 적용 후, 검색어 필터 전 상태의 문서 목록(이름 붙어있음)
var _offset = 0;
var _totalCount = 0;
var PAGE_SIZE = 500; // 서버 기본 한 번에 최대 1000행 제한이 있어서, 여유 있게 페이지당 500건씩 나눠서 불러온다

function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function hideLoading() { var el = document.getElementById('globalLoading'); if (el) el.classList.remove('is-open'); }

var STATUS_LABEL = { DRAFT: '임시저장', IN_PROGRESS: '결재중', APPROVED: '승인완료', REJECTED: '반려', CANCELED: '취소' };
var STATUS_BADGE = { DRAFT: 'gray', IN_PROGRESS: 'yellow', APPROVED: 'green', REJECTED: 'red', CANCELED: 'gray' };
var TYPE_LABEL = { GENERAL: '일반 기안서', LEAVE: '연차 신청' };

async function init() {
  ['hDateFrom', 'hDateTo'].forEach(mountCustomDateInput);
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'approval/history')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    setDefaultDateRange();
    bindUi();
    await loadHistory();
    hideLoading();
  } catch (e) {
    console.error('[approval/history] 초기화 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 문제가 발생했습니다: ' + e.message);
  }
}

function setDefaultDateRange() {
  var today = new Date();
  var from = new Date(today); from.setDate(from.getDate() - 90); // 기본 최근 90일 — 이력 조회라 좀 더 넓게
  document.getElementById('hDateFrom').value = localDateStr(from);
  document.getElementById('hDateTo').value = localDateStr(today);
}

function bindUi() {
  document.getElementById('hSearchBtn').addEventListener('click', function() { loadHistory(); });
  document.getElementById('hSearch').addEventListener('keydown', function(e) { if (e.key === 'Enter') loadHistory(); });
  document.getElementById('hStatusFilter').addEventListener('change', function() { loadHistory(); });
  document.getElementById('hTypeFilter').addEventListener('change', function() { loadHistory(); });
  document.getElementById('hLoadMoreBtn')?.addEventListener('click', function() { loadHistory(true); });
}

async function loadHistory(append) {
  var list = document.getElementById('hList');
  try {
    if (!append) { _offset = 0; allDocs = []; }

    var status = val('hStatusFilter');
    var docType = val('hTypeFilter');
    var dateFrom = val('hDateFrom');
    var dateTo = val('hDateTo');

    var q = supabaseClient.from('approval_documents')
      .select('id, doc_no, title, doc_type, status, drafter_member_id, submitted_at, created_at, completed_at', { count: 'exact' })
      .eq('org_id', currentUser.org_id)
      .order('created_at', { ascending: false })
      .range(_offset, _offset + PAGE_SIZE - 1);
    if (status) q = q.eq('status', status);
    if (docType) q = q.eq('doc_type', docType);
    if (dateFrom) q = q.gte('created_at', kstDateRangeStart(dateFrom));
    if (dateTo) q = q.lte('created_at', kstDateRangeEnd(dateTo));

    var { data, error, count } = await q;
    if (error) throw new Error(error.message);
    var docs = data || [];

    var drafterIds = [...new Set(docs.map(function(d) { return d.drafter_member_id; }).filter(Boolean))];
    var nameMap = {};
    if (drafterIds.length) {
      var { data: members, error: memErr } = await supabaseClient.from('org_members_detail').select('id, user_name').in('id', drafterIds);
      if (memErr) throw new Error(memErr.message);
      (members || []).forEach(function(m) { nameMap[m.id] = m.user_name; });
    }
    docs.forEach(function(d) { d.drafter_name = nameMap[d.drafter_member_id] || '(알 수 없음)'; });

    _totalCount = count || 0;
    allDocs = allDocs.concat(docs);
    _offset = allDocs.length;

    var moreBtn = document.getElementById('hLoadMoreBtn');
    if (moreBtn) moreBtn.style.display = (allDocs.length < _totalCount) ? '' : 'none';
    var countLabel = document.getElementById('hCountLabel');
    if (countLabel) countLabel.textContent = '불러온 ' + allDocs.length + '건 / 전체 ' + _totalCount + '건';

    renderList();
  } catch (e) {
    console.error('[approval/history] loadHistory 실패:', e);
    list.innerHTML = '<div class="apr-empty">' + ts(e.message) + '</div>';
  }
}

var historyGrid = null;
function renderList() {
  var q = val('hSearch').trim().toLowerCase();
  var rows = allDocs.filter(function(d) {
    return !q ||
      (d.doc_no || '').toLowerCase().indexOf(q) !== -1 ||
      (d.title || '').toLowerCase().indexOf(q) !== -1 ||
      (d.drafter_name || '').toLowerCase().indexOf(q) !== -1;
  });
  var cols = [
    { headerName: '문서번호', field: 'doc_no', flex: 1, minWidth: 110, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '제목', field: 'title', flex: 2, minWidth: 160, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start', fontWeight: 600 } },
    { headerName: '구분', field: 'doc_type', flex: 0.8, minWidth: 90, valueFormatter: function(p) { return TYPE_LABEL[p.value] || p.value; } },
    { headerName: '기안자', field: 'drafter_name', flex: 0.9, minWidth: 90 },
    { headerName: '상태', field: 'status', flex: 0.8, minWidth: 90,
      cellRenderer: function(p) {
        var color = { DRAFT: '#6b7280', IN_PROGRESS: '#d97706', APPROVED: '#059669', REJECTED: '#dc2626', CANCELED: '#6b7280' }[p.value] || '#6b7280';
        var s = document.createElement('span');
        s.style.cssText = 'color:' + color + ';font-weight:600;';
        s.textContent = STATUS_LABEL[p.value] || p.value;
        return s;
      } },
    { headerName: '기안일', field: 'created_at', flex: 0.8, minWidth: 90, valueFormatter: function(p) { return p.value ? localDateStr(new Date(p.value)) : ''; } },
    { headerName: '완료일', field: 'completed_at', flex: 0.8, minWidth: 90, valueFormatter: function(p) { return p.value ? localDateStr(new Date(p.value)) : '-'; } },
    { headerName: '', flex: 0, width: 80, sortable: false,
      cellRenderer: function(p) {
        var a = document.createElement('a'); a.className = 'btn btn-sm'; a.textContent = '상세';
        a.href = 'doc-detail.html?id=' + p.data.id;
        return a;
      } },
  ];
  if (historyGrid) {
    updateMgGrid(historyGrid, rows);
  } else {
    historyGrid = createMgGrid('hList', cols, rows, { noRowsText: '조회 결과가 없습니다.' });
  }
}

init();