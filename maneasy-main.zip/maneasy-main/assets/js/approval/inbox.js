'use strict';

var currentUser = null;
var myOrgMemberId = null;
var orgMembers = [];
var currentTab = 'pending';
var pendingRows = [];   // [{ stepApproverId, stepId, documentId, stepNo, decisionRule }]
var doneRows = [];      // [{ stepApproverId, action, comment, actedAt, documentId }]
var watchingRows = [];  // [{ watcherRowId, documentId, watcherType }]
var docCache = {};       // documentId -> approval_documents row (지연 로딩 캐시)

function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function showLoading(text) {
  var el = document.getElementById('globalLoading');
  var t = document.getElementById('globalLoadingText');
  if (t && text) t.textContent = text;
  if (el) el.classList.add('is-open');
}
function hideLoading() {
  var el = document.getElementById('globalLoading');
  if (el) el.classList.remove('is-open');
}

var STATUS_LABEL = { DRAFT: '임시저장', IN_PROGRESS: '결재중', APPROVED: '승인완료', REJECTED: '반려', CANCELED: '취소' };
var STATUS_BADGE = { DRAFT: 'badge-blue', IN_PROGRESS: 'badge-yellow', APPROVED: 'badge-green', REJECTED: 'badge-red', CANCELED: 'badge-blue' };
var ACTION_LABEL = { PENDING: '대기', APPROVED: '승인', REJECTED: '반려', SKIPPED: '-' };

async function init() {
  ['aprDateFrom', 'aprDateTo'].forEach(mountCustomDateInput);
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'approval/inbox')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    await resolveMyContext();
    if (!myOrgMemberId) {
      hideLoading();
      document.querySelector('.master-page').innerHTML =
        '<div class="m-card" style="text-align:center;color:#6b7280;font-size:13px;padding:40px;">' +
        (currentUser.is_preview
          ? '플랫폼 관리자의 "의원 미리보기" 모드에서는 전자결재를 사용할 수 없습니다.<br>실제 소속 구성원 계정으로 로그인해주세요.'
          : '소속 구성원 정보를 확인할 수 없어 전자결재를 사용할 수 없습니다.<br>관리자에게 문의해주세요.') +
        '</div>';
      return;
    }
    await loadOrgMembers();
    setDefaultDateRange();
    bindUi();
    await loadPending();
    hideLoading();
  } catch (e) {
    console.error('[approval/inbox] 초기화 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 문제가 발생했습니다: ' + e.message);
  }
}

/** 플랫폼 관리자의 "의원 미리보기" 세션은 실제 org_members 행이 없다 — draft.js 참고 */
async function resolveMyContext() {
  if (!currentUser.org_member_id) { console.warn('[approval/inbox] org_member_id 없음'); return; }
  var { data, error } = await supabaseClient
    .from('org_members')
    .select('id')
    .eq('id', currentUser.org_member_id)
    .maybeSingle();
  if (error) { console.error('[approval/inbox] resolveMyContext 조회 오류:', error); return; }
  if (!data) { console.warn('[approval/inbox] org_members 행 없음 — 미리보기 계정일 수 있음 (is_preview=' + currentUser.is_preview + ')'); return; }
  myOrgMemberId = data.id;
}

async function loadOrgMembers() {
  var { data } = await supabaseClient.from('org_members_detail').select('id, user_name').eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false);
  orgMembers = data || [];
}
function memberName(id) {
  var m = orgMembers.find(function(o) { return o.id === id; });
  return m ? m.user_name : '(알 수 없음)';
}

/** 날짜 필터 기본값 — 최근 1주일 */
function setDefaultDateRange() {
  var today = new Date();
  var weekAgo = new Date(today);
  weekAgo.setDate(today.getDate() - 7);
  document.getElementById('aprDateFrom').value = localDateStr(weekAgo);
  document.getElementById('aprDateTo').value = localDateStr(today);
}

function bindUi() {
  document.querySelectorAll('#aprInboxTabs button').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('#aprInboxTabs button').forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      currentTab = btn.dataset.tab;
      document.getElementById('aprInboxSearch').value = '';
      if (inboxGrid) inboxGrid.setGridOption('quickFilterText', '');
      reloadCurrentTab();
    });
  });
  document.getElementById('aprInboxSearch').addEventListener('input', function() {
    if (inboxGrid) inboxGrid.setGridOption('quickFilterText', this.value);
  });
  document.getElementById('aprDateFrom').addEventListener('change', reloadCurrentTab);
  document.getElementById('aprDateTo').addEventListener('change', reloadCurrentTab);
  document.getElementById('aprInboxSearchBtn').addEventListener('click', reloadCurrentTab);
}

function reloadCurrentTab() {
  if (currentTab === 'pending') loadPending();
  else if (currentTab === 'done') loadDone();
  else loadWatching();
}

function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }

/* ── 결재 대기 목록 ──
 * approval_step_approvers -> approval_steps 두 단계로 나눠 조회한다.
 * (org_members<->departments 사이에 FK가 2개(org_members.dept_id, departments.manager_id)라
 *  이 페이지에서 부서 정보를 임베드할 일은 없지만, 혹시 몰라 항상 명시적으로 확인 후 진행)
 */
async function loadPending() {
  if (!myOrgMemberId) return;
  var { data: saRows, error: saErr } = await supabaseClient
    .from('approval_step_approvers')
    .select('id, step_id')
    .eq('org_member_id', myOrgMemberId)
    .eq('action', 'PENDING');
  if (saErr) { console.error('[approval/inbox] approval_step_approvers 조회 실패:', saErr); renderList([]); return; }
  if (!saRows || !saRows.length) { pendingRows = []; renderList([]); return; }

  var stepIds = saRows.map(function(r) { return r.step_id; });
  var { data: steps, error: stepErr } = await supabaseClient
    .from('approval_steps')
    .select('id, step_no, decision_rule, status, document_id')
    .in('id', stepIds)
    .eq('status', 'IN_PROGRESS');
  if (stepErr) { console.error('[approval/inbox] approval_steps 조회 실패:', stepErr); renderList([]); return; }

  var stepById = {};
  (steps || []).forEach(function(s) { stepById[s.id] = s; });

  pendingRows = saRows
    .filter(function(sa) { return stepById[sa.step_id]; })
    .map(function(sa) {
      var s = stepById[sa.step_id];
      return { stepApproverId: sa.id, stepId: s.id, stepNo: s.step_no, decisionRule: s.decision_rule, documentId: s.document_id };
    });

  await hydrateDocs(pendingRows.map(function(r) { return r.documentId; }));
  renderList(pendingRows.map(function(r) {
    var d = docCache[r.documentId];
    return { key: r.stepApproverId, doc: d, sub: r.stepNo + '단계 결재 대기', row: r };
  }));
}

async function loadDone() {
  if (!myOrgMemberId) return;
  var { data: saRows, error } = await supabaseClient
    .from('approval_step_approvers')
    .select('id, step_id, action, comment, acted_at')
    .eq('org_member_id', myOrgMemberId)
    .neq('action', 'PENDING')
    .order('acted_at', { ascending: false });
  if (error) { console.error('[approval/inbox] 처리내역 조회 실패:', error); renderList([]); return; }
  if (!saRows || !saRows.length) { doneRows = []; renderList([]); return; }

  var stepIds = saRows.map(function(r) { return r.step_id; });
  var { data: steps } = await supabaseClient.from('approval_steps').select('id, document_id').in('id', stepIds);
  var docIdByStep = {};
  (steps || []).forEach(function(s) { docIdByStep[s.id] = s.document_id; });

  doneRows = saRows.map(function(sa) {
    return { stepApproverId: sa.id, action: sa.action, comment: sa.comment, actedAt: sa.acted_at, documentId: docIdByStep[sa.step_id] };
  }).filter(function(r) { return r.documentId; });

  await hydrateDocs(doneRows.map(function(r) { return r.documentId; }));
  renderList(doneRows.map(function(r) {
    var d = docCache[r.documentId];
    var label = ACTION_LABEL[r.action] || r.action;
    return { key: r.stepApproverId, doc: d, sub: '내가 ' + label + ' · ' + (r.actedAt ? localDateStr(new Date(r.actedAt)) : ''), row: r };
  }));
}

/** 참조/회람 탭 — 결재선엔 없지만 지정받아 볼 수 있는 문서 목록 */
async function loadWatching() {
  if (!myOrgMemberId) return;
  var { data: rows, error } = await supabaseClient
    .from('approval_document_watchers')
    .select('id, document_id, watcher_type')
    .eq('org_member_id', myOrgMemberId);
  if (error) { console.error('[approval/inbox] approval_document_watchers 조회 실패:', error); watchingRows = []; renderList([]); return; }
  watchingRows = (rows || []).map(function(r) { return { watcherRowId: r.id, documentId: r.document_id, watcherType: r.watcher_type }; });
  if (!watchingRows.length) { renderList([]); return; }

  await hydrateDocs(watchingRows.map(function(r) { return r.documentId; }));
  var typeLabel = { REF: '참조', CIRCULATE: '회람' };
  renderList(watchingRows.map(function(r) {
    var d = docCache[r.documentId];
    return { key: r.watcherRowId, doc: d, sub: typeLabel[r.watcherType] || r.watcherType };
  }));
}

/** documentId 목록을 한 번에 조회해 docCache에 채운다. 이미 캐시된 건 재조회 안 함. */
async function hydrateDocs(docIds) {
  var need = [...new Set(docIds)].filter(function(id) { return id && !docCache[id]; });
  if (!need.length) return;
  // org_members에는 user_name 컬럼이 없어서(profiles에 있고 org_members_detail 뷰로만 조인됨)
  // org_members(user_name) 중첩 임베드는 항상 실패한다 — 기안자 이름은 따로 조회해서 붙인다.
  var { data, error } = await supabaseClient
    .from('approval_documents')
    .select('id, doc_no, title, status, content_html, submitted_at, created_at, drafter_member_id')
    .in('id', need);
  if (error) { console.error('[approval/inbox] approval_documents 조회 실패:', error); return; }
  var docs = data || [];

  var drafterIds = [...new Set(docs.map(function(d) { return d.drafter_member_id; }).filter(Boolean))];
  var nameMap = {};
  if (drafterIds.length) {
    var { data: members, error: memErr } = await supabaseClient.from('org_members_detail').select('id, user_name').in('id', drafterIds);
    if (memErr) console.error('[approval/inbox] 기안자 이름 조회 실패:', memErr);
    (members || []).forEach(function(m) { nameMap[m.id] = m.user_name; });
  }

  docs.forEach(function(d) { d.drafter_name = nameMap[d.drafter_member_id] || ''; docCache[d.id] = d; });
}

var inboxGrid = null;

function renderList(items) {
  var emptyMsg = currentTab === 'pending' ? '결재 대기 중인 문서가 없습니다.'
    : currentTab === 'done' ? '처리한 문서가 없습니다.'
    : '참조/회람으로 지정된 문서가 없습니다.';

  var dateFrom = currentTab === 'pending' ? '' : document.getElementById('aprDateFrom').value;
  var dateTo = currentTab === 'pending' ? '' : document.getElementById('aprDateTo').value;

  var rows = items.filter(function(item) { return item.doc; }).map(function(item) {
    var d = item.doc;
    return {
      key: item.key,
      tab: currentTab,
      doc_no: d.doc_no,
      title: d.title,
      drafter: d.drafter_name || '',
      status: d.status,
      sub: item.sub,
      date: (d.submitted_at || d.created_at) ? localDateStr(new Date(d.submitted_at || d.created_at)) : '',
    };
  }).filter(function(r) {
    if (dateFrom && r.date && r.date < dateFrom) return false;
    if (dateTo && r.date && r.date > dateTo) return false;
    return true;
  });

  var ACTION_LABEL_BY_TAB = { pending: '결재하기', done: '결재 확인', watching: '열람' };
  var cols = [
    { headerName: '문서번호', field: 'doc_no', flex: 1, minWidth: 110, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start' } },
    { headerName: '제목', field: 'title', flex: 2, minWidth: 140, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start', fontWeight: 600 } },
    { headerName: '기안자', field: 'drafter', flex: 1, minWidth: 90 },
    { headerName: '구분', field: 'sub', flex: 1, minWidth: 100,
      cellRenderer: function(p) {
        var color = { DRAFT: '#6b7280', IN_PROGRESS: '#d97706', APPROVED: '#059669', REJECTED: '#dc2626', CANCELED: '#6b7280' }[p.data.status] || '#6b7280';
        var s = document.createElement('span');
        s.style.cssText = 'color:' + color + ';font-weight:600;';
        s.textContent = p.value;
        return s;
      } },
    { headerName: '날짜', field: 'date', flex: 1, minWidth: 90 },
    { headerName: '', field: 'key', flex: 0, width: 100, sortable: false,
      cellRenderer: function(p) {
        var btn = document.createElement('button');
        btn.className = 'btn btn-sm'; btn.textContent = ACTION_LABEL_BY_TAB[p.data.tab] || '상세보기';
        btn.addEventListener('click', function(e) { e.stopPropagation(); openDetail(p.value); });
        return btn;
      } },
  ];

  if (!inboxGrid) {
    inboxGrid = createMgGrid('aprInboxList', cols, rows, {
      noRowsText: emptyMsg,
      onRowClick: function(data) { openDetail(data.key); },
    });
  } else {
    // updateMgGrid는 rowData만 바꾸고 overlayNoRowsTemplate(빈 상태 문구)은 그대로 두기 때문에,
    // 탭을 바꿔도 맨 처음 만들어질 때의 문구("결재 대기 중인 문서가 없습니다")가 계속 남아있던
    // 버그가 있었다 — 탭이 바뀔 때마다 문구도 같이 갱신해준다.
    inboxGrid.setGridOption('overlayNoRowsTemplate', '<span style="color:#9ca3af;font-size:12px;">' + emptyMsg + '</span>');
    updateMgGrid(inboxGrid, rows);
  }
}

async function openDetail(key) {
  var source = currentTab === 'pending' ? pendingRows : currentTab === 'done' ? doneRows : watchingRows;
  var keyField = currentTab === 'watching' ? 'watcherRowId' : 'stepApproverId';
  var item = source.find(function(r) { return String(r[keyField]) === String(key); });
  if (!item) return;
  var doc = docCache[item.documentId];
  if (!doc) return;

  var { data: steps } = await supabaseClient
    .from('approval_steps')
    .select('id, step_no, decision_rule, step_type, status, approval_step_approvers(id, org_member_id, action, comment, acted_at)')
    .eq('document_id', item.documentId).order('step_no');

  var stepCols = (steps || []).map(function(s) {
    var approversHtml = (s.approval_step_approvers || []).map(function(a) {
      var label = ACTION_LABEL[a.action] || a.action;
      var canRetract = a.org_member_id === myOrgMemberId && (a.action === 'APPROVED' || a.action === 'REJECTED') &&
        doc.status !== 'REJECTED' && doc.status !== 'CANCELED';
      return '<div class="apr-line-approver-chip"><span>' + ts(memberName(a.org_member_id)) + '</span>' +
        '<span class="badge ' + (a.action === 'APPROVED' ? 'badge-green' : a.action === 'REJECTED' ? 'badge-red' : 'badge-blue') + '">' + label + '</span></div>' +
        (a.acted_at ? '<div style="font-size:10px;color:#9ca3af;padding:0 2px;">' + ts(formatDateTimeKRCompact(a.acted_at)) + '</div>' : '') +
        (a.comment ? '<div style="font-size:10px;color:#9ca3af;padding:0 2px;">' + ts(a.comment) + '</div>' : '') +
        (canRetract ? '<button type="button" class="btn btn-sm" style="width:100%;margin-top:3px;color:#b91c1c;" onclick="retractMyApproval(\'' + a.id + '\')">결재 취소</button>' : '');
    }).join('') || '<div style="font-size:10px;color:#c7ccd4;text-align:center;padding:8px 0;">결재자 없음</div>';

    return '<div class="apr-line-col">' +
      '<div class="apr-line-col-head"><b>' + s.step_no + '단계</b>' +
        '<span class="badge ' + (STATUS_BADGE[s.status] || 'badge-blue') + '" style="font-size:10px;">' + (STATUS_LABEL[s.status] || s.status) + '</span></div>' +
      '<span class="apr-type-badge type-' + (s.step_type === 'CONSULT' ? 'consult">협의' : 'approve">결재') + '</span>' +
      '<div class="apr-line-col-body">' + approversHtml + '</div>' +
    '</div>';
  });
  var stepsHtml = stepCols.length
    ? '<div class="apr-line-cols">' + stepCols.join('<div class="apr-line-arrow"><i class="ti ti-chevron-right"></i></div>') + '</div>'
    : '<div class="apr-empty">결재선 정보가 없습니다.</div>';

  var canAct = currentTab === 'pending';
  var currentStep = canAct ? (steps || []).find(function(s) { return s.status === 'IN_PROGRESS'; }) : null;
  var isConsult = currentStep && currentStep.step_type === 'CONSULT';

  var body =
    '<h3 style="margin:0 0 4px;font-size:15px;">' + ts(doc.title) + '</h3>' +
    '<div style="font-size:11px;color:#9ca3af;margin-bottom:14px;">' + ts(doc.doc_no) + ' · 기안자: ' + ts(doc.drafter_name || '') +
      ' · <span class="badge ' + (STATUS_BADGE[doc.status] || 'badge-blue') + '">' + (STATUS_LABEL[doc.status] || doc.status) + '</span></div>' +
    '<div class="m-section-title"><i class="ti ti-route"></i> 결재 진행 현황</div>' +
    stepsHtml +
    '<div class="apr-doc-render" style="border:1px solid #e5e7eb;border-radius:8px;padding:16px;margin:14px 0;">' + doc.content_html + '</div>';

  if (canAct) {
    if (isConsult) {
      body += '<div style="font-size:11px;color:#9ca3af;margin-top:10px;">이 단계는 협의 단계입니다 — 반려를 선택해도 의견으로만 기록되고 결재는 계속 진행됩니다.</div>';
    }
    body += '<textarea id="aprCommentBox" placeholder="의견 (선택)"></textarea>' +
      '<div class="apr-action-row">' +
        '<button type="button" class="btn btn-sm" id="aprRejectBtn" style="flex:1;">' + (isConsult ? '반대 의견' : '반려') + '</button>' +
        '<button type="button" class="btn btn-sm btn-primary" id="aprApproveBtn" style="flex:1;">' + (isConsult ? '동의' : '승인') + '</button>' +
      '</div>';
  }

  document.getElementById('aprDetailBody').innerHTML = body;
  openModal('aprDetailModal');

  if (canAct) {
    document.getElementById('aprApproveBtn').addEventListener('click', function() { act(item.stepApproverId, 'APPROVED'); });
    document.getElementById('aprRejectBtn').addEventListener('click', function() { act(item.stepApproverId, 'REJECTED'); });
  }
}

async function act(stepApproverId, action) {
  var label = action === 'APPROVED' ? '승인' : '반려';
  if (!confirm(label + '하시겠습니까?')) return;
  var comment = (document.getElementById('aprCommentBox') || {}).value || '';
  try {
    const { error } = await supabaseClient.rpc('act_on_approval_step', {
      p_step_approver_id: stepApproverId, p_action: action, p_comment: comment,
    });
    if (error) throw new Error(error.message);
    systemLog(action === 'APPROVED' ? 'APPROVAL_APPROVE' : 'APPROVAL_REJECT', '결재 ' + label + (comment ? ' — ' + comment : ''), { target_type: 'approval_step', target_id: stepApproverId }).catch(() => {});
    alert(label + ' 처리되었습니다.');
    closeModal('aprDetailModal');
    docCache = {}; // 상태 바뀐 문서가 있을 수 있어 캐시 초기화 후 재조회
    if (currentTab === 'pending') await loadPending(); else await loadDone();
  } catch (e) {
    alert(label + ' 실패: ' + e.message);
  }
}

window.retractMyApproval = async function(stepApproverId) {
  if (!confirm('이미 처리한 결재를 취소할까요? 문서는 다시 이 단계 대기 상태로 돌아갑니다.')) return;
  try {
    var { error } = await supabaseClient.rpc('retract_approval_step', { p_step_approver_id: stepApproverId });
    if (error) throw new Error(error.message);
    closeModal('aprDetailModal');
    reloadCurrentTab();
  } catch (e) {
    alert('취소 실패: ' + e.message);
  }
};

init();