'use strict';

var currentUser = null;
var myOrgMemberId = null;
var orgMembers = [];

function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function hideLoading() {
  var el = document.getElementById('globalLoading');
  if (el) el.classList.remove('is-open');
}

var STATUS_LABEL = { DRAFT: '임시저장', IN_PROGRESS: '결재중', APPROVED: '승인완료', REJECTED: '반려', CANCELED: '취소' };
var STATUS_BADGE = { DRAFT: 'badge-blue', IN_PROGRESS: 'badge-yellow', APPROVED: 'badge-green', REJECTED: 'badge-red', CANCELED: 'badge-blue' };
var ACTION_LABEL = { PENDING: '대기', APPROVED: '승인', REJECTED: '반려', SKIPPED: '-' };

async function init() {
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'approval/doc-detail')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    document.getElementById('backToListBtn').addEventListener('click', function() {
      location.href = 'draft.html?tab=mydocs';
    });

    await resolveMyContext();
    await loadOrgMembers();

    var docId = new URLSearchParams(location.search).get('id');
    if (!docId) {
      hideLoading();
      document.getElementById('aprDocDetailBody').innerHTML = '<div class="apr-empty">문서 정보가 없습니다.</div>';
      return;
    }
    await renderDetail(docId);
    hideLoading();
  } catch (e) {
    console.error('[approval/doc-detail] 초기화 실패:', e);
    hideLoading();
    document.getElementById('aprDocDetailBody').innerHTML = '<div class="apr-empty">문서를 불러오는 중 문제가 발생했습니다: ' + ts(e.message) + '</div>';
  }
}

async function resolveMyContext() {
  if (!currentUser.org_member_id) { console.warn('[approval/doc-detail] org_member_id 없음'); return; }
  var { data, error } = await supabaseClient
    .from('org_members')
    .select('id')
    .eq('id', currentUser.org_member_id)
    .maybeSingle();
  if (error) { console.error('[approval/doc-detail] resolveMyContext 조회 오류:', error); return; }
  if (!data) { console.warn('[approval/doc-detail] org_members 행 없음 — 미리보기 계정일 수 있음'); return; }
  myOrgMemberId = data.id;
}

async function loadOrgMembers() {
  var { data } = await supabaseClient.from('org_members_detail').select('id, user_name').eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false);
  orgMembers = data || [];
}
function memberName(id) {
  var m = orgMembers.find(function(o) { return o.id === id; });
  return m ? m.user_name : '(알 수 없음)';
}

async function renderDetail(docId) {
  var body = document.getElementById('aprDocDetailBody');

  var docErr, docFull;
  ({ data: docFull, error: docErr } = await supabaseClient
    .from('approval_documents').select('*').eq('id', docId).single());
  if (docErr) { body.innerHTML = '<div class="apr-empty">문서를 불러오지 못했습니다: ' + ts(docErr.message) + '</div>'; return; }

  var resubmitBtn = document.getElementById('aprResubmitBtn');
  if (resubmitBtn) {
    var canResubmit = docFull.status === 'REJECTED' && docFull.drafter_member_id === myOrgMemberId;
    resubmitBtn.style.display = canResubmit ? '' : 'none';
    resubmitBtn.onclick = function() {
      location.href = 'draft.html?resubmit=' + encodeURIComponent(docId);
    };
  }

  // 임시저장 상태는 아직 결재선이 없어서 진행 현황이 없다 — 이어서 작성하도록 유도.
  if (docFull.status === 'DRAFT') {
    body.innerHTML =
      '<div style="text-align:center;padding:40px 16px;">' +
      '<div class="apr-doc-no" style="display:inline-block;margin-bottom:10px;">' + ts(docFull.doc_no) + '</div>' +
      '<div style="font-size:16px;font-weight:800;color:#111827;margin-bottom:6px;">' + ts(docFull.title) + '</div>' +
      '<div style="font-size:11px;color:#9ca3af;margin-bottom:20px;">임시저장 상태</div>' +
      '<button type="button" class="btn btn-sm btn-primary" id="aprContinueBtn"><i class="ti ti-pencil"></i> 이어서 작성</button>' +
      '</div>';
    document.getElementById('aprContinueBtn').addEventListener('click', function() {
      location.href = 'draft.html?continue=' + encodeURIComponent(docId);
    });
    return;
  }

  var { data: steps, error: stepsErr } = await supabaseClient
    .from('approval_steps')
    .select('id, step_no, decision_rule, step_type, status, approval_step_approvers(id, org_member_id, action, comment, acted_at)')
    .eq('document_id', docId).order('step_no');
  if (stepsErr) console.error('[approval/doc-detail] approval_steps 조회 실패:', stepsErr);
  var { data: watcherRows, error: watcherErr } = await supabaseClient
    .from('approval_document_watchers').select('org_member_id, watcher_type').eq('document_id', docId);
  if (watcherErr) console.error('[approval/doc-detail] approval_document_watchers 조회 실패:', watcherErr);

  var stepCols = (steps || []).map(function(s) {
    var approversHtml = (s.approval_step_approvers || []).map(function(a) {
      var actionLabel = ACTION_LABEL[a.action] || a.action;
      var canRetract = a.org_member_id === myOrgMemberId && (a.action === 'APPROVED' || a.action === 'REJECTED') &&
        docFull.status !== 'REJECTED' && docFull.status !== 'CANCELED';
      return '<div class="apr-line-approver-chip"><span>' + ts(memberName(a.org_member_id)) + '</span>' +
        '<span class="badge ' + (a.action === 'APPROVED' ? 'badge-green' : a.action === 'REJECTED' ? 'badge-red' : 'badge-blue') + '">' + actionLabel + '</span></div>' +
        (a.acted_at ? '<div style="font-size:10px;color:#9ca3af;padding:0 2px;">' + ts(formatDateTimeKRCompact(a.acted_at)) + '</div>' : '') +
        (a.comment ? '<div style="font-size:10px;color:#9ca3af;padding:0 2px;">' + ts(a.comment) + '</div>' : '') +
        (canRetract ? '<button type="button" class="btn btn-sm" style="width:100%;margin-top:3px;color:#b91c1c;" onclick="retractMyApproval(\'' + a.id + '\')">결재 취소</button>' : '');
    }).join('') || '<div style="font-size:10px;color:#c7ccd4;text-align:center;padding:8px 0;">결재자 없음</div>';

    return '<div class="apr-line-col">' +
      '<div class="apr-line-col-head"><b>' + s.step_no + '단계</b>' +
        '<span class="badge ' + (STATUS_BADGE[s.status] || 'badge-blue') + '" style="font-size:10px;">' + (STATUS_LABEL[s.status] || s.status) + '</span></div>' +
      '<span class="apr-type-badge type-' + (s.step_type === 'CONSULT' ? 'consult">협의' : 'approve">결재') + '</span>' +
      '<div class="apr-line-col-body">' + approversHtml + '</div>' +
    '</div>';
  });
  var stepsHtml = stepCols.length
    ? '<div class="apr-line-cols">' + stepCols.join('<div class="apr-line-arrow"><i class="ti ti-chevron-right"></i></div>') + '</div>'
    : '<div class="apr-empty">결재선 정보가 없습니다.</div>';

  var typeLabel = { REF: '참조', CIRCULATE: '회람' };
  var watchersHtml = (watcherRows || []).length
    ? '<div class="apr-doc-watchers">참조/회람: ' +
        (watcherRows || []).map(function(w) {
          return '[' + typeLabel[w.watcher_type] + '] ' + ts(memberName(w.org_member_id));
        }).join(', ') +
      '</div>'
    : '';

  var { data: attachRows, error: attachErr } = await supabaseClient
    .from('approval_document_files').select('*').eq('document_id', docId).order('sort_order');
  if (attachErr) console.error('[approval/doc-detail] approval_document_files 조회 실패:', attachErr);
  var attachItemsHtml = await Promise.all((attachRows || []).map(async function(f) {
    var href = await db.getSignedUrl('approval-files', f.storage_path, 3600, f.file_name) || '#';
    return '<div class="apr-attach-list-item">' +
      '<i class="ti ti-paperclip"></i>' +
      '<span class="apr-attach-list-name">' + ts(f.file_name) + '</span>' +
      '<span class="apr-attach-list-size">' + fmtDocFileSize(f.file_size || 0) + '</span>' +
      '<a class="btn btn-sm" href="' + href + '" target="_blank" rel="noopener"><i class="ti ti-download"></i> 다운로드</a>' +
    '</div>';
  }));
  var attachHtml = attachItemsHtml.length
    ? '<div class="m-section-title"><i class="ti ti-paperclip"></i>첨부파일</div><div class="apr-attach-list">' + attachItemsHtml.join('') + '</div>'
    : '';

  var draftedAt = docFull.submitted_at || docFull.created_at;

  body.innerHTML =
    '<div class="apr-doc-header">' +
      '<div class="apr-doc-header-top">' +
        '<span class="apr-doc-no">' + ts(docFull.doc_no) + '</span>' +
        '<span class="badge ' + (STATUS_BADGE[docFull.status] || 'badge-blue') + '">' + (STATUS_LABEL[docFull.status] || docFull.status) + '</span>' +
      '</div>' +
      '<h2 class="apr-doc-title">' + ts(docFull.title) + '</h2>' +
      '<div class="apr-doc-meta">' +
        '<div class="apr-doc-meta-item"><span class="apr-doc-meta-label">기안자</span><span class="apr-doc-meta-value">' + ts(memberName(docFull.drafter_member_id)) + '</span></div>' +
        (draftedAt ? '<div class="apr-doc-meta-item"><span class="apr-doc-meta-label">기안일</span><span class="apr-doc-meta-value">' + ts(formatDateTimeKRCompact(draftedAt)) + '</span></div>' : '') +
        (docFull.completed_at ? '<div class="apr-doc-meta-item"><span class="apr-doc-meta-label">완료일</span><span class="apr-doc-meta-value">' + ts(formatDateTimeKRCompact(docFull.completed_at)) + '</span></div>' : '') +
      '</div>' +
    '</div>' +
    watchersHtml +
    '<div class="m-section-title"><i class="ti ti-route"></i>결재 진행 현황</div>' +
    stepsHtml +
    attachHtml +
    '<div class="apr-doc-render" style="border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin:14px 0;background:#fff;">' + docFull.content_html + '</div>';
}

function fmtDocFileSize(b) { return b < 1024 * 1024 ? (b / 1024).toFixed(0) + 'KB' : (b / (1024 * 1024)).toFixed(1) + 'MB'; }

window.retractMyApproval = async function(stepApproverId) {
  if (!confirm('이미 처리한 결재를 취소할까요? 문서는 다시 이 단계 대기 상태로 돌아갑니다.')) return;
  try {
    var { error } = await supabaseClient.rpc('retract_approval_step', { p_step_approver_id: stepApproverId });
    if (error) throw new Error(error.message);
    var docId = new URLSearchParams(location.search).get('id');
    await renderDetail(docId);
  } catch (e) {
    alert('취소 실패: ' + e.message);
  }
};

init();