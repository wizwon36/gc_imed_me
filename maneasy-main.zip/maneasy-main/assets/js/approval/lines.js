import { createRichEditor, insertTablePreset as _insertTablePreset } from '../core/rich-editor.js';

'use strict';

var currentUser = null;
var editor = null;
var departments = [];
var orgMembers = [];
var docTemplates = [];    // 양식 목록(content_html은 선택 시에만 채움)
var tplDeptMap = {};      // template_id -> [{id, dept_name}] (approval_doc_template_departments 조인 결과)
var docCategories = [];   // 업무분류 트리
var currentTplId = null;

function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v; }
function getCheckedDeptIds() {
  return Array.prototype.slice.call(document.querySelectorAll('.apr-tpl-dept-cb:checked')).map(function(cb) { return cb.value; });
}
function setCheckedDeptIds(ids) {
  var idSet = {};
  (ids || []).forEach(function(id) { idSet[id] = true; });
  document.querySelectorAll('.apr-tpl-dept-cb').forEach(function(cb) { cb.checked = !!idSet[cb.value]; });
  updateDeptScopeSummary();
}
function updateDeptScopeSummary() {
  var el = document.getElementById('aprTplDeptScopeSummary');
  if (!el) return;
  var checked = getCheckedDeptIds();
  if (!checked.length) { el.textContent = '전체 부서 공용'; return; }
  var names = checked.map(function(id) {
    var d = departments.find(function(x) { return x.id === id; });
    return d ? ts(d.dept_name) : '';
  }).filter(Boolean);
  el.textContent = names.length + '개 부서 — ' + names.join(', ');
}
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) {
  document.getElementById(id)?.classList.remove('is-open');
  updateDeptScopeSummary(); // 모달 닫을 때 요약 문구를 최신 체크 상태로 반영
}
// 이 파일은 <script type="module">로 로드돼서 함수들이 전역(window)에 자동으로 안 붙는다 —
// 그런데 HTML의 onclick="closeModal(...)"은 전역 스코프에서 이 이름을 찾으므로, 명시적으로 붙여줘야 한다.
window.openModal = openModal;
window.closeModal = closeModal;
function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function showLoading(text) {
  var el = document.getElementById('globalLoading');
  var t = document.getElementById('globalLoadingText');
  if (t && text) t.textContent = text;
  if (el) el.classList.add('is-open');
}
function hideLoading() {
  var el = document.getElementById('globalLoading');
  if (el) el.classList.remove('is-open');
}

async function init() {
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'approval/lines')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    await Promise.all([loadDepartments(), loadOrgMembers(), loadCategories()]);
    bindUi();
    await loadDocTemplates();
    hideLoading();
  } catch (e) {
    console.error('[approval/lines] 초기화 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 문제가 발생했습니다: ' + e.message);
  }
}

async function loadDepartments() {
  var { data } = await supabaseClient.from('departments').select('id, dept_name, clinic_id').eq('org_id', currentUser.org_id).eq('is_platform_test', false).order('dept_name');
  departments = data || [];
  var el2 = document.getElementById('aprTplDeptScopeList');
  if (el2) {
    el2.innerHTML = departments.map(function(d) {
      return '<label><input type="checkbox" class="apr-tpl-dept-cb" value="' + d.id + '"> ' + ts(d.dept_name) + '</label>';
    }).join('') || '<span style="font-size:12px;color:#9ca3af;">등록된 부서가 없습니다</span>';
  }
}

async function loadOrgMembers() {
  var { data, error } = await supabaseClient.from('org_members_detail').select('id, user_name, role').eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false);
  if (error) { console.error('[approval/lines] org_members_detail 조회 실패:', error); orgMembers = []; return; }
  orgMembers = data || [];
}
function memberName(id) {
  var m = orgMembers.find(function(o) { return o.id === id; });
  return m ? m.user_name : '(알 수 없음)';
}

function insertTablePreset(key) { _insertTablePreset(editor, key); }

function bindUi() {
  document.getElementById('aprTplNewBtn').addEventListener('click', startNewTemplate);
  document.getElementById('aprCategoryNewBtn').addEventListener('click', function() { addCategory(null); });
  document.getElementById('aprTplSearch').addEventListener('input', renderTplList);
  document.getElementById('aprTplSaveBtn').addEventListener('click', saveTemplate);
  document.getElementById('aprTplDeleteBtn').addEventListener('click', deleteTemplate);
  document.getElementById('aprTplUploadBtn').addEventListener('click', function() { document.getElementById('aprTplUploadInput').click(); });
  document.getElementById('aprTplUploadInput').addEventListener('change', onUploadTemplateFile);
  document.getElementById('aprTplWordUploadBtn').addEventListener('click', function() { document.getElementById('aprTplWordUploadInput').click(); });
  document.getElementById('aprTplWordUploadInput').addEventListener('change', onUploadWordTemplateFile);
  document.querySelectorAll('.apr-table-presets button[data-preset]').forEach(function(b) {
    b.addEventListener('click', function() { insertTablePreset(b.dataset.preset); });
  });
  var deptScopeBtn = document.getElementById('aprTplDeptScopeBtn');
  if (deptScopeBtn) {
    deptScopeBtn.addEventListener('click', function() {
      try { openModal('aprTplDeptModal'); }
      catch (e) { console.error('[approval/lines] 부서 모달 열기 실패:', e); alert('부서 선택 창을 여는 중 오류가 발생했습니다: ' + e.message); }
    });
  } else {
    console.error('[approval/lines] #aprTplDeptScopeBtn 요소를 찾을 수 없습니다 — HTML이 최신 버전인지 확인이 필요합니다.');
  }
  document.getElementById('aprTplDeptSelectAllBtn')?.addEventListener('click', function() {
    document.querySelectorAll('.apr-tpl-dept-cb').forEach(function(cb) { cb.checked = true; });
  });
  document.getElementById('aprTplDeptClearAllBtn')?.addEventListener('click', function() {
    document.querySelectorAll('.apr-tpl-dept-cb').forEach(function(cb) { cb.checked = false; });
  });
}

/* ══════════════ 양식 관리 ══════════════ */

async function loadCategories() {
  var { data, error } = await supabaseClient
    .from('approval_doc_categories')
    .select('id, parent_id, name, sort_order')
    .eq('org_id', currentUser.org_id).eq('active', true)
    .order('sort_order');
  if (error) { console.error('[approval/lines] approval_doc_categories 조회 실패:', error); docCategories = []; }
  else docCategories = data || [];
  populateCategorySelect();
}

function populateCategorySelect() {
  var sel = document.getElementById('aprTplCategorySelect');
  if (!sel) return;
  function opts(parentId, depth) {
    return docCategories.filter(function(c) { return c.parent_id === parentId; }).map(function(c) {
      return '<option value="' + c.id + '">' + '　'.repeat(depth) + ts(c.name) + '</option>' + opts(c.id, depth + 1);
    }).join('');
  }
  sel.innerHTML = '<option value="">미분류</option>' + opts(null, 0);
}

async function loadDocTemplates() {
  var { data, error } = await supabaseClient
    .from('approval_doc_templates')
    .select('id, name, doc_type, active, clinic_id, category_id')
    .eq('org_id', currentUser.org_id).eq('active', true)
    .order('name');
  if (error) { console.error('[approval/lines] approval_doc_templates 조회 실패:', error); docTemplates = []; }
  else docTemplates = data || [];

  tplDeptMap = {};
  if (docTemplates.length) {
    var ids = docTemplates.map(function(t) { return t.id; });
    var { data: links, error: linkErr } = await supabaseClient
      .from('approval_doc_template_departments')
      .select('template_id, dept_id, departments(dept_name)')
      .in('template_id', ids);
    if (linkErr) console.error('[approval/lines] approval_doc_template_departments 조회 실패:', linkErr);
    (links || []).forEach(function(l) {
      if (!tplDeptMap[l.template_id]) tplDeptMap[l.template_id] = [];
      tplDeptMap[l.template_id].push({ id: l.dept_id, dept_name: l.departments ? l.departments.dept_name : '' });
    });
  }
  renderTplList();
}

function templateScopeLabel(t) {
  var depts = tplDeptMap[t.id] || [];
  if (!depts.length) return '전체 부서';
  return depts.map(function(d) { return ts(d.dept_name); }).join(' · ');
}

var collapsedGroups = {}; // 그룹 헤더 접힘 상태 저장

function renderTplList() {
  var list = document.getElementById('aprTplList');
  var q = (document.getElementById('aprTplSearch')?.value || '').trim().toLowerCase();
  var visibleTemplates = q ? docTemplates.filter(function(t) { return (t.name || '').toLowerCase().indexOf(q) !== -1; }) : docTemplates;
  if (!docTemplates.length && !docCategories.length) { list.innerHTML = '<div class="apr-empty" style="padding:12px;">등록된 양식이 없습니다.</div>'; return; }

  function templateItemHtml(t, depth) {
    return '<div class="apr-list-item' + (t.id === currentTplId ? ' active' : '') + '" draggable="true" data-id="' + t.id + '" style="padding-left:' + (20 + depth * 10) + 'px;">' +
      '<div class="name">' + ts(t.name) + '</div>' +
      '<div class="meta">' + templateScopeLabel(t) + '</div>' +
    '</div>';
  }

  function renderNode(cat, depth) {
    var children = docCategories.filter(function(c) { return c.parent_id === cat.id; });
    var myTemplates = visibleTemplates.filter(function(t) { return t.category_id === cat.id; });
    var renderedChildren = children.map(function(c) { return renderNode(c, depth + 1); }).join('');
    if (q && !renderedChildren && !myTemplates.length) return ''; // 검색 중엔 매칭 없는 빈 분류는 아예 숨김
    var collapsed = !q && !!collapsedGroups[cat.id]; // 검색 중엔 접힘 무시하고 항상 펼침
    var header = '<div class="apr-group-header" data-cat-id="' + cat.id + '" data-group="' + cat.id + '" style="padding-left:' + (12 + depth * 10) + 'px;">' +
      '<span><span class="apr-group-arrow">' + (collapsed ? '▸' : '▾') + '</span> ' + ts(cat.name) + ' <span class="count">(' + myTemplates.length + ')</span></span>' +
      '<span class="apr-tree-actions">' +
        '<button type="button" class="apr-cat-add" data-id="' + cat.id + '" title="하위 분류 추가"><i class="ti ti-folder-plus"></i></button>' +
        '<button type="button" class="apr-cat-rename" data-id="' + cat.id + '" title="이름 변경"><i class="ti ti-pencil"></i></button>' +
        '<button type="button" class="apr-cat-del" data-id="' + cat.id + '" title="삭제"><i class="ti ti-trash"></i></button>' +
      '</span>' +
    '</div>';
    var body = '<div class="apr-group-children" style="display:' + (collapsed ? 'none' : '') + ';">' +
      renderedChildren + myTemplates.map(function(t) { return templateItemHtml(t, depth); }).join('') +
    '</div>';
    return header + body;
  }

  var topCategories = docCategories.filter(function(c) { return !c.parent_id; });
  var uncategorized = visibleTemplates.filter(function(t) { return !t.category_id; });

  var html = topCategories.map(function(c) { return renderNode(c, 0); }).join('');
  if (uncategorized.length) {
    var uCollapsed = !q && !!collapsedGroups['uncategorized'];
    html += '<div class="apr-group-header" data-cat-id="" data-group="uncategorized">' +
      '<span><span class="apr-group-arrow">' + (uCollapsed ? '▸' : '▾') + '</span> 미분류 <span class="count">(' + uncategorized.length + ')</span></span></div>' +
      '<div class="apr-group-children" style="display:' + (uCollapsed ? 'none' : '') + ';">' +
        uncategorized.map(function(t) { return templateItemHtml(t, 0); }).join('') +
      '</div>';
  }
  list.innerHTML = html || '<div class="apr-empty" style="padding:12px;">' + (q ? '검색 결과가 없습니다.' : '등록된 양식이 없습니다.') + '</div>';

  list.querySelectorAll('.apr-group-header').forEach(function(h) {
    h.addEventListener('click', function() {
      var gid = h.dataset.group;
      collapsedGroups[gid] = !collapsedGroups[gid];
      renderTplList();
    });
  });
  list.querySelectorAll('.apr-list-item').forEach(function(item) {
    item.addEventListener('click', function() { openTemplate(item.dataset.id); });
    item.addEventListener('dragstart', function(e) {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', item.dataset.id);
      item.classList.add('is-dragging');
    });
    item.addEventListener('dragend', function() { item.classList.remove('is-dragging'); });
  });
  list.querySelectorAll('.apr-cat-add').forEach(function(b) {
    b.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); addCategory(b.dataset.id); });
  });
  list.querySelectorAll('.apr-cat-rename').forEach(function(b) {
    b.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); renameCategory(b.dataset.id); });
  });
  list.querySelectorAll('.apr-cat-del').forEach(function(b) {
    b.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); deleteCategory(b.dataset.id); });
  });

  // 드롭 대상 — 분류 헤더 위에 양식을 끌어다 놓으면 그 분류로 이동(미분류는 data-cat-id="")
  list.querySelectorAll('.apr-group-header[data-cat-id]').forEach(function(header) {
    header.addEventListener('dragover', function(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      header.classList.add('is-drop-target');
    });
    header.addEventListener('dragleave', function() { header.classList.remove('is-drop-target'); });
    header.addEventListener('drop', function(e) {
      e.preventDefault();
      header.classList.remove('is-drop-target');
      var templateId = e.dataTransfer.getData('text/plain');
      moveTemplateToCategory(templateId, header.dataset.catId || null);
    });
  });
}

/** 드래그 앤 드롭으로 양식을 다른 업무분류로 이동 */
async function moveTemplateToCategory(templateId, categoryId) {
  var tpl = docTemplates.find(function(t) { return t.id === templateId; });
  if (!tpl || tpl.category_id === categoryId) return; // 제자리에 놓으면 아무 것도 안 함
  try {
    const { error } = await supabaseClient.from('approval_doc_templates').update({ category_id: categoryId }).eq('id', templateId);
    if (error) throw new Error(error.message);
    await loadDocTemplates();
  } catch (e) {
    alert('이동 실패: ' + e.message);
  }
}

async function addCategory(parentId) {
  var name = prompt(parentId ? '하위 분류 이름을 입력하세요.' : '새 업무분류 이름을 입력하세요.');
  if (!name || !name.trim()) return;
  try {
    const { error } = await supabaseClient.from('approval_doc_categories')
      .insert({ org_id: currentUser.org_id, parent_id: parentId || null, name: name.trim() });
    if (error) throw new Error(error.message);
    await loadCategories();
    renderTplList();
  } catch (e) {
    alert('추가 실패: ' + e.message);
  }
}

async function renameCategory(id) {
  var cat = docCategories.find(function(c) { return c.id === id; });
  if (!cat) return;
  var name = prompt('새 이름을 입력하세요.', cat.name);
  if (!name || !name.trim() || name.trim() === cat.name) return;
  try {
    const { error } = await supabaseClient.from('approval_doc_categories').update({ name: name.trim() }).eq('id', id);
    if (error) throw new Error(error.message);
    await loadCategories();
    renderTplList();
  } catch (e) {
    alert('이름 변경 실패: ' + e.message);
  }
}

async function deleteCategory(id) {
  var hasChildren = docCategories.some(function(c) { return c.parent_id === id; });
  var hasTemplates = docTemplates.some(function(t) { return t.category_id === id; });
  if (hasChildren || hasTemplates) {
    alert('하위 분류나 소속 양식이 있는 분류는 삭제할 수 없습니다. 먼저 비워주세요.');
    return;
  }
  if (!confirm('이 업무분류를 삭제하시겠습니까?')) return;
  try {
    const { error } = await supabaseClient.from('approval_doc_categories').update({ active: false }).eq('id', id);
    if (error) throw new Error(error.message);
    await loadCategories();
    renderTplList();
  } catch (e) {
    alert('삭제 실패: ' + e.message);
  }
}

async function ensureEditor(initialData) {
  if (editor) { editor.setData(initialData || ''); return; }
  editor = await createRichEditor(document.getElementById('aprDocEditor'), initialData);
}

function startNewTemplate() {
  currentTplId = null;
  tplOpenToken++; // 진행 중이던 openTemplate 결과가 있다면 이 시점 이후로는 무시되게 한다
  setVal('aprTplName', '');
  setVal('aprTplCategorySelect', '');
  setCheckedDeptIds([]);
  document.getElementById('aprTplEmptyMsg').style.display = 'none';
  document.getElementById('aprTplEditorWrap').style.display = '';
  document.getElementById('aprTplHeaderActions').style.display = 'flex';
  ensureEditor('<h2 style="text-align:center;">기 안 서</h2><p>&nbsp;</p>');
  renderTplList();
}

var tplOpenToken = 0; // 빠르게 여러 양식을 연달아 클릭할 때, 늦게 도착한 이전 요청이 나중에
                       // 도착한(=지금 선택된) 요청 결과를 덮어써버리는 경쟁 상태를 막기 위한 토큰.
                       // 매 openTemplate 호출마다 값을 올리고, 실제로 반영하기 직전에 그 사이
                       // 더 최신 호출이 없었는지(토큰이 그대로인지) 확인한다.

async function openTemplate(id) {
  currentTplId = id;
  renderTplList();
  var myToken = ++tplOpenToken;

  // "가끔씩" 실패하는 건 대개 네트워크 순간 지연이나 인증 토큰 갱신 타이밍 같은 일시적인
  // 문제라, 데이터/권한 자체는 멀쩡한데도 어쩌다 한 번 빈 결과가 오는 경우가 있다.
  // 완벽한 근본 원인을 못 잡아도, 실패 시 짧게 기다렸다가 한 번 더 시도하면 대부분 해결된다.
  var data, error;
  for (var attempt = 0; attempt < 2; attempt++) {
    var res = await supabaseClient.from('approval_doc_templates').select('*').eq('id', id).single();
    data = res.data; error = res.error;
    if (!error) break;
    if (attempt === 0) await new Promise(function(r) { setTimeout(r, 400); });
  }
  if (myToken !== tplOpenToken) return; // 그 사이 다른 양식을 또 클릭했으면 이 결과는 버린다
  if (error) { alert('양식을 불러오지 못했습니다: ' + error.message); return; }

  var { data: links } = await supabaseClient.from('approval_doc_template_departments').select('dept_id').eq('template_id', id);
  if (myToken !== tplOpenToken) return; // 여기서도 한 번 더 확인 — 두 번째 조회가 오래 걸릴 수도 있음

  setVal('aprTplName', data.name);
  setVal('aprTplCategorySelect', data.category_id || '');
  setCheckedDeptIds((links || []).map(function(l) { return l.dept_id; }));
  document.getElementById('aprTplEmptyMsg').style.display = 'none';
  document.getElementById('aprTplEditorWrap').style.display = '';
  document.getElementById('aprTplHeaderActions').style.display = 'flex';
  await ensureEditor(data.content_html);
  if (myToken !== tplOpenToken) return; // ensureEditor 자체도 비동기라, 그사이 또 바뀌었으면 여기서도 방어
}

function onUploadTemplateFile(e) {
  var file = e.target.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function() {
    if (editor) editor.setData(String(reader.result || ''));
  };
  reader.readAsText(file, 'utf-8');
  e.target.value = '';
}

/** .docx 업로드 → mammoth.js로 브라우저에서 바로 HTML 변환 (서버 처리 단계가 없는
 *  정적 사이트 구조라, 문서 서식을 그나마 안전하게 옮겨올 수 있는 방법 중 하나) */
async function onUploadWordTemplateFile(e) {
  var file = e.target.files[0];
  if (!file) return;
  if (typeof mammoth === 'undefined') {
    alert('Word 변환 기능을 불러오지 못했습니다. 인터넷 연결을 확인하고 새로고침 후 다시 시도해주세요.');
    e.target.value = '';
    return;
  }
  try {
    var arrayBuffer = await file.arrayBuffer();
    var result = await mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
    if (editor) editor.setData(result.value || '');
    if (result.messages && result.messages.length) {
      console.warn('[approval/lines] mammoth 변환 경고:', result.messages);
    }
    // 워드 문서 특성상 표/서식이 에디터로 그대로 다 옮겨지지 않을 수 있어서,
    // 불러온 뒤엔 반드시 화면에서 표/레이아웃을 눈으로 확인하고 다듬어야 한다고 안내.
    alert('Word 문서를 불러왔습니다. 표나 서식이 그대로 안 옮겨진 부분이 있을 수 있으니, 저장 전에 내용을 확인해주세요.');
  } catch (err) {
    alert('Word 변환 실패: ' + err.message);
  }
  e.target.value = '';
}

async function saveTemplate() {
  var name = val('aprTplName').trim();
  if (!name) { alert('양식 이름을 입력해주세요.'); return; }
  var contentHtml = editor ? editor.getData() : '';

  if (!currentUser.clinic_id) { alert('소속 의원 정보를 확인할 수 없어 저장할 수 없습니다.'); return; }

  try {
    var payload = {
      org_id: currentUser.org_id, doc_type: 'GENERAL', name: name, content_html: contentHtml,
      category_id: val('aprTplCategorySelect') || null,
      clinic_id: currentUser.clinic_id, // 양식은 항상 내(작성자) 소속 의원으로 저장 — 의원별 완전 분리
      created_by: currentUser.id,
    };
    var tplId = currentTplId;
    if (!tplId) {
      var { data, error } = await supabaseClient.from('approval_doc_templates').insert(payload).select().single();
      if (error) throw new Error(error.message);
      tplId = data.id;
    } else {
      var { error: upErr } = await supabaseClient.from('approval_doc_templates')
        .update({
          name: name, content_html: contentHtml,
          category_id: val('aprTplCategorySelect') || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', tplId);
      if (upErr) throw new Error(upErr.message);
    }

    // 적용 부서(다중) 동기화 — 기존 연결을 지우고 지금 체크된 것들로 다시 넣는 게 제일 단순하고 안전하다.
    var checkedDeptIds = getCheckedDeptIds();
    var { error: delErr } = await supabaseClient.from('approval_doc_template_departments').delete().eq('template_id', tplId);
    if (delErr) throw new Error(delErr.message);
    if (checkedDeptIds.length) {
      var { error: linkErr } = await supabaseClient.from('approval_doc_template_departments')
        .insert(checkedDeptIds.map(function(deptId) { return { template_id: tplId, dept_id: deptId }; }));
      if (linkErr) throw new Error(linkErr.message);
    }

    alert('저장되었습니다.');
    currentTplId = tplId;
    await loadDocTemplates();
  } catch (e) {
    alert('저장 실패: ' + e.message);
  }
}

async function deleteTemplate() {
  if (!currentTplId) { resetTplEditor(); return; }
  if (!confirm('이 양식을 삭제하시겠습니까? (이미 이 양식으로 작성된 문서엔 영향 없습니다)')) return;
  try {
    // 물리 삭제 대신 active=false로 비활성화 — 과거 문서가 참조하는 template_id가 끊기지 않도록.
    const { error } = await supabaseClient.from('approval_doc_templates').update({ active: false }).eq('id', currentTplId);
    if (error) throw new Error(error.message);
    resetTplEditor();
    await loadDocTemplates();
  } catch (e) {
    alert('삭제 실패: ' + e.message);
  }
}

function resetTplEditor() {
  currentTplId = null;
  tplOpenToken++;
  document.getElementById('aprTplEditorWrap').style.display = 'none';
  document.getElementById('aprTplEmptyMsg').style.display = '';
  document.getElementById('aprTplHeaderActions').style.display = 'none';
}

init();