(function () {
  'use strict';

  let currentUser = null;
  let myOrgMemberId = null;

  let calYear  = new Date().getFullYear();
  let calMonth = new Date().getMonth(); // 0-based
  let selectedDate = null;

  let _resources = [];        // 활성 자원 전체(유형 필터용)
  let _selectedResourceId = null;
  let _monthReservations = []; // 선택한 자원의, 현재 달력에 보이는 범위 전체 예약
  let _userNameCache = {};    // org_member_id -> { user_name, dept_name } (상세 패널에 예약자 표시용)

  function esc(v) {
    return String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function openModal(id)  { document.getElementById(id)?.classList.add('is-open'); }
  function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
  window.closeModal = closeModal;

  function localDateStr(d) {
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  }
  function todayStr() { return localDateStr(new Date()); }
  function fmtHM(isoStr) {
    const d = new Date(isoStr);
    return String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
  }

  function getGridRange() {
    const firstDay = new Date(calYear, calMonth, 1).getDay();
    const lastDate = new Date(calYear, calMonth+1, 0).getDate();
    const totalCellsBeforeTrailing = firstDay + lastDate;
    const trailing = (7 - (totalCellsBeforeTrailing % 7)) % 7;
    const gridStartDate = new Date(calYear, calMonth, 1 - firstDay);
    const gridEndExclusiveDate = new Date(calYear, calMonth, lastDate + trailing + 1);
    return { gridStart: localDateStr(gridStartDate), gridEndExclusive: localDateStr(gridEndExclusiveDate) };
  }

  async function loadResourceOptions() {
    const typeFilter = document.getElementById('rbTypeFilter').value;
    let q = supabaseClient.from('resources').select('*')
      .eq('org_id', currentUser.org_id).eq('active', true)
      .order('type').order('name');
    if (typeFilter) q = q.eq('type', typeFilter);
    const { data, error } = await q;
    if (error) { alert('자원 목록 조회 실패: ' + error.message); return; }
    _resources = data || [];

    const sel = document.getElementById('rbResourceSelect');
    if (!_resources.length) {
      sel.innerHTML = '<option value="">등록된 자원이 없습니다</option>';
      _selectedResourceId = null;
      renderCalGrid();
      renderDetail();
      return;
    }
    const keepId = _resources.some(r => r.id === _selectedResourceId) ? _selectedResourceId : _resources[0].id;
    sel.innerHTML = _resources.map(r =>
      `<option value="${r.id}">${r.type === 'room' ? '🏢' : '🚗'} ${esc(r.name)}${r.detail ? ' (' + esc(r.detail) + ')' : ''}${r.type === 'room' && r.capacity ? ' · ' + r.capacity + '인' : ''}</option>`
    ).join('');
    sel.value = keepId;
    _selectedResourceId = keepId;
    await loadMonthReservations();
  }

  async function loadMonthReservations() {
    if (!_selectedResourceId) return;
    const { gridStart, gridEndExclusive } = getGridRange();
    const { data, error } = await supabaseClient
      .from('resource_reservations')
      .select('id, org_member_id, title, start_at, end_at')
      .eq('resource_id', _selectedResourceId)
      .lt('start_at', gridEndExclusive + 'T00:00:00+09:00')
      .gt('end_at', gridStart + 'T00:00:00+09:00')
      .order('start_at');
    if (error) { alert('예약 현황 조회 실패: ' + error.message); return; }
    _monthReservations = data || [];

    // 예약자 이름·부서 캐시 채우기(상세 패널용) — 아직 캐시에 없는 사람만 조회
    const missingIds = [...new Set(_monthReservations.map(r => r.org_member_id))].filter(id => !_userNameCache[id]);
    if (missingIds.length) {
      const { data: members } = await supabaseClient
        .from('org_members_detail').select('id, user_name, dept_name').in('id', missingIds);
      (members || []).forEach(m => { _userNameCache[m.id] = { user_name: m.user_name, dept_name: m.dept_name }; });
    }

    document.getElementById('rbMonthLabel').textContent = `${calYear}년 ${calMonth+1}월`;
    renderCalGrid();
    renderDetail();
  }

  function localDateOf(isoStr) {
    const d = new Date(isoStr);
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  }

  function reservationsOnDate(dateStr) {
    return _monthReservations.filter(r => {
      // r.start_at/end_at는 서버가 UTC로 내려주므로, 문자열을 그대로 자르면 자정 근처
      // 시간대(예: 새벽 1시 KST = 전날 16시 UTC)에서 날짜가 하루 밀리는 버그가 있었다.
      // 반드시 Date로 변환해 로컬(KST) 달력 날짜 기준으로 비교해야 한다.
      const s = localDateOf(r.start_at), e = localDateOf(r.end_at);
      return dateStr >= s && dateStr <= e;
    });
  }

  function renderCalGrid() {
    const grid = document.getElementById('rbCalGrid');
    const today = todayStr();
    const firstDay = new Date(calYear, calMonth, 1).getDay();
    const lastDate = new Date(calYear, calMonth+1, 0).getDate();
    const prevLastDate = new Date(calYear, calMonth, 0).getDate();
    const cells = [];

    function ld(y, m, d) { return `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }

    for (let i = firstDay-1; i >= 0; i--) {
      const dd = prevLastDate - i;
      let pm = calMonth, py = calYear;
      if (pm === 0) { pm = 12; py--; }
      cells.push({ date: ld(py, pm, dd), otherMonth: true });
    }
    for (let d = 1; d <= lastDate; d++) cells.push({ date: ld(calYear, calMonth+1, d), otherMonth: false });
    let next = 1, nm = calMonth + 2, ny = calYear;
    if (nm > 12) { nm = 1; ny++; }
    while (cells.length % 7 !== 0) cells.push({ date: ld(ny, nm, next++), otherMonth: true });

    grid.innerHTML = cells.map(({ date, otherMonth }) => {
      const day = new Date(date + 'T00:00:00').getDay();
      const resv = reservationsOnDate(date).sort((a,b) => a.start_at.localeCompare(b.start_at));
      const isSel = date === selectedDate;
      const isTod = date === today;

      const cls = ['cal-cell'];
      if (otherMonth) cls.push('other-month');
      if (day === 0) cls.push('sun');
      if (day === 6) cls.push('sat');
      if (isSel) cls.push('selected');
      if (isTod) cls.push('today');

      const dayNum = parseInt(date.slice(8));
      const chips = resv.slice(0, 3).map(r => {
        const mine = r.org_member_id === myOrgMemberId;
        return `<div class="cal-res-chip${mine ? ' mine' : ''}" title="${esc(fmtHM(r.start_at) + '~' + fmtHM(r.end_at) + ' ' + r.title)}">${fmtHM(r.start_at)} ${esc(r.title)}</div>`;
      }).join('');
      const more = resv.length > 3 ? `<div class="cal-res-chip more">+${resv.length-3}건</div>` : '';

      return `<div class="${cls.join(' ')}" data-date="${date}">
        <div class="cal-date-num">${dayNum}</div>
        ${chips}${more}
      </div>`;
    }).join('');

    grid.querySelectorAll('.cal-cell').forEach(cell => {
      cell.addEventListener('click', () => { selectedDate = cell.dataset.date; renderCalGrid(); renderDetail(); });
    });
  }

  function renderDetail() {
    const dateLabel = document.getElementById('rbDetailDate');
    const body = document.getElementById('rbDetailBody');
    const addBtn = document.getElementById('rbAddBtn');

    if (!selectedDate || !_selectedResourceId) {
      dateLabel.textContent = '날짜를 선택하세요';
      addBtn.disabled = true;
      return;
    }
    const d = new Date(selectedDate + 'T00:00:00');
    dateLabel.textContent = `${d.getMonth()+1}월 ${d.getDate()}일 (${['일','월','화','수','목','금','토'][d.getDay()]})`;
    addBtn.disabled = false;

    const resv = reservationsOnDate(selectedDate).sort((a,b) => a.start_at.localeCompare(b.start_at));
    if (!resv.length) {
      body.innerHTML = '<div style="text-align:center;color:#9ca3af;font-size:12px;padding:20px 0;">이 날짜엔 예약이 없습니다.</div>';
      return;
    }
    body.innerHTML = resv.map(r => {
      const mine = r.org_member_id === myOrgMemberId;
      const owner = _userNameCache[r.org_member_id];
      const ownerLabel = owner
        ? [owner.dept_name, owner.user_name].filter(Boolean).join(' / ')
        : '';
      return `<div class="rb-item-card">
        <div class="rb-item-time">${fmtHM(r.start_at)} ~ ${fmtHM(r.end_at)}</div>
        <div class="rb-item-title">${esc(r.title)}${ownerLabel ? ' <span style="color:#9ca3af;">· ' + esc(ownerLabel) + '</span>' : ''}</div>
        ${mine ? `<div class="rb-item-foot"><button class="tbl-btn tbl-btn--danger" data-res-id="${r.id}">취소</button></div>` : ''}
      </div>`;
    }).join('');
    body.querySelectorAll('[data-res-id]').forEach(btn => {
      btn.addEventListener('click', () => deleteReservation(btn.dataset.resId));
    });
  }

  function timeOptionsHtml() {
    let html = '';
    for (let h = 0; h < 24; h++) {
      for (let m = 0; m < 60; m += 30) {
        const v = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0');
        html += `<option value="${v}">${v}</option>`;
      }
    }
    return html;
  }

  function openBookModal() {
    if (!selectedDate || !_selectedResourceId) return;
    const res = _resources.find(r => r.id === _selectedResourceId);
    const d = new Date(selectedDate + 'T00:00:00');
    const dateLabel = `${d.getMonth()+1}월 ${d.getDate()}일(${['일','월','화','수','목','금','토'][d.getDay()]})`;
    document.getElementById('rbBookModalTitle').textContent = dateLabel + ' · ' + (res ? res.name : '자원') + ' 예약';
    document.getElementById('rb_title').value = '';
    const startSel = document.getElementById('rb_start');
    const endSel = document.getElementById('rb_end');
    startSel.innerHTML = timeOptionsHtml();
    endSel.innerHTML = timeOptionsHtml();
    startSel.value = '09:00';
    endSel.value = '10:00';
    openModal('rbBookModal');
  }

  async function saveReservation() {
    const title = (document.getElementById('rb_title').value || '').trim();
    const startTime = document.getElementById('rb_start').value;
    const endTime = document.getElementById('rb_end').value;
    if (!title) { alert('예약 목적/제목을 입력해 주세요.'); return; }
    if (!startTime || !endTime || startTime >= endTime) { alert('시작 시간이 종료 시간보다 빨라야 합니다.'); return; }

    const payload = {
      org_id: currentUser.org_id,
      resource_id: _selectedResourceId,
      org_member_id: myOrgMemberId,
      title,
      start_at: selectedDate + 'T' + startTime + ':00+09:00',
      end_at: selectedDate + 'T' + endTime + ':00+09:00',
    };
    const { error } = await supabaseClient.from('resource_reservations').insert(payload);
    if (error) {
      if (error.message && (error.message.toLowerCase().includes('exclusion') || error.message.toLowerCase().includes('_excl'))) {
        alert('이미 그 시간대에 예약이 있습니다. 다른 시간을 선택해 주세요.');
      } else {
        alert('예약 실패: ' + error.message);
      }
      return;
    }
    closeModal('rbBookModal');
    await loadMonthReservations();
  }

  async function deleteReservation(id) {
    if (!confirm('이 예약을 취소하시겠습니까?')) return;
    const { error } = await supabaseClient.from('resource_reservations').delete().eq('id', id);
    if (error) { alert('취소 실패: ' + error.message); return; }
    await loadMonthReservations();
  }

  async function init() {
    currentUser = await auth.getSession();
    if (!currentUser) { parent.shellNavigate?.('login'); return; }

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'task/resource-booking')) {
      alert('이 페이지에 접근할 권한이 없습니다.');
      parent.shellNavigate?.('home');
      return;
    }
    myOrgMemberId = currentUser.org_member_id || null;

    document.getElementById('rbTypeFilter').addEventListener('change', async () => {
      showGlobalLoading('자원 정보를 불러오는 중...');
      try { await loadResourceOptions(); } finally { hideGlobalLoading(); }
    });
    document.getElementById('rbResourceSelect').addEventListener('change', async function() {
      _selectedResourceId = this.value || null;
      selectedDate = null;
      showGlobalLoading('예약 현황을 불러오는 중...');
      try { await loadMonthReservations(); } finally { hideGlobalLoading(); }
    });
    document.getElementById('rbPrevBtn').addEventListener('click', () => { calMonth--; if (calMonth < 0) { calMonth = 11; calYear--; } loadMonthReservations(); });
    document.getElementById('rbNextBtn').addEventListener('click', () => { calMonth++; if (calMonth > 11) { calMonth = 0; calYear++; } loadMonthReservations(); });
    document.getElementById('rbTodayBtn').addEventListener('click', () => {
      const now = new Date();
      calYear = now.getFullYear(); calMonth = now.getMonth(); selectedDate = todayStr();
      loadMonthReservations();
    });
    document.getElementById('rbAddBtn').addEventListener('click', openBookModal);
    document.getElementById('rbBookSaveBtn').addEventListener('click', saveReservation);

    document.getElementById('rbMonthLabel').textContent = `${calYear}년 ${calMonth+1}월`;
    await loadResourceOptions();
    hideGlobalLoading();
  }

  document.addEventListener('DOMContentLoaded', init);
})();