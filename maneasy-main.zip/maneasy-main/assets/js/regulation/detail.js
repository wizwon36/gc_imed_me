/**
 * assets/js/regulation/detail.js
 * 규정 상세 — 조항(전체보기/목록·편집) + 버전 이력/배포, 위원회와 독립적으로 관리.
 * 이 규정을 사용하는 위원회 목록은 committee_regulations 연결 테이블로 조회해서 보여준다
 * (연결/해제 자체는 위원회 상세 화면에서 한다).
 */
import { createRichEditor } from '../core/rich-editor.js';

let currentUser = null;
let canEdit = false;   // manager 이상
let canDelete = false; // admin (규정 자체 관리에서는 현재 별도 삭제 UI 없음 — 필요 시 확장)

let regulationId = null;
let regulation = null;
let sections = [];
let currentVersion = null; // 현재 시행 중인 버전(최근 배포 이력) — 화면 표기 + 출력 시 기본값으로 사용

function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.openModal = openModal;
window.closeModal = closeModal;

function getRegulationIdFromUrl() {
  return new URLSearchParams(location.search).get('id');
}

/* ══════════════════════════════════════════════
   규정 기본 정보
══════════════════════════════════════════════ */
async function loadRegulation() {
  const { data, error } = await supabaseClient.from('regulations').select('*').eq('id', regulationId).single();
  if (error) throw new Error(error.message);
  return data;
}

/** 배포된 버전 이력 중 "현재 시행 중"으로 볼 수 있는 가장 최근 버전을 가져온다.
 * 시행일(effective_date)이 있으면 그 기준 최신순, 없으면 배포일시(snapshot_at) 기준 최신순. */
async function loadCurrentVersion() {
  const { data, error } = await supabaseClient
    .from('regulation_history')
    .select('*')
    .eq('regulation_id', regulationId)
    .order('effective_date', { ascending: false, nullsFirst: false })
    .order('snapshot_at', { ascending: false })
    .limit(1);
  if (error) throw new Error(error.message);
  return (data && data[0]) || null;
}

function renderRegulationHead() {
  document.getElementById('regName').textContent = regulation.name;
  const badge = document.getElementById('regStatusBadge');
  badge.textContent = regulation.active === 'Y' ? '활성' : '비활성';
  badge.classList.toggle('is-in-use', regulation.active === 'Y');
  document.title = regulation.name + ' · 규정 상세';
}

function renderCurrentVersionBadge() {
  const badge = document.getElementById('regCurrentVersionBadge');
  if (!currentVersion) { badge.style.display = 'none'; return; }
  badge.style.display = '';
  badge.textContent = currentVersion.version_label + (currentVersion.effective_date ? ' · 시행일 ' + currentVersion.effective_date : '');
}

function openEditRegulation() {
  setVal('rf_name', regulation.name);
  setVal('rf_description', regulation.description || '');
  setVal('rf_active', regulation.active || 'Y');
  openModal('regulationModal');
}

async function saveRegulationInfo() {
  const name = val('rf_name');
  if (!name) { showMessage('규정명은 필수입니다.', 'warning'); return; }
  try {
    showGlobalLoading('저장 중...');
    const payload = { name, description: val('rf_description'), active: val('rf_active') || 'Y', updated_at: new Date().toISOString() };
    const { error } = await supabaseClient.from('regulations').update(payload).eq('id', regulationId);
    if (error) throw new Error(error.message);
    systemLog('REGULATION_UPDATE', '규정 정보 수정 — ' + name, { target_type: 'regulations', target_id: regulationId }).catch(() => {});
    regulation = await loadRegulation();
    renderRegulationHead();
    closeModal('regulationModal');
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   사용 위원회 (committee_regulations 연결 조회 전용 — 연결/해제는 위원회 상세에서)
══════════════════════════════════════════════ */
async function loadLinkedCommittees() {
  const { data, error } = await supabaseClient
    .from('committee_regulations')
    .select('committees(id, name)')
    .eq('regulation_id', regulationId);
  if (error) throw new Error(error.message);
  return (data || []).map(r => r.committees).filter(Boolean);
}

function renderLinkedCommittees(list) {
  const area = document.getElementById('linkedCommitteesArea');
  if (!list.length) {
    area.className = 'm-empty';
    // 원래 HTML의 인라인 스타일(white-space:nowrap; overflow-x:auto; height:20px)은 칩(뱃지)이
    // 가로로 나열될 때를 위한 것이라, 문장 형태의 안내문구에 그대로 적용되면 한 줄로 강제되면서
    // 잘려 보이는 문제가 있었다(실제로 겪음) — 안내문구를 보여줄 땐 이 제약들을 풀어준다.
    area.style.padding = '10px 0';
    area.style.whiteSpace = 'normal';
    area.style.height = 'auto';
    area.style.overflowX = 'visible';
    area.textContent = '이 규정을 사용하는 위원회가 없습니다. (연결은 위원회 상세 화면에서 할 수 있어요)';
    return;
  }
  area.className = '';
  area.style.padding = '';
  area.style.whiteSpace = 'nowrap';
  area.style.height = '20px';
  area.style.overflowX = 'auto';
  area.innerHTML = list.map(c =>
    `<a class="list-context-chip" href="javascript:void(0)" onclick="parent.shellNavigate && parent.shellNavigate('committee/detail?id=${encodeURIComponent(c.id)}')" style="text-decoration:none;margin:0 6px 0 0;vertical-align:middle;">
      <i class="ti ti-users-group"></i>${ts(c.name)}
    </a>`).join('');
}

/* ══════════════════════════════════════════════
   규정 조항 (전체보기 / 목록·편집)
══════════════════════════════════════════════ */
async function loadSections() {
  const { data, error } = await supabaseClient
    .from('regulation_sections')
    .select('*')
    .eq('regulation_id', regulationId)
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

let _sectionGridApi = null;
let _regView = 'doc'; // 'doc' | 'grid'

function renderSections() {
  renderRegDoc();
  if (_sectionGridApi || _regView === 'grid') renderSectionGrid();
}

/** 전체보기 — 조항을 순서대로 이어붙여서 실제 규정 문서처럼 한 번에 읽을 수 있게 렌더링 */
function renderRegDoc() {
  const view = document.getElementById('regDocView');
  if (!sections.length) {
    view.innerHTML = '<div style="padding:24px;text-align:center;color:#9ca3af;font-size:13px;">등록된 조항이 없습니다.</div>';
    return;
  }
  view.innerHTML = '<div class="reg-doc-view">' +
    sections.map(s => `
      <div class="reg-doc-section">
        <div class="reg-doc-section-title">${ts(s.title)} <span class="sec-key">${ts(s.sec_id)}</span></div>
        ${s.content_html || '<em style="color:#9ca3af;">내용 없음</em>'}
      </div>`).join('') +
    '</div>';
}

function renderSectionGrid() {
  const rows = sections.map((s, idx) => ({ ...s, _idx: idx }));
  const colDefs = [
    { headerName: '조항 키', field: 'sec_id', width: 130, cellStyle: { fontFamily: 'Consolas, monospace', fontSize: '11px', color: '#6b7280' } },
    { headerName: '제목', field: 'title', flex: 1, minWidth: 200, headerClass: 'ag-left-header',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', fontWeight: 700 } },
    { headerName: '최종 수정', field: 'updated_at', width: 320, headerClass: 'ag-left-header',
      valueFormatter: p => p.value ? (new Date(p.value).toLocaleString('ko-KR') + (p.data.updated_by ? ' · ' + p.data.updated_by : '')) : '-',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', fontSize: '11px', color: '#6b7280' } },
    { headerName: '', width: 90, sortable: false,
      cellRenderer: p => {
        const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;';
        const viewBtn = document.createElement('button'); viewBtn.className = 'btn btn-sm'; viewBtn.textContent = '조회';
        viewBtn.onclick = () => openSectionView(sections[p.data._idx]);
        wrap.append(viewBtn);
        if (canEdit) {
          const editBtn = document.createElement('button'); editBtn.className = 'btn btn-sm'; editBtn.textContent = '수정';
          editBtn.onclick = () => openSectionEdit(sections[p.data._idx]);
          wrap.append(editBtn);
        }
        return wrap;
      }},
  ];
  if (!_sectionGridApi) {
    _sectionGridApi = createMgGrid('sectionGrid', colDefs, rows, { noRowsText: '등록된 조항이 없습니다.' });
  } else {
    updateMgGrid(_sectionGridApi, rows);
  }
}

function switchRegView(view) {
  _regView = view;
  document.getElementById('regDocView').style.display = view === 'doc' ? '' : 'none';
  document.getElementById('sectionGrid').style.display = view === 'grid' ? '' : 'none';
  document.getElementById('regViewDocBtn').classList.toggle('active', view === 'doc');
  document.getElementById('regViewGridBtn').classList.toggle('active', view === 'grid');
  if (view === 'grid') {
    if (!_sectionGridApi) renderSectionGrid();
    else refitGridColumns(_sectionGridApi);
  }
}

function openSectionView(section) {
  document.getElementById('sectionViewTitle').textContent = section.title;
  document.getElementById('sectionViewContent').innerHTML = section.content_html || '<em style="color:#9ca3af;">내용 없음</em>';
  const editBtn = document.getElementById('editFromViewBtn');
  if (canEdit) {
    editBtn.style.display = '';
    editBtn.onclick = () => { closeModal('sectionViewModal'); openSectionEdit(section); };
  } else {
    editBtn.style.display = 'none';
  }
  openModal('sectionViewModal');
}

let _editingSectionId = null;

function openSectionAdd() {
  _editingSectionId = null;
  document.getElementById('sectionModalTitle').textContent = '조항 추가';
  setVal('sf_sec_id', '');
  document.getElementById('sf_sec_id').disabled = false;
  setVal('sf_title', '');
  setSectionContentHtml('');
  document.getElementById('revertSectionBtn').style.display = 'none';
  openModal('sectionModal');
}

function openSectionEdit(section) {
  _editingSectionId = section.id;
  document.getElementById('sectionModalTitle').textContent = '조항 편집 — ' + section.title;
  setVal('sf_sec_id', section.sec_id);
  document.getElementById('sf_sec_id').disabled = true;
  setVal('sf_title', section.title);
  setSectionContentHtml(section.content_html || '');

  const revertBtn = document.getElementById('revertSectionBtn');
  if (section.previous_html) {
    revertBtn.style.display = '';
    revertBtn.onclick = () => revertSection(section);
  } else {
    revertBtn.style.display = 'none';
  }
  openModal('sectionModal');
}

async function saveSection() {
  const secId = val('sf_sec_id');
  const title = val('sf_title');
  const contentHtml = getSectionContentHtml().trim();
  if (!secId) { showMessage('조항 키는 필수입니다.', 'warning'); return; }
  if (!title) { showMessage('제목은 필수입니다.', 'warning'); return; }
  if (!contentHtml) { showMessage('내용은 필수입니다.', 'warning'); return; }

  try {
    showGlobalLoading('저장 중...');
    const now = new Date().toISOString();
    const who = currentUser?.email || currentUser?.user_name || '';

    if (_editingSectionId) {
      const existing = sections.find(s => s.id === _editingSectionId);
      const { error } = await supabaseClient.from('regulation_sections').update({
        title, content_html: contentHtml,
        updated_at: now, updated_by: who,
        previous_html: existing?.content_html || '',
        previous_at: existing?.updated_at || null,
        previous_by: existing?.updated_by || null,
      }).eq('id', _editingSectionId);
      if (error) throw new Error(error.message);
      systemLog('REGULATION_SECTION_UPDATE', '규정 조항 수정 — ' + regulation.name + ' / ' + title, {
        target_type: 'regulation_sections', target_id: _editingSectionId,
      }).catch(() => {});
    } else {
      if (sections.some(s => s.sec_id === secId)) { showMessage('이미 존재하는 조항 키입니다.', 'warning'); hideGlobalLoading(); return; }
      const { data, error } = await supabaseClient.from('regulation_sections').insert({
        regulation_id: regulationId, sec_id: secId, title, content_html: contentHtml,
        updated_at: now, updated_by: who, sort_order: sections.length + 1,
      }).select().single();
      if (error) throw new Error(error.message);
      systemLog('REGULATION_SECTION_CREATE', '규정 조항 등록 — ' + regulation.name + ' / ' + title, {
        target_type: 'regulation_sections', target_id: data?.id,
      }).catch(() => {});
    }

    closeModal('sectionModal');
    sections = await loadSections();
    renderSections();
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function revertSection(section) {
  if (!confirm(`"${section.title}" 조항을 이전 버전으로 되돌리시겠습니까?`)) return;
  try {
    showGlobalLoading('되돌리는 중...');
    const now = new Date().toISOString();
    const who = currentUser?.email || currentUser?.user_name || '';
    const { error } = await supabaseClient.from('regulation_sections').update({
      content_html: section.previous_html,
      updated_at: now, updated_by: who,
      previous_html: section.content_html,
      previous_at: section.updated_at,
      previous_by: section.updated_by,
    }).eq('id', section.id);
    if (error) throw new Error(error.message);
    systemLog('REGULATION_SECTION_REVERT', '규정 조항 되돌리기 — ' + regulation.name + ' / ' + section.title, {
      target_type: 'regulation_sections', target_id: section.id,
    }).catch(() => {});
    closeModal('sectionModal');
    sections = await loadSections();
    renderSections();
    showMessage('이전 버전으로 되돌렸습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '되돌리기 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ── 버전 배포/이력 ── */
function genHistoryId() {
  const d = new Date();
  const dateStr = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  return { prefix: 'RH-' + dateStr + '-', dateStr };
}

async function openDeployModal() {
  setVal('df_version_label', '');
  setVal('df_effective_date', '');
  setVal('df_memo', '');
  openModal('deployModal');
}

async function deployVersion() {
  const versionLabel = val('df_version_label');
  const effectiveDate = val('df_effective_date');
  const memo = val('df_memo');
  if (!versionLabel) { showMessage('버전명은 필수입니다.', 'warning'); return; }
  if (!effectiveDate) { showMessage('시행일은 필수입니다.', 'warning'); return; }

  try {
    showGlobalLoading('배포 중...');
    const { prefix } = genHistoryId();
    const { data: existing } = await supabaseClient
      .from('regulation_history')
      .select('history_id')
      .eq('regulation_id', regulationId)
      .like('history_id', prefix + '%');
    const seq = String((existing?.length || 0) + 1).padStart(3, '0');
    const historyId = prefix + seq;

    const snapshot = sections.map(s => ({ sec_id: s.sec_id, title: s.title, content_html: s.content_html }));
    const who = currentUser?.email || currentUser?.user_name || '';

    const { error } = await supabaseClient.from('regulation_history').insert({
      regulation_id: regulationId, history_id: historyId, version_label: versionLabel,
      effective_date: effectiveDate, created_by: who, memo, sections_json: snapshot,
    });
    if (error) throw new Error(error.message);
    systemLog('REGULATION_DEPLOY', '규정 버전 배포 — ' + regulation.name + ' / ' + versionLabel, {
      target_type: 'regulation_history', target_id: historyId,
    }).catch(() => {});
    closeModal('deployModal');
    showMessage('배포되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '배포 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function openHistoryModal() {
  showGlobalLoading('불러오는 중...');
  try {
    const { data, error } = await supabaseClient
      .from('regulation_history')
      .select('*')
      .eq('regulation_id', regulationId)
      .order('snapshot_at', { ascending: false });
    if (error) throw new Error(error.message);

    const body = document.getElementById('historyListBody');
    if (!data || !data.length) {
      body.innerHTML = '<tr class="sec-tbl-row sec-tbl-row--empty"><td class="sec-tbl-cell sec-tbl-cell--empty" colspan="6">배포된 버전이 없습니다.</td></tr>';
    } else {
      body.innerHTML = data.map(h => `
        <tr class="sec-tbl-row">
          <td class="sec-tbl-cell"><span class="badge badge-green">${ts(h.version_label)}</span></td>
          <td class="sec-tbl-cell">${h.effective_date || '-'}</td>
          <td class="sec-tbl-cell" style="font-size:11px;">${h.snapshot_at ? new Date(h.snapshot_at).toLocaleString('ko-KR') : '-'}</td>
          <td class="sec-tbl-cell" style="font-size:11px;">${ts(h.created_by || '-')}</td>
          <td class="sec-tbl-cell" style="font-size:11px;color:#6b7280;">${ts(h.memo || '-')}</td>
          <td class="sec-tbl-cell sec-tbl-cell--action">
            <button class="btn btn-sm js-print-version" data-id="${h.id}">출력</button>
            ${canEdit ? `<button class="btn btn-sm js-restore-version" data-id="${h.id}">복원</button>` : ''}
          </td>
        </tr>`).join('');
      body.querySelectorAll('.js-print-version').forEach(btn => {
        btn.addEventListener('click', () => printRegulationVersion(data.find(h => h.id === btn.dataset.id)));
      });
      body.querySelectorAll('.js-restore-version').forEach(btn => {
        btn.addEventListener('click', () => restoreVersion(data.find(h => h.id === btn.dataset.id)));
      });
    }
    openModal('historyModal');
  } catch (e) {
    showMessage(e.message || '조회 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function restoreVersion(historyRow) {
  if (!historyRow) return;
  if (!confirm(`"${historyRow.version_label}" 버전으로 전체 조항을 복원하시겠습니까?\n복원 전 현재 상태는 자동으로 백업됩니다.`)) return;

  try {
    showGlobalLoading('복원 중...');
    const now = new Date().toISOString();
    const who = currentUser?.email || currentUser?.user_name || '';

    const currentSnapshot = sections.map(s => ({ sec_id: s.sec_id, title: s.title, content_html: s.content_html }));
    const { prefix } = genHistoryId();
    const { data: existing } = await supabaseClient
      .from('regulation_history').select('history_id')
      .eq('regulation_id', regulationId).like('history_id', prefix + '%');
    const seq = String((existing?.length || 0) + 1).padStart(3, '0');
    await supabaseClient.from('regulation_history').insert({
      regulation_id: regulationId, history_id: prefix + seq, version_label: '[복원 전 자동백업]',
      created_by: who, memo: historyRow.version_label + ' 복원 전 자동 백업', sections_json: currentSnapshot,
    });

    const targetSections = historyRow.sections_json || [];
    const bySecId = {};
    sections.forEach(s => { bySecId[s.sec_id] = s; });

    for (const t of targetSections) {
      const found = bySecId[t.sec_id];
      if (found) {
        await supabaseClient.from('regulation_sections').update({
          title: t.title, content_html: t.content_html, updated_at: now, updated_by: who,
          previous_html: found.content_html, previous_at: found.updated_at, previous_by: found.updated_by,
        }).eq('id', found.id);
      } else {
        await supabaseClient.from('regulation_sections').insert({
          regulation_id: regulationId, sec_id: t.sec_id, title: t.title, content_html: t.content_html,
          updated_at: now, updated_by: who, sort_order: sections.length + 1,
        });
      }
    }

    systemLog('REGULATION_RESTORE', '규정 버전 복원 — ' + regulation.name + ' / ' + historyRow.version_label, {
      target_type: 'regulation_history', target_id: historyRow.id,
    }).catch(() => {});

    closeModal('historyModal');
    sections = await loadSections();
    renderSections();
    showMessage(historyRow.version_label + ' 버전으로 복원되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '복원 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

/* ══════════════════════════════════════════════
   출력(인쇄) — 표지 + 목차 + 본문을 window.print()로 PDF/인쇄
   (레거시 구매규정 화면의 표지·목차 출력 기능을 그대로 이식)
══════════════════════════════════════════════ */
function buildCoverPage(versionLabel, effectiveDate) {
  const today = new Date();
  const dateStr = today.getFullYear() + '.' + String(today.getMonth() + 1).padStart(2, '0') + '.' + String(today.getDate()).padStart(2, '0');
  const orgName = currentUser?.org_name || ''; // 여러 의원이 각자 쓰는 제품이라 특정 병원명을
                                                // 고정으로 넣지 않고, 로그인한 사용자의 실제
                                                // 소속 의원명을 그때그때 넣는다.
  const div = document.createElement('div');
  div.className = 'reg-cover reg-print-only';
  const metaRows = [];
  if (versionLabel) metaRows.push(`<div class="reg-cover-meta-row"><span class="reg-cover-meta-label">버전</span><span>${ts(versionLabel)}</span></div>`);
  if (effectiveDate) metaRows.push(`<div class="reg-cover-meta-row"><span class="reg-cover-meta-label">시행일</span><span>${ts(effectiveDate)}</span></div>`);
  metaRows.push(`<div class="reg-cover-meta-row"><span class="reg-cover-meta-label">출력일</span><span>${dateStr}</span></div>`);
  div.innerHTML = `
    <div class="reg-cover-top"><span class="reg-cover-top-text">GC REGULATION</span></div>
    <div class="reg-cover-body">
      <div class="reg-cover-label">Green Book</div>
      <div class="reg-cover-title">${ts(regulation.name)}</div>
      <div class="reg-cover-subtitle">${ts(orgName)}</div>
      <div class="reg-cover-divider"></div>
      <div class="reg-cover-meta">${metaRows.join('')}</div>
    </div>
    <div class="reg-cover-bottom">
      <span class="reg-cover-company">${ts(orgName)}</span>
      <span class="reg-cover-logo"><img src="../../assets/images/logo.png" alt="${ts(orgName)}" /></span>
    </div>`;
  return div;
}

function buildTocPage(sectionList) {
  const div = document.createElement('div');
  div.className = 'reg-print-toc reg-print-only';
  let html = '<div class="reg-print-toc-title">CONTENTS</div>';
  sectionList.forEach(s => {
    html += `<div class="reg-toc-entry"><span class="reg-toc-entry-key">${ts(s.sec_id)}</span><span>${ts(s.title)}</span></div>`;
  });
  div.innerHTML = html;
  return div;
}

function buildPrintHeader(versionLabel) {
  const div = document.createElement('div');
  div.className = 'reg-print-header reg-print-only';
  const orgName = currentUser?.org_name || '';
  const nameLine = versionLabel ? `${ts(regulation.name)} (${ts(versionLabel)})` : ts(regulation.name);
  div.innerHTML = `<span>${ts(orgName)} · ${nameLine}</span><span>Green Book</span>`;
  return div;
}

function buildDocContentHtml(sectionList) {
  return '<div class="reg-doc-view">' +
    sectionList.map(s => `
      <div class="reg-doc-section">
        <div class="reg-doc-section-title">${ts(s.title)} <span class="sec-key">${ts(s.sec_id)}</span></div>
        ${s.content_html || '<em style="color:#9ca3af;">내용 없음</em>'}
      </div>`).join('') +
    '</div>';
}

/** 실행 순서가 같아서 공통으로 뺀 인쇄 로직 — cover/toc/header를 앞에 끼워넣고 window.print()한 뒤 정리한다 */
function runPrint(cover, toc, header) {
  const page = document.querySelector('.reg-detail-page');
  page.insertBefore(header, page.firstChild);
  page.insertBefore(toc, page.firstChild);
  page.insertBefore(cover, page.firstChild);
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      window.print();
      cover.remove();
      toc.remove();
      header.remove();
    });
  });
}

/** 현재(최신) 조항 내용으로 출력 — 화면에 표시된 "현재 시행 버전" 배지와 동일한 버전정보를 표지에 함께 넣는다 */
function printRegulation() {
  if (!regulation || !sections.length) { showMessage('출력할 조항이 없습니다.', 'warning'); return; }
  const versionLabel = currentVersion?.version_label;
  const effectiveDate = currentVersion?.effective_date;
  runPrint(buildCoverPage(versionLabel, effectiveDate), buildTocPage(sections), buildPrintHeader(versionLabel));
}

/** 버전 이력의 특정 스냅샷 기준으로 출력 — 현재 화면의 전체보기 내용을 잠깐 그 버전 내용으로
 * 바꿔치기했다가 인쇄가 끝나면 원래 내용으로 되돌린다 (실제 조항 데이터는 건드리지 않음) */
function printRegulationVersion(historyRow) {
  if (!historyRow || !historyRow.sections_json || !historyRow.sections_json.length) {
    showMessage('이 버전에는 출력할 조항 스냅샷이 없습니다.', 'warning');
    return;
  }
  closeModal('historyModal');
  const docView = document.getElementById('regDocView');
  const originalHtml = docView.innerHTML;
  const originalDisplay = docView.style.display;
  const sectionGrid = document.getElementById('sectionGrid');
  const sectionGridDisplay = sectionGrid.style.display;

  docView.innerHTML = buildDocContentHtml(historyRow.sections_json);
  docView.style.display = '';
  sectionGrid.style.display = 'none';

  const cover = buildCoverPage(historyRow.version_label, historyRow.effective_date);
  const toc = buildTocPage(historyRow.sections_json);
  const header = buildPrintHeader(historyRow.version_label);
  const page = document.querySelector('.reg-detail-page');
  page.insertBefore(header, page.firstChild);
  page.insertBefore(toc, page.firstChild);
  page.insertBefore(cover, page.firstChild);

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      window.print();
      cover.remove();
      toc.remove();
      header.remove();
      // 원래 화면 상태(전체보기/목록편집 중 보고 있던 것)로 복구
      docView.innerHTML = originalHtml;
      docView.style.display = originalDisplay;
      sectionGrid.style.display = sectionGridDisplay;
    });
  });
}

/* ══════════════════════════════════════════════
   조항 편집기 — maneasy Tiptap 기반 에디터로 교체
   (mso_manage 자체 제작 contenteditable 에디터를 통째로 대체)
══════════════════════════════════════════════ */
let sectionEditor = null; // createRichEditor()가 반환하는 Tiptap 에디터 인스턴스

function getSectionContentHtml() {
  return sectionEditor ? sectionEditor.getHTML() : '';
}
function setSectionContentHtml(html) {
  if (sectionEditor) sectionEditor.setData(html || '');
}

async function initRte() {
  sectionEditor = await createRichEditor(document.getElementById('sf_content'), '');
}

/* ══════════════════════════════════════════════
   초기화
══════════════════════════════════════════════ */
async function init() {
  ['df_effective_date'].forEach(mountCustomDateInput);
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();
  auth.applyBrandColor(currentUser.primary_color);

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'regulation/list')) {
    showMessage('이 페이지에 접근할 권한이 없습니다.', 'error');
    parent.shellNavigate?.('home/home');
    return;
  }
  canEdit = window.PagePerms.atLeast(currentUser, 'regulation/list', 'manager');
  canDelete = window.PagePerms.atLeast(currentUser, 'regulation/list', 'admin');

  regulationId = getRegulationIdFromUrl();
  if (!regulationId) { showMessage('규정 ID가 없습니다.', 'error'); return; }

  await initRte();

  if (canEdit) {
    document.getElementById('editRegulationBtn').style.display = '';
    document.getElementById('editRegulationBtn').addEventListener('click', openEditRegulation);
    document.getElementById('addSectionBtn').style.display = '';
    document.getElementById('addSectionBtn').addEventListener('click', openSectionAdd);
    document.getElementById('deployVersionBtn').style.display = '';
    document.getElementById('deployVersionBtn').addEventListener('click', openDeployModal);
  } else {
    // 조회만 가능한 사람은 "전체보기"만 볼 수 있으면 충분하다 — 목록/편집 그리드나
    // 버전 이력·조항 추가·버전 배포 버튼은 전부 편집 권한이 있어야 의미가 있으므로
    // 툴바 자체를 통째로 숨긴다.
    document.getElementById('regToolbar').style.display = 'none';
  }

  document.getElementById('regulationModalSave')?.addEventListener('click', saveRegulationInfo);
  document.getElementById('sectionModalSave')?.addEventListener('click', saveSection);
  document.getElementById('deployModalSave')?.addEventListener('click', deployVersion);
  document.getElementById('viewHistoryBtn')?.addEventListener('click', openHistoryModal);
  document.getElementById('printRegulationBtn')?.addEventListener('click', printRegulation);
  document.getElementById('regViewDocBtn')?.addEventListener('click', () => switchRegView('doc'));
  document.getElementById('regViewGridBtn')?.addEventListener('click', () => switchRegView('grid'));

  showGlobalLoading('불러오는 중...');
  try {
    regulation = await loadRegulation();
    renderRegulationHead();
    const [loadedSections, linkedCommittees, loadedCurrentVersion] = await Promise.all([loadSections(), loadLinkedCommittees(), loadCurrentVersion()]);
    sections = loadedSections;
    currentVersion = loadedCurrentVersion;
    renderSections();
    renderLinkedCommittees(linkedCommittees);
    renderCurrentVersionBadge();
  } catch (e) {
    showMessage(e.message || '조회 실패', 'error');
  } finally {
    hideGlobalLoading();
  }
}

document.addEventListener('DOMContentLoaded', init);