/**
 * assets/js/regulation/list.js
 * 규정 관리 — 목록 조회 + 등록/수정 (위원회와 독립적으로 관리, N:N으로 위원회에 연결해서 사용)
 */

let currentUser = null;
let canEdit = false;
let regulationCache = [];
let editingRegulationId = null;

function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }

async function loadRegulations() {
  const { data, error } = await supabaseClient
    .from('regulations')
    .select('*, regulation_sections(count), committee_regulations(count)')
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

let _regulationGridApi = null;

function renderRegulations(list, keyword) {
  const kw = (keyword || '').toLowerCase();
  const filtered = kw ? list.filter(r => (r.name || '').toLowerCase().includes(kw)) : list;
  const rows = filtered.map((r, idx) => ({ ...r, _idx: idx }));

  const colDefs = [
    { headerName: '규정명', field: 'name', width: 180, headerClass: 'ag-left-header',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', fontWeight: 700 } },
    { headerName: '설명', field: 'description', flex: 1, minWidth: 200, headerClass: 'ag-left-header',
      valueFormatter: p => p.value || '-',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start', color: '#6b7280' } },
    { headerName: '코드', field: 'code', width: 130, cellStyle: { fontFamily: 'Consolas, monospace', fontSize: '11px', color: '#6b7280' } },
    { headerName: '조항 수', width: 90, valueGetter: p => p.data.regulation_sections?.[0]?.count ?? 0 },
    { headerName: '사용 위원회', width: 100, valueGetter: p => p.data.committee_regulations?.[0]?.count ?? 0 },
    { headerName: '상태', width: 90,
      cellRenderer: p => {
        const s = document.createElement('span');
        if (p.data.active === 'Y') { s.className = 'badge badge-green'; s.textContent = '활성'; }
        else { s.className = 'badge'; s.textContent = '비활성'; }
        return s;
      } },
    { headerName: '관리', width: 90, sortable: false,
      cellRenderer: p => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-sm';
        btn.textContent = '조회';
        btn.onclick = () => { parent.shellNavigate?.('regulation/detail?id=' + encodeURIComponent(p.data.id)); };
        return btn;
      } },
  ];

  if (!_regulationGridApi) {
    _regulationGridApi = createMgGrid('regulationGrid', colDefs, rows, { noRowsText: '등록된 규정이 없습니다.' });
  } else {
    updateMgGrid(_regulationGridApi, rows);
  }
}

function applyFilter() {
  renderRegulations(regulationCache, val('keyword'));
}

/* ── 등록/수정 모달 ── */
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }

function openAddRegulation() {
  editingRegulationId = null;
  document.getElementById('regulationModalTitle').textContent = '규정 등록';
  setVal('rf_name', '');
  setVal('rf_code', '');
  setVal('rf_description', '');
  setVal('rf_active', 'Y');
  openModal('regulationModal');
}
window.openAddRegulation = openAddRegulation;

async function saveRegulation() {
  const name = val('rf_name');
  const code = val('rf_code').toUpperCase().replace(/[^A-Z0-9_-]/g, '');
  if (!name) { showMessage('규정명은 필수입니다.', 'warning'); return; }
  if (!code) { showMessage('코드는 필수입니다 (영문/숫자).', 'warning'); return; }

  const payload = {
    name,
    code,
    description: val('rf_description'),
    active: val('rf_active') || 'Y',
    updated_at: new Date().toISOString(),
  };

  try {
    showGlobalLoading('저장 중...');
    if (editingRegulationId) {
      const { error } = await supabaseClient.from('regulations').update(payload).eq('id', editingRegulationId);
      if (error) throw new Error(error.message);
      systemLog('REGULATION_UPDATE', '규정 수정 — ' + name, { target_type: 'regulations', target_id: editingRegulationId }).catch(() => {});
    } else {
      payload.sort_order = regulationCache.length + 1;
      const { data, error } = await supabaseClient.from('regulations').insert(payload).select().single();
      if (error) throw new Error(error.message);
      systemLog('REGULATION_CREATE', '규정 등록 — ' + name, { target_type: 'regulations', target_id: data?.id }).catch(() => {});
    }
    closeModal('regulationModal');
    await refresh();
    showMessage('저장되었습니다.', 'success');
  } catch (e) {
    showMessage(e.message || '저장에 실패했습니다.', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function refresh() {
  regulationCache = await loadRegulations();
  applyFilter();
}

async function init() {
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'regulation/list')) {
    showMessage('이 페이지에 접근할 권한이 없습니다.', 'error');
    parent.shellNavigate?.('home/home');
    return;
  }
  canEdit = window.PagePerms.atLeast(currentUser, 'regulation/list', 'manager');

  if (canEdit) {
    document.getElementById('addRegulationBtn').style.display = '';
    document.getElementById('addRegulationBtn').addEventListener('click', openAddRegulation);
  }

  document.getElementById('searchForm')?.addEventListener('submit', e => { e.preventDefault(); applyFilter(); });
  document.getElementById('resetFilterBtn')?.addEventListener('click', () => { setVal('keyword', ''); applyFilter(); });
  document.getElementById('regulationModalClose')?.addEventListener('click', () => closeModal('regulationModal'));
  document.getElementById('regulationModalCancel')?.addEventListener('click', () => closeModal('regulationModal'));
  document.getElementById('regulationModalSave')?.addEventListener('click', saveRegulation);

  showGlobalLoading('불러오는 중...');
  try {
    await refresh();
  } catch (e) {
    showMessage(e.message || '조회에 실패했습니다.', 'error');
  } finally {
    hideGlobalLoading();
  }
}

document.addEventListener('DOMContentLoaded', init);