'use strict';

var currentUser = null;
var myOrgMemberId = null;
var myClinicId = null, myDeptId = null;
var myRole = 'user';
var isHr = false;           // manager/admin 여부 — 모듈 전역에서 재사용(연차 취소 처리 등)
var targetMemberId = null;  // URL ?id= 로 지정된, 지금 보고 있는 사람
var entryTab = '';          // URL ?tab= 로 지정된, 진입 시 바로 열어줄 탭 (예: 'leave')
var entryFrom = '';         // URL ?from= 로 지정된, 진입 출처 — "목록으로" 버튼이 돌아갈 곳을 결정
var familyRows = [];        // [{ id, relation, name, birth_date, occupation }]
var originalFamilyIds = []; // 로드 시점의 가족사항 id 목록 — 저장 시 "빠진 행"을 찾아 삭제하는 데 사용
var licenseRows = [];       // [{ id, license_name, license_no, issuer, issued_date, expires_date }]
var awardRows = [];         // [{ id, award_name, awarding_org, awarded_date, description }]

// 연차관리 탭 — 여기서는 조회(현황/신청내역)만 한다. 실제 신청은 전자결재 > 기안 작성에서.
var leaveTypeMap = {};     // id -> row, 신청 내역 표시용(비활성 포함 전체)
var myRequests = [];
var leaveAdjustments = [];  // 관리자용 — 수동 조정(이월·특별 부여 등) 내역
var leaveLedgerPeriods = []; // 기간별 발생/이월/소멸 계산 결과(get_leave_ledger_periods)

var STATUS_LABEL = { PENDING: '승인 대기', APPROVED: '승인', REJECTED: '반려', CANCELED: '취소' };
var STATUS_TEXT_COLOR = { PENDING: '#b45309', APPROVED: '#047857', REJECTED: '#b91c1c', CANCELED: '#6b7280' };

function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v == null ? '' : v; }
function hideLoading() { var el = document.getElementById('globalLoading'); if (el) el.classList.remove('is-open'); }

async function init() {
  ['hrHireDate', 'hrResignDate', 'hrBirthDate', 'hrLeaveStartDate'].forEach(mountCustomDateInput);
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'hr/personal-info-detail')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    await resolveMyContext();
    if (!myOrgMemberId) {
      hideLoading();
      document.querySelector('.hr-det-page').innerHTML =
        '<div style="text-align:center;color:#6b7280;font-size:13px;padding:60px;">' +
        (currentUser.is_platform_admin
          ? '플랫폼 관리자의 "의원 미리보기" 모드에서는 인사관리를 사용할 수 없습니다.<br>실제 소속 구성원 계정으로 로그인해주세요.'
          : '소속 구성원 정보를 확인할 수 없어 인사관리를 사용할 수 없습니다.<br>관리자에게 문의해주세요.') +
        '</div>';
      return;
    }

    isHr = myRole === 'manager' || myRole === 'admin';
    var params = new URLSearchParams(location.search);
    targetMemberId = params.get('id') || myOrgMemberId;
    entryTab = params.get('tab') || '';
    entryFrom = params.get('from') || '';
    // 일반 직원이 URL을 조작해서 남의 id를 넣어도, RLS가 어차피 조회/저장을 막아준다.
    // 여기서는 화면 요소만 그에 맞게 조정한다(목록으로 버튼, 잠금 안내 문구 등).
    // 요소 하나가 어떤 이유로든 없어도(캐시된 구버전 HTML 등) 전체 초기화가 멈추지 않도록
    // 각각 null 체크 후 적용한다.
    function setDisplay(id, show) { var el = document.getElementById(id); if (el) el.style.display = show ? '' : 'none'; }
    setDisplay('backToListBtn', isHr);
    setDisplay('hrMemoCard', isHr);
    setDisplay('hrSelfMemoCard', targetMemberId === myOrgMemberId);
    setDisplay('hrReadonlyHint', !isHr && targetMemberId !== myOrgMemberId);
    // 신청 링크는 본인 것을 보고 있을 때만 — 연차 신청은 전자결재 기안작성에서 본인이 직접 한다.
    var adjustSection = document.getElementById('hrLeaveAdjustSection');
    if (adjustSection) adjustSection.style.display = isHr ? 'flex' : 'none';
    // 입사일/퇴사일/연차 기산일은 org_members 테이블에 저장되는데, 그 테이블 자체에 대한
    // UPDATE 권한은 admin으로 제한돼 있다(role/page_perms 같은 민감한 컬럼도 같이 있어서).
    // 하지만 manager가 이 앱의 실제 연차 관리자라서, 이 세 필드만 건드릴 수 있는 전용 RPC
    // (set_member_hr_dates)를 통해 manager도 조회·수정 가능하게 한다.
    var hireDateEl = document.getElementById('hrHireDate');
    var resignDateEl = document.getElementById('hrResignDate');
    if (hireDateEl) hireDateEl.disabled = !isHr;
    if (resignDateEl) resignDateEl.disabled = !isHr;
    var leaveStartSection = document.getElementById('hrLeaveStartDateSection');
    if (leaveStartSection) leaveStartSection.style.display = isHr ? 'flex' : 'none';

    bindUi();
    await loadLeaveTypes();
    await loadTarget();
    if (entryTab) {
      var tabBtn = document.querySelector('#hrTabs .tab-btn[data-tab="' + entryTab + '"]');
      if (tabBtn) tabBtn.click();
    }
    hideLoading();
  } catch (e) {
    console.error('[hr/personal-info-detail] init 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 오류가 발생했습니다.');
  }
}

async function resolveMyContext() {
  if (!currentUser.org_member_id) { console.warn('[hr/personal-info-detail] org_member_id 없음'); return; }
  var { data, error } = await supabaseClient.from('org_members').select('id, clinic_id, dept_id, role').eq('id', currentUser.org_member_id).maybeSingle();
  if (error) { console.error('[hr/personal-info-detail] resolveMyContext 오류:', error); return; }
  if (!data) return;
  myOrgMemberId = data.id;
  myClinicId = data.clinic_id;
  myDeptId = data.dept_id;
  myRole = data.role;
}

/** 신청 내역 표시용 — 연차 유형 id → 이름 매핑(비활성 유형도 과거 이력엔 남아있으므로 전체 조회). */
var minLeaveUnit = 1; // 이 의원에 설정된 연차 유형 중 가장 작은 차감단위(예: 반반차 0.25) — 수동 조정 입력 단위로 사용

async function loadLeaveTypes() {
  try {
    var { data, error } = await supabaseClient.from('leave_types').select('id, name, deduction_ratio, clinic_id, active').eq('org_id', currentUser.org_id);
    if (error) throw new Error(error.message);
    var all = data || [];
    leaveTypeMap = {};
    all.forEach(function(t) { leaveTypeMap[t.id] = t; });

    // 의원 전용 유형이 있으면 그걸로, 없으면 공통 유형으로 최소 단위를 판단한다(draft.js의 연차신청 로직과 동일 원칙).
    var scoped = myClinicId ? all.filter(function(t) { return t.clinic_id === myClinicId; }) : [];
    var pool = (scoped.length ? scoped : all.filter(function(t) { return !t.clinic_id; }))
      .filter(function(t) { return t.active && Number(t.deduction_ratio) > 0; });
    if (pool.length) {
      minLeaveUnit = Math.min.apply(null, pool.map(function(t) { return Number(t.deduction_ratio); }));
    }
    var adjustInput = document.getElementById('hrAdjustDays');
    if (adjustInput) adjustInput.step = minLeaveUnit;
  } catch (e) {
    console.error('[hr/personal-info-detail] loadLeaveTypes 실패:', e);
  }
}

function on(id, event, handler) {
  var el = document.getElementById(id);
  if (el) el.addEventListener(event, handler);
  else console.warn('[hr/personal-info-detail] 요소를 찾지 못해 이벤트를 못 걸었습니다: #' + id);
}

function bindUi() {
  on('backToListBtn', 'click', function() {
    // 연차정책(leave-admin) 전체현황에서 들어온 경우엔 그쪽으로, 아니면 원래대로 인사기록관리 목록으로.
    var target = (entryFrom === 'leave-admin') ? 'leave/leave-admin' : 'hr/personal-info';
    parent.shellNavigate ? parent.shellNavigate(target) : (location.href = target === 'leave/leave-admin' ? '../leave/leave-admin.html' : 'personal-info.html');
  });
  on('hrSaveBtn', 'click', saveAll);
  on('hrAddFamilyBtn', 'click', function() {
    familyRows.push({ id: null, relation: '', name: '', birth_date: '', occupation: '', is_dependent: false, hasResidentNumber: false, residentNumberFront: '', residentNumberBack: '', revealedResidentNumber: null });
    renderFamilyRows();
  });
  on('hrAddLicenseBtn', 'click', function() {
    licenseRows.push({ id: null, license_name: '', license_no: '', issuer: '', issued_date: '', expires_date: '' });
    renderLicenseRows();
  });
  on('hrAddAwardBtn', 'click', function() {
    awardRows.push({ id: null, award_name: '', awarding_org: '', awarded_date: '', description: '' });
    renderAwardRows();
  });
  on('hrAdjustAddBtn', 'click', saveLeaveAdjustment);
  on('hrLeaveStartDateSaveBtn', 'click', saveLeaveStartDate);
  on('hrCardConfirmBtn', 'click', confirmHrCard);
  on('hrCardUnlockBtn', 'click', unlockHrCard);
  on('hrAddressSearchBtn', 'click', function() {
    if (typeof daum === 'undefined' || !daum.Postcode) { alert('주소 검색 서비스를 불러오지 못했습니다. 잠시 후 다시 시도해주세요.'); return; }
    new daum.Postcode({
      oncomplete: function(data) {
        setVal('hrZipcode', data.zonecode);
        setVal('hrAddress', data.roadAddress || data.jibunAddress);
        document.getElementById('hrAddressDetail')?.focus();
      },
    }).open();
  });

  document.getElementById('hrTabs')?.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('#hrTabs .tab-btn').forEach(function(b) { b.classList.remove('active'); });
      document.querySelectorAll('.hr-det-tab-panel').forEach(function(p) { p.classList.remove('active'); });
      btn.classList.add('active');
      document.querySelector('.hr-det-tab-panel[data-tab="' + btn.dataset.tab + '"]')?.classList.add('active');
      if (btn.dataset.tab === 'leave') {
        if (_leaveRequestGridInstance) {
          setTimeout(function() { fitGridColumnsPinned(_leaveRequestGridInstance, _leaveRequestGridInstance.getColumnDefs()); }, 0);
        } else {
          renderLeaveRequestRows();
        }
      }
    });
  });
}

/* ── 대상자 데이터 로드 ── */
async function loadTarget() {
  document.getElementById('hrEmptyMsg').style.display = '';
  document.getElementById('hrContent').style.display = 'none';

  var { data: member } = await supabaseClient
    .from('org_members_detail').select('user_name, clinic_name, dept_name, position_name, hire_date, resign_date, leave_start_date')
    .eq('id', targetMemberId).maybeSingle();
  document.getElementById('heroName').textContent = member ? member.user_name : '개인신상정보';
  document.getElementById('heroMeta').textContent = member ? [member.clinic_name, member.dept_name, member.position_name].filter(Boolean).join(' · ') : '';
  setVal('hrHireDate', member && member.hire_date);
  setVal('hrResignDate', member && member.resign_date);
  setVal('hrLeaveStartDate', member && member.leave_start_date);

  var [{ data: info, error: infoErr }, { data: family, error: famErr }, { data: licenses, error: licErr }, { data: awards, error: awardErr }] = await Promise.all([
    supabaseClient.from('employee_personal_info').select('*').eq('org_member_id', targetMemberId).maybeSingle(),
    supabaseClient.from('employee_family_members').select('*').eq('org_member_id', targetMemberId).order('sort_order'),
    supabaseClient.from('employee_licenses').select('*').eq('org_member_id', targetMemberId).order('sort_order'),
    supabaseClient.from('employee_awards').select('*').eq('org_member_id', targetMemberId).order('sort_order'),
  ]);
  if (infoErr) console.error('[hr/personal-info-detail] employee_personal_info 조회 실패:', infoErr);
  if (famErr) console.error('[hr/personal-info-detail] employee_family_members 조회 실패:', famErr);
  if (licErr) console.error('[hr/personal-info-detail] employee_licenses 조회 실패:', licErr);
  if (awardErr) console.error('[hr/personal-info-detail] employee_awards 조회 실패:', awardErr);

  info = info || {};
  setVal('hrBirthDate', info.birth_date);
  setVal('hrGender', info.gender);
  setVal('hrPhone', info.personal_phone);
  setVal('hrEmail', info.personal_email);
  setVal('hrZipcode', info.postal_code);
  setVal('hrAddress', info.address);
  setVal('hrAddressDetail', info.address_detail);
  setVal('hrEmName', info.emergency_contact_name);
  setVal('hrEmRelation', info.emergency_contact_relation);
  setVal('hrEmPhone', info.emergency_contact_phone);
  setVal('hrEducation', info.final_education);
  setVal('hrHighSchoolName', info.high_school_name);
  setVal('hrHighSchoolAdmission', info.high_school_admission_month);
  setVal('hrHighSchoolGraduation', info.high_school_graduation_month);
  setVal('hrJuniorCollegeName', info.junior_college_name);
  setVal('hrJuniorCollegeMajor', info.junior_college_major);
  setVal('hrJuniorCollegeAdmission', info.junior_college_admission_month);
  setVal('hrJuniorCollegeGraduation', info.junior_college_graduation_month);
  setVal('hrCollegeName', info.college_name);
  setVal('hrCollegeMajor', info.college_major);
  setVal('hrCollegeAdmission', info.college_admission_month);
  setVal('hrCollegeGraduation', info.college_graduation_month);
  setVal('hrGradSchoolName', info.grad_school_name);
  setVal('hrGradSchoolMajor', info.grad_school_major);
  setVal('hrGradSchoolAdmission', info.grad_school_admission_month);
  setVal('hrGradSchoolGraduation', info.grad_school_graduation_month);
  setVal('hrMilitaryStatus', info.military_status);
  setVal('hrMilitaryBranch', info.military_branch);
  setVal('hrMilitaryEnlistDate', info.military_enlist_date);
  setVal('hrMilitaryDischargeDate', info.military_discharge_date);
  setVal('hrBankName', info.bank_name);
  setVal('hrBankAccountNo', info.bank_account_no);
  setVal('hrBankHolder', info.bank_account_holder);
  setVal('hrMemo', info.hr_memo);
  setVal('hrSelfMemo', info.self_memo);

  familyRows = (family || []).map(function(f) {
    return {
      id: f.id, relation: f.relation, name: f.name, birth_date: f.birth_date, occupation: f.occupation,
      is_dependent: !!f.is_dependent, hasResidentNumber: !!f.resident_number_enc, residentNumberFront: '', residentNumberBack: '', revealedResidentNumber: null,
    };
  });
  originalFamilyIds = familyRows.map(function(f) { return f.id; });
  licenseRows = (licenses || []).map(function(l) {
    return { id: l.id, license_name: l.license_name, license_no: l.license_no, issuer: l.issuer, issued_date: l.issued_date, expires_date: l.expires_date };
  });
  awardRows = (awards || []).map(function(a) {
    return { id: a.id, award_name: a.award_name, awarding_org: a.awarding_org, awarded_date: a.awarded_date, description: a.description };
  });
  renderFamilyRows();
  renderLicenseRows();
  renderAwardRows();

  applyHrCardLockUI(!!info.hr_card_confirmed_at, targetMemberId === myOrgMemberId);

  await Promise.all([loadLeaveBalance(), loadLeaveRequests(), loadLeaveAdjustments(), loadLeaveLedgerPeriods()]);
  renderLeaveRequestRows();

  document.getElementById('hrEmptyMsg').style.display = 'none';
  document.getElementById('hrContent').style.display = 'flex';
}

/** 가족/자격증/수상이력 공통 — 표 형태(한 정보당 한 줄)로 그려주는 헬퍼.
 *  fields: [{ key, type, placeholder }] — 컬럼 순서대로 <td> 하나씩 생성 */
function renderEntryTableRows(tbodyId, emptyHintId, rows, fields, onChange, onRemove) {
  var tbody = document.getElementById(tbodyId);
  document.getElementById(emptyHintId).style.display = rows.length ? 'none' : '';
  tbody.innerHTML = rows.map(function(row, i) {
    var cells = fields.map(function(f) {
      var v = ts(row[f.key] || '');
      return '<td><input type="' + (f.type || 'text') + '" data-field="' + f.key + '" value="' + v + '"' +
        (f.placeholder ? ' placeholder="' + f.placeholder + '"' : '') + ' /></td>';
    }).join('');
    return '<tr data-i="' + i + '">' + cells +
      '<td><button type="button" class="hr-row-del" data-i="' + i + '"><i class="ti ti-trash"></i></button></td>' +
    '</tr>';
  }).join('');
  tbody.querySelectorAll('input').forEach(function(inp) {
    inp.addEventListener('input', function() {
      var i = Number(inp.closest('tr').dataset.i);
      onChange(i, inp.dataset.field, inp.value);
    });
  });
  tbody.querySelectorAll('.hr-row-del').forEach(function(b) {
    b.addEventListener('click', function() { onRemove(Number(b.dataset.i)); });
  });
}

function applyHrCardLockUI(locked, isOwn) {
  var shouldLockCore = locked; // 잠기면 본인도 포함해서 아무도 수정 불가 — 인사담당자가 해제해야 함
  function show(id, visible) { var el = document.getElementById(id); if (el) el.style.display = visible ? '' : 'none'; }
  show('hrCardLockedHint', locked);
  show('hrCardConfirmBtn', isOwn && !locked);
  show('hrCardUnlockBtn', locked && isHr);

  // 기본정보 탭의 핵심 입력 필드 — 입사일/퇴사일(별도 gate)과 우편번호/주소(이미 readonly)는 제외
  document.querySelectorAll('.hr-basic-cols input, .hr-basic-cols select, .hr-basic-cols button').forEach(function(el) {
    if (el.id === 'hrHireDate' || el.id === 'hrResignDate' || el.id === 'hrZipcode' || el.id === 'hrAddress') return;
    el.disabled = shouldLockCore;
  });
  // 가족·자격증 탭 — 추가 버튼 및 기존 행 입력/삭제 버튼
  ['hrAddFamilyBtn', 'hrAddLicenseBtn', 'hrAddAwardBtn'].forEach(function(id) {
    var b = document.getElementById(id); if (b) b.disabled = shouldLockCore;
  });
  document.querySelectorAll('#hrFamilyRows input, #hrFamilyRows button, #hrLicenseRows input, #hrLicenseRows button, #hrAwardRows input, #hrAwardRows button').forEach(function(el) {
    el.disabled = shouldLockCore;
  });
}

async function confirmHrCard() {
  if (!confirm('제출 확정하면 이후에는 본인을 포함해 아무도 이 인사카드 내용을 수정할 수 없습니다(인사담당자가 잠금을 해제해야만 다시 수정 가능). 계속하시겠습니까?')) return;
  var btn = document.getElementById('hrCardConfirmBtn');
  btn.disabled = true;
  try {
    var { error } = await supabaseClient.rpc('confirm_hr_card', { p_org_member_id: targetMemberId });
    if (error) throw new Error(error.message);
    await loadTarget();
  } catch (e) {
    alert('제출 확정 실패: ' + e.message);
    btn.disabled = false;
  }
}

async function unlockHrCard() {
  if (!confirm('잠금을 해제하면 본인 또는 인사담당자가 이 인사카드 내용을 다시 수정할 수 있게 됩니다. 계속하시겠습니까?')) return;
  var btn = document.getElementById('hrCardUnlockBtn');
  btn.disabled = true;
  try {
    var { error } = await supabaseClient.rpc('unlock_hr_card', { p_org_member_id: targetMemberId });
    if (error) throw new Error(error.message);
    await loadTarget();
  } catch (e) {
    alert('잠금 해제 실패: ' + e.message);
    btn.disabled = false;
  }
}

/* ── 가족사항 (부양가족 체크 시 생년월일 대신 주민번호 입력 — 실제 값은 암호화 저장, 화면엔 마스킹) ── */
function renderFamilyRows() {
  var tbody = document.getElementById('hrFamilyRows');
  document.getElementById('hrFamilyEmptyHint').style.display = familyRows.length ? 'none' : '';
  tbody.innerHTML = familyRows.map(function(f, i) {
    var dep = !!f.is_dependent;
    var residentCell;
    var residentInputsHtml =
      '<div style="display:flex;align-items:center;gap:4px;">' +
        '<input type="text" data-field="residentNumberFront" inputmode="numeric" maxlength="6" style="flex:3;min-width:0;" value="' + ts(f.residentNumberFront || '') + '" placeholder="900101" />' +
        '<span style="color:#9ca3af;">-</span>' +
        '<input type="text" data-field="residentNumberBack" inputmode="numeric" maxlength="7" style="flex:4;min-width:0;" value="' + ts(f.residentNumberBack || '') + '" placeholder="1234567" />' +
      '</div>';
    if (!dep) {
      residentCell = '<input type="date" data-field="birth_date" value="' + ts(f.birth_date || '') + '" />';
    } else if (f.id && f.hasResidentNumber) {
      var shown = f.revealedResidentNumber != null ? ts(f.revealedResidentNumber) : '●●●●●●-●●●●●●●';
      residentCell =
        '<div style="display:flex;align-items:center;gap:4px;margin-bottom:4px;">' +
          '<span style="font-family:monospace;font-size:11px;">' + shown + '</span>' +
          (isHr ? '<button type="button" class="btn btn-sm" style="padding:2px 6px;font-size:10px;" onclick="hrToggleResidentNumber(\'' + f.id + '\', ' + i + ')">' + (f.revealedResidentNumber != null ? '가리기' : '보기') + '</button>' : '') +
        '</div>' +
        residentInputsHtml +
        '<div style="font-size:10px;color:#9ca3af;">변경하려면 입력(비워두면 기존 값 유지)</div>';
    } else {
      residentCell = residentInputsHtml;
    }
    return '<tr data-i="' + i + '">' +
      '<td style="text-align:center;padding-left:8px;"><input type="checkbox" data-field="is_dependent"' + (dep ? ' checked' : '') + ' /></td>' +
      '<td><input type="text" data-field="relation" value="' + ts(f.relation || '') + '" placeholder="예: 배우자" /></td>' +
      '<td><input type="text" data-field="name" value="' + ts(f.name || '') + '" /></td>' +
      '<td>' + residentCell + '</td>' +
      '<td><input type="text" data-field="occupation" value="' + ts(f.occupation || '') + '" /></td>' +
      '<td><button type="button" class="hr-row-del" data-i="' + i + '"><i class="ti ti-trash"></i></button></td>' +
    '</tr>';
  }).join('');

  tbody.querySelectorAll('input[type="checkbox"][data-field="is_dependent"]').forEach(function(cb) {
    cb.addEventListener('change', function() {
      var i = Number(cb.closest('tr').dataset.i);
      familyRows[i].is_dependent = cb.checked;
      renderFamilyRows(); // 생년월일/주민번호 필드 전환을 반영하기 위해 다시 그림
    });
  });
  tbody.querySelectorAll('input[data-field="residentNumberFront"], input[data-field="residentNumberBack"]').forEach(function(inp) {
    inp.addEventListener('input', function() {
      var i = Number(inp.closest('tr').dataset.i);
      var digits = inp.value.replace(/\D/g, '').slice(0, inp.maxLength);
      inp.value = digits;
      familyRows[i][inp.dataset.field] = digits;
      // 앞자리 6자리를 다 채우면 자동으로 뒷자리 칸으로 포커스 이동
      if (inp.dataset.field === 'residentNumberFront' && digits.length === 6) {
        var back = inp.parentElement.querySelector('input[data-field="residentNumberBack"]');
        if (back) back.focus();
      }
    });
  });
  tbody.querySelectorAll('input:not([type="checkbox"]):not([data-field="residentNumberFront"]):not([data-field="residentNumberBack"])').forEach(function(inp) {
    inp.addEventListener('input', function() {
      var i = Number(inp.closest('tr').dataset.i);
      familyRows[i][inp.dataset.field] = inp.value;
    });
  });
  tbody.querySelectorAll('.hr-row-del').forEach(function(b) {
    b.addEventListener('click', function() { familyRows.splice(Number(b.dataset.i), 1); renderFamilyRows(); });
  });
}

/** manager 이상만 — 주민번호 마스킹 해제/재마스킹. 실제 복호화는 서버(RPC)에서만 이뤄지고,
 *  평문은 이 순간 화면에만 잠깐 보였다가 "가리기"를 누르면(또는 다시 로드하면) 사라진다. */
window.hrToggleResidentNumber = async function(familyId, rowIndex) {
  if (!isHr) return;
  var row = familyRows[rowIndex];
  if (!row || row.id !== familyId) return;
  if (row.revealedResidentNumber != null) {
    row.revealedResidentNumber = null;
    renderFamilyRows();
    return;
  }
  try {
    var { data, error } = await supabaseClient.rpc('get_family_resident_number', { p_family_id: familyId });
    if (error) throw new Error(error.message);
    row.revealedResidentNumber = data || '(등록된 값 없음)';
    renderFamilyRows();
  } catch (e) {
    alert('주민번호 확인 실패: ' + e.message);
  }
};

/* ── 자격증/면허 ── */
function renderLicenseRows() {
  renderEntryTableRows('hrLicenseRows', 'hrLicenseEmptyHint', licenseRows, [
    { key: 'license_name', placeholder: '예: 정보처리기사' },
    { key: 'license_no' },
    { key: 'issuer' },
    { key: 'issued_date', type: 'date' },
    { key: 'expires_date', type: 'date' },
  ], function(i, field, value) { licenseRows[i][field] = value; },
     function(i) { licenseRows.splice(i, 1); renderLicenseRows(); });
}

/* ── 수상이력 ── */
function renderAwardRows() {
  renderEntryTableRows('hrAwardRows', 'hrAwardEmptyHint', awardRows, [
    { key: 'award_name', placeholder: '예: 우수사원상' },
    { key: 'awarding_org' },
    { key: 'awarded_date', type: 'date' },
    { key: 'description' },
  ], function(i, field, value) { awardRows[i][field] = value; },
     function(i) { awardRows.splice(i, 1); renderAwardRows(); });
}

/* ── 저장 ── */
async function saveAll() {
  var btn = document.getElementById('hrSaveBtn');
  btn.disabled = true;
  try {
    var payload = {
      org_id: currentUser.org_id,
      org_member_id: targetMemberId,
      birth_date: val('hrBirthDate') || null,
      gender: val('hrGender') || null,
      personal_phone: val('hrPhone') || null,
      personal_email: val('hrEmail') || null,
      postal_code: val('hrZipcode') || null,
      address: val('hrAddress') || null,
      address_detail: val('hrAddressDetail') || null,
      emergency_contact_name: val('hrEmName') || null,
      emergency_contact_relation: val('hrEmRelation') || null,
      emergency_contact_phone: val('hrEmPhone') || null,
      final_education: val('hrEducation') || null,
      high_school_name: val('hrHighSchoolName') || null,
      high_school_admission_month: val('hrHighSchoolAdmission') || null,
      high_school_graduation_month: val('hrHighSchoolGraduation') || null,
      junior_college_name: val('hrJuniorCollegeName') || null,
      junior_college_major: val('hrJuniorCollegeMajor') || null,
      junior_college_admission_month: val('hrJuniorCollegeAdmission') || null,
      junior_college_graduation_month: val('hrJuniorCollegeGraduation') || null,
      college_name: val('hrCollegeName') || null,
      college_major: val('hrCollegeMajor') || null,
      college_admission_month: val('hrCollegeAdmission') || null,
      college_graduation_month: val('hrCollegeGraduation') || null,
      grad_school_name: val('hrGradSchoolName') || null,
      grad_school_major: val('hrGradSchoolMajor') || null,
      grad_school_admission_month: val('hrGradSchoolAdmission') || null,
      grad_school_graduation_month: val('hrGradSchoolGraduation') || null,
      military_status: val('hrMilitaryStatus') || null,
      military_branch: val('hrMilitaryBranch') || null,
      military_enlist_date: val('hrMilitaryEnlistDate') || null,
      military_discharge_date: val('hrMilitaryDischargeDate') || null,
      bank_name: val('hrBankName') || null,
      bank_account_no: val('hrBankAccountNo') || null,
      bank_account_holder: val('hrBankHolder') || null,
      updated_at: new Date().toISOString(),
      updated_by: myOrgMemberId,
    };
    // 인사담당자 메모 탭은 manager/admin에게만 보이므로, 그 경우에만 페이로드에 포함한다
    // (일반 사용자 화면에는 필드 자체가 없어 기존 메모 값을 실수로 지우는 일이 없다).
    if (myRole === 'manager' || myRole === 'admin') payload.hr_memo = val('hrMemo') || null;
    if (targetMemberId === myOrgMemberId) payload.self_memo = val('hrSelfMemo') || null;

    var { error: upsertErr } = await supabaseClient.from('employee_personal_info').upsert(payload, { onConflict: 'org_member_id' });
    if (upsertErr) throw new Error('기본 신상정보 저장 실패: ' + upsertErr.message);

    // 입사일/퇴사일은 employee_personal_info가 아니라 org_members 테이블에 저장된다
    // (사용자관리 화면과 같은 컬럼을 그대로 공유 — 어느 쪽에서 바꿔도 서로 반영됨).
    // admin이 아니면 필드 자체가 disabled라 값이 안 바뀌었을 테니, 매번 시도해도 무해하다.
    if (isHr) {
      var { error: omErr } = await supabaseClient.rpc('set_member_hr_dates', {
        p_org_member_id: targetMemberId,
        p_hire_date: val('hrHireDate') || null,
        p_resign_date: val('hrResignDate') || null,
        p_leave_start_date: val('hrLeaveStartDate') || null,
      });
      if (omErr) throw new Error('입사일/퇴사일 저장 실패: ' + omErr.message);
    }

    // 가족사항 — 주민번호가 암호화 저장이라, 다른 항목들처럼 "전부 지우고 새로 넣기"를 하면
    // 안 건드린 행의 암호화된 값까지 통째로 날아간다. 그래서 이 표만 행 단위로
    // update(기존 id)/insert(신규)/delete(빠진 id)로 처리한다.
    var keptFamilyIds = familyRows.filter(function(f) { return f.id; }).map(function(f) { return f.id; });
    var familyIdsToDelete = originalFamilyIds.filter(function(id) { return keptFamilyIds.indexOf(id) === -1; });
    if (familyIdsToDelete.length) {
      var { error: famDelErr } = await supabaseClient.from('employee_family_members').delete().in('id', familyIdsToDelete);
      if (famDelErr) throw new Error('가족사항 저장 실패: ' + famDelErr.message);
    }
    var famSortOrder = 0;
    for (var fi = 0; fi < familyRows.length; fi++) {
      var f = familyRows[fi];
      if (!(f.name || '').trim()) continue;
      var famPayload = {
        relation: f.relation || '', name: f.name,
        birth_date: f.is_dependent ? null : (f.birth_date || null),
        is_dependent: !!f.is_dependent,
        resident_number_plain: (f.is_dependent && f.residentNumberFront && f.residentNumberBack) ? (f.residentNumberFront + '-' + f.residentNumberBack) : null,
        occupation: f.occupation || null, sort_order: famSortOrder++,
      };
      if (f.id) {
        var { error: famUpdErr } = await supabaseClient.from('employee_family_members').update(famPayload).eq('id', f.id);
        if (famUpdErr) throw new Error('가족사항 저장 실패: ' + famUpdErr.message);
      } else {
        famPayload.org_id = currentUser.org_id;
        famPayload.org_member_id = targetMemberId;
        var { error: famInsErr } = await supabaseClient.from('employee_family_members').insert(famPayload);
        if (famInsErr) throw new Error('가족사항 저장 실패: ' + famInsErr.message);
      }
    }

    await supabaseClient.from('employee_licenses').delete().eq('org_member_id', targetMemberId);
    var licenseToInsert = licenseRows.filter(function(l) { return (l.license_name || '').trim(); }).map(function(l, i) {
      return { org_id: currentUser.org_id, org_member_id: targetMemberId, license_name: l.license_name, license_no: l.license_no || null, issuer: l.issuer || null, issued_date: l.issued_date || null, expires_date: l.expires_date || null, sort_order: i };
    });
    if (licenseToInsert.length) {
      var { error: licErr } = await supabaseClient.from('employee_licenses').insert(licenseToInsert);
      if (licErr) throw new Error('자격증/면허 저장 실패: ' + licErr.message);
    }

    await supabaseClient.from('employee_awards').delete().eq('org_member_id', targetMemberId);
    var awardToInsert = awardRows.filter(function(a) { return (a.award_name || '').trim(); }).map(function(a, i) {
      return { org_id: currentUser.org_id, org_member_id: targetMemberId, award_name: a.award_name, awarding_org: a.awarding_org || null, awarded_date: a.awarded_date || null, description: a.description || null, sort_order: i };
    });
    if (awardToInsert.length) {
      var { error: awardErr } = await supabaseClient.from('employee_awards').insert(awardToInsert);
      if (awardErr) throw new Error('수상이력 저장 실패: ' + awardErr.message);
    }

    await loadTarget();
    systemLog('HR_UPDATE', '인사기록 수정', { target_type: 'employee_personal_info', target_id: targetMemberId }).catch(() => {});
    alert('저장되었습니다.');
  } catch (e) {
    console.error('[hr/personal-info-detail] 저장 실패:', e);
    alert(e.message || '저장 중 오류가 발생했습니다.');
  } finally {
    btn.disabled = false;
  }
}

/* ── 연차관리 탭: 현황 ── */
async function loadLeaveBalance() {
  var body = document.getElementById('hrLeaveBalanceBody');
  try {
    var { data, error } = await supabaseClient.rpc('get_leave_balance', { p_org_member_id: targetMemberId });
    if (error) throw new Error(error.message);
    var b = (data && data[0]) || null;
    if (!b) { body.innerHTML = '<div class="hr-empty-hint">연차 정보를 불러올 수 없습니다.</div>'; return; }
    body.innerHTML =
      '<div style="text-align:center;padding:6px 0 14px;">' +
        '<div class="leave-balance-num">' + b.remaining_days + '<span style="font-size:13px;color:#9ca3af;">일</span></div>' +
        '<div class="leave-balance-label">잔여 연차</div>' +
      '</div>' +
      '<div class="leave-balance-row"><span>이번 기간</span><b>' + ts(b.period_start) + ' ~ ' + ts(b.period_end) + '</b></div>' +
      '<div class="leave-balance-row"><span>근속연수</span><b>' + b.years_of_service + '년차</b></div>' +
      '<div class="leave-balance-row"><span>발생 일수</span><b>' + b.entitlement_days + '일</b></div>' +
      (Number(b.carried_over_days) !== 0 ? '<div class="leave-balance-row"><span>이월 일수</span><b>' + b.carried_over_days + '일</b></div>' : '') +
      '<div class="leave-balance-row"><span>사용 일수</span><b>' + b.used_days + '일</b></div>' +
      (Number(b.adjustment_days) !== 0 ? '<div class="leave-balance-row"><span>수동 조정</span><b>' + (b.adjustment_days > 0 ? '+' : '') + b.adjustment_days + '일</b></div>' : '');
  } catch (e) {
    console.error('[hr/personal-info-detail] loadLeaveBalance 실패:', e);
    body.innerHTML = '<div class="hr-empty-hint">' + ts(e.message) + '</div>';
  }
}

/* ── 연차관리 탭: 연차 내역(발생/조정/사용/소멸) 계산용 — 기간별 발생·소멸 데이터 ── */
async function loadLeaveLedgerPeriods() {
  try {
    var { data, error } = await supabaseClient.rpc('get_leave_ledger_periods', { p_org_member_id: targetMemberId });
    if (error) throw new Error(error.message);
    leaveLedgerPeriods = data || [];
  } catch (e) {
    console.error('[hr/personal-info-detail] loadLeaveLedgerPeriods 실패:', e);
    leaveLedgerPeriods = [];
  }
}


async function loadLeaveAdjustments() {
  try {
    var { data, error } = await supabaseClient
      .from('leave_adjustments')
      .select('id, period_start, period_end, adjustment_days, reason, created_at')
      .eq('org_member_id', targetMemberId)
      .order('created_at', { ascending: false });
    if (error) throw new Error(error.message);
    leaveAdjustments = data || [];
  } catch (e) {
    console.error('[hr/personal-info-detail] loadLeaveAdjustments 실패:', e);
    leaveAdjustments = [];
  }
}

async function saveLeaveAdjustment() {
  var days = parseFloat(val('hrAdjustDays'));
  var reason = val('hrAdjustReason').trim();
  if (!days) { alert('조정 일수를 입력해주세요.'); return; }
  var steps = days / minLeaveUnit;
  if (Math.abs(steps - Math.round(steps)) > 1e-6) {
    alert('이 의원의 최소 연차 단위는 ' + minLeaveUnit + '일입니다. ' + minLeaveUnit + '일 단위로 입력해주세요.');
    return;
  }
  try {
    var { data: b, error: balErr } = await supabaseClient.rpc('get_leave_balance', { p_org_member_id: targetMemberId });
    if (balErr) throw new Error(balErr.message);
    var period = (b && b[0]) || null;
    if (!period) throw new Error('현재 연차 기간 정보를 확인할 수 없습니다(입사일/정책을 먼저 확인해주세요).');
    var { error } = await supabaseClient.from('leave_adjustments').insert({
      org_id: currentUser.org_id, org_member_id: targetMemberId,
      period_start: period.period_start, period_end: period.period_end,
      adjustment_days: days, reason: reason || null, created_by: myOrgMemberId,
    });
    if (error) throw new Error(error.message);
    setVal('hrAdjustDays', ''); setVal('hrAdjustReason', '');
    await Promise.all([loadLeaveBalance(), loadLeaveAdjustments(), loadLeaveLedgerPeriods()]);
    renderLeaveRequestRows();
  } catch (e) {
    alert('조정 실패: ' + e.message);
  }
}

async function saveLeaveStartDate() {
  var btn = document.getElementById('hrLeaveStartDateSaveBtn');
  btn.disabled = true;
  try {
    var { error } = await supabaseClient.rpc('set_member_hr_dates', {
      p_org_member_id: targetMemberId,
      p_hire_date: val('hrHireDate') || null,
      p_resign_date: val('hrResignDate') || null,
      p_leave_start_date: val('hrLeaveStartDate') || null,
    });
    if (error) throw new Error(error.message);
    await Promise.all([loadLeaveBalance(), loadLeaveLedgerPeriods()]);
    renderLeaveRequestRows();
  } catch (e) {
    alert('연차 기산일 저장 실패: ' + e.message);
  } finally {
    btn.disabled = false;
  }
}

/* ── 연차관리 탭: 연차 내역 (발생/조정/사용/소멸 통합 원장, ag-grid) ── */
var _leaveRequestGridInstance = null;
var LEDGER_CATEGORY_COLOR = { 발생: '#2563eb', 조정: '#7c3aed', 사용: '#374151', 소멸: '#b91c1c' };

async function loadLeaveRequests() {
  var { data, error } = await supabaseClient
    .from('leave_requests')
    .select('id, start_date, end_date, leave_type_id, days_count, reason, status, requested_at, decision_comment, approval_document_id')
    .eq('org_member_id', targetMemberId)
    .order('requested_at', { ascending: false });
  if (error) { console.error('[hr/personal-info-detail] loadLeaveRequests 실패:', error); myRequests = []; }
  else myRequests = data || [];
}

/** myRequests / leaveAdjustments / leaveLedgerPeriods를 하나의 원장(날짜순)으로 합친다. */
function buildLeaveLedgerRows() {
  var rows = [];
  var seq = 0;

  leaveLedgerPeriods.forEach(function(p) {
    if (Number(p.entitlement_days) !== 0) {
      rows.push({ seq: seq++, date: p.period_start, category: '발생', amount: Number(p.entitlement_days), detail: p.years_of_service + '년차 정규 발생', affectsBalance: true });
    }
    if (Number(p.carried_in_days) !== 0) {
      rows.push({ seq: seq++, date: p.period_start, category: '발생', amount: Number(p.carried_in_days), detail: '전기 이월', affectsBalance: true });
    }
    if (!p.is_current && Number(p.forfeited_days) > 0) {
      rows.push({ seq: seq++, date: p.period_end, category: '소멸', amount: -Number(p.forfeited_days), detail: '미사용 연차 소멸(이월 한도 초과)', affectsBalance: true });
    }
  });

  leaveAdjustments.forEach(function(a) {
    rows.push({
      seq: seq++, date: a.created_at ? localDateStr(new Date(a.created_at)) : a.period_start,
      category: '조정', amount: Number(a.adjustment_days), detail: a.reason || '사유 없음', affectsBalance: true,
    });
  });

  myRequests.forEach(function(r) {
    var period = r.start_date === r.end_date ? r.start_date : r.start_date + ' ~ ' + r.end_date;
    var typeName = (leaveTypeMap[r.leave_type_id] && leaveTypeMap[r.leave_type_id].name) || '연차';
    rows.push({
      seq: seq++, date: r.start_date, category: '사용', amount: -Number(r.days_count), detail: typeName + ' (' + period + ')',
      status: r.status, approval_document_id: r.approval_document_id, request_id: r.id,
      affectsBalance: r.status === 'APPROVED', // 승인 대기/반려/취소 건은 아직 잔여에 반영되지 않음
    });
  });

  // 잔여일수 누적 흐름 — 날짜(오래된 순)를 따라가며 실제 잔여에 영향을 준 항목만 누적
  var asc = rows.slice().sort(function(a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : a.seq - b.seq; });
  var running = 0;
  asc.forEach(function(row) {
    if (row.affectsBalance) running += row.amount;
    row.balance = running;
  });

  rows.sort(function(a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : b.seq - a.seq; }); // 화면은 최신순
  return rows;
}

function renderLeaveRequestRows() {
  var el = document.getElementById('hrLeaveRequestGrid');
  if (!el) return;

  var rows = buildLeaveLedgerRows();

  if (_leaveRequestGridInstance) {
    _leaveRequestGridInstance.setGridOption('rowData', rows);
    return;
  }

  // 아직 "연차관리" 탭이 화면에 보이는 상태가 아니면(display:none) 컨테이너 크기가 0이라
  // 지금 agGrid.createGrid()를 해도 높이를 제대로 못 잡는다(equipment-list.js처럼
  // visibility:hidden을 쓰는 페이지와 달리, 탭은 display:none이라 레이아웃 자체가 없다).
  // 탭이 실제로 열릴 때(탭 클릭 핸들러) 다시 이 함수를 호출해서 그때 생성한다.
  var panel = document.querySelector('.hr-det-tab-panel[data-tab="leave"]');
  if (!panel || !panel.classList.contains('active')) return;

  var columnDefs = [
    { headerName: '일자', field: 'date', flex: 0.9, minWidth: 95 },
    { headerName: '구분', field: 'category', flex: 0.6, minWidth: 65,
      cellRenderer: function(p) {
        return '<span style="color:' + (LEDGER_CATEGORY_COLOR[p.value] || '#374151') + ';font-weight:700;">' + ts(p.value) + '</span>';
      }
    },
    { headerName: '일수', field: 'amount', flex: 0.6, minWidth: 65,
      cellRenderer: function(p) {
        var color = p.value > 0 ? '#2563eb' : p.value < 0 ? '#b91c1c' : '#6b7280';
        var opacity = p.data.affectsBalance === false ? ' opacity:0.55;' : '';
        return '<span style="color:' + color + ';font-weight:600;' + opacity + '">' + (p.value > 0 ? '+' : '') + p.value + '일</span>';
      }
    },
    { headerName: '잔여', field: 'balance', flex: 0.6, minWidth: 65,
      cellRenderer: function(p) { return '<b>' + p.value + '일</b>'; }
    },
    { headerName: '내용', field: 'detail', flex: 1.6, minWidth: 150, headerClass: 'ag-left-header',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' } },
    { headerName: '상태', field: 'status', flex: 0.7, minWidth: 80,
      cellRenderer: function(p) {
        return p.value ? '<span style="color:' + (STATUS_TEXT_COLOR[p.value] || '#374151') + ';font-weight:600;">' + ts(STATUS_LABEL[p.value] || p.value) + '</span>' : '-';
      }
    },
    { headerName: '', field: 'approval_document_id', flex: 0, width: isHr ? 170 : 90, sortable: false,
      cellRenderer: function(p) {
        if (p.data.category !== '사용') return '';
        var showCancel = isHr && p.data.status === 'APPROVED';
        var html = p.value
          ? '<a class="btn btn-sm" href="../approval/doc-detail.html?id=' + p.value + '">결재 확인</a>'
          : (showCancel ? '' : '-');
        if (showCancel) {
          html += (html ? ' ' : '') + '<button type="button" class="btn btn-sm" style="color:#b91c1c;" onclick="hrCancelLeaveRequest(\'' + p.data.request_id + '\',\'' + (p.value || '') + '\')">취소 처리</button>';
        }
        return html;
      }
    },
  ];

  var defaultColDef = {
    sortable: true,
    resizable: true,
    suppressMovable: true,
    headerClass: 'ag-center-header',
    cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'center' },
  };

  // 액션 컬럼(flex:0)은 sizeColumnsToFit()을 호출해도 늘어나지 않도록 폭을 고정한다
  // (createMgGrid 공통 유틸의 fitColumns 로직과 동일한 원리 — 이 그리드는 별도로 만들어서 직접 적용).
  var fixedColumnLimits = columnDefs.filter(function(c) { return c.flex === 0 && c.width; })
    .map(function(c) { return { key: c.field, minWidth: c.width, maxWidth: c.width }; });
  function fitLeaveGridColumns(api) {
    api.sizeColumnsToFit(fixedColumnLimits.length ? { columnLimits: fixedColumnLimits } : undefined);
  }

  // CSS height:100%만으로는 flex 체인 어딘가에서 실제로 안 늘어나는 경우가 있어서,
  // wrap의 실측 픽셀 높이를 JS로 직접 읽어 그리드 컨테이너에 강제로 지정한다.
  function resizeLeaveGridEl() {
    var wrap = document.getElementById('hrLeaveRequestGridWrap');
    if (wrap && wrap.clientHeight > 0) el.style.height = wrap.clientHeight + 'px';
  }

  _leaveRequestGridInstance = agGrid.createGrid(el, {
    columnDefs: columnDefs,
    defaultColDef: defaultColDef,
    rowData: rows,
    rowHeight: 35,
    headerHeight: 35,
    suppressPaginationPanel: true,
    suppressScrollOnNewData: true,
    suppressHorizontalScroll: true,
    suppressCellFocus: true,
    overlayNoRowsTemplate: '<span style="color:#9ca3af;font-size:12px;">연차 내역이 없습니다.</span>',
    onGridReady: function(params) {
      resizeLeaveGridEl();
      fitLeaveGridColumns(params.api);
      window.addEventListener('resize', function() {
        resizeLeaveGridEl();
        if (_leaveRequestGridInstance) fitLeaveGridColumns(_leaveRequestGridInstance);
      });
      // 처음 생성될 때는 "연차관리" 탭이 비활성(display:none)이라 실제 크기가 0이다.
      // 이후 탭을 눌러 보이게 되는 순간은 window resize가 아니라 컨테이너 크기 변화라서
      // 위 resize 리스너로는 못 잡는다 — ResizeObserver로 그 변화를 감지해 다시 맞춘다.
      if (typeof ResizeObserver !== 'undefined') {
        var ro = new ResizeObserver(function() {
          resizeLeaveGridEl();
          if (_leaveRequestGridInstance) fitLeaveGridColumns(_leaveRequestGridInstance);
          else ro.disconnect();
        });
        ro.observe(document.getElementById('hrLeaveRequestGridWrap'));
      }
    }
  });
}

/** 관리자용 — 승인된 연차를 취소 처리. 결재문서를 CANCELED로 바꾸면 트리거가 leave_requests.status와
 *  잔여 일수까지 함께 맞춰준다(마스터 관리 > 연차 전체 관리의 '취소 처리'와 동일한 로직). */
window.hrCancelLeaveRequest = async function(requestId, approvalDocId) {
  if (!isHr) return;
  if (!confirm('이 연차를 취소 처리할까요? 사용한 일수만큼 잔여 연차로 복구됩니다.')) return;
  try {
    if (!approvalDocId) throw new Error('연결된 결재 문서를 찾을 수 없습니다.');
    var { error } = await supabaseClient.from('approval_documents')
      .update({ status: 'CANCELED', completed_at: new Date().toISOString(), updated_at: new Date().toISOString() })
      .eq('id', approvalDocId);
    if (error) throw new Error(error.message);
    await Promise.all([loadLeaveRequests(), loadLeaveBalance(), loadLeaveLedgerPeriods()]);
    renderLeaveRequestRows();
  } catch (e) {
    alert('취소 실패: ' + e.message);
  }
};

init();