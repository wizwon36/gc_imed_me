'use strict';

var currentUser = null;
var myOrgMemberId = null;
var myRole = 'user';
var allMembers = [];
var hrGridApi = null;

var ROLE_LABEL = { user: '일반', manager: '매니저', admin: '관리자' };

function ts(s) { return (s == null ? '' : String(s)).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function hideLoading() { var el = document.getElementById('globalLoading'); if (el) el.classList.remove('is-open'); }

async function init() {
  try {
    var session = await auth.requireAuth();
    if (!session) return;
    currentUser = await auth.getSession();
    auth.applyBrandColor(currentUser.primary_color);

    if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'hr/personal-info')) {
      hideLoading();
      alert('이 페이지에 접근할 권한이 없습니다.');
      location.replace('../home/home.html');
      return;
    }

    await resolveMyContext();
    if (!myOrgMemberId) {
      hideLoading();
      document.querySelector('.hr-page').innerHTML =
        '<div style="text-align:center;color:#6b7280;font-size:13px;padding:60px;">' +
        (currentUser.is_platform_admin
          ? '플랫폼 관리자의 "의원 미리보기" 모드에서는 인사관리를 사용할 수 없습니다.<br>실제 소속 구성원 계정으로 로그인해주세요.'
          : '소속 구성원 정보를 확인할 수 없어 인사관리를 사용할 수 없습니다.<br>관리자에게 문의해주세요.') +
        '</div>';
      return;
    }

    // 일반 직원은 목록 자체가 의미 없다(어차피 본인 것만 볼 수 있음) — 바로 본인 상세로 이동.
    if (myRole !== 'manager' && myRole !== 'admin') {
      location.replace('personal-info-detail.html?id=' + encodeURIComponent(myOrgMemberId));
      return;
    }

    await loadMembers();
    populateFilterSelects();
    bindUi();
    applyFilter();
    hideLoading();
  } catch (e) {
    console.error('[hr/personal-info-list] init 실패:', e);
    hideLoading();
    alert('페이지를 불러오는 중 오류가 발생했습니다.');
  }
}

async function resolveMyContext() {
  if (!currentUser.org_member_id) { console.warn('[hr/personal-info-list] org_member_id 없음'); return; }
  var { data, error } = await supabaseClient.from('org_members').select('id, role').eq('id', currentUser.org_member_id).maybeSingle();
  if (error) { console.error('[hr/personal-info-list] resolveMyContext 오류:', error); return; }
  if (!data) return;
  myOrgMemberId = data.id;
  myRole = data.role;
}

async function loadMembers() {
  var { data, error } = await supabaseClient
    .from('org_members_detail')
    .select('id, user_name, role, clinic_id, clinic_name, dept_id, dept_name, position_name, hire_date')
    .eq('org_id', currentUser.org_id).eq('active', true).eq('is_platform_system_account', false)
    .order('user_name');
  if (error) { console.error('[hr/personal-info-list] loadMembers 실패:', error); allMembers = []; return; }
  allMembers = data || [];
}

/** 의원/부서 필터 select — 실제로 구성원이 속한 곳만 목록에 올린다(빈 부서는 골라봐야 의미 없음). */
function populateFilterSelects() {
  var clinicSel = document.getElementById('clinicFilter');
  var deptSel = document.getElementById('deptFilter');

  var clinics = [];
  var seenClinic = {};
  allMembers.forEach(function(m) {
    if (m.clinic_id && !seenClinic[m.clinic_id]) { seenClinic[m.clinic_id] = true; clinics.push({ id: m.clinic_id, name: m.clinic_name }); }
  });
  clinicSel.innerHTML = '<option value="">전체 의원</option>' +
    clinics.map(function(c) { return '<option value="' + c.id + '">' + ts(c.name) + '</option>'; }).join('');

  var depts = [];
  var seenDept = {};
  allMembers.forEach(function(m) {
    if (m.dept_id && !seenDept[m.dept_id]) { seenDept[m.dept_id] = true; depts.push({ id: m.dept_id, name: m.dept_name }); }
  });
  deptSel.innerHTML = '<option value="">전체 부서</option>' +
    depts.map(function(d) { return '<option value="' + d.id + '">' + ts(d.name) + '</option>'; }).join('');

  // 의원 필터는 화면에서 숨기고, 항상 현재 로그인한 사용자의 소속 의원으로 강제 고정한다.
  if (currentUser && currentUser.clinic_id) {
    clinicSel.value = currentUser.clinic_id;
  }
}

function bindUi() {
  document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();
    applyFilter();
  });
  document.getElementById('keyword').addEventListener('input', applyFilter);
  document.getElementById('clinicFilter').addEventListener('change', applyFilter);
  document.getElementById('deptFilter').addEventListener('change', applyFilter);
  document.getElementById('roleFilter').addEventListener('change', applyFilter);
  document.getElementById('resetFilterBtn').addEventListener('click', function() {
    document.getElementById('keyword').value = '';
    // 의원 필터는 항상 현재 소속 의원으로 고정 — 초기화 대상에서 제외
    document.getElementById('deptFilter').value = '';
    document.getElementById('roleFilter').value = '';
    applyFilter();
  });
}

function applyFilter() {
  var q = document.getElementById('keyword').value.trim().toLowerCase();
  var clinicId = document.getElementById('clinicFilter').value;
  var deptId = document.getElementById('deptFilter').value;
  var role = document.getElementById('roleFilter').value;

  var rows = allMembers.filter(function(m) {
    if (q && ![m.user_name, m.dept_name, m.position_name, m.clinic_name].some(function(v) { return (v || '').toLowerCase().indexOf(q) !== -1; })) return false;
    if (clinicId && m.clinic_id !== clinicId) return false;
    if (deptId && m.dept_id !== deptId) return false;
    if (role && m.role !== role) return false;
    return true;
  });
  renderGrid(rows);
}

function renderGrid(rows) {
  var cols = [
    { headerName: '이름', field: 'user_name', flex: 1.1, minWidth: 100, headerClass: 'ag-left-header',
      cellStyle: { justifyContent: 'flex-start' },
      cellRenderer: function(p) { return ts(p.value); } },
    { headerName: '의원', field: 'clinic_name', flex: 1, minWidth: 100 },
    { headerName: '부서', field: 'dept_name', flex: 1, minWidth: 100 },
    { headerName: '직위', field: 'position_name', flex: 1, minWidth: 90 },
    { headerName: '입사일', field: 'hire_date', flex: 0.9, minWidth: 90 },
    { headerName: '역할', field: 'role', flex: 0.8, minWidth: 80, valueFormatter: function(p) { return ROLE_LABEL[p.value] || p.value; } },
    { headerName: '', field: '_actions', flex: 0, width: 90, sortable: false, filter: false,
      cellRenderer: function(p) {
        var a = document.createElement('a');
        a.className = 'hr-action-btn';
        a.textContent = '상세';
        a.href = 'personal-info-detail.html?id=' + encodeURIComponent(p.data.id);
        a.addEventListener('click', function(e) { e.stopPropagation(); });
        return a;
      } },
  ];
  // 조회할 때마다 그리드를 새로 만들면 이전 인스턴스가 제거되지 않고 컨테이너 안에
  // 계속 쌓여서(중복 DOM) 스크롤/여백이 생기는 문제가 있었다 — 최초 1회만 생성하고,
  // 이후에는 rowData만 갱신한다.
  if (hrGridApi) {
    updateMgGrid(hrGridApi, rows);
    return;
  }
  hrGridApi = createMgGrid('hrGrid', cols, rows, {
    noRowsText: '검색 결과가 없습니다.',
  });
}

init();