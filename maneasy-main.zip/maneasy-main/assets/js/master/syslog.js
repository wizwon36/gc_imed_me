'use strict';

var _grid = null;
var _state = { loading:false, offset:0, totalCount:0, allRows:[] };
var PAGE_SIZE = 500; // 서버 기본 한 번에 최대 1000행 제한이 있어서, 여유 있게 페이지당 500건씩 나눠서 불러온다
var currentUser = null;

function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function fmtDt(v) { return v ? formatDateTimeKRCompact(v) : '-'; }

var ACTION_LABEL = {
  LOGIN:'로그인', SIGNAGE_CREATE:'사인물 신청', SIGNAGE_STATUS:'상태 변경',
  NOTICE_CREATE:'공지 작성', NOTICE_UPDATE:'공지 수정', NOTICE_DELETE:'공지 삭제',
  PROGRAM_REQUEST_CREATE:'프로그램 요청', PROGRAM_REQUEST_STATUS:'상태 변경',
  // 전자결재
  APPROVAL_SUBMIT:'기안 상신', APPROVAL_APPROVE:'결재 승인', APPROVAL_REJECT:'결재 반려',
  // 인사관리
  HR_UPDATE:'인사기록 수정',
  // 자재관리
  MATERIAL_PR_CREATE:'발주요청 제출', MATERIAL_PR_CANCEL:'발주요청 취소',
  MATERIAL_PO_CREATE:'발주서 생성', MATERIAL_PO_UPDATE:'발주서 수정',
  MATERIAL_PO_CONFIRM:'발주 확정', MATERIAL_PO_STATUS:'발주서 상태변경', MATERIAL_PO_EMAIL:'발주서 이메일 발송',
  MATERIAL_RECEIPT:'자재 입고', MATERIAL_TRANSFER:'재고 이동', MATERIAL_USE:'자재 사용처리',
  // 의료장비관리
  EQUIPMENT_CREATE:'장비 등록', EQUIPMENT_UPDATE:'장비 수정', EQUIPMENT_QC_ITEM_SAVE:'정도관리 항목 저장',
  EQUIPMENT_INSPECT_SAVE:'검사이력 등록',
  // 마스터관리
  MASTER_DEPT_SAVE:'부서 저장', MASTER_POSITION_SAVE:'직책 저장', MASTER_USER_SAVE:'사용자·권한 저장',
  MASTER_CATEGORY_SAVE:'자재구분 저장', MASTER_VENDOR_SAVE:'거래처 저장', MASTER_ITEM_SAVE:'자재코드 저장',
  MASTER_RESOURCE_SAVE:'자원 저장', RESOURCE_CREATE:'자원 등록', RESOURCE_UPDATE:'자원 수정', RESOURCE_DELETE:'자원 삭제',
  // 계약관리
  CONTRACT_CREATE:'계약 등록', CONTRACT_UPDATE:'계약 수정', CONTRACT_DELETE:'계약 삭제',
  CONTRACT_RESTORE:'계약 복구', CONTRACT_VIEW:'계약 열람',
};

function initGrid() {
  _grid = createMgGrid('logGrid', [
    { headerName:'일시', field:'created_at', width:155,
      cellRenderer: function(p) { return fmtDt(p.value); }
    },
    { headerName:'액션', field:'action', width:180,
      cellRenderer: function(p) {
        var cls = 'log-badge log-' + (p.value || '');
        var label = ACTION_LABEL[p.value] || p.value;
        return '<span class="' + cls + '">' + label + '</span>';
      }
    },
    { headerName:'사용자', field:'user_name', width:100 },
    { headerName:'내용', field:'description', flex:1, minWidth:120,
      headerClass:'ag-left-header',
      cellStyle:{ display:'flex', alignItems:'center', justifyContent:'flex-start' },
    },
    { headerName:'대상', field:'target_type', width:130,
      cellRenderer: function(p) {
        if (!p.value) return '-';
        var map = { signage_request:'사인물 신청', system_notice:'공지사항' };
        return map[p.value] || p.value;
      }
    },
  ], [], { noRowsText: '로그가 없습니다.' });
}

/** append=false: 새 조회(필터 변경, 검색 등) — 처음부터 다시. append=true: "더 불러오기". */
async function loadLogs(append) {
  if (_state.loading) return;
  _state.loading = true;
  showGlobalLoading('로그를 불러오는 중...');

  if (!append) { _state.offset = 0; _state.allRows = []; }

  var from    = val('logFrom');
  var to      = val('logTo');
  var action  = val('logAction');
  var keyword = val('logKeyword');

  var q = supabaseClient.from('system_logs').select('*', { count:'exact' })
    .eq('org_id', currentUser.org_id)
    .order('created_at', { ascending:false })
    .range(_state.offset, _state.offset + PAGE_SIZE - 1);

  if (from)    q = q.gte('created_at', from);
  if (to)      q = q.lte('created_at', to + 'T23:59:59');
  if (action)  q = q.eq('action', action);
  if (keyword) q = q.or('user_name.ilike.%' + escapeIlikeKeyword(keyword) + '%,description.ilike.%' + escapeIlikeKeyword(keyword) + '%');

  var { data, error, count } = await q;
  hideGlobalLoading();
  _state.loading = false;

  if (error) { alert('로드 실패: ' + error.message); return; }

  _state.totalCount = count || 0;
  _state.allRows = _state.allRows.concat(data || []);
  _state.offset = _state.allRows.length;

  var label = document.getElementById('logCountLabel');
  if (label) label.textContent = '불러온 ' + _state.allRows.length + '건 / 전체 ' + _state.totalCount + '건';

  var moreBtn = document.getElementById('logLoadMoreBtn');
  if (moreBtn) moreBtn.style.display = (_state.allRows.length < _state.totalCount) ? '' : 'none';

  updateMgGrid(_grid, _state.allRows);
}

async function init() {
  ['logFrom', 'logTo'].forEach(mountCustomDateInput);
  var session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();

  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'master/syslog')) {
    hideGlobalLoading();
    alert('이 페이지에 접근할 권한이 없습니다.');
    location.replace('../home/home.html');
    return;
  }

  var today = new Date();
  var weekAgo = new Date(today); weekAgo.setDate(today.getDate() - 7);
  document.getElementById('logFrom').value = localDateStr(weekAgo);
  document.getElementById('logTo').value   = localDateStr(today);

  initGrid();
  document.getElementById('logSearchBtn')?.addEventListener('click', function() { loadLogs(); });
  document.getElementById('logKeyword')?.addEventListener('keydown', function(e) { if (e.key==='Enter') loadLogs(); });
  document.getElementById('logLoadMoreBtn')?.addEventListener('click', function() { loadLogs(true); });

  await loadLogs();
}

document.addEventListener('DOMContentLoaded', init);