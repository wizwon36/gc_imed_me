/**
 * assets/js/master/org.js
 * 의원 관리 — 의원 / 부서 / 사용자
 * admin role만 접근 가능
 *
 * 연동 구조:
 *   clinicCache → 부서 탭 필터 + 부서 모달 select + 사용자 모달 select
 *   deptCache   → 부서 탭 필터 + 사용자 탭 필터 + 사용자 모달 select (의원 선택 후 필터)
 *   userCache   → 사용자 탭 렌더링 (clinic_code / team_code 기준 필터)
 */
'use strict';

let currentUser    = null;
let editingClinicId = null;
let editingDeptId   = null;
let editingPositionId = null;
let editingUserId   = null;
let editingUserUserId = null;  // org_members.user_id (profiles 업데이트용, editingUserId는 org_members.id)

let clinicCache = [];   // { id, clinic_code, clinic_name, ... }
let deptCache   = [];   // { id, clinic_id, dept_code, dept_name, ... }
let positionCache = []; // { id, name, sort_order, active }
let userCache   = [];   // user_profiles rows

/* ── 앱별 권한 ─────────────────────────────────
   app.html MENU_META / 사이드바 노출 로직과 동일한 페이지 키 사용 */
// 사용자별 개별 권한 편집 UI에 보여줄 페이지 목록 — core/pages.js(PageRegistry)에서 파생된다.
// 새 페이지를 추가할 땐 이 파일이 아니라 pages.js의 GROUPS에 등록한다.
const PAGE_GROUPS = window.PageRegistry.buildPermissionGroups();

// 역할별 기본 page_perms — 단일 기준(assets/js/core/permissions.js)을 그대로 사용한다.
// 여기서 따로 값을 들고 있으면 실제 런타임 판단 기준(PagePerms.getLevel)과 어긋날 수 있어서
// (실제로 한 번 어긋났었음) 절대 이 파일에 사본을 두지 않는다.
const ROLE_DEFAULT_PAGES = window.PagePerms.ROLE_DEFAULT_PAGES;

/* ── 유틸 ─────────────────────────────────── */
function ts(v) {
  return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function val(id)       { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }

function badgeActive(v) {
  // departments.active는 text('Y'/'N')이고, clinics.is_active/org_members_detail.active는
  // boolean이라 이 함수가 둘 다 받는다. 이전엔 'Y'만 봐서 사용자 목록의 "상태" 컬럼이
  // 실제 활성 사용자도 전부 "비활성"으로 표시되는 버그가 있었다.
  const isActive = v === 'Y' || v === true;
  return isActive
    ? '<span class="badge-active">활성</span>'
    : '<span class="badge-inactive">비활성</span>';
}
function badgeRole(r) {
  const map = {
    admin:   '<span class="badge-role-admin">admin</span>',
    edit:    '<span class="badge-role-edit">edit</span>',
    manager: '<span class="badge-role-manager">manager</span>',
    user:    '<span class="badge-role-user">user</span>',
  };
  return map[r] || ts(r);
}

/* ── 탭 ── */
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`tab-${target}`)?.classList.add('active');

      // 탭 전환 후 그리드 width/height 재계산 (display:none 상태에서 초기화되면 0으로 잡힘)
      requestAnimationFrame(() => {
        const gridMap = { clinics: '_clinicGrid', departments: '_deptGrid', positions: '_positionGrid', users: '_userGrid' };
        const g = window[gridMap[target]];
        if (g) fitGridColumnsPinned(g, g.getColumnDefs());
      });
    });
  });
}

/* ── 모달 ── */
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.closeModal = closeModal;

/* ════════════════════════════════════════════
   공통 select 헬퍼
════════════════════════════════════════════ */

/** 의원 select 채우기 (여러 곳에서 공유) */
function fillClinicSelect(selId, placeholder, selectedId) {
  const sel = document.getElementById(selId);
  if (!sel) return;
  sel.innerHTML = `<option value="">${placeholder}</option>` +
    clinicCache.map(c =>
      `<option value="${c.id}" data-code="${ts(c.clinic_code)}" data-name="${ts(c.clinic_name)}">${ts(c.clinic_name)}</option>`
    ).join('');
  if (selectedId) sel.value = selectedId;
}

/** 직책 select 채우기 */
function fillPositionSelect(selId, placeholder, selectedId) {
  const sel = document.getElementById(selId);
  if (!sel) return;
  sel.innerHTML = `<option value="">${placeholder}</option>` +
    positionCache.filter(p => p.active).map(p => `<option value="${p.id}">${ts(p.name)}</option>`).join('');
  if (selectedId) sel.value = selectedId;
}

/** 특정 의원(clinic_id)에 속한 부서만 select에 채우기 */
function fillDeptSelect(selId, placeholder, clinicId, selectedId) {
  const sel = document.getElementById(selId);
  if (!sel) return;
  const filtered = clinicId
    ? deptCache.filter(d => d.clinic_id === clinicId)
    : deptCache;
  sel.innerHTML = `<option value="">${placeholder}</option>` +
    filtered.map(d =>
      `<option value="${d.id}" data-code="${ts(d.dept_code)}" data-name="${ts(d.dept_name)}" data-team-group="${ts(d.team_group_code||'')}">${ts(d.dept_name)}</option>`
    ).join('');
  if (selectedId) sel.value = selectedId;
}

/* ════════════════════════════════════════════
   의원 (clinics)
════════════════════════════════════════════ */
async function loadClinics() {
  const { data, error } = await supabaseClient
    .from('clinics')
    .select('*')
    .eq('id', currentUser.org_id)
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

function renderClinics(rows) {
  clinicCache = rows;
  const list  = document.getElementById('clinicList');
  const empty = document.getElementById('clinicEmpty');
  if (!list) return;

  if (empty) empty.style.display = 'none';
  paintClinicPage(rows);
  syncClinicSelects();
}

function paintClinicPage(rows) {
  if (!window._clinicGrid) {
    window._clinicGrid =
  createMgGrid('clinicList', [
      { headerName: '코드',       field: 'clinic_code',  flex: 1, minWidth: 90 },
      { headerName: '의원명',     field: 'clinic_name',  flex: 2, minWidth: 120 },
      { headerName: '사업자번호', field: 'business_no',  width: 130, valueFormatter: p => p.value || '-' },
      { headerName: '요양기관번호', field: 'care_inst_no', width: 120, valueFormatter: p => p.value || '-' },
      { headerName: '전화',       field: 'phone',        flex: 1, minWidth: 110, valueFormatter: p => p.value || '-' },
      { headerName: '주소',       field: 'address',      flex: 2, minWidth: 140, valueFormatter: p => p.value || '-' },
      { headerName: '순서',   field: 'sort_order',  flex: 0, width: 60 },
      { headerName: '상태',   field: 'is_active',      flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
    ], rows, { fit: true, noRowsText: '등록된 의원이 없습니다. 플랫폼 관리자가 의원 생성 시 등록합니다.' });
  } else {
    updateMgGrid(window._clinicGrid, rows);
  }
}

/** 의원 데이터가 바뀔 때마다 연관 select 전부 갱신 */
function syncClinicSelects() {
  // 조직=의원이 항상 1:1이라, 아래 "필터"/select들은 전부 선택지가 하나뿐이다.
  // 완전히 없애기보다는(레이아웃 유지), 이 의원 하나로 자동 세팅하고 잠가둔다.
  var onlyClinic = clinicCache[0] || null;

  // 부서 탭 필터
  const deptFilter = document.getElementById('deptClinicFilter');
  if (deptFilter) {
    deptFilter.innerHTML = onlyClinic
      ? `<option value="${onlyClinic.id}">${ts(onlyClinic.clinic_name)}</option>`
      : '<option value="">의원 정보 없음</option>';
    deptFilter.value = onlyClinic ? onlyClinic.id : '';
    deptFilter.disabled = true;
  }
  // 사용자 탭 필터
  const userFilter = document.getElementById('userClinicFilter');
  if (userFilter) {
    userFilter.innerHTML = onlyClinic
      ? `<option value="${onlyClinic.id}">${ts(onlyClinic.clinic_name)}</option>`
      : '<option value="">의원 정보 없음</option>';
    userFilter.value = onlyClinic ? onlyClinic.id : '';
    userFilter.disabled = true;
  }
  // 부서 모달 — 의원 select
  fillClinicSelect('d_clinic_id', '의원을 선택하세요', onlyClinic ? onlyClinic.id : null);
  if (document.getElementById('d_clinic_id')) document.getElementById('d_clinic_id').disabled = true;
  // 사용자 모달 — 의원 select
  fillClinicSelect('u_clinic_select', '선택 안 함', onlyClinic ? onlyClinic.id : null);
  if (document.getElementById('u_clinic_select')) document.getElementById('u_clinic_select').disabled = true;
}

async function refreshClinics() {
  const rows = await loadClinics();
  renderClinics(rows);
}

/* ════════════════════════════════════════════
   부서 (departments)
════════════════════════════════════════════ */
async function loadDepts() {
  const { data, error } = await supabaseClient
    .from('departments')
    .select('*, clinics!departments_clinic_id_fkey(clinic_name, clinic_code)')
    .eq('org_id', currentUser.org_id)
    .eq('is_platform_test', false)
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

let _lastDeptFiltered = null;

function renderDepts(rows, filterClinicId) {
  deptCache = rows;
  const list  = document.getElementById('deptList');
  const empty = document.getElementById('deptEmpty');
  if (!list) return;

  const filtered = filterClinicId
    ? rows.filter(r => r.clinic_id === filterClinicId)
    : rows;
  _lastDeptFiltered = filtered;

  if (empty) empty.style.display = 'none';
  paintDeptPage(filtered);
  syncDeptFilter();
}

function paintDeptPage(filtered) {
  if (!window._deptGrid) {
    window._deptGrid =
  createMgGrid('deptList', [
      { headerName: '코드',     field: 'dept_code',  flex: 1, minWidth: 90 },
      { headerName: '부서명',   field: 'dept_name',  flex: 2, minWidth: 100 },
      { headerName: '소속 의원', flex: 1, minWidth: 100,
        valueGetter: p => p.data.clinics?.clinic_name || '-' },
      { headerName: '부서장', flex: 1, minWidth: 90,
        valueGetter: p => {
          if (!p.data.manager_id) return '-';
          const m = userCache.find(u => u.id === p.data.manager_id);
          return m ? m.user_name : '-';
        }},
      { headerName: '공유그룹', field: 'team_group_code', flex: 1, minWidth: 90,
        valueGetter: p => p.data.team_group_code || '-' },
      { headerName: '순서',     field: 'sort_order', flex: 0, width: 60 },
      { headerName: '상태',     field: 'active',     flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
      { headerName: '', flex: 0, width: 120, sortable: false,
        cellRenderer: p => {
          if (!window.canManageOrg) { const s = document.createElement('span'); s.textContent = '-'; return s; }
          const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;align-items:center;';
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정'; e.onclick = () => window.openEditDept(p.data.id);
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제'; d.onclick = () => window.deleteDept(p.data.id);
          wrap.append(e, d); return wrap;
        }},
    ], filtered, { fit: true, noRowsText: '등록된 부서가 없습니다.' });
  } else {
    updateMgGrid(window._deptGrid, filtered);
  }
}

/** 사용자 탭 부서 필터 select 갱신 (현재 선택된 의원 기준) */
function syncDeptFilter() {
  const userClinicFilter = document.getElementById('userClinicFilter');
  const clinicId = userClinicFilter?.value || '';
  const userDeptFilter = document.getElementById('userDeptFilter');
  if (!userDeptFilter) return;

  const cur = userDeptFilter.value;
  const filtered = clinicId
    ? deptCache.filter(d => d.clinic_id === clinicId)
    : deptCache;

  userDeptFilter.innerHTML = '<option value="">전체</option>' +
    filtered.map(d => `<option value="${d.id}">${ts(d.dept_name)}</option>`).join('');
  if (cur) userDeptFilter.value = cur;
}

function openAddDept() {
  editingDeptId = null;
  setVal('d_clinic_id', '');
  ['d_dept_code','d_dept_name','d_team_group_code'].forEach(id => setVal(id, ''));
  setVal('d_sort_order', '0');
  setVal('d_active', 'Y');
  populateDeptManagerOptions('');
  // 현재 부서 탭 필터에 의원이 선택돼 있으면 모달에 미리 세팅
  const filterVal = document.getElementById('deptClinicFilter')?.value || '';
  if (filterVal) setVal('d_clinic_id', filterVal);
  document.getElementById('deptModalTitle').textContent = '부서 추가';
  openModal('deptModal');
}

/** 부서장 select 옵션 채우기 — userCache(org_members_detail) 기준, 활성 사용자만.
 *  clinicId를 주면 그 의원 소속만 우선 보여주되, 지금 선택된 부서장이 다른 의원
 *  소속이어도(의원 개편 등) 목록에서 사라지지 않도록 항상 포함시킨다. */
function populateDeptManagerOptions(clinicId, currentManagerId) {
  const sel = document.getElementById('d_manager_id');
  if (!sel) return;
  let members = userCache.filter(u => u.active === true);
  if (clinicId) {
    members = members.filter(u => u.clinic_id === clinicId || u.id === currentManagerId);
  }
  sel.innerHTML = '<option value="">지정 안 함</option>' +
    members.map(u => `<option value="${u.id}">${ts(u.user_name)}${u.clinic_name ? ' · ' + ts(u.clinic_name) : ''}</option>`).join('');
  sel.value = currentManagerId || '';
}

function openEditDept(id) {
  const row = deptCache.find(r => r.id === id);
  if (!row) return;
  editingDeptId = id;
  setVal('d_clinic_id',  row.clinic_id || '');
  setVal('d_dept_code',  row.dept_code);
  setVal('d_dept_name',  row.dept_name);
  setVal('d_team_group_code', row.team_group_code || '');
  setVal('d_sort_order', row.sort_order ?? 0);
  setVal('d_active',     row.active);
  populateDeptManagerOptions(row.clinic_id || '', row.manager_id || '');
  document.getElementById('deptModalTitle').textContent = '부서 수정';
  openModal('deptModal');
}
window.openEditDept = openEditDept;

async function saveDept() {
  if (!window.canManageOrg) throw new Error('부서 정보를 수정할 권한이 없습니다.');
  const clinicId = val('d_clinic_id');
  if (!clinicId) throw new Error('소속 의원을 선택해주세요.');
  const payload = {
    dept_code: editingDeptId ? val('d_dept_code') : await (async () => {
      const { data, error } = await supabaseClient.rpc('generate_dept_code', { p_org_id: currentUser.org_id });
      if (error) throw new Error('부서 코드 채번 실패: ' + error.message);
      return data || 'DEPT-' + Date.now().toString().slice(-6);
    })(),
    dept_name:  val('d_dept_name'),
    clinic_id:  clinicId,
    manager_id: val('d_manager_id') || null,
    team_group_code: val('d_team_group_code').trim(),
    sort_order: Number(val('d_sort_order') || 0),
    active:     val('d_active'),
    updated_at: new Date().toISOString(),
  };
  // dept_code는 자동생성
  if (!payload.dept_name) throw new Error('부서명은 필수입니다.');
  if (editingDeptId) {
    const { error } = await supabaseClient.from('departments').update(payload).eq('id', editingDeptId);
    if (error) throw new Error(error.message);
  } else {
    payload.org_id = currentUser.org_id;
    const { error } = await supabaseClient.from('departments').insert(payload);
    if (error) throw new Error(error.message);
  }
}

async function deleteDept(id) {
  if (!confirm('부서를 삭제하시겠습니까?')) return;
  const { error } = await supabaseClient.from('departments').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  await refreshDepts();
}
window.deleteDept = deleteDept;

async function refreshDepts() {
  const rows = await loadDepts();
  const filterVal = document.getElementById('deptClinicFilter')?.value || '';
  renderDepts(rows, filterVal || null);
}

/* ════════════════════════════════════════════
   직책 (positions) — 의원 전체 공통, 소속 구분 없음
════════════════════════════════════════════ */
async function loadPositions() {
  const { data, error } = await supabaseClient
    .from('positions')
    .select('*')
    .eq('org_id', currentUser.org_id)
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

function renderPositions(rows) {
  positionCache = rows;
  const empty = document.getElementById('positionEmpty');
  if (empty) empty.style.display = 'none';
  paintPositionPage(rows);
}

function paintPositionPage(rows) {
  if (!window._positionGrid) {
    window._positionGrid = createMgGrid('positionList', [
      { headerName: '직책명', field: 'name', flex: 2, minWidth: 120, headerClass: 'ag-left-header', cellStyle: { justifyContent: 'flex-start', fontWeight: 600 } },
      { headerName: '순서', field: 'sort_order', flex: 0, width: 70 },
      { headerName: '상태', field: 'active', flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
      { headerName: '', flex: 0, width: 120, sortable: false,
        cellRenderer: p => {
          if (!window.canManageOrg) { const s = document.createElement('span'); s.textContent = '-'; return s; }
          const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;align-items:center;';
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정'; e.onclick = () => window.openEditPosition(p.data.id);
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제'; d.onclick = () => window.deletePosition(p.data.id);
          wrap.append(e, d); return wrap;
        }},
    ], rows, { fit: true, noRowsText: '등록된 직책이 없습니다.' });
  } else {
    updateMgGrid(window._positionGrid, rows);
  }
}

function openAddPosition() {
  editingPositionId = null;
  setVal('p_name', '');
  setVal('p_sort_order', '0');
  setVal('p_active', 'Y');
  document.getElementById('positionModalTitle').textContent = '직책 추가';
  openModal('positionModal');
}

function openEditPosition(id) {
  const row = positionCache.find(r => r.id === id);
  if (!row) return;
  editingPositionId = id;
  setVal('p_name', row.name);
  setVal('p_sort_order', row.sort_order ?? 0);
  setVal('p_active', row.active ? 'Y' : 'N');
  document.getElementById('positionModalTitle').textContent = '직책 수정';
  openModal('positionModal');
}
window.openEditPosition = openEditPosition;

async function savePosition() {
  if (!window.canManageOrg) throw new Error('직책 정보를 수정할 권한이 없습니다.');
  const name = val('p_name').trim();
  if (!name) throw new Error('직책명은 필수입니다.');
  const payload = {
    name,
    sort_order: Number(val('p_sort_order') || 0),
    active: val('p_active') === 'Y',
    updated_at: new Date().toISOString(),
  };
  if (editingPositionId) {
    const { error } = await supabaseClient.from('positions').update(payload).eq('id', editingPositionId);
    if (error) throw new Error(error.message);
  } else {
    payload.org_id = currentUser.org_id;
    const { error } = await supabaseClient.from('positions').insert(payload);
    if (error) throw new Error(error.message);
  }
}

async function deletePosition(id) {
  if (!confirm('직책을 삭제하시겠습니까? 이 직책을 가진 사용자는 "미지정" 상태가 됩니다.')) return;
  const { error } = await supabaseClient.from('positions').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  await refreshPositions();
}
window.deletePosition = deletePosition;

async function refreshPositions() {
  const rows = await loadPositions();
  renderPositions(rows);
}

/* ════════════════════════════════════════════
   사용자 (user_profiles)
════════════════════════════════════════════ */
async function loadUsers() {
  const { data, error } = await supabaseClient
    .from('org_members_detail')
    .select('*')
    .eq('org_id', currentUser.org_id)
    .eq('is_platform_system_account', false)
    .order('user_name', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

let _lastUserFiltered = null;

function renderUsers(rows, filterClinicId, filterDeptId) {
  userCache = rows;
  const list  = document.getElementById('userList');
  const empty = document.getElementById('userEmpty');
  if (!list) return;

  const inactiveCount = rows.filter(r => r.active !== true).length;
  const pendingEl = document.getElementById('userPendingCount');
  if (pendingEl) pendingEl.textContent = inactiveCount ? `(${inactiveCount})` : '';

  let filtered = rows;
  if (filterClinicId) filtered = filtered.filter(r => r.clinic_id === filterClinicId);
  if (filterDeptId)   filtered = filtered.filter(r => r.dept_id   === filterDeptId);
  if (document.getElementById('userPendingOnly')?.checked) filtered = filtered.filter(r => r.active !== true);
  _lastUserFiltered = filtered;

  if (empty) empty.style.display = 'none';
  paintUserPage(filtered);
}

function paintUserPage(filtered) {
  if (!window._userGrid) {
    window._userGrid =
  createMgGrid('userList', [
      { headerName: '', field: '_check', width: 40, flex: 0, sortable: false,
        cellRenderer: function(p) {
          var cb = document.createElement('input'); cb.type = 'checkbox';
          cb.checked = bulkSelectedUserIds.has(p.data.id);
          cb.addEventListener('change', function() { toggleUserSelected(p.data.id, cb.checked); });
          return cb;
        } },
      { headerName: '이름',   field: 'user_name',  flex: 1, minWidth: 80, valueFormatter: p => p.value || '-' },
      { headerName: '이메일', field: 'email',      flex: 2, minWidth: 160, valueFormatter: p => p.value || '-' },
      { headerName: '역할',   field: 'role',       flex: 0, width: 90,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeRole(p.value); return s; } },
      { headerName: '의원',   field: 'clinic_name', flex: 1, minWidth: 90, valueFormatter: p => p.value || '-' },
      { headerName: '부서',   field: 'dept_name',   flex: 1, minWidth: 90, valueFormatter: p => p.value || '-' },
      { headerName: '직책',   field: 'position_name', flex: 1, minWidth: 80, valueFormatter: p => p.value || '-' },
      { headerName: '전화',   field: 'phone',      flex: 1, minWidth: 110, valueFormatter: p => p.value || '-' },
      { headerName: '상태',   field: 'active',     flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
      { headerName: '', flex: 0, width: 90, sortable: false,
        cellRenderer: p => {
          if (!window.canManageOrg) { const s = document.createElement('span'); s.textContent = '-'; return s; }
          const btnEdit = document.createElement('button'); btnEdit.className = 'btn btn-sm'; btnEdit.textContent = '수정';
          btnEdit.onclick = () => window.openEditUser(p.data.id);
          return btnEdit;
        }},
    ], filtered, { fit: true, noRowsText: '등록된 사용자가 없습니다.' });
  } else {
    updateMgGrid(window._userGrid, filtered);
  }
}

/* ── 선택(체크박스) 및 일괄 권한 적용 ── */
var bulkSelectedUserIds = new Set();

function toggleUserSelected(id, checked) {
  if (checked) bulkSelectedUserIds.add(id); else bulkSelectedUserIds.delete(id);
  updateBulkPermButton();
}

function toggleSelectAllUsers(checked) {
  var rows = _lastUserFiltered || [];
  rows.forEach(function(r) { if (checked) bulkSelectedUserIds.add(r.id); else bulkSelectedUserIds.delete(r.id); });
  if (window._userGrid) updateMgGrid(window._userGrid, rows); // 체크 상태 다시 그리기
  updateBulkPermButton();
}

function updateBulkPermButton() {
  var btn = document.getElementById('bulkPermBtn');
  var countEl = document.getElementById('bulkSelCount');
  if (countEl) countEl.textContent = String(bulkSelectedUserIds.size);
  if (btn) btn.disabled = bulkSelectedUserIds.size === 0;
}

function openBulkPermModal() {
  if (!bulkSelectedUserIds.size) return;
  var targets = userCache.filter(function(u) { return bulkSelectedUserIds.has(u.id); });
  var listEl = document.getElementById('bulkPermTargetList');
  if (listEl) listEl.textContent = targets.map(function(u) { return u.user_name || u.email; }).join(', ');

  var userSel = document.getElementById('bulkPermUserSelect');
  if (userSel) {
    userSel.innerHTML = userCache.map(function(u) { return '<option value="' + u.id + '">' + ts(u.user_name || u.email) + '</option>'; }).join('');
  }
  document.querySelector('input[name="bulkPermMode"][value="role"]').checked = true;
  document.getElementById('bulkPermRoleWrap').style.display = '';
  document.getElementById('bulkPermUserWrap').style.display = 'none';
  setVal('bulkPermRoleSelect', 'user');
  refreshBulkPermPreview();
  openModal('bulkPermModal');
}

/** 현재 선택된 모드(역할/사용자)에 맞춰 미리보기 그리드를 다시 그린다 — 직접 손댄 값은
 *  모드나 대상을 바꾸면 초기화된다(그 시점부터 새로 미리보기하고 다시 조정하면 된다). */
function refreshBulkPermPreview() {
  var mode = document.querySelector('input[name="bulkPermMode"]:checked')?.value || 'role';
  var basePerms;
  if (mode === 'role') {
    var role = val('bulkPermRoleSelect') || 'user';
    basePerms = ROLE_DEFAULT_PAGES[role] || {};
  } else {
    var sourceId = val('bulkPermUserSelect');
    var source = userCache.find(function(u) { return u.id === sourceId; });
    basePerms = source ? (source.page_perms || ROLE_DEFAULT_PAGES[source.role] || {}) : {};
  }
  renderBulkPermBody(basePerms);
}

async function confirmBulkPerm() {
  var newPerms = getPagePermsFromBulkGrid();
  var ids = Array.from(bulkSelectedUserIds);
  if (!confirm(ids.length + '명에게 지금 보이는 권한 설정을 적용할까요? 되돌릴 수 없습니다.')) return;
  try {
    var { error } = await supabaseClient.from('org_members').update({ page_perms: newPerms }).in('id', ids);
    if (error) throw new Error(error.message);
    closeModal('bulkPermModal');
    bulkSelectedUserIds.clear();
    updateBulkPermButton();
    await refreshUsers();
    alert('적용되었습니다.');
  } catch (e) {
    alert('일괄 적용 실패: ' + e.message);
  }
}

/** 사용자 모달: 의원 선택 → 해당 의원 부서만 부서 select에 뿌리기 */
function onUserClinicSelectChange() {
  const clinicId = document.getElementById('u_clinic_select')?.value || '';
  fillDeptSelect('u_dept_select', '선택 안 함', clinicId || null, null);
}

/** 권한 레벨 옵션 */
const PERM_LEVELS = ['접근불가', 'user', 'edit', 'manager', 'admin'];
const PERM_COLORS = {
  '접근불가': '#dc2626',
  'user':     '#6b7280',
  'edit':     '#7c3aed',
  'manager':  '#d97706',
  'admin':    '#2563eb',
};

let _gridUserPerm = null;
let _gridBulkPerm = null; // 일괄 적용 모달 전용 미리보기 그리드(userPermGrid와 별개)

/** 앱 접근 권한 AG Grid 렌더링 */
/** 등급(user/edit/manager/admin/접근불가)이 실제로 무엇까지 허용하는지 풀어서 보여주는 텍스트.
 *  업무일지(task/task-manager)는 manager 등급이 "팀장 역할"이라는 별도 의미를 가져서 표시를 더해준다. */
/** 페이지별로 등급(user/edit/manager/admin)이 실제로 뭘 할 수 있는지 구체적으로 적어둔 표.
 *  등급 이름 자체가 프로그램마다 의미가 조금씩 달라서(예: 재고관리는 manager부터 처리 가능,
 *  발주관리는 취소만 user도 가능 등) 이걸 페이지 키별로 따로 관리한다.
 *  여기 없는 페이지/등급 조합은 일반적인 조회/수정/삭제 설명으로 대체된다. */
var LEVEL_NOTES = {
  'materials/purchase-request': {
    user: '조회만 가능, 신청 작성 불가',
    edit: '본인 발주요청 작성 및 취소 가능',
    manager: '본인 발주요청 작성 및 취소 가능',
    admin: '본인 발주요청 작성 및 취소 가능',
  },
  'materials/procurement': {
    user: '조회만 가능(처리 불가)',
    edit: '발주 취소만 가능, 확정 등 처리 불가',
    manager: '발주 등록부터 확정까지 전체 처리 가능',
    admin: '발주 등록부터 확정까지 전체 처리 가능',
  },
  'materials/stock': {
    user: '조회만 가능(처리 불가)',
    edit: '입고 등록·재고조사 처리 가능',
    manager: '입고 등록·재고조사 처리 가능',
    admin: '입고 등록·재고조사 처리 및 데이터 삭제 가능',
  },
  'task/task-manager': {
    user: '조회만 가능',
    edit: '본인 업무일정·일지 작성 가능',
    manager: '팀장 역할 — 소속 팀원 업무일정·일지 조회 및 관리',
    admin: '전체 의원 업무일정·일지 조회 및 관리',
  },
  'leave/leave-admin': {
    user: '접근 불가',
    admin: '전체 의원·부서 연차 현황 조회 및 정책 설정 가능',
  },
  'approval/lines': {
    user: '조회만 가능(등록/수정 불가)',
    edit: '결재선·양식 등록 및 수정 가능',
    manager: '결재선·양식 등록 및 수정 가능',
    admin: '결재선·양식 등록·수정 및 삭제 가능',
  },
  'master/org': {
    user: '접근 불가',
    manager: '의원·부서·사용자 등록 및 수정 가능(삭제 불가)',
    admin: '의원·부서·사용자 등록·수정 및 삭제 가능',
  },
  'master/supply': {
    user: '접근 불가',
    manager: '자재·거래처 기준정보 등록 및 수정 가능(삭제 불가)',
    admin: '자재·거래처 기준정보 등록·수정 및 삭제 가능',
  },
  'master/notice': {
    admin: '공지사항 작성·수정·삭제 가능(admin 고정)',
  },
  'master/syslog': {
    admin: '시스템 로그 조회 가능(admin 고정)',
  },
};

function levelToScopeText(level, pageKey) {
  if (!level || level === '접근불가') return '접근 불가';
  var override = LEVEL_NOTES[pageKey] && LEVEL_NOTES[pageKey][level];
  if (override) return override;
  var parts = ['조회'];
  if (level === 'edit' || level === 'manager' || level === 'admin') parts.push('수정');
  if (level === 'admin') parts.push('삭제');
  return parts.join('·');
}

function renderUserPermBody(pagePerms, disabled) {
  // pagePerms: { "page/key": "user"|"edit"|"manager"|"admin" } 또는 레거시 배열
  // 레거시 배열 호환
  let permMap = {};
  if (Array.isArray(pagePerms)) {
    pagePerms.forEach(k => { permMap[k] = 'user'; });
  } else if (pagePerms && typeof pagePerms === 'object') {
    permMap = { ...pagePerms };
  }

  // 행 데이터 생성
  const rows = [];
  PAGE_GROUPS.forEach(group => {
    group.pages.forEach(p => {
      rows.push({
        _key:   p.key,
        app:    group.app,
        label:  p.label,
        note:   p.note || '',
        level:  permMap[p.key] || '접근불가',
      });
    });
  });

  const el = document.getElementById('userPermGrid');
  if (!el) return;

  const colDefs = [
    { headerName: '앱', field: 'app', width: 100, rowGroup: false,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start',
                   fontSize:'11px', color:'#6b7280', fontWeight:600 },
    },
    { headerName: '페이지', field: 'label', width: 140,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'12px' },
    },
    { headerName: '접근 권한', field: 'level', width: 140,
      editable: false,
      cellRenderer: function(p) {
        if (disabled) {
          const v = p.value || '접근불가';
          const color = PERM_COLORS[v] || '#6b7280';
          return `<span style="display:inline-flex;align-items:center;gap:5px;">
            <span style="width:8px;height:8px;border-radius:50%;background:${color};flex-shrink:0;"></span>
            <span style="color:${color};font-weight:600;font-size:11px;">${v}</span>
          </span>`;
        }
        // 드롭다운 select 렌더링 (인라인, 셀 클릭 없이 바로 변경)
        const sel = document.createElement('select');
        sel.style.cssText = 'width:100%;height:100%;padding:0 8px;border:none;border-radius:0;font-size:11px;font-weight:600;outline:none;cursor:pointer;background:transparent;box-sizing:border-box;';
        PERM_LEVELS.forEach(lv => {
          const opt = document.createElement('option');
          opt.value = lv;
          opt.textContent = lv;
          if (lv === (p.value || '접근불가')) opt.selected = true;
          sel.appendChild(opt);
        });
        sel.style.color = PERM_COLORS[p.value || '접근불가'] || '#6b7280';
        sel.addEventListener('change', function() {
          p.node.data.level = sel.value;  // 직접 data 수정 (editable:false 환경)
          sel.style.color = PERM_COLORS[sel.value] || '#6b7280';
          // 같은 행의 "허용 범위" 셀도 즉시 갱신 (그리드 전체를 다시 그리지 않고 셀만 직접 갱신)
          var scopeCell = sel.closest('.ag-row')?.querySelector('[col-id="scope"]');
          if (scopeCell) scopeCell.textContent = levelToScopeText(sel.value, p.node.data._key);
        });
        return sel;
      },
    },
    { headerName: '허용 범위', colId: 'scope', width: 230,
      valueGetter: function(p) { return levelToScopeText(p.data.level, p.data._key); },
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'11px', color:'#6b7280', whiteSpace:'normal', lineHeight:'1.3' },
    },
    { headerName: '설명', field: 'note', flex: 1,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'11px', color:'#9ca3af' },
    },
  ];

  if (_gridUserPerm) {
    _gridUserPerm.destroy();
    _gridUserPerm = null;
    el.innerHTML = '';
  }

  _gridUserPerm = agGrid.createGrid(el, {
    columnDefs: colDefs,
    rowData: rows,
    rowHeight: 34,
    headerHeight: 34,
    suppressCellFocus: true,
    suppressHorizontalScroll: false,
    stopEditingWhenCellsLoseFocus: true,
    singleClickEdit: false,
    defaultColDef: {
      sortable: false, resizable: true, suppressMovable: true,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center' },
    },
    onGridReady: function(p) {
      setTimeout(() => { if (el.offsetWidth > 0) p.api.sizeColumnsToFit(); }, 50);
    },
  });
}

/** 현재 그리드에서 page_perms 객체 추출 — "접근불가"를 골랐어도 그 선택 자체를 명시적으로
 *  저장한다. 예전엔 접근불가면 저장 대상에서 빼서(=역할 기본값을 그대로 쓰라는 뜻으로
 *  취급) 두는 방식이었는데, 대부분의 페이지는 역할 기본값 자체가 접근불가라 결과가 같아서
 *  문제가 안 드러났었다. 그런데 admin 역할의 기본값이 접근불가가 아닌 페이지(예:
 *  committee/list, regulation/list, approval/history 등 admin:'admin'인 페이지)에서는,
 *  관리자 계정에게서 일부러 그 권한을 빼려고 접근불가를 선택해도 저장이 안 되고 역할
 *  기본값(admin)으로 그대로 폴백되어 계속 접근되는 문제가 있었다(실제로 겪음). 그래서
 *  선택값이 뭐든(접근불가 포함) 있는 그대로 저장한다. */
function getPagePermsFromGrid() {
  if (!_gridUserPerm) return {};
  const result = {};
  _gridUserPerm.forEachNode(function(node) {
    if (node.data.level) {
      result[node.data._key] = node.data.level;
    }
  });
  return result;
}

/** 일괄 적용 모달의 미리보기 그리드 — userPermGrid와 컬럼 구성은 같지만 항상 편집 가능하고
 *  대상이 여러 명이라 "역할 기본값 사용" 개념이 없다(늘 명시적 page_perms로 적용한다). */
function renderBulkPermBody(pagePerms) {
  let permMap = (pagePerms && typeof pagePerms === 'object') ? { ...pagePerms } : {};
  const rows = [];
  PAGE_GROUPS.forEach(group => {
    group.pages.forEach(p => {
      rows.push({ _key: p.key, app: group.app, label: p.label, note: p.note || '', level: permMap[p.key] || '접근불가' });
    });
  });

  const el = document.getElementById('bulkPermGrid');
  if (!el) return;

  const colDefs = [
    { headerName: '앱', field: 'app', width: 100,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'11px', color:'#6b7280', fontWeight:600 } },
    { headerName: '페이지', field: 'label', width: 140,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'12px' } },
    { headerName: '접근 권한', field: 'level', width: 140,
      editable: false,
      cellRenderer: function(p) {
        const sel = document.createElement('select');
        sel.style.cssText = 'width:100%;height:100%;padding:0 8px;border:none;border-radius:0;font-size:11px;font-weight:600;outline:none;cursor:pointer;background:transparent;box-sizing:border-box;';
        PERM_LEVELS.forEach(lv => {
          const opt = document.createElement('option');
          opt.value = lv; opt.textContent = lv;
          if (lv === (p.value || '접근불가')) opt.selected = true;
          sel.appendChild(opt);
        });
        sel.style.color = PERM_COLORS[p.value || '접근불가'] || '#6b7280';
        sel.addEventListener('change', function() {
          p.node.data.level = sel.value;
          sel.style.color = PERM_COLORS[sel.value] || '#6b7280';
          var scopeCell = sel.closest('.ag-row')?.querySelector('[col-id="scope"]');
          if (scopeCell) scopeCell.textContent = levelToScopeText(sel.value, p.node.data._key);
        });
        return sel;
      } },
    { headerName: '허용 범위', colId: 'scope', width: 230,
      valueGetter: function(p) { return levelToScopeText(p.data.level, p.data._key); },
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'11px', color:'#6b7280', whiteSpace:'normal', lineHeight:'1.3' } },
    { headerName: '설명', field: 'note', flex: 1,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', fontSize:'11px', color:'#9ca3af' } },
  ];

  if (_gridBulkPerm) { _gridBulkPerm.destroy(); _gridBulkPerm = null; el.innerHTML = ''; }

  _gridBulkPerm = agGrid.createGrid(el, {
    columnDefs: colDefs,
    rowData: rows,
    rowHeight: 34,
    headerHeight: 34,
    suppressCellFocus: true,
    stopEditingWhenCellsLoseFocus: true,
    singleClickEdit: false,
    defaultColDef: { sortable: false, resizable: true, suppressMovable: true, cellStyle: { display:'flex', alignItems:'center', justifyContent:'center' } },
    onGridReady: function(p) {
      setTimeout(() => { if (el.offsetWidth > 0) p.api.sizeColumnsToFit(); }, 50);
    },
  });
}

/** 일괄 적용 그리드에서 page_perms 추출 — 이 기능은 애초에 "역할 기본값 사용" 개념이
 *  없고 늘 명시적으로 적용하는 게 목적이라(위 renderBulkPermBody 설명 참고), 접근불가를
 *  뺴놓고 저장 안 하는 건 더더욱 이 기능의 취지와 안 맞는다 — userPermGrid 쪽과 같은
 *  이유로 선택값이 뭐든 그대로 저장한다. */
function getPagePermsFromBulkGrid() {
  if (!_gridBulkPerm) return {};
  const result = {};
  _gridBulkPerm.forEachNode(function(node) {
    if (node.data.level) result[node.data._key] = node.data.level;
  });
  return result;
}

/** 역할 select가 바뀌면 */
function onUserRoleChange() {
  const role = val('u_role') || 'user';
  document.getElementById('u_perm_roleLabel').textContent = role;
  if (document.getElementById('u_perm_useDefault')?.checked) {
    if (_gridUserPerm) { try { _gridUserPerm.destroy(); } catch(e) {} _gridUserPerm = null; }
    const _permEl = document.getElementById('userPermGrid');
    if (_permEl) _permEl.innerHTML = '';
    renderUserPermBody(ROLE_DEFAULT_PAGES[role] || {}, true);
  }
}
window.onUserRoleChange = onUserRoleChange;

/** "역할 기본값 사용" 토글 */
function onUserPermUseDefaultChange() {
  const useDefault = document.getElementById('u_perm_useDefault')?.checked;
  const role = val('u_role') || 'user';
  if (useDefault) {
    renderUserPermBody(ROLE_DEFAULT_PAGES[role] || {}, true);
  } else {
    // 직접 설정 모드 — 현재 그리드 상태 유지하되 편집 가능하게
    const cur = getPagePermsFromGrid();
    renderUserPermBody(cur, false);
  }
}
window.onUserPermUseDefaultChange = onUserPermUseDefaultChange;

/** 다른 사용자의 권한을 지금 편집 중인 그리드로 복사(저장은 별도로 눌러야 반영됨) */
function openCopyPermModal() {
  if (!editingUserId) return;
  const sel = document.getElementById('copyPermSourceSelect');
  if (!sel) return;
  sel.innerHTML = userCache
    .filter(function(u) { return u.id !== editingUserId; })
    .map(function(u) { return '<option value="' + u.id + '">' + ts(u.user_name || u.email) + '</option>'; }).join('');
  openModal('copyPermModal');
}

function confirmCopyPerm() {
  const sourceId = val('copyPermSourceSelect');
  const source = userCache.find(function(u) { return u.id === sourceId; });
  if (!source) { alert('복사할 사용자를 선택해주세요.'); return; }
  const useDefault = source.page_perms === null || source.page_perms === undefined;
  const perms = useDefault ? (ROLE_DEFAULT_PAGES[source.role] || {}) : source.page_perms;
  document.getElementById('u_perm_useDefault').checked = useDefault;
  if (_gridUserPerm) { try { _gridUserPerm.destroy(); } catch (e) {} _gridUserPerm = null; }
  const permEl = document.getElementById('userPermGrid');
  if (permEl) permEl.innerHTML = '';
  renderUserPermBody(perms, useDefault);
  closeModal('copyPermModal');
}

function openEditUser(id) {
  const row = userCache.find(r => r.id === id);
  if (!row) return;
  editingUserId = id;       // org_members.id
  editingUserUserId = row.user_id;  // auth.users.id (profiles 업데이트용)

  setVal('u_email',      row.email || '');
  setVal('u_user_name',  row.user_name);
  setVal('u_phone',      row.phone);
  setVal('u_role',       row.role);
  setVal('u_active',     row.active ? 'Y' : 'N');
  // '부서 (직접입력)' 필드는 org_members에 대응 컬럼이 없음 — 의원/부서 select로 대체됨
  const deptFreeTextField = document.getElementById('u_department')?.closest('.m-field');
  if (deptFreeTextField) deptFreeTextField.style.display = 'none';

  // 조직=의원이 항상 1:1이라 u_clinic_select는 늘 비활성화된 채 하나뿐인 의원으로 고정된다.
  // row.clinic_id가 비어있는 사용자(초대코드로 막 합류해 아직 의원 배정이 안 된 경우)를
  // fillClinicSelect에 그대로 null을 넘기면 select가 빈 값으로 리셋된 채 비활성화만 유지돼서,
  // 관리자가 고칠 수도 없고 저장해도 계속 null로 남는 문제가 있었다 — 항상 그 하나뿐인
  // 의원으로 기본 선택되도록 폴백을 둔다.
  const onlyClinicId = row.clinic_id || (clinicCache[0] && clinicCache[0].id) || null;
  fillClinicSelect('u_clinic_select', '선택 안 함', onlyClinicId);
  fillDeptSelect('u_dept_select', '선택 안 함', onlyClinicId, row.dept_id || null);
  fillPositionSelect('u_position_select', '선택 안 함', row.position_id || null);
  setVal('u_hire_date', row.hire_date || '');
  setVal('u_is_equipment_manager', row.is_equipment_manager ? 'Y' : 'N');
  setVal('u_is_signage_manager', row.is_signage_manager ? 'Y' : 'N');
  setVal('u_is_qc_manager', row.is_qc_manager ? 'Y' : 'N');

  // 앱 접근 권한 — page_perms가 비어있으면 역할 기본값 사용 모드
  const pagePerms = row.page_perms || null;
  const useDefault = pagePerms === null || pagePerms === undefined;
  document.getElementById('u_perm_useDefault').checked = useDefault;
  document.getElementById('u_perm_roleLabel').textContent = row.role || '-';
  if (_gridUserPerm) { try { _gridUserPerm.destroy(); } catch(e) {} _gridUserPerm = null; }
  const permEl = document.getElementById('userPermGrid');
  if (permEl) permEl.innerHTML = '';
  renderUserPermBody(useDefault ? (ROLE_DEFAULT_PAGES[row.role] || {}) : pagePerms, useDefault);

  document.getElementById('userModalTitle').textContent = '사용자 수정';
  openModal('userModal');
}
window.openEditUser = openEditUser;

async function saveUser() {
  if (!window.canManageOrg) throw new Error('사용자 정보를 수정할 권한이 없습니다.');
  const clinic_id = val('u_clinic_select') || null;
  const dept_id   = val('u_dept_select') || null;

  const useDefault = document.getElementById('u_perm_useDefault')?.checked;
  const role = val('u_role') || 'user';
  // "역할 기본값 사용"을 체크해도 null로 저장하면 안 된다 — DB단 has_page_level() 체크가
  // page_perms의 실제 값을 보고 판단하기 때문에, 기본값이어도 그 기본값 자체를 그대로 명시적으로
  // 채워 넣어야 서버 쪽 권한 검사가 정확히 동작한다(안 그러면 "기본값 사용"으로 저장한 사람은
  // DB 레벨에서 아무 권한도 없는 것처럼 취급되어 정상 기능까지 막힐 수 있음).
  const page_perms = useDefault ? (ROLE_DEFAULT_PAGES[role] || {}) : (getPagePermsFromGrid() || {});

  // profiles(전역 프로필)와 org_members(의원 내 소속 정보)는 별개 테이블이라 각각 업데이트한다.
  const { error: profileErr } = await supabaseClient
    .from('profiles')
    .update({ user_name: val('u_user_name'), phone: val('u_phone'), updated_at: new Date().toISOString() })
    .eq('id', editingUserUserId);
  if (profileErr) throw new Error(profileErr.message);

  const { error: memberErr } = await supabaseClient
    .from('org_members')
    .update({
      role: val('u_role'),
      clinic_id,
      dept_id,
      position_id: val('u_position_select') || null,
      hire_date: val('u_hire_date') || null,
      active: val('u_active') === 'Y',
      page_perms: page_perms,
      is_equipment_manager: val('u_is_equipment_manager') === 'Y',
      is_signage_manager: val('u_is_signage_manager') === 'Y',
      is_qc_manager: val('u_is_qc_manager') === 'Y',
    })
    .eq('id', editingUserId);
  if (memberErr) {
    if (memberErr.message.includes('one_real_admin_per_org')) {
      throw new Error('이 의원엔 이미 관리자(admin)가 있습니다. 의원당 관리자는 한 명만 지정할 수 있어요 — 기존 관리자를 먼저 user로 바꾼 뒤 다시 시도해주세요.');
    }
    throw new Error(memberErr.message);
  }
}

async function refreshUsers() {
  const rows = await loadUsers();
  const cc = document.getElementById('userClinicFilter')?.value || '';
  const dc = document.getElementById('userDeptFilter')?.value || '';
  renderUsers(rows, cc, dc);
}

/* ════════════════════════════════════════════
   초대코드 (org_invite_codes) — 이 의원 admin이 발급
════════════════════════════════════════════ */
function genInviteCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 0/O, 1/I 등 혼동 문자 제외
  const part = n => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return part(4) + '-' + part(4);
}

async function loadInviteCodes() {
  const { data, error } = await supabaseClient
    .from('org_invite_codes')
    .select('*')
    .eq('org_id', currentUser.org_id)
    .order('created_at', { ascending: false });
  if (error) { alert('초대코드 목록 로드 실패: ' + error.message); return []; }
  return data || [];
}

function renderInviteCodes(rows) {
  const tbody = document.getElementById('ic_list');
  if (!tbody) return;
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#9ca3af;padding:14px;">발급된 초대코드가 없습니다</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(iv => {
    const usable = iv.active && iv.used_count < iv.max_uses && (!iv.expires_at || iv.expires_at >= localDateStr(new Date()));
    const clinicName = clinicCache.find(c => c.id === iv.clinic_id)?.clinic_name || '-';
    return `<tr>
      <td style="padding:6px 8px;border-bottom:1px solid #f3f4f6;">
        <span class="ic-code-chip" data-code="${ts(iv.code)}" title="클릭하여 복사"
          style="font-family:monospace;font-weight:700;background:#f0f2f5;padding:2px 8px;border-radius:6px;cursor:pointer;">${ts(iv.code)}</span>
      </td>
      <td style="padding:6px 8px;border-bottom:1px solid #f3f4f6;">${ts(clinicName)}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #f3f4f6;">${ts(iv.role)}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #f3f4f6;">${iv.used_count} / ${iv.max_uses}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #f3f4f6;">${usable ? '<span style="color:#059669;font-weight:700;">사용가능</span>' : '<span style="color:#9ca3af;">종료</span>'}</td>
    </tr>`;
  }).join('');
  tbody.querySelectorAll('.ic-code-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      navigator.clipboard?.writeText(chip.dataset.code);
      const original = chip.textContent;
      chip.textContent = '복사됨!';
      setTimeout(() => { chip.textContent = original; }, 1000);
    });
  });
}

async function refreshInviteCodes() {
  renderInviteCodes(await loadInviteCodes());
}

/* ════════════════════════════════════════════
   저장 버튼 공통
════════════════════════════════════════════ */
function bindSaveBtn(btnId, saveFn, modalId, refreshFn, logInfo) {
  document.getElementById(btnId)?.addEventListener('click', async () => {
    const btn = document.getElementById(btnId);
    btn.disabled = true;
    try {
      await saveFn();
      closeModal(modalId);
      await refreshFn();
      if (logInfo) systemLog(logInfo.action, logInfo.label).catch(() => {});
    } catch (e) {
      alert('저장 실패: ' + e.message);
    } finally {
      btn.disabled = false;
    }
  });
}

/* ════════════════════════════════════════════
   필터 이벤트 바인딩
════════════════════════════════════════════ */
function initFilters() {
  // 부서 탭 — 의원 필터
  document.getElementById('deptClinicFilter')?.addEventListener('change', e => {
    renderDepts(deptCache, e.target.value || null);
  });

  // 사용자 탭 — 의원 필터
  document.getElementById('userClinicFilter')?.addEventListener('change', e => {
    syncDeptFilter();                        // 부서 필터 갱신
    setVal('userDeptFilter', '');           // 부서 필터 초기화
    const cc = e.target.value;
    renderUsers(userCache, cc, '');
  });

  // 사용자 탭 — 부서 필터
  document.getElementById('userDeptFilter')?.addEventListener('change', e => {
    const cc = document.getElementById('userClinicFilter')?.value || '';
    renderUsers(userCache, cc, e.target.value);
  });

  // 사용자 모달 — 의원 select → 부서 select 연동
  document.getElementById('u_clinic_select')?.addEventListener('change', onUserClinicSelectChange);
}

/* ════════════════════════════════════════════
   초기화
════════════════════════════════════════════ */
let isPlatformAdminUser = false;

async function init() {
  ['ic_expires', 'u_hire_date'].forEach(mountCustomDateInput);
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();
  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'master/org')) {
    alert('접근할 수 없습니다.');
    location.replace(CONFIG.SITE_BASE_URL + '/app.html');
    return;
  }
  // 페이지 진입은 접근불가만 아니면 누구나 가능하고, 실제 생성/수정/발급 같은 의원 관리
  // 액션은 이 레벨로 따로 막는다 (아래 canManageOrg를 각 버튼/폼 노출 여부에 사용).
  window.canManageOrg = window.PagePerms.atLeast(currentUser, 'master/org', 'admin');

  const { data: paFlag } = await supabaseClient.rpc('is_platform_admin');
  isPlatformAdminUser = !!paFlag;

  // 초대코드 발급은 의원 admin이 아니라 플랫폼 관리자만 가능하도록 제한
  // (org_invite_codes INSERT RLS 정책과 동일 기준으로 UI도 맞춤)
  const inviteBtn = document.getElementById('openInviteCodeBtn');
  if (inviteBtn) inviteBtn.style.display = isPlatformAdminUser ? '' : 'none';

  initTabs();
  initFilters();

  const addDeptBtn = document.getElementById('addDeptBtn');
  if (addDeptBtn) addDeptBtn.style.display = window.canManageOrg ? '' : 'none';
  addDeptBtn?.addEventListener('click', openAddDept);
  document.getElementById('d_clinic_id')?.addEventListener('change', function() {
    populateDeptManagerOptions(this.value, val('d_manager_id'));
  });

  const addPositionBtn = document.getElementById('addPositionBtn');
  if (addPositionBtn) addPositionBtn.style.display = window.canManageOrg ? '' : 'none';
  addPositionBtn?.addEventListener('click', openAddPosition);

  document.getElementById('openInviteCodeBtn')?.addEventListener('click', async () => {
    // 의원이 1개뿐이면 그 의원으로 기본 선택해두되(선택 수고를 덜어줌), 여러 개면 반드시
    // 직접 골라야 한다 — "일단 발급하고 나중에 관리자가 추측해서 배정"하던 예전 방식으로
    // 돌아가지 않기 위해 자동 폴백을 두지 않는다.
    fillClinicSelect('ic_clinic', '의원을 선택하세요', clinicCache.length === 1 ? clinicCache[0].id : null);
    openModal('inviteCodeModal');
    await refreshInviteCodes();
  });

  document.getElementById('ic_issue_btn')?.addEventListener('click', async function() {
    const clinicId = val('ic_clinic');
    if (!clinicId) { alert('소속 의원을 선택해 주세요.'); return; }
    this.disabled = true;
    try {
      const payload = {
        org_id: currentUser.org_id,
        clinic_id: clinicId,
        code: genInviteCode(),
        role: val('ic_role') || 'user',
        max_uses: Number(val('ic_max_uses')) || 1,
        expires_at: val('ic_expires') || null,
        created_by: currentUser.id,
      };
      const { error } = await supabaseClient.from('org_invite_codes').insert(payload);
      if (error) throw new Error(error.message);
      setVal('ic_max_uses', '1'); setVal('ic_expires', '');
      await refreshInviteCodes();
    } catch (e) {
      alert('발급 실패: ' + e.message);
    } finally {
      this.disabled = false;
    }
  });

  bindSaveBtn('deptSaveBtn',   saveDept,   'deptModal',   refreshDepts, { action: 'MASTER_DEPT_SAVE', label: '부서 정보 저장' });
  bindSaveBtn('positionSaveBtn', savePosition, 'positionModal', refreshPositions, { action: 'MASTER_POSITION_SAVE', label: '직책 정보 저장' });
  bindSaveBtn('userSaveBtn',   saveUser,   'userModal',   refreshUsers, { action: 'MASTER_USER_SAVE', label: '사용자 정보·권한 저장' });

  document.getElementById('bulkPermBtn')?.addEventListener('click', openBulkPermModal);
  document.getElementById('bulkPermConfirmBtn')?.addEventListener('click', confirmBulkPerm);
  document.querySelectorAll('input[name="bulkPermMode"]').forEach(function(r) {
    r.addEventListener('change', function() {
      document.getElementById('bulkPermRoleWrap').style.display = r.value === 'role' ? '' : 'none';
      document.getElementById('bulkPermUserWrap').style.display = r.value === 'user' ? '' : 'none';
      refreshBulkPermPreview();
    });
  });
  document.getElementById('bulkPermRoleSelect')?.addEventListener('change', refreshBulkPermPreview);
  document.getElementById('bulkPermUserSelect')?.addEventListener('change', refreshBulkPermPreview);

  document.getElementById('copyPermFromUserBtn')?.addEventListener('click', openCopyPermModal);
  document.getElementById('copyPermConfirmBtn')?.addEventListener('click', confirmCopyPerm);

  showGlobalLoading('데이터를 불러오는 중...');
  try {
    const [clinics, depts, positions, users] = await Promise.all([
      loadClinics(),
      loadDepts(),
      loadPositions(),
      loadUsers(),
    ]);
    // 순서 중요: clinic 먼저 → select 동기화 → dept/user 렌더
    renderClinics(clinics);   // clinicCache 세팅 + select 동기화
    renderDepts(depts, null); // deptCache 세팅 + 사용자 탭 부서 필터 동기화
    renderPositions(positions);
    renderUsers(users, '', '');
  } catch (e) {
    alert('초기화 실패: ' + e.message);
    console.error('[master/org]', e);
  } finally {
    hideGlobalLoading();
  }
}

document.addEventListener('DOMContentLoaded', init);