/**
 * assets/js/master/supply.js
 * 자재·거래처 관리 — vendors / items
 * admin role만 접근 가능
 */
'use strict';

let currentUser = null;
let editingVendorId = null;
let editingItemId   = null;
let editingCategoryId = null;
let editingResourceId = null;
let vendorCache = [];
let itemCache   = [];
let categoryCache = [];
let resourceCache = [];

/* ── 유틸 ─────────────────────────────────── */
function ts(v) {
  return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
function badgeActive(v) {
  return v === 'Y'
    ? '<span class="badge-active">활성</span>'
    : '<span class="badge-inactive">비활성</span>';
}
function fmtPrice(v) {
  if (v == null || v === '') return '-';
  return Number(v).toLocaleString('ko-KR') + '원';
}

/* ── 탭 ── */
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`tab-${target}`)?.classList.add('active');

      requestAnimationFrame(() => {
        const gridMap = { categories: '_categoryGrid', vendors: '_vendorGrid', items: '_itemGrid', resources: '_resGrid' };
        const g = window[gridMap[target]];
        if (g) fitGridColumnsPinned(g, g.getColumnDefs());
      });
    });
  });
}

/* ── 모달 ── */
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }
window.closeModal = closeModal;

/* ════════════════════════════════════════════
   자재구분 (item_categories)
════════════════════════════════════════════ */
async function loadCategories() {
  const { data, error } = await supabaseClient
    .from('item_categories')
    .select('*')
    .eq('org_id', currentUser.org_id)
    .order('sort_order', { ascending: true });
  if (error) throw new Error(error.message);
  return data || [];
}

function renderCategories(rows) {
  categoryCache = rows;
  const list  = document.getElementById('categoryList');
  const empty = document.getElementById('categoryEmpty');
  if (!list) return;

  if (empty) empty.style.display = 'none';

  if (!window._categoryGrid) {
    window._categoryGrid =
  createMgGrid('categoryList', [
      { headerName: '코드',     field: 'category_code', flex: 1, minWidth: 100 },
      { headerName: '구분명',   field: 'category_name', flex: 2, minWidth: 120 },
      { headerName: '정렬순서', field: 'sort_order',    flex: 0, width: 80 },
      { headerName: '상태',     field: 'active',        flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
      { headerName: '', flex: 0, width: 120, sortable: false,
        cellRenderer: p => {
          if (!window.canManageSupply) { const s = document.createElement('span'); s.textContent = '-'; return s; }
const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;align-items:center;';
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정'; e.onclick = () => openEditCategory(p.data.id);
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제'; d.onclick = () => deleteCategory(p.data.id);
          wrap.append(e, d); return wrap;
        }},
    ], rows, { fit: true, noRowsText: '등록된 자재구분이 없습니다.' });
  } else {
    updateMgGrid(window._categoryGrid, rows);
  }
  populateCategorySelect(rows);
}

/** 자재 등록/수정 모달의 자재구분 select 채우기 (활성 항목만) */
function populateCategorySelect(rows) {
  const sel = document.getElementById('i_category');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">자재구분 선택</option>' +
    rows.filter(r => r.active === 'Y')
        .map(r => `<option value="${ts(r.category_name)}">${ts(r.category_name)}</option>`).join('');
  if (cur) sel.value = cur;
}

function openAddCategory() {
  editingCategoryId = null;
  ['cat_category_code','cat_category_name'].forEach(id => setVal(id, ''));
  setVal('cat_sort_order', String((categoryCache.length || 0) + 1));
  setVal('cat_active', 'Y');
  document.getElementById('categoryModalTitle').textContent = '자재구분 추가';
  openModal('categoryModal');
}

function openEditCategory(id) {
  const row = categoryCache.find(r => r.id === id);
  if (!row) return;
  editingCategoryId = id;
  setVal('cat_category_code', row.category_code);
  setVal('cat_category_name', row.category_name);
  setVal('cat_sort_order',    row.sort_order ?? 0);
  setVal('cat_active',        row.active);
  document.getElementById('categoryModalTitle').textContent = '자재구분 수정';
  openModal('categoryModal');
}
window.openEditCategory = openEditCategory;

async function saveCategory() {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  const payload = {
    org_id: currentUser.org_id,
    category_code: editingCategoryId ? val('cat_category_code') : await (async () => {
      const { data } = await supabaseClient.rpc('generate_category_code', { p_org_id: currentUser.org_id });
      return data || 'CAT-' + Date.now().toString().slice(-6);
    })(),
    category_name: val('cat_category_name'),
    sort_order:    Number(val('cat_sort_order') || 0),
    active:        val('cat_active'),
    updated_at:    new Date().toISOString(),
  };
  // category_code는 자동생성
  if (!payload.category_name) throw new Error('구분명은 필수입니다.');

  if (editingCategoryId) {
    // 구분명이 바뀌면 items.category_fkey의 ON UPDATE CASCADE가 연결된 자재들을 자동으로 맞춰줍니다.
    const { error } = await supabaseClient.from('item_categories').update(payload).eq('id', editingCategoryId);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabaseClient.from('item_categories').insert(payload);
    if (error) throw new Error(error.message);
  }
}

async function deleteCategory(id) {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  const row = categoryCache.find(r => r.id === id);
  if (!row) return;
  const { count } = await supabaseClient
    .from('items').select('id', { count: 'exact', head: true }).eq('org_id', currentUser.org_id).eq('category', row.category_name);
  if (count > 0) { alert('이 구분을 사용 중인 자재가 ' + count + '건 있어 삭제할 수 없습니다.\n먼저 자재의 구분을 변경해주세요.'); return; }
  if (!confirm('자재구분을 삭제하시겠습니까?')) return;
  const { error } = await supabaseClient.from('item_categories').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  await refreshCategories();
}
window.deleteCategory = deleteCategory;

async function refreshCategories() {
  const rows = await loadCategories();
  renderCategories(rows);
}

/* ════════════════════════════════════════════
   거래처 (vendors)
════════════════════════════════════════════ */
async function loadVendors() {
  const { data } = await fetchAllRows(() => supabaseClient
    .from('vendors')
    .select('*', { count: 'exact' })
    .eq('org_id', currentUser.org_id)
    .order('vendor_name', { ascending: true }));
  return data || [];
}

function renderVendors(rows) {
  vendorCache = rows;
  const list  = document.getElementById('vendorList');
  const empty = document.getElementById('vendorEmpty');
  if (!list) return;

  if (empty) empty.style.display = 'none';

  if (!window._vendorGrid) {
    window._vendorGrid =
  createMgGrid('vendorList', [
      { headerName: '코드',     field: 'vendor_code', flex: 1, minWidth: 90 },
      { headerName: '거래처명', field: 'vendor_name', flex: 2, minWidth: 120,
        cellRenderer: p => ts(p.value) + (p.data.is_current !== 'Y' ? ' <span style="font-size:10px;color:#b45309;background:#fef3c7;padding:1px 6px;border-radius:999px;margin-left:4px;">구 상호</span>' : '') },
      { headerName: '사업자번호', field: 'biz_no',   flex: 1, minWidth: 110, valueFormatter: p => p.value || '-' },
      { headerName: '대표자',   field: 'ceo_name',   flex: 1, minWidth: 80,  valueFormatter: p => p.value || '-' },
      { headerName: '전화',     field: 'phone',      flex: 1, minWidth: 110, valueFormatter: p => p.value || '-' },
      { headerName: '이메일',   field: 'email',      flex: 1.2, minWidth: 140, valueFormatter: p => p.value || '-' },
      { headerName: '여신일자', field: 'credit_terms', flex: 1, minWidth: 100, valueFormatter: p => p.value || '-' },
      { headerName: '계좌정보', field: 'bank_name', flex: 1.4, minWidth: 150,
        valueGetter: p => (p.data.bank_name || p.data.account_number)
          ? [p.data.bank_name, p.data.account_number].filter(Boolean).join(' ') : '',
        valueFormatter: p => p.value || '-' },
      { headerName: '상태',     field: 'active',     flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
      { headerName: '', flex: 0, width: 120, sortable: false,
        cellRenderer: p => {
          if (!window.canManageSupply) { const s = document.createElement('span'); s.textContent = '-'; return s; }
const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;align-items:center;';
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정'; e.onclick = () => openEditVendor(p.data.id);
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제'; d.onclick = () => deleteVendor(p.data.id);
          wrap.append(e, d); return wrap;
        }},
    ], rows, { fit: true, noRowsText: '등록된 거래처가 없습니다.' });
  } else {
    updateMgGrid(window._vendorGrid, rows);
  }
  populateVendorSelect(rows);
}

function populateVendorSelect(vendors) {
  const sel = document.getElementById('i_vendor_id');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">선택 안 함</option>' +
    vendors.map(v => `<option value="${v.id}">${ts(v.vendor_name)}</option>`).join('');
  if (cur) sel.value = cur;
}

function openAddVendor() {
  editingVendorId = null;
  ['v_vendor_code','v_vendor_name','v_biz_no','v_ceo_name',
   'v_phone','v_email','v_address','v_credit_terms','v_bank_name','v_account_number','v_memo'].forEach(id => setVal(id, ''));
  setVal('v_active', 'Y');
  document.getElementById('vendorModalTitle').textContent = '거래처 추가';
  openModal('vendorModal');
}

function openEditVendor(id) {
  const row = vendorCache.find(r => r.id === id);
  if (!row) return;
  editingVendorId = id;
  setVal('v_vendor_code', row.vendor_code);
  setVal('v_vendor_name', row.vendor_name);
  setVal('v_biz_no',      row.biz_no);
  setVal('v_ceo_name',    row.ceo_name);
  setVal('v_phone',       row.phone);
  setVal('v_email',       row.email);
  setVal('v_address',     row.address);
  setVal('v_credit_terms', row.credit_terms);
  setVal('v_bank_name',    row.bank_name);
  setVal('v_account_number', row.account_number);
  setVal('v_memo',        row.memo);
  setVal('v_active',      row.active);
  document.getElementById('vendorModalTitle').textContent = '거래처 수정';
  openModal('vendorModal');
}
window.openEditVendor = openEditVendor;

async function saveVendor() {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  const payload = {
    org_id: currentUser.org_id,
    vendor_code: editingVendorId ? val('v_vendor_code') : await (async () => {
      const { data } = await supabaseClient.rpc('generate_vendor_code', { p_org_id: currentUser.org_id });
      return data || 'VEND-' + Date.now().toString().slice(-6);
    })(),
    vendor_name: val('v_vendor_name'),
    biz_no:      val('v_biz_no'),
    ceo_name:    val('v_ceo_name'),
    phone:       val('v_phone'),
    email:       val('v_email'),
    address:     val('v_address'),
    credit_terms: val('v_credit_terms'),
    bank_name:    val('v_bank_name'),
    account_number: val('v_account_number'),
    memo:        val('v_memo'),
    active:      val('v_active'),
    updated_at:  new Date().toISOString(),
  };
  // vendor_code는 자동생성
  if (!payload.vendor_name) throw new Error('거래처명은 필수입니다.');

  if (editingVendorId) {
    const { error } = await supabaseClient.from('vendors').update(payload).eq('id', editingVendorId);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabaseClient.from('vendors').insert(payload);
    if (error) throw new Error(error.message);
  }
}

async function deleteVendor(id) {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  if (!confirm('거래처를 삭제하시겠습니까?\n연결된 자재가 있으면 삭제되지 않습니다.')) return;
  const { error } = await supabaseClient.from('vendors').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  await refreshVendors();
}
window.deleteVendor = deleteVendor;

async function refreshVendors() {
  const rows = await loadVendors();
  renderVendors(rows);
}

/* ════════════════════════════════════════════
   자재 (items)
════════════════════════════════════════════ */
async function loadItems() {
  const { data } = await fetchAllRows(() => supabaseClient
    .from('items')
    .select('*, vendors(vendor_name)', { count: 'exact' })
    .eq('org_id', currentUser.org_id)
    .order('item_name', { ascending: true }));
  return data || [];
}

function renderItems(rows) {
  itemCache = rows;
  const list  = document.getElementById('itemList');
  const empty = document.getElementById('itemEmpty');
  if (!list) return;

  if (empty) empty.style.display = 'none';

  if (!window._itemGrid) {
    window._itemGrid =
  createMgGrid('itemList', [
      { headerName: '코드',   field: 'item_code',  flex: 1, minWidth: 90 },
      { headerName: '자재명', field: 'item_name',  flex: 2, minWidth: 120 },
      { headerName: '카테고리', field: 'category', flex: 1, minWidth: 90,  valueFormatter: p => p.value || '-' },
      { headerName: '입고단위', field: 'purchase_unit', flex: 0, width: 80, valueFormatter: p => p.value || '-' },
      { headerName: '사용단위', field: 'use_unit',    flex: 0, width: 80, valueFormatter: p => p.value || '-' },
      { headerName: '환산',    field: 'purchase_unit_qty', flex: 0, width: 55, valueFormatter: p => p.value != null ? p.value : 1 },
      { headerName: '규격',   field: 'spec',       flex: 1, minWidth: 90,  valueFormatter: p => p.value || '-' },
      { headerName: '기준단가', field: 'standard_price', flex: 1, minWidth: 90,
        valueFormatter: p => fmtPrice(p.value) },
      { headerName: '거래처', flex: 1, minWidth: 100,
        valueGetter: p => p.data.vendors?.vendor_name || '-' },
      { headerName: '상태',   field: 'active',     flex: 0, width: 70,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = badgeActive(p.value); return s; } },
      { headerName: '', flex: 0, width: 120, sortable: false,
        cellRenderer: p => {
          if (!window.canManageSupply) { const s = document.createElement('span'); s.textContent = '-'; return s; }
const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;align-items:center;';
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정'; e.onclick = () => openEditItem(p.data.id);
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제'; d.onclick = () => deleteItem(p.data.id);
          wrap.append(e, d); return wrap;
        }},
    ], rows, { fit: true, noRowsText: '등록된 자재가 없습니다.' });
  } else {
    updateMgGrid(window._itemGrid, rows);
  }
}

function openAddItem() {
  editingItemId = null;
  ['i_item_code','i_item_name','i_category','i_spec','i_purchase_unit','i_use_unit','i_memo'].forEach(id => setVal(id, ''));
  setVal('i_purchase_unit_qty', '1');
  setVal('i_reorder_point', '');
  setVal('i_safety_stock', '');
  setVal('i_standard_price', '');
  setVal('i_vendor_id', '');
  setVal('i_active', 'Y');
  document.getElementById('itemModalTitle').textContent = '자재 추가';
  openModal('itemModal');
}

function openEditItem(id) {
  const row = itemCache.find(r => r.id === id);
  if (!row) return;
  editingItemId = id;
  setVal('i_item_code',       row.item_code);
  setVal('i_item_name',       row.item_name);
  setVal('i_category',        row.category);
  setVal('i_purchase_unit',     row.purchase_unit);
  setVal('i_purchase_unit_qty', row.purchase_unit_qty ?? 1);
  setVal('i_use_unit',          row.use_unit);
  setVal('i_reorder_point',     row.reorder_point ?? '');
  setVal('i_safety_stock',      row.safety_stock ?? '');
  setVal('i_spec',            row.spec);
  setVal('i_standard_price',  row.standard_price ?? '');
  setVal('i_vendor_id',       row.vendor_id || '');
  setVal('i_memo',            row.memo);
  setVal('i_active',          row.active);
  document.getElementById('itemModalTitle').textContent = '자재 수정';
  openModal('itemModal');
}
window.openEditItem = openEditItem;

async function saveItem() {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  const priceStr = val('i_standard_price');
  const payload = {
    org_id: currentUser.org_id,
    item_code:      editingItemId ? val('i_item_code') : await (async () => {
      var { data } = await supabaseClient.rpc('generate_item_code', { p_org_id: currentUser.org_id });
      return data || 'ITEM-' + Date.now().toString().slice(-6);
    })(),
    item_name:      val('i_item_name'),
    category:       val('i_category'),
    purchase_unit:     val('i_purchase_unit'),
    purchase_unit_qty: Number(val('i_purchase_unit_qty') || 1),
    use_unit:          val('i_use_unit'),
    reorder_point:     val('i_reorder_point') !== '' ? Number(val('i_reorder_point')) : null,
    safety_stock:      val('i_safety_stock')  !== '' ? Number(val('i_safety_stock'))  : null,
    spec:           val('i_spec'),
    standard_price: priceStr !== '' ? Number(priceStr) : null,
    vendor_id:      val('i_vendor_id') || null,
    memo:           val('i_memo'),
    active:         val('i_active'),
    updated_at:     new Date().toISOString(),
  };
  // item_code는 자동생성
  if (!payload.item_name) throw new Error('자재명은 필수입니다.');
  if (!payload.category)  throw new Error('자재구분은 필수입니다.');
  if (!payload.purchase_unit) throw new Error('입고 단위는 필수입니다.');
  if (!payload.use_unit)      throw new Error('사용(출고) 단위는 필수입니다.');
  if (!payload.purchase_unit_qty || payload.purchase_unit_qty < 1) throw new Error('환산수는 1 이상이어야 합니다.');

  if (editingItemId) {
    const { error } = await supabaseClient.from('items').update(payload).eq('id', editingItemId);
    if (error) throw new Error(error.message);
  } else {
    const { error } = await supabaseClient.from('items').insert(payload);
    if (error) throw new Error(error.message);
  }
}

async function deleteItem(id) {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  if (!confirm('자재를 삭제하시겠습니까?')) return;
  const { error } = await supabaseClient.from('items').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  await refreshItems();
}
window.deleteItem = deleteItem;

async function refreshItems() {
  const rows = await loadItems();
  renderItems(rows);
}

/* ════════════════════════════════════════════
   저장 버튼 공통
════════════════════════════════════════════ */
function bindSaveBtn(btnId, saveFn, modalId, refreshFn, logInfo) {
  document.getElementById(btnId)?.addEventListener('click', async () => {
    const btn = document.getElementById(btnId);
    btn.disabled = true;
    try {
      await saveFn();
      closeModal(modalId);
      await refreshFn();
      if (logInfo) systemLog(logInfo.action, logInfo.label).catch(() => {});
    } catch (e) {
      alert('저장 실패: ' + e.message);
    } finally {
      btn.disabled = false;
    }
  });
}

/* ════════════════════════════════════════════
   자원 (resources — 회의실·차량. 실제 예약은 업무일정 관리 > 자원예약에서)
════════════════════════════════════════════ */
const RES_TYPE_LABEL = { room: '회의실', vehicle: '차량' };

async function loadResources() {
  const typeFilter = document.getElementById('resTypeFilter')?.value || '';
  let q = supabaseClient.from('resources').select('*')
    .eq('org_id', currentUser.org_id).order('type').order('name');
  if (typeFilter) q = q.eq('type', typeFilter);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return data || [];
}

function renderResources(rows) {
  resourceCache = rows;
  const list  = document.getElementById('resList');
  const empty = document.getElementById('resEmpty');
  if (!list) return;
  if (empty) empty.style.display = 'none';

  if (!window._resGrid) {
    window._resGrid =
  createMgGrid('resList', [
      { headerName: '유형', field: 'type', flex: 0, width: 90,
        cellRenderer: p => { const s = document.createElement('span'); s.textContent = RES_TYPE_LABEL[p.value] || p.value; return s; } },
      { headerName: '이름', field: 'name', flex: 2, minWidth: 140 },
      { headerName: '상세', field: 'detail', flex: 2, minWidth: 140,
        cellRenderer: p => { const s = document.createElement('span'); s.textContent = p.value || '-'; return s; } },
      { headerName: '수용인원', field: 'capacity', flex: 0, width: 90,
        cellRenderer: p => { const s = document.createElement('span'); s.textContent = p.data.type === 'room' ? (p.value ?? '-') : '-'; return s; } },
      { headerName: '상태', field: 'active', flex: 0, width: 90,
        cellRenderer: p => { const s = document.createElement('span'); s.innerHTML = p.value ? '<span class="badge-active">사용 중</span>' : '<span class="badge-inactive">사용 안 함</span>'; return s; } },
      { headerName: '', flex: 0, width: 120, sortable: false,
        cellRenderer: p => {
          if (!window.canManageSupply) { const s = document.createElement('span'); s.textContent = '-'; return s; }
          const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;gap:4px;align-items:center;';
          const e = document.createElement('button'); e.className = 'btn btn-sm'; e.textContent = '수정'; e.onclick = () => openEditResource(p.data.id);
          const d = document.createElement('button'); d.className = 'btn btn-sm btn-danger'; d.textContent = '삭제'; d.onclick = () => deleteResource(p.data.id);
          wrap.append(e, d); return wrap;
        }},
    ], rows, { fit: true, noRowsText: '등록된 자원이 없습니다.' });
  } else {
    updateMgGrid(window._resGrid, rows);
  }
}

async function refreshResources() { renderResources(await loadResources()); }

function toggleResCapacityField() {
  const wrap = document.getElementById('rf_capacity_wrap');
  if (wrap) wrap.style.display = val('rf_type') === 'room' ? '' : 'none';
}

function openAddResource() {
  editingResourceId = null;
  setVal('rf_type', 'room');
  setVal('rf_name', '');
  setVal('rf_detail', '');
  setVal('rf_capacity', '');
  setVal('rf_active', 'true');
  toggleResCapacityField();
  document.getElementById('resModalTitle').textContent = '자원 등록';
  openModal('resModal');
}

function openEditResource(id) {
  const row = resourceCache.find(r => r.id === id);
  if (!row) return;
  editingResourceId = id;
  setVal('rf_type', row.type);
  setVal('rf_name', row.name);
  setVal('rf_detail', row.detail || '');
  setVal('rf_capacity', row.capacity || '');
  setVal('rf_active', String(row.active));
  toggleResCapacityField();
  document.getElementById('resModalTitle').textContent = '자원 수정';
  openModal('resModal');
}
window.openEditResource = openEditResource;

async function saveResource() {
  if (!window.canManageSupply) throw new Error('권한이 없습니다.');
  const name = val('rf_name');
  if (!name) { alert('이름을 입력해주세요.'); return; }
  const type = val('rf_type');
  const payload = {
    org_id: currentUser.org_id,
    type,
    name,
    detail: val('rf_detail') || null,
    capacity: type === 'room' && val('rf_capacity') ? Number(val('rf_capacity')) : null,
    active: document.getElementById('rf_active').value === 'true',
  };
  const res = editingResourceId
    ? await supabaseClient.from('resources').update(payload).eq('id', editingResourceId)
    : await supabaseClient.from('resources').insert(payload);
  if (res.error) throw new Error(res.error.message);
  systemLog(editingResourceId ? 'RESOURCE_UPDATE' : 'RESOURCE_CREATE',
    (RES_TYPE_LABEL[type] || type) + ' ' + (editingResourceId ? '수정' : '등록') + ': ' + name,
    { target_type:'resource', target_id: editingResourceId || '' }).catch(() => {});
}

async function deleteResource(id) {
  if (!window.canManageSupply) { alert('권한이 없습니다.'); return; }
  if (!confirm('이 자원을 삭제하시겠습니까? 관련된 예약 내역도 함께 삭제됩니다.')) return;
  const { error } = await supabaseClient.from('resources').delete().eq('id', id);
  if (error) { alert('삭제 실패: ' + error.message); return; }
  systemLog('RESOURCE_DELETE', '자원 삭제', { target_type:'resource', target_id: id }).catch(() => {});
  await refreshResources();
}

/* ════════════════════════════════════════════
   초기화
════════════════════════════════════════════ */
async function init() {
  const session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();
  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'master/supply')) {
    alert('접근할 수 없습니다.');
    location.replace(CONFIG.SITE_BASE_URL + '/app.html');
    return;
  }
  // 페이지 진입은 접근불가만 아니면 누구나 가능하고, 실제 등록/수정 액션은 이 레벨로 따로 막는다.
  window.canManageSupply = window.PagePerms.atLeast(currentUser, 'master/supply', 'admin');

  initTabs();

  document.getElementById('addCategoryBtn')?.addEventListener('click', openAddCategory);
  document.getElementById('addVendorBtn')?.addEventListener('click', openAddVendor);
  document.getElementById('addItemBtn')?.addEventListener('click', openAddItem);
  document.getElementById('resAddBtn')?.addEventListener('click', openAddResource);
  document.getElementById('resTypeFilter')?.addEventListener('change', refreshResources);
  document.getElementById('rf_type')?.addEventListener('change', toggleResCapacityField);
  if (!window.canManageSupply) {
    ['addCategoryBtn', 'addVendorBtn', 'addItemBtn', 'resAddBtn'].forEach(id => {
      const btn = document.getElementById(id);
      if (btn) btn.style.display = 'none';
    });
  }

  bindSaveBtn('categorySaveBtn', saveCategory, 'categoryModal', async () => {
    await refreshCategories();
    await refreshItems(); // 구분명이 바뀐 경우를 반영
  }, { action: 'MASTER_CATEGORY_SAVE', label: '자재 구분 저장' });
  bindSaveBtn('vendorSaveBtn', saveVendor, 'vendorModal', refreshVendors, { action: 'MASTER_VENDOR_SAVE', label: '거래처 정보 저장' });
  bindSaveBtn('itemSaveBtn',   saveItem,   'itemModal',   refreshItems, { action: 'MASTER_ITEM_SAVE', label: '자재 코드 저장' });
  bindSaveBtn('resSaveBtn',    saveResource, 'resModal',  refreshResources, { action: 'MASTER_RESOURCE_SAVE', label: '자원 저장' });

  showGlobalLoading('데이터를 불러오는 중...');
  // 각 탭을 서로 독립적으로 로드한다 — 예전엔 거래처/자재코드/자원을 Promise.all로 묶어서,
  // 셋 중 하나만 실패해도 나머지 전부(그리드 자체를) 못 그리는 상태가 됐었다(자원 탭이
  // 새로 생긴 거라 유독 눈에 띄었지만, 실제로는 거래처·자재코드도 같이 흔들릴 수 있는 구조였음).
  const sections = [
    { name: '자재구분', load: loadCategories, render: renderCategories },
    { name: '거래처',   load: loadVendors,    render: renderVendors },
    { name: '자재코드', load: loadItems,      render: renderItems },
    { name: '자원',     load: loadResources,  render: renderResources },
  ];
  for (const s of sections) {
    try {
      s.render(await s.load());
    } catch (e) {
      console.error('[master/supply] ' + s.name + ' 로드 실패:', e);
      alert(s.name + ' 목록을 불러오지 못했습니다: ' + e.message);
    }
  }
  hideGlobalLoading();
}

document.addEventListener('DOMContentLoaded', init);

async function genDocNo(prefix) {
  var year = new Date().getFullYear();
  var { data, error } = await supabaseClient.rpc('next_doc_seq', { p_org_id: currentUser.org_id, p_prefix: prefix, p_year: year });
  if (error || data == null) return prefix + '-' + year + '-' + Date.now().toString().slice(-6);
  return prefix + '-' + year + '-' + String(data).padStart(6, '0');
}