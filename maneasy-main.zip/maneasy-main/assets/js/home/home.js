'use strict';

var DAYS = ['일','월','화','수','목','금','토'];
var STATUS_BADGE = { REQUESTED:'badge-requested', PROCESSING:'badge-processing', COMPLETED:'badge-completed', REJECTED:'badge-rejected', CANCELLED:'badge-cancelled' };
var STATUS_LABEL = { REQUESTED:'접수', PROCESSING:'진행중', COMPLETED:'완료', REJECTED:'반려', CANCELLED:'취소' };
var MAX_FAV = 6;

// 즐겨찾기 가능한 전체 페이지 목록 — core/pages.js(PageRegistry)에서 파생된다.
// 새 페이지를 추가할 땐 이 파일이 아니라 pages.js의 GROUPS에 등록한다.
var ALL_PAGES = window.PageRegistry.buildFavoritePages();

var currentUser = null;
var userFavorites = []; // page key 배열
var allowedPageKeys = [];
var tempSelected = [];

function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

/* ── 시계 + 시간대별 인사문구 ── */
// 시간대 경계는 순서대로 확인 — 새벽(0~5), 아침(5~11), 점심(11~14), 오후(14~18), 저녁(18~22), 밤(22~24)
var GREETING_RANGES = [
  { from: 0,  to: 5,  text: '늦은 시간까지 고생 많으세요', emoji: '🌙' },
  { from: 5,  to: 9,  text: '좋은 아침이에요',            emoji: '🌅' },
  { from: 9,  to: 11, text: '활기찬 오전 보내세요',        emoji: '☀️' },
  { from: 11, to: 14, text: '점심 맛있게 드세요',          emoji: '🍚' },
  { from: 14, to: 18, text: '오늘도 힘내세요',             emoji: '💪' },
  { from: 18, to: 22, text: '오늘 하루도 고생 많으셨어요',  emoji: '🌆' },
  { from: 22, to: 24, text: '늦은 시간까지 고생 많으세요', emoji: '🌙' },
];
function getGreeting(hour) {
  var r = GREETING_RANGES.find(function(r) { return hour >= r.from && hour < r.to; });
  return r || GREETING_RANGES[0];
}

/* ── 날씨 (Open-Meteo — 무료, API 키 불필요) ──
 * 브라우저 위치 권한을 받아서 현재 위치의 날씨를 가져오고, 비/눈/천둥 등일 때만
 * 짧은 챙길 것 문구를 인사말 뒤에 붙인다. 권한 거부/실패 시에는 그냥 시간대 인사말만 보여준다
 * (날씨는 부가 정보라 실패해도 화면에 에러를 노출하지 않는다). */
var _weatherTip = ''; // 날씨 조회 성공 시 "비 소식이 있어요, 우산 챙기세요 ☔" 형태로 채워짐 (기온은 시계 쪽에 별도 표시)

function weatherAdviceTip(code, temp) {
  if ([95, 96, 99].indexOf(code) !== -1) return '천둥·번개가 예상돼요, 외출 시 주의하세요 ⛈️';
  if ([71, 73, 75, 77, 85, 86].indexOf(code) !== -1) return '눈이 내려요, 빙판길 조심하세요 ❄️';
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].indexOf(code) !== -1) return '비 소식이 있어요, 우산 챙기세요 ☔';
  if ([45, 48].indexOf(code) !== -1) return '안개가 껴 있어요, 시야 확보에 주의하세요 🌫️';
  if (temp >= 30) return '무더운 날씨예요, 더위 조심하세요 🥵';
  if (temp <= 0) return '쌀쌀해요, 따뜻하게 입으세요 🧥';
  return null; // 특별히 챙길 게 없는 평범한 날씨 — 인사말 줄엔 아무것도 안 붙인다
}

var WEATHER_TEMP_ICON = { clear:'ti-sun', cloudy:'ti-cloud', rain:'ti-cloud-rain', snow:'ti-snowflake', thunder:'ti-bolt', fog:'ti-cloud-fog' };
function renderTempDisplay(temp, category) {
  var el = document.getElementById('homeTemp');
  if (!el) return;
  var icon = WEATHER_TEMP_ICON[category] || 'ti-temperature';
  el.innerHTML = '<i class="ti ' + icon + '"></i>' + Math.round(temp) + '°C';
  el.classList.add('is-visible');
}

/** weather_code(WMO) → 배너 효과 카테고리. 코드 표는 Open-Meteo 문서 기준. */
function weatherCategory(code) {
  if ([95, 96, 99].indexOf(code) !== -1) return 'thunder';
  if ([71, 73, 75, 77, 85, 86].indexOf(code) !== -1) return 'snow';
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].indexOf(code) !== -1) return 'rain';
  if ([45, 48].indexOf(code) !== -1) return 'fog';
  if ([1, 2, 3].indexOf(code) !== -1) return 'cloudy';
  return 'clear'; // code 0
}

/** 랜덤 범위 헬퍼 — 파티클 위치/속도/지연을 흩뿌리는 용도. */
function rnd(min, max) { return min + Math.random() * (max - min); }

/** 배너 뒤에 깔리는 은은한 날씨 연출. 텍스트를 가리지 않도록 z-index를 배너보다 낮게 두고
 *  (.home-banner-fx가 z-index:1, 텍스트 쪽은 z-index:2), 파티클 개수도 적게 유지해서
 *  과하지 않게 — 어디까지나 부가 연출이라 성능/가독성을 해치면 안 된다. */
function renderWeatherFx(category) {
  var el = document.getElementById('homeWeatherFx');
  if (!el) return;
  var html = '';

  if (category === 'rain' || category === 'thunder') {
    for (var i = 0; i < 26; i++) {
      var left = rnd(0, 100), dur = rnd(0.5, 1.0), delay = rnd(0, 2);
      html += '<div class="wfx-drop" style="left:' + left + '%;animation-duration:' + dur + 's;animation-delay:' + delay + 's;"></div>';
    }
    if (category === 'thunder') html += '<div class="wfx-flash-layer"></div>';
  } else if (category === 'snow') {
    for (var j = 0; j < 22; j++) {
      var sLeft = rnd(0, 100), sSize = rnd(3, 7), sDur = rnd(4, 7), sDelay = rnd(0, 4);
      html += '<div class="wfx-flake" style="left:' + sLeft + '%;width:' + sSize + 'px;height:' + sSize + 'px;animation-duration:' + sDur + 's;animation-delay:' + sDelay + 's;"></div>';
    }
  } else if (category === 'clear') {
    html += '<div class="wfx-sun-glow"></div>';
  } else if (category === 'cloudy') {
    for (var k = 0; k < 3; k++) {
      html += '<div class="wfx-cloud" style="top:' + (10 + k * 22) + 'px;animation-duration:' + (18 + k * 6) + 's;animation-delay:' + (-k * 6) + 's;"></div>';
    }
  } else if (category === 'fog') {
    for (var m = 0; m < 3; m++) {
      html += '<div class="wfx-fog-band" style="top:' + (8 + m * 20) + 'px;animation-duration:' + (14 + m * 5) + 's;animation-delay:' + (-m * 5) + 's;"></div>';
    }
  }
  el.innerHTML = html;
}

function loadWeather() {
  var retryBtn = document.getElementById('homeWeatherRetryBtn');
  if (!('geolocation' in navigator)) return;
  navigator.geolocation.getCurrentPosition(
    async function(pos) {
      try {
        var lat = pos.coords.latitude, lon = pos.coords.longitude;
        var url = 'https://api.open-meteo.com/v1/forecast?latitude=' + lat + '&longitude=' + lon +
          '&current=temperature_2m,weather_code&timezone=auto';
        var res = await fetch(url);
        if (!res.ok) return;
        var data = await res.json();
        var cur = data && data.current;
        if (!cur) return;
        var category = weatherCategory(cur.weather_code);
        _weatherTip = weatherAdviceTip(cur.weather_code, cur.temperature_2m);
        renderGreeting(); // 팁 도착 즉시 인사문구 갱신 — 다음 정시까지 기다릴 필요 없다
        renderTempDisplay(cur.temperature_2m, category);
        renderWeatherFx(category);
        if (retryBtn) retryBtn.classList.remove('is-visible'); // 성공했으니 재시도 버튼은 더 이상 필요 없음
      } catch (e) {
        console.warn('[home] 날씨 조회 실패:', e); // 부가 정보라 사용자에게는 알리지 않는다
      }
    },
    function(err) {
      // 위치 권한 거부/실패 — 조용히 무시하고 시간대 인사말만 표시하되,
      // "나중에 다시 허용하고 싶은 경우"를 위해 재시도 버튼을 보여준다.
      if (retryBtn) retryBtn.classList.add('is-visible');
    },
    { timeout: 8000, maximumAge: 10 * 60 * 1000 } // 10분 내 캐시된 위치는 재사용
  );
}

/** 위치 권한을 처음에 거부했다가 나중에 브라우저 설정에서 허용을 바꾼 뒤 다시 시도하는 버튼.
 *  브라우저는 한 번 거부된 권한을 JS로 다시 강제 요청할 수 없으므로(네이티브 프롬프트가 다시
 *  뜨지 않음), 버튼을 누르면 getCurrentPosition을 다시 호출해서 그 사이 사용자가 브라우저
 *  설정에서 권한을 바꿨는지 확인하는 방식으로 동작한다. */
function retryWeather() {
  var label = document.getElementById('homeWeatherRetryLabel');
  var btn = document.getElementById('homeWeatherRetryBtn');
  if (label) label.textContent = '조회 중...';
  if (btn) btn.style.pointerEvents = 'none';
  navigator.permissions?.query({ name: 'geolocation' }).then(function(status) {
    if (status.state === 'denied' && label) {
      // 여전히 브라우저 자체에서 차단된 상태 — getCurrentPosition을 불러봐야 같은 결과라
      // 브라우저 설정을 바꿔야 한다는 안내로 대신한다.
      label.textContent = '브라우저 설정에서 위치 권한을 허용해주세요';
      if (btn) btn.style.pointerEvents = '';
      setTimeout(function() { if (label) label.textContent = '날씨 정보 보기'; }, 4000);
      return;
    }
    loadWeather();
    setTimeout(function() {
      if (btn) btn.style.pointerEvents = '';
      if (label && label.textContent === '조회 중...') label.textContent = '날씨 정보 보기';
    }, 3000);
  }).catch(function() {
    // Permissions API 미지원 브라우저 — 그냥 바로 시도
    loadWeather();
    setTimeout(function() {
      if (btn) btn.style.pointerEvents = '';
      if (label && label.textContent === '조회 중...') label.textContent = '날씨 정보 보기';
    }, 3000);
  });
}

var _lastGreetingHour = null;
function renderGreeting() {
  var g = document.getElementById('homeGreeting');
  if (!g) return;
  var hour = new Date().getHours();
  _lastGreetingHour = hour;
  var greeting = getGreeting(hour);
  g.textContent = greeting.text + ' ' + greeting.emoji + (_weatherTip ? ' · ' + _weatherTip : '');
}
function startClock() {
  function tick() {
    var now = new Date();
    var d = document.getElementById('homeDate');
    var t = document.getElementById('homeTime');
    if (d) d.textContent = now.getFullYear() + '년 ' + (now.getMonth()+1) + '월 ' + now.getDate() + '일 (' + DAYS[now.getDay()] + ')';
    if (t) t.textContent = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
    // 인사문구는 시간대(hour)가 바뀔 때만 다시 계산 — 매초 다시 그릴 필요는 없다.
    if (now.getHours() !== _lastGreetingHour) renderGreeting();
  }
  tick();
  setInterval(tick, 1000);
  loadWeather();
}

/* ── 즐겨찾기 렌더 ── */
function renderFavList() {
  var el = document.getElementById('homeFavList');
  if (!userFavorites.length) {
    el.innerHTML = '<span class="home-fav-empty">즐겨찾기가 없습니다. 편집 버튼으로 추가해보세요.</span>';
    return;
  }
  el.innerHTML = userFavorites.map(function(key) {
    var page = ALL_PAGES.find(function(p) { return p.key === key; });
    if (!page) return '';
    return '<div class="home-fav-card" onclick="parent.shellNavigate && parent.shellNavigate(\'' + key + '\')">' +
      '<i class="ti ' + page.icon + '"></i>' + ts(page.label) + '</div>';
  }).join('');
}

/* ── 즐겨찾기 편집 모달 ── */
function openFavModal() {
  tempSelected = userFavorites.slice();
  renderFavPicker();
  document.getElementById('favModal').classList.add('is-open');
}
function closeFavModal() {
  document.getElementById('favModal').classList.remove('is-open');
}
window.closeFavModal = closeFavModal;

function renderFavPicker() {
  var grid = document.getElementById('favPickGrid');
  var available = ALL_PAGES.filter(function(p) { return allowedPageKeys.includes(p.key); });
  grid.innerHTML = available.map(function(p) {
    var selIdx = tempSelected.indexOf(p.key);
    var sel = selIdx !== -1;
    var badgeContent = sel ? (selIdx + 1) : '';
    return '<div class="fav-pick-card' + (sel ? ' is-selected' : '') + '" data-key="' + p.key + '">' +
      '<i class="ti ' + p.icon + ' fav-pick-icon" style="color:' + (sel ? 'var(--navy)' : '#9ca3af') + ';"></i>' +
      '<span class="fav-pick-label">' + ts(p.label) + '</span>' +
      '<span class="fav-pick-badge">' + badgeContent + '</span>' +
    '</div>';
  }).join('');

  grid.querySelectorAll('.fav-pick-card').forEach(function(card) {
    card.addEventListener('click', function() {
      var key = card.dataset.key;
      var idx = tempSelected.indexOf(key);
      if (idx !== -1) {
        tempSelected.splice(idx, 1);
      } else {
        if (tempSelected.length >= MAX_FAV) {
          alert('즐겨찾기는 최대 ' + MAX_FAV + '개까지 추가할 수 있습니다.');
          return;
        }
        tempSelected.push(key);
      }
      renderFavPicker(); // 번호 갱신
    });
  });
}

async function saveFavorites() {
  var { error } = await supabaseClient
    .from('profiles')
    .update({ favorites: tempSelected })
    .eq('id', currentUser.id);
  if (error) { alert('저장 실패: ' + error.message); return; }
  userFavorites = tempSelected.slice();
  renderFavList();
  closeFavModal();
}

/* ── 공지사항 ── */
async function loadNotices() {
  var today = localDateStr(new Date());
  var { data } = await supabaseClient
    .from('system_notices').select('*')
    .eq('org_id', auth.getCurrentOrgId())
    .eq('is_active', true)
    .or('expose_start.is.null,expose_start.lte.' + today)
    .or('expose_end.is.null,expose_end.gte.' + today)
    .order('is_pinned', { ascending:false })
    .order('created_at', { ascending:false })
    .limit(10);

  var el = document.getElementById('noticeList');
  if (!data || !data.length) { el.innerHTML = '<div class="home-empty">등록된 공지사항이 없습니다</div>'; return; }
  el.innerHTML = data.map(function(n) {
    var pin = n.is_pinned ? '<span class="notice-pin"><i class="ti ti-pin" style="font-size:9px;"></i> 공지</span>' : '';
    return '<div class="notice-item" onclick="this.classList.toggle(\'is-open\')">' +
      '<div class="notice-item-head">' + pin + '<span class="notice-title">' + ts(n.title) + '</span><i class="ti ti-chevron-down notice-expand-icon"></i></div>' +
      (n.content ? '<div class="notice-content">' + ts(n.content) + '</div>' : '') +
      '<div class="notice-meta">' + ts(n.author_name) + ' · ' + (n.created_at ? localDateStr(new Date(n.created_at)) : '') + '</div>' +
    '</div>';
  }).join('');
}

/* ── 이번 주 업무일정 ── */
var PRIORITY_BADGE = {
  HIGH:   '<span style="padding:1px 6px;border-radius:999px;font-size:10px;font-weight:700;background:#fee2e2;color:#dc2626;flex-shrink:0;">높음</span>',
  MEDIUM: '<span style="padding:1px 6px;border-radius:999px;font-size:10px;font-weight:700;background:#fef3c7;color:#92400e;flex-shrink:0;">중간</span>',
  LOW:    '<span style="padding:1px 6px;border-radius:999px;font-size:10px;font-weight:700;background:#f3f4f6;color:#6b7280;flex-shrink:0;">낮음</span>',
};

async function loadTasks(userEmail) {
  var now = new Date();
  var day = now.getDay();
  var mon = new Date(now); mon.setDate(now.getDate() - (day === 0 ? 6 : day - 1));
  var sun = new Date(mon); sun.setDate(mon.getDate() + 6);
  var monStr = localDateStr(mon);
  var sunStr = localDateStr(sun);

  var { data } = await supabaseClient
    .from('task_items')
    .select('task_id,title,start_date,end_date,status,priority,is_done,category')
    .eq('user_email', userEmail)
    .lte('start_date', sunStr)
    .gte('end_date', monStr)
    .order('start_date', { ascending:true })
    .limit(10);

  var el = document.getElementById('taskList');
  if (!data || !data.length) {
    el.innerHTML = '<div class="home-empty">이번 주 업무일정이 없습니다</div>';
    return;
  }
  el.innerHTML = data.map(function(t) {
    var done = t.is_done;
    var badge = PRIORITY_BADGE[t.priority] || '';
    var dateStr = t.start_date === t.end_date
      ? t.start_date
      : t.start_date + ' ~ ' + (t.end_date || '');
    return '<div class="recent-item">' +
      (badge) +
      '<span class="recent-title" style="' + (done ? 'text-decoration:line-through;color:#9ca3af;' : '') + '">' +
        ts(t.title || '-') + '</span>' +
      '<span class="recent-date">' + (t.start_date ? t.start_date.slice(5) : '') + '</span>' +
    '</div>';
  }).join('');
}

/* ── 권한 계산 (assets/js/core/permissions.js의 PagePerms를 단일 기준으로 사용) ── */
function computeAllowedKeys(user) {
  return ALL_PAGES
    .map(function(p) { return p.key; })
    .filter(function(k) { return window.PagePerms.canAccess(user, k); });
}

/* ── init ── */
async function init() {
  var session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession();
  auth.applyBrandColor(currentUser.primary_color);

  // 즐겨찾기 — getSession()이 profiles.favorites를 이미 가져오므로 별도 조회 불필요
  userFavorites = currentUser.favorites || [];

  // 이름/소속
  document.getElementById('homeName').textContent = (currentUser.user_name || currentUser.email) + '님';
  var sub = [];
  if (currentUser.clinic_name) sub.push(currentUser.clinic_name);
  if (currentUser.team_name) sub.push(currentUser.team_name);
  var roleMap = { admin:'관리자', manager:'매니저', edit:'편집자', user:'일반 사용자' };
  if (roleMap[currentUser.role]) sub.push(roleMap[currentUser.role]);
  document.getElementById('homeSub').textContent = sub.join(' · ');

  allowedPageKeys = computeAllowedKeys(currentUser);

  // 즐겨찾기에서 권한 없는 항목 제거
  userFavorites = userFavorites.filter(function(k) { return allowedPageKeys.includes(k); });

  startClock();
  renderFavList();

  document.getElementById('favEditBtn')?.addEventListener('click', openFavModal);
  document.getElementById('favSaveBtn')?.addEventListener('click', saveFavorites);

  var pp = currentUser.page_perms || {};
  var hasPP = Object.keys(pp).length > 0;
  var histLevel = hasPP ? (pp['signage/history'] || '') : currentUser.role;
  var canManage = histLevel === 'admin' || histLevel === 'manager';

  await Promise.all([loadNotices(), loadTasks(currentUser.email)]);
  hideGlobalLoading();
}

document.addEventListener('DOMContentLoaded', init);