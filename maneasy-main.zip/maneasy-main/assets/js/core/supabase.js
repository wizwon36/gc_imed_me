/**
 * supabase.js — SDK 초기화 싱글턴
 * app.html(셸)과 iframe 내부 페이지가 동일한 storage key를 사용해
 * 같은 세션을 공유한다.
 */

const { createClient } = supabase;

const supabaseClient = createClient(
  CONFIG.SUPABASE_URL,
  CONFIG.SUPABASE_ANON_KEY,
  {
    auth: {
      // 활동 중인 사용자는 계속 자동 갱신되어야 하므로 true로 둔다 — "1시간 지나면 무조건
      // 만료"는 이 설정이 아니라 auth.js의 유휴시간(idle) 체크가 담당한다(마지막 조작 후
      // 1시간 경과 시 requireAuth()에서 강제 로그아웃).
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
      storageKey: 'maneasy-auth',   // 고정 키 — 셸/iframe 공유
      // localStorage는 브라우저를 완전히 껐다 켜도 세션이 그대로 남아있어서, "창을 닫으면
      // 무조건 로그아웃"을 원하면 맞지 않는다. sessionStorage는 탭(브라우징 컨텍스트) 단위로만
      // 유지되고 탭/창을 닫으면 사라지는데, 같은 탭 안의 셸-iframe끼리는 sessionStorage도
      // 동일 출처면 공유되므로 셸/iframe 세션 공유는 그대로 유지된다 — 다만 새 탭을 여러 개
      // 띄우면 탭마다 따로 로그인해야 하는 점은 감안해야 한다.
      // 데스크톱(Electron) 앱은 브라우저 탭이 아니라 "창을 닫아도 로그인 유지"가 되는
      // 독립 앱이어야 하므로 localStorage(재실행해도 남음)를 쓰고, 웹은 기존대로
      // sessionStorage(탭 닫으면 로그아웃)를 쓴다. preload.js가 페이지 스크립트 실행 전에
      // window.__IS_ELECTRON__ = true를 심어둔다.
      storage: window.__IS_ELECTRON__ ? window.localStorage : window.sessionStorage,
    },
  }
);