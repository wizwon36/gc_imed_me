/**
 * db.js
 * Supabase DB / Storage 공통 래퍼.
 * 에러 핸들링을 한 곳에서 처리하고 호출부를 단순하게 유지한다.
 */

window.db = (function () {

  /* ── DB 헬퍼 ─────────────────────────────────── */

  function handleError(error, context = '') {
    const msg = error?.message || '알 수 없는 오류가 발생했습니다.';
    console.error(`[db${context ? ':' + context : ''}]`, error);
    throw new Error(msg);
  }

  async function select(table, queryFn) {
    let q = supabaseClient.from(table).select('*');
    if (queryFn) q = queryFn(q);
    const { data, error } = await q;
    if (error) handleError(error, `select:${table}`);
    return data || [];
  }

  async function selectOne(table, queryFn) {
    let q = supabaseClient.from(table).select('*');
    if (queryFn) q = queryFn(q);
    const { data, error } = await q.single();
    if (error) handleError(error, `selectOne:${table}`);
    return data;
  }

  async function insert(table, row) {
    const { data, error } = await supabaseClient
      .from(table)
      .insert(row)
      .select()
      .single();
    if (error) handleError(error, `insert:${table}`);
    return data;
  }

  async function update(table, id, patch) {
    const { data, error } = await supabaseClient
      .from(table)
      .update(patch)
      .eq('id', id)
      .select()
      .single();
    if (error) handleError(error, `update:${table}`);
    return data;
  }

  async function remove(table, id) {
    const { error } = await supabaseClient
      .from(table)
      .delete()
      .eq('id', id);
    if (error) handleError(error, `delete:${table}`);
  }

  /* ── Storage 헬퍼 ────────────────────────────── */

  // 이미지 리사이즈/압축 (Canvas API)
  function compressImage(file, maxWidth = 1280, quality = 0.82) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        let w = img.naturalWidth, h = img.naturalHeight;
        if (w > maxWidth) { h = Math.round(h * maxWidth / w); w = maxWidth; }
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        canvas.toBlob(blob => {
          if (!blob) { reject(new Error('이미지 압축 실패')); return; }
          resolve(new File([blob], file.name.replace(/\.[^.]+$/, '.jpg'), { type: 'image/jpeg' }));
        }, 'image/jpeg', quality);
      };
      img.onerror = () => reject(new Error('이미지 로드 실패'));
      img.src = url;
    });
  }

  async function uploadPhoto(file, equipmentId) {
    // 업로드 전 리사이즈/압축 (최대 1280px, JPEG 품질 82%)
    const compressed = await compressImage(file);
    const path = `${equipmentId}/${Date.now()}.jpg`;

    const { error } = await supabaseClient.storage
      .from(CONFIG.STORAGE.EQUIPMENT_PHOTOS)
      .upload(path, compressed, { upsert: true, contentType: 'image/jpeg' });

    if (error) handleError(error, 'uploadPhoto');

    const { data } = supabaseClient.storage
      .from(CONFIG.STORAGE.EQUIPMENT_PHOTOS)
      .getPublicUrl(path);

    return { path, url: data.publicUrl };
  }

  async function deletePhoto(path) {
    if (!path) return;
    const { error } = await supabaseClient.storage
      .from(CONFIG.STORAGE.EQUIPMENT_PHOTOS)
      .remove([path]);
    if (error) console.warn('[db:deletePhoto]', error);
  }

  // ── 범용 비공개 파일 업로드 (signage-files, approval-files 등 private 버킷) ──
  async function uploadFile(bucket, file, pathPrefix) {
    // 이미지면 업로드 전에 리사이즈/압축(최대 1600px, JPEG 품질 85%) — uploadPhoto와 같은
    // compressImage()를 재사용한다. GIF는 애니메이션이 깨지므로 압축 대상에서 제외하고,
    // 이미 작은 파일(300KB 미만)은 화질만 떨어뜨릴 뿐이라 그냥 원본 그대로 올린다.
    let uploadTarget = file;
    if (file.type && file.type.startsWith('image/') && file.type !== 'image/gif' && file.size > 300 * 1024) {
      try {
        uploadTarget = await compressImage(file, 1600, 0.85);
      } catch (e) {
        console.warn('[db:uploadFile] 이미지 압축 실패, 원본으로 업로드합니다:', e);
        uploadTarget = file;
      }
    }
    // 한글 등 비-ASCII 문자가 그대로 들어가면 Supabase Storage가 "Invalid key"로 거부하는
    // 경우가 있어(멀티바이트 문자 처리 이슈), 안전하게 ASCII 범위로만 남기고 나머지는 치환한다.
    // 원본 파일명은 file_name 컬럼에 그대로 저장해두므로(표시/다운로드용) 한글 손실은 문제 없음.
    const safeName = String(uploadTarget.name || 'file').replace(/[^\w.\-]/g, '_');
    const path = `${pathPrefix}/${Date.now()}_${safeName}`;
    const { error } = await supabaseClient.storage
      .from(bucket)
      .upload(path, uploadTarget, { upsert: false, contentType: uploadTarget.type || 'application/octet-stream' });
    if (error) handleError(error, `uploadFile:${bucket}`);
    return { path, name: uploadTarget.name, size: uploadTarget.size };
  }

  async function deleteFile(bucket, path) {
    if (!path) return;
    const { error } = await supabaseClient.storage.from(bucket).remove([path]);
    if (error) console.warn('[db:deleteFile]', error);
  }

  // private 버킷은 getPublicUrl이 통하지 않으므로 signed URL 발급 (기본 1시간)
  async function getSignedUrl(bucket, path, expiresIn = 3600, downloadName) {
    // downloadName을 주면 Supabase가 Content-Disposition: attachment로 응답해서,
    // 브라우저가 (이미지/PDF라도) 새 탭에 그냥 열어버리지 않고 실제로 다운로드된다.
    const opts = downloadName ? { download: downloadName } : undefined;
    const { data, error } = await supabaseClient.storage
      .from(bucket)
      .createSignedUrl(path, expiresIn, opts);
    if (error) { console.warn('[db:getSignedUrl]', error); return ''; }
    return data?.signedUrl || '';
  }

  return {
    select,
    selectOne,
    insert,
    update,
    remove,
    uploadPhoto,
    deletePhoto,
    uploadFile,
    deleteFile,
    getSignedUrl,
  };
})();