// "오늘 날짜"류 값을 date.toISOString().slice(0,10)으로 뽑으면 UTC 기준으로 잘려서,
// 한국시간 00:00~08:59(=UTC 전날 15:00~23:59)에는 하루 전 날짜가 나오는 버그가 있다.
// 날짜 하나(YYYY-MM-DD)가 필요할 땐 항상 이 함수를 쓴다 — 로컬(브라우저) 타임존 기준으로 자른다.
function localDateStr(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

// 날짜 범위 필터(gte/lte)를 timestamptz 컬럼(created_at 등)에 걸 때 쓴다. "2026-07-11"을
// 그냥 문자열로 비교하면 UTC 자정 기준으로 해석돼서, 한국시간 자정~오전 9시 사이의 결재는
// 하루 어긋난 날짜로 취급된다 — 명시적으로 +09:00 오프셋을 붙여 그 날짜의 한국시간 시작/끝을
// 정확한 UTC 시각으로 바꿔준다.
function kstDateRangeStart(dateStr) { return new Date(dateStr + 'T00:00:00+09:00').toISOString(); }
function kstDateRangeEnd(dateStr) { return new Date(dateStr + 'T23:59:59.999+09:00').toISOString(); }

function qs(selector) {
  return document.querySelector(selector);
}

function qsa(selector) {
  return document.querySelectorAll(selector);
}

function getQueryParam(name) {
  const params = new URLSearchParams(location.search);
  return params.get(name);
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

// .or('a.ilike.%키워드%,b.ilike.%키워드%') 처럼 검색 조건을 문자열로 직접 조립하는 화면들이
// 많은데, 검색어에 ',' '(' ')' 가 들어가면 PostgREST가 그걸 조건 구분자/그룹핑 문법으로
// 오인해서 "failed to parse logic tree" 에러로 검색 자체가 실패한다. '%' '_' 는 ILIKE
// 와일드카드라 검색어에 그대로 있으면 의도치 않게 패턴처럼 동작한다. 전부 백슬래시로
// 이스케이프해서 순수 리터럴 문자로 취급되게 한다. .or()로 여러 컬럼을 검색하는 곳은
// 전부 이 함수를 거쳐서 값을 넣어야 한다.
function escapeIlikeKeyword(kw) {
  return String(kw ?? '').replace(/[\\%_,()]/g, '\\$&');
}

function safeText(value, fallback = '-') {
  const normalized = value === null || value === undefined || value === '' ? fallback : value;
  return escapeHtml(normalized);
}

function formatNumber(value) {
  if (value === null || value === undefined || value === '') return '';

  const num = Number(value);
  if (Number.isNaN(num)) return value;

  return num.toLocaleString('ko-KR');
}

function nl2br(value) {
  return escapeHtml(value).replace(/\n/g, '<br>');
}

function showMessage(message, type = 'info', duration = 4000) {
  // 토스트 컨테이너 (없으면 생성)
  let container = document.getElementById('_toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = '_toastContainer';
    container.style.cssText = [
      'position:fixed', 'bottom:20px', 'right:20px', 'z-index:99999',
      'display:flex', 'flex-direction:column', 'gap:8px',
      'pointer-events:none', 'max-width:360px',
    ].join(';');
    document.body.appendChild(container);
  }

  const COLORS = {
    success: { bg:'#f0fdf4', border:'#86efac', icon:'#16a34a', text:'#166534', ico:'✓' },
    error:   { bg:'#fef2f2', border:'#fca5a5', icon:'#dc2626', text:'#991b1b', ico:'✕' },
    warning: { bg:'#fffbeb', border:'#fcd34d', icon:'#d97706', text:'#92400e', ico:'⚠' },
    info:    { bg:'#eff6ff', border:'#93c5fd', icon:'#2563eb', text:'#1e40af', ico:'ℹ' },
  };
  const c = COLORS[type] || COLORS.info;

  const toast = document.createElement('div');
  toast.style.cssText = [
    'display:flex', 'align-items:flex-start', 'gap:10px',
    'padding:12px 14px', 'border-radius:8px',
    'background:' + c.bg, 'border:1px solid ' + c.border,
    'box-shadow:0 4px 12px rgba(0,0,0,0.12)',
    'font-size:12px', 'line-height:1.5', 'color:' + c.text,
    'pointer-events:auto', 'cursor:pointer',
    'opacity:0', 'transform:translateX(20px)',
    'transition:opacity 0.25s, transform 0.25s',
    'word-break:keep-all',
  ].join(';');

  toast.innerHTML =
    '<span style="font-size:14px;color:' + c.icon + ';flex-shrink:0;margin-top:1px;">' + c.ico + '</span>' +
    '<span style="flex:1;">' + String(message).replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</span>' +
    '<span style="color:#9ca3af;font-size:11px;flex-shrink:0;margin-top:1px;">✕</span>';

  container.appendChild(toast);

  // 애니메이션 in
  requestAnimationFrame(function() {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  });

  function dismiss() {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    setTimeout(function() { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 250);
  }

  toast.addEventListener('click', dismiss);
  if (duration > 0) setTimeout(dismiss, duration);
}

function clearMessage() {
  // 기존 messageBox 숨김 (레거시 호환)
  const box = qs('#messageBox');
  if (box) { box.style.display = 'none'; box.textContent = ''; box.className = 'message-box'; }
}

function setLoading(button, isLoading, loadingText = '처리 중...') {
  if (!button) return;

  if (isLoading) {
    button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.textContent = loadingText;
    return;
  }

  button.disabled = false;
  button.textContent = button.dataset.originalText || '저장';
}

function goToDetail(equipmentId) {
  location.href = `detail.html?id=${encodeURIComponent(equipmentId)}`;
}

// ============================
// 전역 로딩 (상단 토스트 스피너)
// ============================

let GLOBAL_LOADING_COUNT     = 0;
let GLOBAL_LOADING_OPENED_AT = 0;
const GLOBAL_LOADING_MIN_MS  = 300;

function showGlobalLoading(text = '불러오는 중...') {
  const overlay = qs('#globalLoading');
  if (!overlay) return;

  const textEl = qs('#globalLoadingText');
  if (textEl) textEl.textContent = text;

  GLOBAL_LOADING_COUNT += 1;

  if (!overlay.classList.contains('is-open')) {
    GLOBAL_LOADING_OPENED_AT = Date.now();
    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
  }
}

async function hideGlobalLoading(force = false) {
  const overlay = qs('#globalLoading');
  if (!overlay) return;

  if (force) {
    GLOBAL_LOADING_COUNT = 0;
  } else {
    GLOBAL_LOADING_COUNT = Math.max(0, GLOBAL_LOADING_COUNT - 1);
  }

  if (GLOBAL_LOADING_COUNT > 0) return;

  const elapsed   = Date.now() - GLOBAL_LOADING_OPENED_AT;
  const remaining = Math.max(0, GLOBAL_LOADING_MIN_MS - elapsed);

  if (remaining > 0) {
    await new Promise(resolve => setTimeout(resolve, remaining));
  }

  overlay.classList.remove('is-open');
  overlay.setAttribute('aria-hidden', 'true');
}

async function withGlobalLoading(task, text = '불러오는 중...') {
  showGlobalLoading(text);

  try {
    return await task();
  } finally {
    await hideGlobalLoading();
  }
}

// ============================
// 상태 / 이력 / 재고 레이블
// ============================

function statusLabel(status) {
  const map = {
    IN_USE: '사용중',
    REPAIRING: '수리중',
    INSPECTING: '점검중',
    STORED: '보관',
    DISPOSED: '폐기'
  };

  return map[String(status || '').trim()] || String(status || '');
}

function statusClass(status) {
  const map = {
    IN_USE: 'is-in-use',
    REPAIRING: 'is-repairing',
    INSPECTING: 'is-inspecting',
    STORED: 'is-stored',
    DISPOSED: 'is-disposed'
  };

  return map[String(status || '').trim()] || '';
}

function historyTypeLabel(type) {
  const map = {
    REPAIR: '수리',
    INSPECTION: '점검',
    MAINTENANCE: '유지보수',
    OTHER: '기타'
  };

  return map[String(type || '').trim()] || String(type || '');
}

function resultStatusLabel(type) {
  const value = String(type || '').trim();

  if (!value) return '미등록';  // 🔥 핵심 fallback

  const map = {
    COMPLETED: '완료',
    IN_PROGRESS: '진행중',
    PENDING: '대기'
  };

  return map[value] || value;
}


function ResultStatusClass(status) {
  const map = {
    COMPLETED: 'badge-green',
    IN_PROGRESS: 'badge-orange',
    PENDING: 'badge-gray'
  };
  return map[status] || 'badge-gray';
}

function conditionStatusLabel(type) {
  const value = String(type || '').trim();

  if (!value) return '미등록';

  const map = {
    NORMAL: '정상',
    NEEDS_CHECK: '확인 필요',
    ABNORMAL: '이상',
    MISSING: '분실',
  };

  return map[value] || value;
}

function formatDateTimeKR(value) {
  if (!value) return '-';

  const date = new Date(value);
  if (isNaN(date)) return value;

  return date.toLocaleString('ko-KR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

// 결재 처리시각처럼 작은 칩/배지 아래 짧게 보여줄 때 쓰는 압축 포맷("YYYY-MM-DD HH:MM").
// timestamptz 값을 new Date()로 파싱한 뒤 로컬(브라우저=한국시간) 시/분을 그대로 쓴다 —
// 예전엔 DB가 준 UTC 문자열을 파싱 없이 그냥 잘라 썼던 탓에 실제 시각보다 9시간 이르게
// 보이는 버그가 있었다.
function formatDateTimeKRCompact(value) {
  if (!value) return '';
  var d = new Date(value);
  if (isNaN(d.getTime())) return '';
  return localDateStr(d) + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

// ============================
// 의원별 앱 접근 제한
// ============================

function isEquipmentClinicAllowed(user) {
  var allowed = (typeof CONFIG !== 'undefined' && Array.isArray(CONFIG.EQUIPMENT_ALLOWED_CLINICS))
    ? CONFIG.EQUIPMENT_ALLOWED_CLINICS
    : ['서울숲의원'];
  var clinicName = String((user && user.clinic_name) || '').trim();
  return allowed.some(function(name) { return clinicName.indexOf(name) !== -1; });
}

// ============================
// 모바일 topbar 버튼 수 자동 열 조정
// portal-top-actions 안의 portal-header-btn 수를 세어
// top-actions--cols-1/2/3 클래스를 자동으로 부여
// 새 페이지를 추가해도 별도 작업 불필요
// ============================

// ============================
// 모바일 topbar 버튼 수 자동 열 조정
// portal-top-actions 안의 portal-header-btn 수를 세어
// top-actions--cols-1/2/3 클래스를 자동으로 부여
// 새 페이지를 추가해도 별도 작업 불필요
// ============================

function applyTopActionsColClass() {
  var containers = document.querySelectorAll('.portal-top-actions, .top-brand-actions');
  containers.forEach(function (container) {
    // display:none 버튼은 제외하고 실제 보이는 버튼만 카운트
    var btns = container.querySelectorAll('.portal-header-btn');
    var visibleCount = 0;
    btns.forEach(function (btn) {
      if (btn.style.display !== 'none' && btn.offsetParent !== null) {
        visibleCount++;
      }
    });
    if (visibleCount < 1) return;
    var cols = Math.min(visibleCount, 3);
    container.classList.remove('top-actions--cols-1', 'top-actions--cols-2', 'top-actions--cols-3');
    container.classList.add('top-actions--cols-' + cols);
  });
}

(function () {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTopActionsColClass);
  } else {
    applyTopActionsColClass();
  }
})();

// ── Shell SPA 감지 ─────────────────────────────────────────
// ?shell=1 파라미터가 있으면 body에 in-shell 클래스 추가
// → common.css의 body.in-shell 규칙으로 topbar 자동 숨김
(function () {
  if (new URLSearchParams(location.search).get('shell') === '1') {
    document.documentElement.classList.add('in-shell');
    if (document.body) {
      document.body.classList.add('in-shell');
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        document.body.classList.add('in-shell');
      });
    }
  }
})();


// ── AG Grid 공통 헬퍼 ──────────────────────────────────────
/**
 * createMgGrid(containerId, colDefs, rows, options)
 *
 * options:
 *   pageSize   {number}  페이지당 행 수 (기본 20). 높이 계산에 사용.
 *   fit        {boolean} true면 컨테이너 높이에 맞게 rowHeight 자동 계산 (기본 true)
 *   noRowsText {string}  데이터 없을 때 문구
 *   onRowClick {fn}      행 클릭 핸들러 (params.data 전달)
 *
 * 반환값: gridApi 인스턴스 (destroy/setGridOption 가능)
 */
/** ag-grid의 sizeColumnsToFit()은 컬럼 정의의 flex 값과 무관하게 "현재 폭 비율대로" 모든 컬럼을
 *  늘려버린다 — 그래서 액션 버튼 컬럼처럼 flex:0 + 고정 width로 만들어둔 컬럼도 화면이 넓으면
 *  같이 늘어나버리는 문제가 있다. flex:0인 컬럼은 sizeColumnsToFit 호출 때마다 자신의 width를
 *  min/maxWidth로 넘겨 고정폭을 유지하도록 한다.
 *  createMgGrid는 내부적으로 이 로직을 쓰고, agGrid.createGrid를 직접 쓰는 그리드는
 *  sizeColumnsToFit() 호출 부분을 fitGridColumnsPinned(api, colDefs)로 바꿔서 재사용하면 된다. */
function fitGridColumnsPinned(api, colDefs) {
  var fixedColumnLimits = [];
  colDefs.forEach(function(col, idx) {
    if (col.flex === 0 && col.width) {
      if (!col.colId) col.colId = col.field || ('mgFixedCol_' + idx);
      fixedColumnLimits.push({ key: col.colId, minWidth: col.width, maxWidth: col.width });
    }
  });
  api.sizeColumnsToFit(fixedColumnLimits.length ? { columnLimits: fixedColumnLimits } : undefined);
}

function createMgGrid(containerId, colDefs, rows, options) {
  options = options || {};
  var el = document.getElementById(containerId);
  if (!el) return null;
  if (typeof agGrid === 'undefined') return null;

  // sizeColumnsToFit()은 flex를 안 쓴(=고정폭 의도) 컬럼까지 남는 공간 비율만큼 늘려버린다.
  // 컬럼 수가 적은 화면일수록 액션 버튼 컬럼 등이 화면 끝까지 벌어지는 원인이 됨.
  // maxWidth를 폭과 동일하게 걸어두면 sizeColumnsToFit이 그 폭에서 더는 늘리지 못하고,
  // 남는 공간은 flex를 준 컬럼(제목/내용 등)에만 배분된다.
  (colDefs || []).forEach(function(col) {
    if (col.width != null && col.maxWidth == null && !col.flex) {
      col.maxWidth = col.width;
    }
  });

  var noRowsText = options.noRowsText || '조회된 데이터가 없습니다.';

  // ag-theme-alpine 자동 추가
  if (!el.classList.contains('ag-theme-alpine')) {
    el.classList.add('ag-theme-alpine');
  }

  // 페이지 작성자가 마크업에 미리 인라인 height(px)를 박아둔 경우엔 그 값을 그대로 존중
  var authorHeight = null;
  if (el.style.height && el.style.height.endsWith('px')) {
    var ah = parseInt(el.style.height);
    if (ah > 40) authorHeight = ah;
  }

  // el 자신이 flex-grow로 부모를 채우도록 설계된 대상인지(.m-table-wrap류) 여부.
  // 이 값은 레이아웃이 한 번 안정된 뒤(최초 측정 시점)에 판단하면 되고, el.style.height를
  // 우리가 직접 건드려도 flex-grow 자체(CSS 속성)는 바뀌지 않으므로 이 판단은 항상 안정적이다.
  var growsWithParent = parseFloat(getComputedStyle(el).flexGrow || '0') > 0;

  // 높이 결정.
  //  - flex로 늘어나는 대상: el 자신이 아니라 "el이 채워야 하는" 부모(flex 컨테이너) 체인의
  //    실제 레이아웃 높이를 매번 다시 측정한다. (el.offsetHeight를 읽으면, 한 번 잘못된 값으로
  //    굳어진 뒤엔 그 값만 계속 반복해서 읽게 돼서 resize/탭전환 후에도 영원히 보정되지 않는
  //    문제가 있었음 — 그리드가 컨테이너를 다 못 채우고 높이가 작게 고정되는 버그의 원인)
  //  - 고정 크기 박스(예: 180px 높이로 의도된 영역): el 자신의 레이아웃 높이를 그대로 쓴다.
  function resolveHeight() {
    if (authorHeight) return authorHeight;
    if (growsWithParent) {
      var p = el.parentElement;
      while (p) {
        if (p.clientHeight > 40) return p.clientHeight;
        p = p.parentElement;
      }
      return Math.max(300, window.innerHeight - 160);
    }
    if (el.offsetHeight > 40) return el.offsetHeight;
    return Math.max(180, window.innerHeight - 160);
  }

  var ROW_H     = 34;
  var HEADER_H  = 34;

  // 박스 크기는 항상 CSS/부모 컨테이너가 정한 실제 크기를 그대로 쓴다 (equipment-list.js와 동일 원칙).
  // pageSize는 "그 크기에 몇 행이 대략 들어갈지" 데이터 조회용 참고값일 뿐, 박스 높이를
  // JS로 역산해서 강제로 고정하지 않는다 — 그렇게 하면 실측값과 어긋나 오히려 더 틀어진다.
  var gridH = resolveHeight();
  el.style.height = gridH + 'px';

  // ag-grid의 sizeColumnsToFit()은 컬럼 정의의 flex 값과 무관하게 "현재 폭 비율대로" 모든 컬럼을
  // 늘려버린다 — 그래서 액션 버튼 컬럼처럼 flex:0 + 고정 width로 만들어둔 컬럼도 화면이 넓으면
  // 같이 늘어나버리는 문제가 있었다. fitGridColumnsPinned()가 flex:0 컬럼의 폭을 고정해준다.
  function fitColumns(_api) {
    fitGridColumnsPinned(_api, colDefs);
  }

  // equipment-list.js defaultColDef와 동일
  var defaultColDef = {
    sortable: true,
    resizable: true,
    suppressMovable: true,
    headerClass: 'ag-center-header',
    cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'center' },
  };

  var gridOptions = {
    columnDefs: colDefs,
    defaultColDef: defaultColDef,
    rowData: rows,
    rowHeight: ROW_H,
    headerHeight: HEADER_H,
    // 세로 스크롤바는 행 개수(조회 결과)에 따라 나타났다 사라졌다 하는데, 그때마다
    // sizeColumnsToFit()의 기준 폭이 달라져서 조회할 때마다 컬럼폭이 미묘하게 흔들리는
    // 원인이 됐다. 스크롤바 자리를 항상 예약해두면 행 개수와 무관하게 기준 폭이 고정된다.
    alwaysShowVerticalScroll: true,
    pagination: !!options.pageSize,
    paginationPageSize: options.pageSize || undefined,
    suppressPaginationPanel: !options.pageSize,
    suppressScrollOnNewData: true,
    suppressHorizontalScroll: true,
    suppressCellFocus: true,
    suppressPropertyNamesCheck: true,
    overlayNoRowsTemplate: '<span style="color:#9ca3af;font-size:12px;">' + noRowsText + '</span>',
    onGridReady: function(params) {
      var _api = params.api;
      setTimeout(function() {
        if (_api && !(_api.isDestroyed && _api.isDestroyed()) && el.offsetWidth > 0) {
          var h = resolveHeight();
          if (h !== gridH) { gridH = h; el.style.height = h + 'px'; }
          fitColumns(_api);
        }
      }, 0);
      window.addEventListener('resize', function() {
        if (_api && !(_api.isDestroyed && _api.isDestroyed()) && el.offsetWidth > 0) {
          gridH = resolveHeight();
          el.style.height = gridH + 'px';
          fitColumns(_api);
        }
      });
      // 가로폭이 처음 측정될 때 아직 자리를 잡기 전이거나(폰트 로딩, 형제 요소 변화 등)
      // 이후에 컨테이너 폭이 바뀌는 경우에도 항상 다시 맞춰지도록 — window resize 이벤트
      // 하나에만 의존하면 그런 변화를 못 잡아서 컬럼이 좁게 고정된 채로 남는 문제가 있었음
      if (typeof ResizeObserver !== 'undefined') {
        var ro = new ResizeObserver(function() {
          if (_api && !(_api.isDestroyed && _api.isDestroyed())) fitColumns(_api);
          else ro.disconnect(); // 그리드가 없어졌으면 관찰도 그만 — 컨테이너가 재사용될 다음 그리드와 안 섞이게
        });
        ro.observe(el);
      }
    },
  };

  if (options.onRowClick) {
    gridOptions.onRowClicked = function(params) {
      if (params.data) options.onRowClick(params.data);
    };
    gridOptions.rowStyle = { cursor: 'pointer' };
  }

  var api = agGrid.createGrid(el, gridOptions);
  api._resolveHeight = resolveHeight;
  return api;
}


function updateMgGrid(api, rows) {
  if (api && rows) {
    api.setGridOption('rowData', rows);
    refitGridColumns(api);
  }
}

/** rowData가 바뀌어서 스크롤바가 새로 생기거나 없어지는 경우, 컬럼폭을 다시 맞춰서
 *  마지막 컬럼(보통 버튼)이 스크롤바에 가려 잘리는 걸 막는다.
 *  agGrid.createGrid()로 직접 만든 그리드에서 setGridOption('rowData', ...) 직후 호출. */
/** 시스템 로그 기록 — 마스터 관리 > 시스템 로그 화면에 남는다.
 *  auth.js/notice.js/signage/*.js/program-request/*.js 등 여러 곳에서 이미
 *  `systemLog(action, description, {target_type, target_id, meta}).catch(()=>{})`
 *  형태로 호출하고 있었는데, 정작 이 함수 자체가 어디에도 정의된 적이 없어서
 *  (auth.js는 typeof systemLog === 'function' 체크까지 해뒀는데도) 전부 조용히 무시되고
 *  있었다 — 시스템 로그가 안 쌓이던 진짜 원인. 기존 호출부들이 이미 기대하고 있던
 *  시그니처 그대로 정의해서, 코드를 하나도 안 건드리고 바로 로그가 쌓이게 한다. */
async function systemLog(action, description, opts) {
  opts = opts || {};
  var user = window.auth && window.auth.getSession ? await window.auth.getSession() : null;
  if (!user || !user.org_id) return;
  var { error } = await supabaseClient.from('system_logs').insert({
    org_id: user.org_id,
    user_id: user.id || null,
    user_name: user.user_name || user.name || '',
    action: action,
    description: description || null,
    target_type: opts.target_type || null,
    target_id: opts.target_id || null,
    meta: opts.meta || null,
  });
  if (error) throw new Error(error.message);
}

function refitGridColumns(api) {
  if (!api) return;
  setTimeout(function() {
    try { fitGridColumnsPinned(api, api.getColumnDefs() || []); } catch(e) { /* 그리드가 이미 제거된 경우 무시 */ }
  }, 0);
}


// 시스템 로그 기록 헬퍼 (fire-and-forget)
/** PostgREST는 기본적으로 한 번에 최대 1000행까지만 반환한다(서버 설정) — .limit()을
 *  더 크게 줘도 소용없고, count와 실제 행 수가 안 맞는 채로 조용히 잘리는 게 제일 위험하다
 *  (그리드엔 1000건만 뜨는데 "총 X건"이라고 다른 숫자를 보여주는 식). "전체를 다 봐야 하는"
 *  마스터 데이터류(자재/거래처 목록 등, 페이지네이션 UI를 따로 만들 필요는 없는 화면)에서
 *  buildQuery(항상 새로 체이닝을 만들어 반환하는 함수, .range()는 호출하지 않은 상태)를
 *  넘기면 필요한 만큼 반복 조회해서 전체 행을 모아 돌려준다.
 *  사용례: const { data, count } = await fetchAllRows(() =>
 *    supabaseClient.from('items').select('*', {count:'exact'}).eq('org_id', orgId).order('item_name'));
 */
async function fetchAllRows(buildQuery, pageSize) {
  pageSize = pageSize || 1000;
  var allRows = [];
  var offset = 0;
  var totalCount = null;
  while (true) {
    var { data, error, count } = await buildQuery().range(offset, offset + pageSize - 1);
    if (error) throw new Error(error.message);
    if (totalCount === null) totalCount = (typeof count === 'number') ? count : null;
    var rows = data || [];
    allRows = allRows.concat(rows);
    offset += pageSize;
    if (rows.length < pageSize) break; // 이번에 페이지를 다 못 채웠으면 더 없는 것
    if (totalCount !== null && allRows.length >= totalCount) break;
  }
  return { data: allRows, count: totalCount };
}
/* ══════════════════════════════════════════════
   커스텀 날짜 입력 (연/월/일 3분할) — mso_manage에서 이식
   브라우저 기본 <input type="date">는 연도 칸에 4자리를 넘겨 6자리까지 입력해도
   자동으로 월 칸으로 안 넘어가는 등, 내부 동작을 JS로 통제할 수 없는 문제가 있다.
   이 함수는 기존 <input type="date" id="...">를 연/월/일 3개의 텍스트 입력으로 바꿔치기하면서,
   원본 id를 가진 <input type="hidden">은 그대로 남겨 val()/setVal() 등 기존 코드가
   손댈 필요 없이 계속 "YYYY-MM-DD" 문자열로 읽고 쓸 수 있게 한다 (.value/.disabled 프록시).
══════════════════════════════════════════════ */
function mountCustomDateInput(id) {
  const orig = document.getElementById(id);
  if (!orig || orig.tagName !== 'INPUT' || orig.dataset.cdateMounted) return;

  const minAttr = orig.getAttribute('min'); // 'YYYY-MM-DD'
  const maxAttr = orig.getAttribute('max');
  const minYear = minAttr ? Number(minAttr.slice(0, 4)) : 1000;
  const maxYear = maxAttr ? Number(maxAttr.slice(0, 4)) : 9999;
  const initialValue = orig.value || '';
  const initialDisabled = !!orig.disabled;
  const extraClass = orig.className || '';
  const extraStyle = orig.getAttribute('style') || '';

  const wrap = document.createElement('span');
  wrap.className = 'input cdate-wrap' + (extraClass ? ' ' + extraClass : '');
  if (extraStyle) wrap.setAttribute('style', wrap.getAttribute('style') ? wrap.getAttribute('style') + ';' + extraStyle : extraStyle);

  const y = document.createElement('input');
  y.type = 'text'; y.inputMode = 'numeric'; y.autocomplete = 'off'; y.maxLength = 4; y.placeholder = 'YYYY';
  y.className = 'cdate-seg cdate-y';
  const m = document.createElement('input');
  m.type = 'text'; m.inputMode = 'numeric'; m.autocomplete = 'off'; m.maxLength = 2; m.placeholder = 'MM';
  m.className = 'cdate-seg cdate-m';
  const d = document.createElement('input');
  d.type = 'text'; d.inputMode = 'numeric'; d.autocomplete = 'off'; d.maxLength = 2; d.placeholder = 'DD';
  d.className = 'cdate-seg cdate-d';
  const sep1 = document.createElement('span'); sep1.className = 'cdate-sep'; sep1.textContent = '-';
  const sep2 = document.createElement('span'); sep2.className = 'cdate-sep'; sep2.textContent = '-';

  // 달력 아이콘 — 클릭하면 브라우저 기본 달력 팝업을 띄운다. 세그먼트 자체는 계속 타이핑도 가능하다.
  const calBtn = document.createElement('button');
  calBtn.type = 'button';
  calBtn.className = 'cdate-cal-btn';
  calBtn.tabIndex = -1; // 탭 이동은 연/월/일 세그먼트끼리만 자연스럽게 되도록, 버튼은 탭 순서에서 제외
  calBtn.setAttribute('aria-label', '달력에서 날짜 선택');
  calBtn.innerHTML = '<i class="ti ti-calendar"></i>';

  // 실제 값 반영은 항상 세그먼트(y/m/d)를 통해서만 하고, 이 프록시는 오직 브라우저 달력 팝업을
  // 띄우기 위한 용도로만 쓴다 — 화면엔 보이지 않는다.
  const pickerProxy = document.createElement('input');
  pickerProxy.type = 'date';
  pickerProxy.className = 'cdate-picker-proxy';
  pickerProxy.tabIndex = -1;
  if (minAttr) pickerProxy.min = minAttr;
  if (maxAttr) pickerProxy.max = maxAttr;

  wrap.append(y, sep1, m, sep2, d, calBtn, pickerProxy);

  const parentEl = orig.parentNode;
  parentEl.insertBefore(wrap, orig);
  orig.type = 'hidden';
  orig.dataset.cdateMounted = '1';
  wrap.appendChild(orig);

  function onlyDigits(el) { el.value = el.value.replace(/[^\d]/g, ''); }
  function composeISO() {
    if (y.value.length === 4 && m.value.length && d.value.length) {
      return y.value + '-' + m.value.padStart(2, '0') + '-' + d.value.padStart(2, '0');
    }
    return '';
  }

  let lastCommitted = initialValue;
  function commit() {
    const iso = composeISO();
    if (iso === lastCommitted) return;
    lastCommitted = iso;
    rawValue = iso;
    orig.dispatchEvent(new Event('input', { bubbles: true }));
    orig.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function finalizeSegments() {
    if (m.value) m.value = String(Math.min(12, Math.max(1, parseInt(m.value, 10) || 0))).padStart(2, '0');
    if (d.value) d.value = String(Math.min(31, Math.max(1, parseInt(d.value, 10) || 0))).padStart(2, '0');
    if (y.value) {
      const yv = Math.min(maxYear, Math.max(minYear, parseInt(y.value, 10) || minYear));
      y.value = String(yv).padStart(4, '0');
    }
    commit();
  }

  y.addEventListener('input', () => {
    onlyDigits(y);
    if (y.value.length > 4) y.value = y.value.slice(0, 4);
    if (y.value.length === 4) m.focus();
  });
  m.addEventListener('input', () => {
    onlyDigits(m);
    if (m.value.length > 2) m.value = m.value.slice(0, 2);
    if (m.value.length === 2) d.focus();
  });
  d.addEventListener('input', () => {
    onlyDigits(d);
    if (d.value.length > 2) d.value = d.value.slice(0, 2);
    if (d.value.length === 2) commit(); // 일(day)까지 다 채워지면 그 즉시 완성된 값으로 커밋
  });

  // 백스페이스로 빈 칸에서 이전 칸으로 이동 (네이티브 date input과 동일한 UX)
  m.addEventListener('keydown', e => { if (e.key === 'Backspace' && !m.value) y.focus(); });
  d.addEventListener('keydown', e => { if (e.key === 'Backspace' && !d.value) m.focus(); });

  [y, m, d].forEach(seg => seg.addEventListener('blur', finalizeSegments));
  [y, m, d].forEach(seg => seg.addEventListener('focus', () => seg.select()));

  // 달력 아이콘 클릭 → 숨겨둔 네이티브 date input의 팝업 달력을 띄운다.
  // 달력에서 고른 값은 세그먼트에 채워 넣고 commit()으로 반영해서, 타이핑으로 완성했을 때와
  // 동일하게 input/change 이벤트가 나가도록 한다.
  calBtn.addEventListener('click', () => {
    if (calBtn.disabled) return;
    pickerProxy.value = composeISO() || '';
    if (typeof pickerProxy.showPicker === 'function') {
      try { pickerProxy.showPicker(); return; } catch (e) { /* showPicker 미지원/차단 시 focus로 대체 */ }
    }
    pickerProxy.focus();
  });
  pickerProxy.addEventListener('change', () => {
    if (!pickerProxy.value) return;
    const [yy, mm, dd] = pickerProxy.value.split('-');
    y.value = yy; m.value = mm; d.value = dd;
    commit();
  });

  let rawValue = initialValue;
  Object.defineProperty(orig, 'value', {
    get() { return rawValue; },
    set(v) {
      rawValue = v || '';
      lastCommitted = rawValue;
      if (rawValue) {
        const parts = rawValue.split('-');
        y.value = parts[0] || ''; m.value = parts[1] || ''; d.value = parts[2] || '';
      } else {
        y.value = ''; m.value = ''; d.value = '';
      }
    },
  });

  let rawDisabled = initialDisabled;
  Object.defineProperty(orig, 'disabled', {
    get() { return rawDisabled; },
    set(v) {
      rawDisabled = !!v;
      [y, m, d].forEach(seg => { seg.disabled = rawDisabled; });
      calBtn.disabled = rawDisabled;
      wrap.classList.toggle('cdate-disabled', rawDisabled);
    },
  });

  orig.value = initialValue; // 세그먼트 초기 동기화
  orig.disabled = initialDisabled;
}
