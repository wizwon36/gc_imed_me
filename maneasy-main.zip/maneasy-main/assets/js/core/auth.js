/**
 * auth.js
 * Supabase Auth 기반 인증 모듈.
 * - 로그인 / 회원가입 / 승인 대기 처리
 */

window.auth = (function () {

  const ORG_KEY = 'maneasy-current-org';

  // ── 유휴 시간(idle) 세션 만료 ──────────────────────────────────
  // "로그인 후 1시간"이 아니라 "마지막 활동(클릭/입력/스크롤 등) 후 1시간"이 기준이다.
  // localStorage는 셸(app.html)과 iframe 안 페이지들이 전부 공유하므로, 어느 화면에서
  // 활동하든 같은 값을 갱신/확인한다.
  const ACTIVITY_KEY = 'maneasy-last-activity';
  const IDLE_LIMIT_MS = 60 * 60 * 1000; // 1시간

  function markActivity() {
    try { localStorage.setItem(ACTIVITY_KEY, String(Date.now())); } catch (_e) {}
  }

  function getIdleElapsedMs() {
    const last = Number(localStorage.getItem(ACTIVITY_KEY) || 0);
    if (!last) return 0; // 기록이 아예 없으면(첫 로그인 등) 유휴로 취급하지 않는다.
    return Date.now() - last;
  }

  // 사용자 조작이 있을 때마다 활동 시각을 갱신한다. 매 이벤트마다 localStorage에 쓰면
  // 낭비가 크므로 10초에 한 번으로 스로틀링한다. 이 리스너는 auth.js가 로드되는 모든
  // 화면(셸 + iframe 안 각 페이지)에서 각각 등록되므로, 사용자가 iframe 내부에서만
  // 조작해도(마우스가 iframe 밖으로 나가지 않아도) 정상적으로 감지된다.
  (function initActivityTracking() {
    let lastWrite = 0;
    function onActivity() {
      const now = Date.now();
      if (now - lastWrite < 10000) return;
      lastWrite = now;
      markActivity();
    }
    ['mousedown', 'keydown', 'scroll', 'touchstart', 'click'].forEach(function (evt) {
      document.addEventListener(evt, onActivity, { passive: true, capture: true });
    });
  })();

  function getLoginUrl() { return `${CONFIG.SITE_BASE_URL}/index.html`; }
  function getAppUrl()   { return `${CONFIG.SITE_BASE_URL}/app.html`; }

  function setMessage(message, type = '') {
    const el = document.getElementById('authMessage');
    if (!el) return;
    el.textContent = message || '';
    el.className = 'auth-message' + (type ? ` is-${type}` : '');
  }

  function escapeHtml(v) {
    return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  /* ── 현재 의원 컨텍스트 ───────────────────────── */

  function getCurrentOrgId() {
    return localStorage.getItem(ORG_KEY) || null;
  }

  function setCurrentOrgId(orgId) {
    clearSessionCache(); // 의원 컨텍스트가 바뀌면 캐시된 세션(메모리+sessionStorage)은 더 이상 유효하지 않다
    // 임포마네이션 세션은 시작할 때의 조직에만 유효하다 — 다른 조직으로 전환하거나
    // 컨텍스트를 비우면(로그아웃 등) 남아있던 세션 기록은 더 이상 의미가 없으므로 같이 지운다.
    try {
      const raw = localStorage.getItem('maneasy-impersonation');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.orgId !== orgId) localStorage.removeItem('maneasy-impersonation');
      }
    } catch (e) {}
    if (orgId) localStorage.setItem(ORG_KEY, orgId);
    else localStorage.removeItem(ORG_KEY);
  }

  /** 내가 소속된 의원 목록 (org_id, org_name, role, logo_url, primary_color) */
  async function getMyOrgs() {
    // org_members의 RLS는 "그 의원 소속이면 의원 내 다른 사람 행도 조회 가능"(is_org_member(org_id))
    // 조건이라, user_id 필터를 안 걸면 같은 의원의 다른 활성 멤버 행까지 "내가 속한 의원"으로
    // 잘못 집계된다 (실제로 이 버그로 의원이 1개뿐인 사용자에게도 의원 선택 화면이 떴었음).
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session) return [];
    const { data, error } = await supabaseClient
      .from('org_members')
      .select('org_id, role, clinics!org_members_org_id_fkey(id, org_name, logo_url, primary_color, is_active)')
      .eq('user_id', session.user.id)
      .eq('active', true);
    if (error) { console.warn('[auth] getMyOrgs error:', error); return []; }
    return (data || [])
      .filter(m => m.clinics && m.clinics.is_active)
      .map(m => ({
        org_id: m.org_id,
        role: m.role,
        org_name: m.clinics.org_name,
        logo_url: m.clinics.logo_url,
        primary_color: m.clinics.primary_color,
      }));
  }

  /** 초대코드로 의원에 합류 */
  async function redeemInviteCode(code) {
    const { data, error } = await supabaseClient.rpc('redeem_invite_code', { p_code: code });
    if (error) return { success: false, error: error.message };
    return data; // { success, org_id?, role?, error? }
  }

  /** ensure_org_admin_account RPC 결과(가상 admin 계정의 org_members.id)를 세션스토리지에 캐시.
   *  의원마다 다르므로 orgId를 캐시 키에 포함한다. checkPlatformAdminCached와 같은 이유로 캐시함 —
   *  이미 있으면 RPC가 그냥 기존 id를 반환하지만, 페이지 전환마다 매번 왕복할 필요는 없다. */
  async function ensurePlatformSystemAccountCached(orgId) {
    const cacheKey = 'maneasy-preview-admin-' + orgId;
    const cached = sessionStorage.getItem(cacheKey);
    if (cached) return cached;
    const { data, error } = await supabaseClient.rpc('ensure_org_admin_account', { p_org_id: orgId });
    if (error) { console.error('[ensurePlatformSystemAccountCached] 실패:', error.message); return null; }
    if (data) sessionStorage.setItem(cacheKey, data);
    return data;
  }

  /** is_platform_admin() RPC 호출 결과를 세션스토리지에 캐시.
   *  이 값은 로그인 세션 동안 바뀌지 않으므로, getSession()이 페이지 이동(iframe 전환)마다
   *  매번 새로 호출되는 것과 달리 이 RPC까지 매번 왕복하면 안 된다 — 실제로 매 페이지 진입마다
   *  불필요한 네트워크 왕복이 하나 늘어 체감 지연(스피너 뜨기 전 멈칫함)의 원인이 됐었다.
   *  sessionStorage는 같은 출처의 iframe들과 공유되므로 탭 하나에서 한 번만 확인하면 된다. */
  async function checkPlatformAdminCached() {
    const cacheKey = 'maneasy-is-platform-admin';
    const cached = sessionStorage.getItem(cacheKey);
    if (cached !== null) return cached === '1';
    const { data } = await supabaseClient.rpc('is_platform_admin');
    const result = !!data;
    sessionStorage.setItem(cacheKey, result ? '1' : '0');
    return result;
  }

  /* ── 세션 ─────────────────────────────────────── */

  /**
   * 현재 로그인 사용자 + 현재 의원 컨텍스트를 합친 세션 객체를 반환.
   * org_id가 아직 정해지지 않았거나(0/2개 이상 소속) 더 이상 유효하지 않으면
   * org_id/role은 null로 온다 — 호출부(각 페이지)는 이 경우 정상 동작을 기대하면 안 되고,
   * requireAuth()가 자동으로 로그인 화면의 의원 선택 단계로 돌려보낸다.
   */
  // requireAuth()가 이미 getSession()을 한 번 계산해두고도 raw session만 반환하는 바람에,
  // 페이지 스크립트들이 관례적으로 requireAuth() 다음에 getSession()을 또 불러 완전히
  // 동일한 조회(profiles → org_members → clinics/departments)를 처음부터
  // 다시 수행하고 있었다 — 페이지 하나 뜨는 데 이 체인이 여러 번 반복되며 체감 지연의
  // 실질적인 주범이었다.
  //
  // 메모리 변수만으로는 "같은 페이지 로드 안에서 여러 번 부르는 것"만 막을 수 있고,
  // app.html(껍데기) → pages/*.html(iframe 콘텐츠)처럼 페이지가 바뀌면(=새 JS 컨텍스트)
  // 다시 처음부터 조회하게 된다. 실측(HAR)해보니 이 조합만으로도 페이지 이동 한 번에
  // 체인이 2번(쉘 1번 + iframe 1번) 나가고 있었다. 그래서 sessionStorage에도 같이
  // 캐시해서, 같은 탭 안에서는 쉘이든 iframe이든 어느 페이지가 먼저 계산해두었든
  // 그 결과를 그대로 재사용한다. 60초 TTL — 권한/소속이 바뀌는 일은 흔치 않고,
  // 그 안에 바뀌어도 사이드바의 "캐시 클리어" 버튼으로 즉시 무효화 가능하다.
  const SESSION_CACHE_KEY = 'maneasy-session-cache';
  const SESSION_CACHE_TTL_MS = 60000;
  let _sessionCache = null;

  function _readSessionCacheStorage(authUserId) {
    try {
      const raw = sessionStorage.getItem(SESSION_CACHE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || (Date.now() - parsed.ts) > SESSION_CACHE_TTL_MS) return null;
      if (parsed.orgId !== getCurrentOrgId()) return null; // 의원 컨텍스트 불일치 시 무시
      // 로그아웃 후 다른 계정으로 로그인해도 orgId가 같으면(흔한 케이스: 의원이 1개뿐인 데모 환경)
      // 위 orgId 체크만으론 캐시를 통과해버려 이전 계정의 세션 데이터가 그대로 재사용되는
      // 문제가 있었다 — 실제 로그인된 auth 사용자 id까지 같이 맞는지 반드시 확인한다.
      if (!parsed.user || parsed.user.id !== authUserId) return null;
      return parsed.user;
    } catch(e) { return null; }
  }

  function _writeSessionCacheStorage(user) {
    try {
      sessionStorage.setItem(SESSION_CACHE_KEY, JSON.stringify({
        ts: Date.now(), orgId: getCurrentOrgId(), user: user
      }));
    } catch(e) {}
  }

  function clearSessionCache() {
    _sessionCache = null;
    try { sessionStorage.removeItem(SESSION_CACHE_KEY); } catch(e) {}
  }

  function getSession() {
    if (_sessionCache) return _sessionCache;

    _sessionCache = (async function() {
      // 캐시를 신뢰하기 전에 "지금 실제로 로그인된 사용자가 누구인지"부터 확인한다.
      // supabaseClient.auth.getSession()은 로컬에 저장된 토큰을 읽는 것이라 보통 네트워크
      // 왕복 없이 즉시 반환되므로, 매번 확인해도 캐시를 두는 의미(반복 쿼리 방지)는 그대로 유지된다.
      const { data: { session } } = await supabaseClient.auth.getSession();
      if (!session) return null;

      const stored = _readSessionCacheStorage(session.user.id);
      if (stored) return stored;

      const user = await _computeSession();
      if (user) _writeSessionCacheStorage(user);
      return user;
    })();
    return _sessionCache;
  }

  async function _computeSession() {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session) return null;

    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();

    let orgId = getCurrentOrgId();
    let role = null;
    let orgName = '';
    let pagePerms = null;
    let isPreview = false;
    let isPlatformAdmin = false;
    let memberOrgMemberId = null;   // 실제 소속원일 때의 org_members.id
    let previewOrgMemberId = null;  // 미리보기일 때 대신 쓰는 가상 admin 계정의 org_members.id

    let clinicCode = '', clinicName = '', teamCode = '', teamName = '', teamGroupCode = '', department = '';
    let logoUrl = '', primaryColor = '';
    let aiAssistantEnabled = false;
    let approvalEnabled = false;
    let hrEnabled = false;
    let committeeEnabled = false;
    let messengerEnabled = false;
    let memberClinicId = null, memberDeptId = null;
    let isEquipmentManager = false, isSignageManager = false, isQcManager = false;

    if (orgId) {
      const { data: member, error: memberErr } = await supabaseClient
        .from('org_members')
        .select('id, role, page_perms, clinic_id, dept_id, is_equipment_manager, is_signage_manager, is_qc_manager, clinics!org_members_org_id_fkey(clinic_code, clinic_name, org_name, is_active, logo_url, primary_color, feature_flags), departments!org_members_dept_id_fkey(dept_code, dept_name, team_group_code)')
        .eq('org_id', orgId).eq('user_id', session.user.id).eq('active', true)
        .maybeSingle();
      // 예전엔 error를 아예 안 보고 data(=member)만 썼다 — 쿼리 자체가 오류로 실패해도
      // "멤버가 아님"과 똑같이(else 분기로) 처리돼서 orgId가 null로 리셋되고, 다음 로드에서
      // resolve_org=1로 돌아가 다시 같은 오류로 실패하는 무한 리다이렉트 루프에 빠질 수 있었다.
      // 실제 오류는 "소속 아님"과 다르게 취급해서 무한 루프 대신 명확히 실패시킨다.
      if (memberErr) {
        console.error('[auth] org_members 조회 실패 — orgId를 리셋하지 않고 세션 조회를 실패 처리합니다:', memberErr);
        return null;
      }
      // 의원 자체가 정지(clinics.is_active=false)된 경우 — org_members는 active여도
      // 로그인을 막아야 한다. 그렇지 않으면 이미 로그인해 캐시된 세션(localStorage의
      // 선택 의원)을 가진 사용자는 정지 이후에도 계속 접근 가능해져서 "정지" 기능이
      // 무력화된다. 멤버가 없는 경우와 동일하게 처리해 재선택 화면으로 돌려보낸다.
      if (member && member.clinics && member.clinics.is_active === false) {
        setCurrentOrgId(null);
        orgId = null;
      } else if (member) {
        memberOrgMemberId = member.id;
        role = member.role;
        orgName = member.clinics?.org_name || '';
        logoUrl = member.clinics?.logo_url || '';
        primaryColor = member.clinics?.primary_color || '';
        aiAssistantEnabled = !!member.clinics?.feature_flags?.ai_assistant;
        approvalEnabled = !!member.clinics?.feature_flags?.approval;
        hrEnabled = !!member.clinics?.feature_flags?.hr;
        committeeEnabled = !!member.clinics?.feature_flags?.committee;
        messengerEnabled = !!member.clinics?.feature_flags?.messenger;
        pagePerms = member.page_perms || null;
        clinicCode = member.clinics?.clinic_code || '';
        clinicName = member.clinics?.clinic_name || '';
        teamCode = member.departments?.dept_code || '';
        teamName = member.departments?.dept_name || '';
        teamGroupCode = member.departments?.team_group_code || '';
        memberClinicId = member.clinic_id || null;
        memberDeptId = member.dept_id || null;
        isEquipmentManager = !!member.is_equipment_manager;
        isSignageManager = !!member.is_signage_manager;
        isQcManager = !!member.is_qc_manager;
        department = [clinicName, teamName].filter(Boolean).join(' / ');
        // 실제 소속 멤버라도 플랫폼 관리자 계정일 수 있으므로 별도로 확인해둔다
        // (의원 미리보기 여부와 무관하게 "플랫폼 관리자 페이지로 돌아가기" 버튼 노출 판단에 사용).
        isPlatformAdmin = await checkPlatformAdminCached();
      } else {
        // 실제 소속(org_members)은 아니지만, 플랫폼 관리자가 "선택한 의원으로 앱 보기"로
        // 들어온 경우일 수 있다 — 이 경우엔 선택을 무효화하지 않고 admin 권한으로 미리보기시킨다.
        isPlatformAdmin = await checkPlatformAdminCached();
        if (isPlatformAdmin) {
          const { data: org } = await supabaseClient
            .from('clinics').select('org_name, logo_url, primary_color, feature_flags').eq('id', orgId).maybeSingle();
          if (org) {
            role = 'admin';
            orgName = org.org_name;
            logoUrl = org.logo_url || '';
            primaryColor = org.primary_color || '';
            aiAssistantEnabled = !!org.feature_flags?.ai_assistant;
            approvalEnabled = !!org.feature_flags?.approval;
            hrEnabled = !!org.feature_flags?.hr;
            committeeEnabled = !!org.feature_flags?.committee;
            messengerEnabled = !!org.feature_flags?.messenger;
            isPreview = true;

            // 미리보기는 org_members 행이 없어서 clinic_code/team_code뿐 아니라, 이 세션의
            // "구성원 id" 자체가 없다 — 그래서 org_members.id를 필요로 하는 화면(연차/전자결재 등,
            // resolveMyContext류)이 전부 "의원 구성원 정보를 확인할 수 없습니다"로 막혔었다.
            // 그렇다고 실제 운영 계정을 빌려 쓰면 미리보기 중 만든 테스트 데이터가 진짜 데이터와
            // 섞여버리므로, 의원마다 격리된 "가상 admin 계정"을 하나 두고(없으면 즉시 생성)
            // 그 계정으로 접속한 것처럼 처리한다. 이 계정은 auth.users.banned_until이 먼 미래로
            // 설정돼 있어 실제 로그인은 불가능하고, org_members.is_platform_system_account=true라
            // 구성원 목록 등 실사용자 화면에서 걸러진다.
            previewOrgMemberId = await ensurePlatformSystemAccountCached(orgId);

            // 시스템 계정 자체의 소속 정보(의원/부서)를 그대로 가져다 쓴다 — 이 계정의
            // clinic_id/dept_id가 이미 정확하게 연결돼 있으므로 별도로 "첫 번째 의원",
            // "숨김 부서 찾기/만들기" 쿼리를 또 할 필요가 없다(중복이었고, 한쪽만 고쳐서
            // clinic_id가 비어있는 부서가 남아있었던 적도 있었다).
            if (previewOrgMemberId) {
              const { data: acctDetail } = await supabaseClient
                .from('org_members_detail')
                .select('clinic_code, clinic_name, dept_code, dept_name, team_group_code')
                .eq('id', previewOrgMemberId).maybeSingle();
              if (acctDetail) {
                clinicCode = acctDetail.clinic_code || '';
                clinicName = acctDetail.clinic_name || '';
                teamCode = acctDetail.dept_code || '';
                teamName = acctDetail.dept_name || '';
                teamGroupCode = acctDetail.team_group_code || '';
              }
            }
            department = [clinicName, teamName].filter(Boolean).join(' / ');
          } else {
            setCurrentOrgId(null);
            orgId = null;
          }
        } else {
          setCurrentOrgId(null);
          orgId = null;
        }
      }
    } else {
      isPlatformAdmin = await checkPlatformAdminCached();
    }

    return {
      id:          session.user.id,
      email:       session.user.email,
      user_name:   profile?.user_name || session.user.email,
      phone:       profile?.phone || '',
      favorites:   profile?.favorites || null,
      org_id:      orgId,
      org_member_id: isPreview ? previewOrgMemberId : memberOrgMemberId, // resolveMyContext류가 이걸 우선 쓰면 별도 조회가 필요 없다
      role:        role,
      org_name:    orgName,
      is_preview:  isPreview,  // 플랫폼 관리자가 실제 소속 없이 "의원 미리보기"로 들어온 경우 true
      is_platform_admin: isPlatformAdmin, // 플랫폼 관리자 계정 여부 (의원 미리보기 여부와 무관)
      logo_url:    logoUrl,
      primary_color: primaryColor,
      ai_assistant_enabled: aiAssistantEnabled,
      approval_enabled: approvalEnabled,
      hr_enabled: hrEnabled,
      committee_enabled: committeeEnabled,
      messenger_enabled: messengerEnabled,
      clinic_id: memberClinicId, dept_id: memberDeptId,
      is_equipment_manager: isEquipmentManager, is_signage_manager: isSignageManager, is_qc_manager: isQcManager,
      page_perms:  pagePerms,   // assets/js/core/permissions.js(PagePerms)가 이 필드를 기준으로 판단
      clinic_code: clinicCode, clinic_name: clinicName,
      team_code:   teamCode,   team_name:   teamName,
      team_group_code: teamGroupCode, department: department,
    };
  }

  async function clearSession() {
    try {
      await supabaseClient.auth.signOut({ scope: 'local' });
    } catch(e) {
      console.warn('[auth] signOut error:', e);
    }
    setCurrentOrgId(null);
    // localStorage 세션 키 직접 제거 (iframe 공유 키 포함)
    try {
      localStorage.removeItem('maneasy-auth');
      // Supabase가 내부적으로 쓰는 키들도 제거
      Object.keys(localStorage).forEach(function(k) {
        if (k.startsWith('sb-') || k.startsWith('supabase')) {
          localStorage.removeItem(k);
        }
      });
    } catch(e) {}
    // checkPlatformAdminCached()의 캐시도 같이 지운다 — 안 지우면 같은 탭에서 다른 계정으로
    // 다시 로그인했을 때 이전 계정의 플랫폼 관리자 여부가 잘못 남아있게 된다.
    try { sessionStorage.removeItem('maneasy-is-platform-admin'); } catch(e) {}
    // 유휴 타이머 기록도 같이 지운다 — 안 지우면 다음 로그인 때 예전 활동 시각이 남아있어
    // 로그인하자마자 "유휴 시간 초과"로 잘못 튕겨나갈 수 있다.
    try { localStorage.removeItem(ACTIVITY_KEY); } catch(e) {}
  }

  /* ── 인증 가드 ─────────────────────────────────── */

  /** 로그인 + 의원 선택까지 완료된 상태를 요구. 아니면 로그인 화면으로 돌려보낸다. */
  async function requireAuth() {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session) { location.replace(getLoginUrl()); return null; }

    if (getIdleElapsedMs() > IDLE_LIMIT_MS) {
      // 마지막 활동으로부터 1시간 이상 지남 — 무조건 로그아웃시킨다.
      try { localStorage.removeItem(ACTIVITY_KEY); } catch (_e) {}
      await supabaseClient.auth.signOut();
      setCurrentOrgId(null);
      location.replace(getLoginUrl() + '?idle_timeout=1');
      return null;
    }
    markActivity(); // 정상 통과 = 지금 이 순간도 활동이므로 시각 갱신

    const user = await getSession();
    if (!user) {
      // getSession()이 null이면 인증 세션 자체가 없거나, org_members 조회 중 실제 오류가
      // 난 경우다. 이때 orgId를 그대로 두고 로그인 페이지로 보내면, index.html은 orgId가
      // 남아있는 것만 보고 재확인 없이 곧장 app.html로 다시 돌려보내서(bounce) — 여기서
      // 다시 같은 오류가 나고 또 되돌아오는 무한 루프가 된다. 반드시 orgId부터 지운다.
      setCurrentOrgId(null);
      location.replace(getLoginUrl());
      return null;
    }
    if (!user.org_id) {
      location.replace(getLoginUrl() + '?resolve_org=1');
      return null;
    }
    return session;
  }

  async function requireAdmin() {
    const session = await requireAuth();
    if (!session) return null;
    const user = await getSession();
    if (user.role !== 'admin') {
      alert('의원 관리자 권한이 필요합니다.');
      location.replace(getAppUrl());
      return null;
    }
    return session;
  }

  /* ── 로그인 페이지 ─────────────────────────────── */

  async function initLoginPage() {
    // ?type=recovery — 비밀번호 재설정 링크 클릭 후 진입 (예전 방식: 해시에 access_token 포함).
    // 이 체크는 반드시 세션 여부 판단보다 먼저 와야 한다.
    const hashParams = new URLSearchParams(location.hash.slice(1));
    const isRecovery = hashParams.get('type') === 'recovery';
    // 재설정 링크가 만료됐거나(otp_expired) 이미 사용됐거나 무효한 경우, Supabase는
    // type=recovery 대신 #error=access_denied&error_code=otp_expired&error_description=...
    // 형태로 돌려보낸다. 이걸 별도로 감지하지 않으면 그냥 조용히 일반 로그인 화면으로
    // 넘어가버려서 "링크를 눌러도 계속 로그인 페이지로 튕긴다"는 증상으로 보인다.
    const linkError = hashParams.get('error') || hashParams.get('error_code');

    // ?token_hash=...&type=recovery — 새 방식(권장). send-recovery-email 함수가 이제
    // Supabase의 /verify 직행 링크(action_link) 대신 이 형태로 메일을 보낸다.
    // action_link는 클릭(GET) 즉시 1회용 토큰을 소비해버리는데, 회사 메일의 보안
    // 스캐너(Safe Links류)가 메일 도착 직후 링크를 자동으로 미리 열어보면서 토큰을 먼저
    // 써버려서, 정작 사용자 본인이 클릭했을 땐 "만료/무효" 처리되는 문제가 실제로 있었다.
    // token_hash 방식은 페이지 로딩 자체로는 아무것도 소비하지 않고, 사용자가 화면의
    // 버튼을 직접 눌러야만 verifyOtp()가 호출되어 토큰이 소비되므로 자동 프리페치로는
    // 무력화되지 않는다.
    const searchParamsForRecovery = new URLSearchParams(location.search);
    const recoveryTokenHash = searchParamsForRecovery.get('token_hash');
    const isRecoveryPending = !!recoveryTokenHash && searchParamsForRecovery.get('type') === 'recovery';

    // ?token_hash=...&type=signup — send-signup-confirmation-email 함수가 보내는 가입 확인
    // 링크. recovery와 완전히 같은 이유로 같은 방식(페이지 로딩만으로는 소비 안 됨, 버튼을
    // 직접 눌러야 verifyOtp 호출)을 그대로 쓴다.
    const signupTokenHash = searchParamsForRecovery.get('token_hash');
    const isSignupPending = !!signupTokenHash && searchParamsForRecovery.get('type') === 'signup';

    const tabLogin    = document.getElementById('tabLogin');
    const tabSignup    = document.getElementById('tabSignup');
    const tabReset     = document.getElementById('tabReset');
    const tabBar       = document.querySelector('.auth-tab-bar');
    const panelLogin   = document.getElementById('panelLogin');
    const panelSignup  = document.getElementById('panelSignup');
    const panelReset   = document.getElementById('panelReset');
    const panelInvite  = document.getElementById('panelInvite');
    const panelOrgPick = document.getElementById('panelOrgPick');
    const panelSignupConfirm = document.getElementById('panelSignupConfirm');
    const panelSignupSent = document.getElementById('panelSignupSent');

    const ALL_PANELS = [panelLogin, panelSignup, panelReset, panelInvite, panelOrgPick, panelSignupConfirm, panelSignupSent];
    const ALL_TABS   = [tabLogin, tabSignup, tabReset];

    function showTab(tab) {
      if (tabBar) tabBar.style.display = '';
      ALL_TABS.forEach(t => t?.classList.remove('is-active'));
      ALL_PANELS.forEach(p => { if (p) p.style.display = 'none'; });
      if (tab === 'login')  { tabLogin?.classList.add('is-active');  if (panelLogin)  panelLogin.style.display  = ''; }
      if (tab === 'signup') { tabSignup?.classList.add('is-active'); if (panelSignup) panelSignup.style.display = ''; }
      if (tab === 'reset')  { tabReset?.classList.add('is-active');  if (panelReset)  panelReset.style.display  = ''; }
      setMessage('', '');
    }

    function showStep(panel) {
      if (tabBar) tabBar.style.display = 'none';
      ALL_PANELS.forEach(p => { if (p) p.style.display = 'none'; });
      if (panel) panel.style.display = '';
      setMessage('', '');
    }

    function showResetStep(step) {
      // step: 0(확인버튼) | 1(이메일 입력) | 2(새 비밀번호 입력)
      const s0 = document.getElementById('resetStep0');
      const s1 = document.getElementById('resetStep1');
      const s2 = document.getElementById('resetStep2');
      if (s0) s0.style.display = step === 0 ? '' : 'none';
      if (s1) s1.style.display = step === 1 ? '' : 'none';
      if (s2) s2.style.display = step === 2 ? '' : 'none';
    }

    async function resolveOrgAndEnter() {
      if (typeof showGlobalLoading === 'function') showGlobalLoading('의원 정보를 확인하는 중...');

      // 플랫폼 관리자는 특정 의원에 소속되어 있어도(예: 데모 의원의 실제 admin이기도 한 경우)
      // 로그인하면 항상 플랫폼 관리 페이지로 먼저 보낸다. 특정 의원으로 들어가는 건
      // 거기서 "이 의원으로 앱 보기"를 눌렀을 때만 일어나야 하는 명시적 행동이어야 하고,
      // 로그인 시점에 의원 자동입장/의원선택 화면으로 새는 건 사용자가 의도한 바가 아니다.
      const isPlatformAdmin = await checkPlatformAdminCached();
      if (isPlatformAdmin) {
        if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
        location.replace(`${CONFIG.SITE_BASE_URL}/platform-admin.html`);
        return;
      }

      const orgs = await getMyOrgs();

      if (orgs.length === 0) {
        if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
        showStep(panelInvite);
        return;
      }
      if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
      if (orgs.length === 1) {
        setCurrentOrgId(orgs[0].org_id);
        if (typeof systemLog === 'function') {
          await systemLog('LOGIN', '로그인 (' + orgs[0].org_name + ')').catch(() => {});
        }
        location.replace(getAppUrl());
        return;
      }
      const list = document.getElementById('orgPickList');
      if (list) {
        list.innerHTML = orgs.map(o => `
          <button type="button" class="auth-org-pick-btn" data-org="${o.org_id}">
            <span style="display:flex;align-items:center;gap:10px;min-width:0;">
              ${o.logo_url ? `<img src="${escapeHtml(o.logo_url)}" alt="" class="auth-org-pick-logo" />` : ''}
              <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(o.org_name)}</span>
            </span>
            <span style="font-size:11px;color:#9ca3af;flex-shrink:0;">${o.role === 'admin' ? '관리자' : '구성원'}</span>
          </button>`).join('');
        list.querySelectorAll('[data-org]').forEach(btn => {
          btn.addEventListener('click', async () => {
            setCurrentOrgId(btn.dataset.org);
            if (typeof systemLog === 'function') await systemLog('LOGIN', '로그인 (의원 선택)').catch(() => {});
            location.replace(getAppUrl());
          });
        });
      }
      showStep(panelOrgPick);
    }

    const urlParams = new URLSearchParams(location.search);
    if (isRecovery || linkError || isRecoveryPending || isSignupPending) {
      // 재설정/가입확인 흐름(성공/만료/대기 모두) 중엔 기존 세션 유무와 상관없이 절대 앱으로 리다이렉트하지 않는다.
    } else if (urlParams.get('logout') === '1') {
      history.replaceState(null, '', location.pathname);
    } else if (urlParams.get('idle_timeout') === '1') {
      setMessage('장시간 활동이 없어 자동으로 로그아웃되었습니다. 다시 로그인해 주세요.', 'error');
      history.replaceState(null, '', location.pathname);
    } else if (urlParams.get('resolve_org') === '1') {
      const { data: { session } } = await supabaseClient.auth.getSession();
      if (session) { await resolveOrgAndEnter(); return; }
    } else {
      const { data: { session } } = await supabaseClient.auth.getSession();
      if (session) {
        // requireAuth()(app.html 쪽)에만 유휴시간 체크가 있으면, 로그인 페이지가 세션
        // 유효성만 보고 바로 리다이렉트하는 이 경로는 그 체크를 거치지 않고 넘어갈 수
        // 있다 — 여기서도 똑같이 확인해서, 유휴 상태인 세션은 리다이렉트하지 않고 바로
        // 로그아웃시킨다(로그인 폼을 다시 보여준다).
        if (getIdleElapsedMs() > IDLE_LIMIT_MS) {
          try { localStorage.removeItem(ACTIVITY_KEY); } catch (_e) {}
          await supabaseClient.auth.signOut();
          setCurrentOrgId(null);
          setMessage('장시간 활동이 없어 자동으로 로그아웃되었습니다. 다시 로그인해 주세요.', 'error');
        } else {
          markActivity();
          const orgId = getCurrentOrgId();
          if (orgId) { location.replace(getAppUrl()); return; }
          await resolveOrgAndEnter();
          return;
        }
      }
    }

    tabLogin?.addEventListener('click',  () => showTab('login'));
    tabSignup?.addEventListener('click', () => showTab('signup'));
    tabReset?.addEventListener('click',  () => { showTab('reset'); showResetStep(1); });

    if (isRecoveryPending) {
      // 새 방식 — 아직 토큰을 소비하지 않은 상태. 확인 버튼을 눌러야 다음 단계로 진행.
      showTab('reset');
      showResetStep(0);
    } else if (isSignupPending) {
      showStep(panelSignupConfirm);
    } else if (isRecovery) {
      // (해시는 함수 맨 위에서 이미 읽어둔 hashParams/isRecovery를 그대로 사용)
      // 예전 방식 호환 — supabase.js에서 detectSessionInUrl: false로 꺼놨기 때문에,
      // 여기서 URL 해시의 access_token/refresh_token을 직접 읽어 세션을 수동으로
      // 세팅해줘야 updateUser()가 동작한다.
      showTab('reset');
      showResetStep(2);

      const access_token  = hashParams.get('access_token');
      const refresh_token = hashParams.get('refresh_token');
      if (access_token && refresh_token) {
        const { error: sessErr } = await supabaseClient.auth.setSession({ access_token, refresh_token });
        if (sessErr) setMessage('재설정 링크가 만료됐거나 유효하지 않습니다. 다시 요청해 주세요.', 'error');
      } else {
        setMessage('재설정 링크가 올바르지 않습니다. 다시 요청해 주세요.', 'error');
      }
    } else if (linkError) {
      // 링크가 만료됐거나(otp_expired) 이미 사용된 경우 — 재설정 요청 화면(1단계)을 보여주고
      // 왜 실패했는지 명확히 안내한다.
      showTab('reset');
      showResetStep(1);
      const errCode = hashParams.get('error_code') || '';
      const msg = errCode === 'otp_expired'
        ? '재설정 링크가 만료됐거나 이미 사용됐습니다. 다시 요청해 주세요.'
        : '재설정 링크가 유효하지 않습니다. 다시 요청해 주세요.';
      setMessage(msg, 'error');
      history.replaceState(null, '', location.pathname); // 에러 해시 제거
    } else {
      showTab('login');
    }

    // ?token_hash 방식의 확인 버튼 — 사용자가 명시적으로 눌러야만 토큰을 소비한다.
    document.getElementById('resetConfirmLinkBtn')?.addEventListener('click', async function() {
      this.disabled = true;
      setMessage('', '');
      // doLogin()과 동일한 이유 — verifyOtp도 새 세션을 만드는 로그인 경로라, 이전 계정의
      // 플랫폼 관리자 캐시가 남아있으면 새 계정에 잘못 적용될 수 있다.
      try { sessionStorage.removeItem('maneasy-is-platform-admin'); } catch(e) {}
      const { error: verifyErr } = await supabaseClient.auth.verifyOtp({
        token_hash: recoveryTokenHash,
        type: 'recovery',
      });
      if (verifyErr) {
        setMessage('재설정 링크가 만료됐거나 이미 사용됐습니다. 다시 요청해 주세요.', 'error');
        showResetStep(1);
        history.replaceState(null, '', location.pathname); // 쿼리 파라미터 제거
        this.disabled = false;
        return;
      }
      history.replaceState(null, '', location.pathname); // 쿼리 파라미터 제거
      showResetStep(2);
    });

    document.getElementById('signupConfirmLinkBtn')?.addEventListener('click', async function() {
      this.disabled = true;
      setMessage('', '');
      try { sessionStorage.removeItem('maneasy-is-platform-admin'); } catch(e) {}
      const { error: verifyErr } = await supabaseClient.auth.verifyOtp({
        token_hash: signupTokenHash,
        type: 'signup',
      });
      history.replaceState(null, '', location.pathname); // 쿼리 파라미터 제거
      if (verifyErr) {
        setMessage('인증 링크가 만료됐거나 이미 사용됐습니다. 같은 이메일로 다시 가입해 주세요.', 'error');
        showTab('login');
        this.disabled = false;
        return;
      }
      // verifyOtp 성공 시 세션이 바로 생긴다 — 소속 조직 여부에 따라 초대코드 입력/조직 선택/앱 진입으로 이어감.
      await resolveOrgAndEnter();
    });

    /* ── 비밀번호 재설정 ── */
    document.getElementById('resetSendBtn')?.addEventListener('click', async function() {
      const email = document.getElementById('resetEmail')?.value?.trim();
      if (!email) return setMessage('이메일을 입력해 주세요.', 'error');
      setLoading(this, true, '발송 중...');
      setMessage('', '');
      const redirectTo = location.origin + location.pathname;
      const { data, error } = await supabaseClient.functions.invoke('send-recovery-email', {
        body: { email, redirectTo },
      });
      setLoading(this, false);
      if (error || !data?.success) return setMessage('발송 실패: ' + (error?.message || '알 수 없는 오류'), 'error');
      setMessage('해당 이메일 계정이 존재하면 재설정 링크가 발송됩니다. 메일함을 확인해 주세요.', 'success');
    });

    document.getElementById('resetConfirmBtn')?.addEventListener('click', async function() {
      const pw  = document.getElementById('newPassword')?.value?.trim();
      const pw2 = document.getElementById('newPassword2')?.value?.trim();
      if (!pw || pw.length < 6) return setMessage('비밀번호를 6자 이상 입력해 주세요.', 'error');
      if (pw !== pw2) return setMessage('비밀번호가 일치하지 않습니다.', 'error');
      this.disabled = true;
      const { error } = await supabaseClient.auth.updateUser({ password: pw });
      this.disabled = false;
      if (error) return setMessage('변경 실패: ' + error.message, 'error');
      setMessage('비밀번호가 변경됐습니다. 로그인해 주세요.', 'success');
      setTimeout(() => { showTab('login'); history.replaceState(null, '', location.pathname); }, 2000);
    });

    /* ── 로그인 ── */
    const loginBtn      = document.getElementById('loginBtn');
    const emailInput    = document.getElementById('userEmail');
    const passwordInput = document.getElementById('userPassword');

    async function doLogin() {
      const email    = emailInput?.value?.trim();
      const password = passwordInput?.value?.trim();
      if (!email)    return setMessage('이메일을 입력해 주세요.', 'error');
      if (!password) return setMessage('비밀번호를 입력해 주세요.', 'error');

      // 로그아웃을 거치지 않고 같은 탭에서 바로 다른 계정으로 로그인하는 경우를 대비해,
      // 로그인 시도 직전에 이전 계정의 플랫폼 관리자 캐시를 항상 지운다 — 안 그러면
      // 이전 계정이 플랫폼 관리자였을 때 그 캐시가 새 계정에도 잘못 적용될 수 있다.
      try { sessionStorage.removeItem('maneasy-is-platform-admin'); } catch(e) {}

      loginBtn.disabled = true;
      setMessage('', '');
      if (typeof showGlobalLoading === 'function') showGlobalLoading('로그인 중...');

      const { error } = await supabaseClient.auth.signInWithPassword({ email, password });
      if (error) {
        if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
        setMessage('이메일 또는 비밀번호가 올바르지 않습니다.', 'error');
        loginBtn.disabled = false;
        return;
      }

      if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
      loginBtn.disabled = false;
      markActivity(); // 새 로그인 — 유휴 타이머를 지금 시점부터 새로 시작
      await resolveOrgAndEnter();
    }
    loginBtn?.addEventListener('click', doLogin);
    emailInput?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); passwordInput?.focus(); } });
    passwordInput?.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

    /* ── 회원가입 (의원 소속은 별도 — 가입 후 초대코드 입력으로 이어짐) ── */
    const signupBtn       = document.getElementById('signupBtn');
    const signupEmail     = document.getElementById('signupEmail');
    const signupPassword  = document.getElementById('signupPassword');
    const signupPassword2 = document.getElementById('signupPassword2');
    const signupName      = document.getElementById('signupName');

    async function doSignup() {
      const email  = signupEmail?.value?.trim();
      const pw1    = signupPassword?.value?.trim();
      const pw2    = signupPassword2?.value?.trim();
      const name   = signupName?.value?.trim();

      if (!name)          return setMessage('이름을 입력해 주세요.', 'error');
      if (!email)         return setMessage('이메일을 입력해 주세요.', 'error');
      if (!pw1)           return setMessage('비밀번호를 입력해 주세요.', 'error');
      if (pw1.length < 6) return setMessage('비밀번호는 6자 이상이어야 합니다.', 'error');
      if (pw1 !== pw2)    return setMessage('비밀번호가 일치하지 않습니다.', 'error');

      signupBtn.disabled = true;
      setMessage('', '');
      if (typeof showGlobalLoading === 'function') showGlobalLoading('가입 처리 중...');

      const redirectTo = location.origin + location.pathname;
      const { data, error } = await supabaseClient.functions.invoke('send-signup-confirmation-email', {
        body: { email, password: pw1, user_name: name, redirectTo },
      });

      if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
      signupBtn.disabled = false;

      if (error || data?.error) {
        // functions.invoke()는 4xx/5xx 응답을 FunctionsHttpError로 감싸는데, error.message는
        // "Edge Function returned a non-2xx status code"라는 뭉뚱그린 문구뿐이다 — 실제로
        // 서버가 보낸 상세 사유(예: "메일 발송 실패")는 error.context(Response 객체)에서
        // 따로 읽어야 한다.
        let detail = '';
        try {
          if (error?.context && typeof error.context.json === 'function') {
            const body = await error.context.json();
            detail = body?.error || '';
          }
        } catch (_e) { /* 본문 파싱 실패 시 아래 기본 메시지로 대체 */ }
        setMessage(detail || (data && data.error) || error?.message || '회원가입에 실패했습니다.', 'error');
        return;
      }

      const emailLine = document.getElementById('signupSentEmailLine');
      if (emailLine) emailLine.textContent = email + ' 로 인증 메일을 보냈어요.';
      showStep(panelSignupSent);
    }

    document.getElementById('signupSentToLoginBtn')?.addEventListener('click', () => showTab('login'));

    signupBtn?.addEventListener('click', doSignup);
    signupPassword2?.addEventListener('keydown', e => { if (e.key === 'Enter') doSignup(); });

    /* ── 초대코드 입력 ── */
    document.getElementById('inviteSubmitBtn')?.addEventListener('click', async function() {
      const code = document.getElementById('inviteCode')?.value?.trim();
      if (!code) return setMessage('초대코드를 입력해 주세요.', 'error');
      this.disabled = true;
      setMessage('', '');
      if (typeof showGlobalLoading === 'function') showGlobalLoading('초대코드 확인 중...');
      const result = await redeemInviteCode(code);
      if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
      this.disabled = false;
      if (!result.success) return setMessage(result.error || '초대코드 확인에 실패했습니다.', 'error');
      setCurrentOrgId(result.org_id);
      if (typeof systemLog === 'function') await systemLog('LOGIN', '초대코드로 의원 합류').catch(() => {});
      // 조직 admin들에게 새 구성원 합류 알림 — 실패해도 합류 자체는 이미 끝난 뒤라 조용히 넘어간다.
      supabaseClient.functions.invoke('join-notify', { body: { org_id: result.org_id } }).catch(function(e) {
        console.warn('[invite] 관리자 알림 메일 발송 실패:', e);
      });
      location.replace(getAppUrl());
    });
    document.getElementById('inviteLogoutBtn')?.addEventListener('click', async function() {
      await clearSession();
      location.replace(getLoginUrl() + '?logout=1');
    });

    document.getElementById('orgPickLogoutBtn')?.addEventListener('click', async function() {
      await clearSession();
      location.replace(getLoginUrl() + '?logout=1');
    });

    /* ── 캐시 초기화 ── */
    document.getElementById('clearCacheBtn')?.addEventListener('click', () => {
      localStorage.clear();
      sessionStorage.clear();
      location.reload();
    });
  }

  /* ── 로그아웃 ─────────────────────────────────── */

  async function logout() {
    await clearSession();
    setTimeout(function() {
      location.replace(getLoginUrl() + '?logout=1');
    }, 150);
  }

  /** 로그인은 유지한 채 다른 소속 의원으로 전환 (여러 의원 소속자용) */
  function switchOrg() {
    setCurrentOrgId(null);
    location.replace(getLoginUrl() + '?resolve_org=1');
  }

  /** 의원 브랜드 컬러(clinics.primary_color)를 CSS 변수 --brand-color로 반영.
   *  셸(app.html)과 iframe 콘텐츠 페이지가 각각 별개의 document라, 페이지마다
   *  getSession() 이후 한 번씩 호출해줘야 함(자동 전파되지 않음). */
  function applyBrandColor(color) {
    try {
      document.documentElement.style.setProperty('--brand-color', color || '#0a1e3d');
    } catch (e) { /* no-op */ }
  }

  /* ── 플랫폼 관리자 임포마네이션 세션 ──────────────────────────
   * "의원 미리보기"로 앱에 들어갈 때 실제 쓰기 권한(RLS)을 열어주는 세션을 함께 시작한다.
   * localStorage에 저장 — 셸(app.html)과 iframe 콘텐츠 페이지가 공유해서 배너를 같이 볼 수 있어야 함. */
  const IMPERSONATION_KEY = 'maneasy-impersonation';

  function getImpersonation() {
    try {
      const raw = localStorage.getItem(IMPERSONATION_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      // 저장된 조직 컨텍스트와 현재 선택된 조직이 다르면(예: 관리자가 다른 조직을 다시 선택) 무효
      if (parsed.orgId !== getCurrentOrgId()) return null;
      return parsed;
    } catch (e) { return null; }
  }

  function clearImpersonation() {
    try { localStorage.removeItem(IMPERSONATION_KEY); } catch (e) {}
  }

  /** 세션 시작 — 성공 시 로컬에 저장하고 저장된 객체를 반환, 실패 시 null.
   *  이미 같은 조직에 대한 활성 세션이 있으면 RPC가 그 세션을 그대로 재사용해서 돌려준다
   *  (재배포로 새로고침되거나 관리자 페이지를 갔다가 다시 들어와도 세션이 계속 늘어나지 않도록). */
  async function startImpersonation(orgId, reason) {
    const { data, error } = await supabaseClient.rpc('start_impersonation', {
      target_org_id: orgId, impersonation_reason: reason,
    });
    if (error || !data || !data[0]) {
      console.error('[auth] startImpersonation 실패:', error);
      return null;
    }
    const row = data[0];
    const record = {
      sessionId: row.session_id, orgId: orgId, reason: row.reason || reason,
      expiresAt: row.expires_at, startedAt: new Date().toISOString(),
    };
    try { localStorage.setItem(IMPERSONATION_KEY, JSON.stringify(record)); } catch (e) {}
    return record;
  }

  /** 세션 종료 — 지금까지 만든 데이터는 그대로 두고 쓰기 권한만 닫는다 */
  async function endImpersonation() {
    const cur = getImpersonation();
    if (!cur) return { success: true };
    const { error } = await supabaseClient.rpc('end_impersonation', { session_id: cur.sessionId });
    clearImpersonation();
    if (error) { console.error('[auth] endImpersonation 실패:', error); return { success: false, error: error.message }; }
    return { success: true };
  }

  /** 세션 중 발생시킨 데이터를 전부 되돌리고 세션도 종료한다 */
  async function rollbackImpersonation() {
    const cur = getImpersonation();
    if (!cur) return { success: false, error: '진행 중인 세션이 없습니다.' };
    const { data, error } = await supabaseClient.rpc('rollback_impersonation_session', { p_session_id: cur.sessionId });
    clearImpersonation();
    if (error) { console.error('[auth] rollbackImpersonation 실패:', error); return { success: false, error: error.message }; }
    return { success: true, revertedCount: data && data[0] ? data[0].reverted_count : 0 };
  }

  return {
    getSession, clearSession, clearSessionCache, requireAuth, requireAdmin, initLoginPage, logout,
    getCurrentOrgId, setCurrentOrgId, getMyOrgs, redeemInviteCode, switchOrg,
    applyBrandColor,
    getImpersonation, clearImpersonation, startImpersonation, endImpersonation, rollbackImpersonation,
  };
})();

/* ── 유휴시간(idle) 자동 로그아웃 ─────────────────────────────
 * 셸(app.html)과 iframe 콘텐츠 페이지가 이 스크립트를 모두 각자 로드하므로(별개의 document라
 * JS 변수를 직접 공유할 수 없음), "마지막 활동 시각"을 localStorage에 저장해 공유한다
 * (셸/iframe이 이미 storageKey 'maneasy-auth'를 공유하는 것과 같은 원리).
 * 활동 감지 자체는 모든 프레임(셸 + 현재 열려있는 iframe 콘텐츠 페이지)에서 각자 하지만,
 * 경고 모달 표시와 실제 로그아웃 판단은 최상위 프레임(window.self === window.top, 즉 셸이거나
 * 콘텐츠 페이지를 iframe 없이 단독으로 열었을 때)에서만 한다 — 안 그러면 셸과 iframe이 각자
 * 모달을 띄우거나 로그아웃을 중복 호출하게 된다.
 * 로그인 페이지(index.html, #loginBtn 존재)에서는 세션이 없으므로 아예 동작시키지 않는다.
 */
(function () {
  if (document.getElementById('loginBtn')) return; // 로그인 페이지는 제외

  var IDLE_TIMEOUT_MS   = 60 * 60 * 1000; // 1시간 — 이 시점에 실제 로그아웃
  var WARNING_BEFORE_MS = 60 * 1000;      // 로그아웃 1분 전부터 경고 모달 표시
  var CHECK_INTERVAL_MS = 1000;           // 1초마다 체크 (경고 모달 카운트다운용)
  var ACTIVITY_KEY = 'maneasy-last-activity';

  function markActivity() {
    try { localStorage.setItem(ACTIVITY_KEY, String(Date.now())); } catch (e) {}
  }

  function getLastActivity() {
    var v = null;
    try { v = localStorage.getItem(ACTIVITY_KEY); } catch (e) {}
    return v ? Number(v) : Date.now();
  }

  function hasSession() {
    try { return !!localStorage.getItem('maneasy-auth'); } catch (e) { return false; }
  }

  markActivity(); // 페이지 진입 자체도 활동으로 간주

  ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'].forEach(function (evt) {
    window.addEventListener(evt, markActivity, { passive: true });
  });

  if (window.self !== window.top) return; // 경고 모달/로그아웃 판단은 최상위 프레임에서만

  /* ── 경고 모달 ── */
  var modalEl = null;

  function buildModal() {
    var overlay = document.createElement('div');
    overlay.id = 'idleWarningOverlay';
    overlay.style.cssText =
      'position:fixed;inset:0;z-index:999999;background:rgba(11,22,48,0.45);' +
      'display:flex;align-items:center;justify-content:center;';

    var box = document.createElement('div');
    box.style.cssText =
      'background:#fff;border-radius:14px;box-shadow:0 20px 48px rgba(0,0,0,0.25);' +
      'padding:28px 32px;min-width:320px;max-width:360px;text-align:center;' +
      'font-family:inherit;';

    box.innerHTML =
      '<div style="font-size:32px;line-height:1;margin-bottom:12px;">\u23F0</div>' +
      '<div style="font-size:15px;font-weight:700;color:#111827;margin-bottom:8px;">장시간 활동이 없습니다</div>' +
      '<div style="font-size:13px;color:#6b7280;line-height:1.5;margin-bottom:4px;">' +
        '<span id="idleWarningCountdown">60</span>초 후 자동으로 로그아웃됩니다.' +
      '</div>' +
      '<div style="font-size:12px;color:#9ca3af;margin-bottom:18px;">계속 사용하시려면 아래 버튼을 눌러주세요.</div>' +
      '<button id="idleWarningContinueBtn" type="button" style="' +
        'background:#2563eb;color:#fff;border:none;border-radius:8px;' +
        'padding:9px 24px;font-size:13px;font-weight:700;cursor:pointer;">계속 사용하기</button>';

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    document.getElementById('idleWarningContinueBtn').addEventListener('click', function () {
      markActivity();
      hideModal();
    });

    return overlay;
  }

  function showModal(secondsLeft) {
    if (!modalEl) modalEl = buildModal();
    var countdownEl = document.getElementById('idleWarningCountdown');
    if (countdownEl) countdownEl.textContent = String(secondsLeft);
  }

  function hideModal() {
    if (modalEl && modalEl.parentNode) modalEl.parentNode.removeChild(modalEl);
    modalEl = null;
  }

  setInterval(function () {
    if (!hasSession()) { hideModal(); return; }

    var idleFor = Date.now() - getLastActivity();
    var remaining = IDLE_TIMEOUT_MS - idleFor;

    if (remaining <= 0) {
      hideModal();
      // window.auth.logout()은 일반 로그아웃(?logout=1)이라 "왜 로그아웃됐는지" 안내가
      // 없다 — 유휴시간 만료는 이유를 알려줘야 하므로 직접 세션만 지우고 idle_timeout=1로
      // 보낸다(로그인 페이지가 이 파라미터를 보고 "장시간 활동이 없어..." 메시지를 띄운다).
      if (window.auth && typeof window.auth.clearSession === 'function') {
        window.auth.clearSession().then(function () {
          location.replace(CONFIG.SITE_BASE_URL + '/index.html?idle_timeout=1');
        });
      }
    } else if (remaining <= WARNING_BEFORE_MS) {
      showModal(Math.ceil(remaining / 1000));
    } else {
      hideModal(); // 경고가 떠 있던 중 다른 탭/프레임에서의 활동 등으로 여유가 다시 생긴 경우
    }
  }, CHECK_INTERVAL_MS);
})();