/**
 * assets/js/core/permissions.js
 * 앱/페이지 단위 권한 판단 공용 모듈.
 *
 * 판단 순서 (페이지 키 단위로 개별 판단):
 *   1) user.page_perms에 해당 pageKey가 명시적으로 들어있으면 그 값을 그대로 쓴다
 *      (마스터 관리 > 사용자 화면에서 관리자가 그 페이지에 대해 직접 설정한 값).
 *   2) 없으면(관리자가 아직 그 페이지를 개별 설정한 적이 없으면) role(admin/user 등)의
 *      기본값(ROLE_DEFAULT_PAGES)으로 폴백한다.
 *   이렇게 페이지 키 단위로 판단해야, 앱에 새 페이지가 추가됐을 때 이미 커스텀 권한을
 *   가진 기존 사용자들이 그 페이지만 못 보는 문제(권한표에 아직 없는 페이지라서)가
 *   생기지 않는다. 기존에는 "커스텀 권한이 하나라도 있으면 그 안에 없는 페이지는 전부
 *   접근불가"였는데, 새 페이지 추가마다 재발하는 문제라 페이지 키 단위 폴백으로 바꿨다.
 *
 * ROLE_DEFAULT_PAGES는 이제 core/pages.js(PageRegistry)에서 파생된다 — 새 페이지를
 * 추가할 땐 이 파일이 아니라 pages.js의 GROUPS에 등록한다. 이 파일은 pages.js보다
 * 먼저 로드되면 안 된다(모든 html에서 core/pages.js → core/permissions.js 순서 유지).
 */
window.PagePerms = (function () {
  var LEVELS = ['접근불가', 'user', 'edit', 'manager', 'admin'];
  var ROLE_DEFAULT_PAGES = window.PageRegistry.buildRoleDefaults();

  /** user: auth.getSession()이 반환하는 프로필 객체(role, page_perms 포함). pageKey: 'equipment/list' 등. */
  function getLevel(user, pageKey) {
    if (!user) return '접근불가';
    if (user.page_perms && Object.prototype.hasOwnProperty.call(user.page_perms, pageKey)) {
      return user.page_perms[pageKey] || '접근불가';
    }
    var role = String(user.role || 'user').trim().toLowerCase();
    var defaults = ROLE_DEFAULT_PAGES[role] || ROLE_DEFAULT_PAGES.user;
    return defaults[pageKey] || '접근불가';
  }

  /** 해당 페이지에 대해 minLevel 이상의 권한을 갖고 있는지 */
  function atLeast(user, pageKey, minLevel) {
    var level = getLevel(user, pageKey);
    return LEVELS.indexOf(level) >= LEVELS.indexOf(minLevel);
  }

  /** pageKey가 속한 과금 기능(feature_flags) 자체가 켜져 있는지 — role/권한과는 별개 축.
   *  꺼져 있으면 canAccess()도 false를 주지만, 화면에서는 "권한 없음(자물쇠)"이 아니라
   *  "이 조직에 이 기능 자체가 없음"이므로 메뉴에서 완전히 숨기는 용도로 따로 노출한다. */
  function isFeatureEnabled(user, pageKey) {
    if (pageKey.indexOf('approval/') === 0) return !!(user && user.approval_enabled);
    if (pageKey.indexOf('hr/') === 0) return !!(user && user.hr_enabled);
    if (pageKey === 'leave/leave-admin') return !!(user && user.hr_enabled);
    if (pageKey.indexOf('committee/') === 0 || pageKey.indexOf('regulation/') === 0) return !!(user && user.committee_enabled);
    if (pageKey.indexOf('messenger/') === 0) return !!(user && user.messenger_enabled);
    return true;
  }

  /** 접근 자체가 가능한지 (접근불가만 아니면 true) */
  function canAccess(user, pageKey) {
    // 전자결재/인사관리는 과금 기능이라, 조직에서 꺼져 있으면 역할(권한)과 무관하게 잠긴다.
    if (!isFeatureEnabled(user, pageKey)) return false;
    return getLevel(user, pageKey) !== '접근불가';
  }

  return {
    LEVELS: LEVELS,
    ROLE_DEFAULT_PAGES: ROLE_DEFAULT_PAGES,
    getLevel: getLevel,
    atLeast: atLeast,
    canAccess: canAccess,
    isFeatureEnabled: isFeatureEnabled,
  };
})();