/**
 * assets/js/core/pages.js
 * ────────────────────────────────────────────────────────────────
 * 앱에 새 메뉴/페이지를 추가할 때 손대야 할 곳을 한 곳으로 모은 파일.
 *
 * 이전에는 페이지 키 목록이 4군데에 따로 있었다:
 *   - app.html의 사이드바 HTML(아이콘/라벨/순서) + MENU_META(브레드크럼)
 *   - permissions.js의 ROLE_DEFAULT_PAGES(역할별 기본 권한)
 *   - master/org.js의 PAGE_GROUPS(사용자별 개별 권한 편집 UI 목록)
 *   - home/home.js의 ALL_PAGES(즐겨찾기 선택 목록)
 * 4곳이 서로 어긋나기 쉬웠고(실제로 여러 번 어긋났음), 새 기능을 추가할 때마다
 * 4곳을 다 기억해서 고쳐야 했다. 이제 이 파일 하나에만 등록하면 나머지
 * 4곳은 전부 여기서 자동으로 파생된다(각 파일은 window.PageRegistry.build*()를 호출).
 *
 * [새 페이지 추가 시 할 일] 이 파일의 GROUPS에 항목 하나 추가하는 것으로 끝.
 *   - key: 'app/page' 형식의 고유 페이지 키 (pages/app/page.html 파일과 대응)
 *   - label: 사이드바·브레드크럼·권한편집 화면에 공통으로 쓰일 기본 라벨
 *   - icon: tabler-icons 클래스명 (예: 'ti-list')
 *   - roleDefaults: { user: LEVEL, admin: LEVEL } — 비워두면 '접근불가'
 *   - favoritable: false를 주면 홈 화면 즐겨찾기 선택 목록에서 제외 (기본 true)
 *   - hiddenFromMenu: true를 주면 사이드바엔 안 보이지만 접근 권한/브레드크럼은 그대로 적용
 *     (예: 목록에서 행을 클릭해 들어가는 상세/등록 화면처럼 사이드바에 별도 버튼이 없는 경우)
 *   - menuLabel / favLabel / favIcon / permNote: 특정 화면에서만 라벨/아이콘을 다르게
 *     보여주고 싶을 때만 선택적으로 지정 (없으면 label/icon을 그대로 씀)
 */
window.PageRegistry = (function () {
  var GROUPS = [
    {
      key: 'home', label: '홈', icon: 'ti-home', type: 'single',
      pages: [
        { key: 'home/home', label: '홈', icon: 'ti-home', favoritable: false,
          permNote: '홈 대시보드 — 조회 전용',
          roleDefaults: { user: 'user', admin: 'user' } },
      ],
    },
    { type: 'divider' },
    {
      key: 'equipment', label: '의료장비 관리', icon: 'ti-device-desktop-analytics', type: 'group',
      pages: [
        { key: 'equipment/dashboard', label: '대시보드', favLabel: '의료장비 대시보드', icon: 'ti-layout-dashboard',
          permNote: '의료장비 현황 대시보드 — 조회 전용',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'equipment/list', label: '장비 목록', icon: 'ti-list',
          permNote: '장비 목록 (의원 소속 장비 전체 조회 가능 — 등록/수정/폐기는 그 장비 부서의 담당자·admin만)',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'equipment/form', label: '장비 등록·수정', menuLabel: '장비 등록', icon: 'ti-plus',
          permNote: '장비 신규 등록 및 정보 수정',
          favoritable: false, roleDefaults: { user: 'user', admin: 'edit' } },
        { key: 'equipment/detail', label: '장비 상세', icon: 'ti-file-description',
          permNote: '장비 상세 (의원 소속 장비 전체 조회 가능 — 등록/수정/폐기는 그 장비 부서의 담당자·admin만)',
          favoritable: false, hiddenFromMenu: true, roleDefaults: { user: 'user', admin: 'user' } },
      ],
    },
    {
      key: 'material', label: '자재관리', icon: 'ti-box', type: 'group',
      pages: [
        { key: 'materials/purchase-request', label: '발주요청', icon: 'ti-shopping-cart',
          permNote: '발주요청 (본인이 신청/취소, 처리는 자재담당자)',
          roleDefaults: { user: 'edit', admin: 'edit' } },
        { key: 'materials/procurement', label: '발주 관리', icon: 'ti-file-invoice',
          permNote: '발주 관리 (발주 취소는 user도 가능, 발주 확정 등 처리는 manager 이상)',
          roleDefaults: { user: 'manager', admin: 'manager' } },
        { key: 'materials/stock', label: '재고 관리', icon: 'ti-building-warehouse',
          permNote: '재고 관리 — 입고·재고조사 등 처리는 manager 이상',
          roleDefaults: { user: 'manager', admin: 'manager' } },
        { key: 'materials/use-stock', label: '사용처리', icon: 'ti-clipboard-check',
          permNote: '부서별 자재 사용량 등록',
          roleDefaults: { user: 'edit', admin: 'user' } },
        { type: 'subdivider' },
        { key: 'materials/material-stats', label: '자재 통계', icon: 'ti-chart-bar',
          permNote: '자재 통계 — 조회 전용',
          roleDefaults: { user: '접근불가', admin: 'user' } },
      ],
    },
    {
      key: 'signage', label: '사인물 신청', icon: 'ti-rubber-stamp', type: 'group',
      pages: [
        { key: 'signage/apply', label: '신청', favLabel: '사인물 신청', icon: 'ti-pencil', favIcon: 'ti-rubber-stamp',
          permNote: '사인물 제작 신청 작성',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'signage/history', label: '신청내역', icon: 'ti-list-check',
          permNote: '신청내역 (level: manager/admin = 전체 처리, user = 본인만)',
          roleDefaults: { user: 'user', admin: 'admin' } },
      ],
    },
    { type: 'divider' },
    {
      key: 'contract', label: '계약관리', icon: 'ti-file-certificate', type: 'group',
      pages: [
        { key: 'contracts/list', label: '계약 목록', icon: 'ti-list',
          permNote: '계약 목록 (조직 전체 조회 가능 — 등록/수정은 admin 또는 개별 부여자만)',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'contracts/form', label: '계약 등록·수정', menuLabel: '계약 등록', icon: 'ti-plus',
          permNote: '계약 신규 등록 및 정보 수정 (기본값: admin만, 필요 시 담당자에게 개별 부여)',
          favoritable: false, roleDefaults: { user: '접근불가', admin: 'edit' } },
        { key: 'contracts/detail', label: '계약 상세', icon: 'ti-file-description',
          permNote: '계약 상세 (목록과 동일한 조회 권한)',
          favoritable: false, hiddenFromMenu: true, roleDefaults: { user: 'user', admin: 'user' } },
      ],
    },
    { type: 'divider' },
    {
      key: 'task', label: '업무일정 관리', icon: 'ti-calendar-event', type: 'group',
      pages: [
        { key: 'task/task-manager', label: '업무일정관리', favLabel: '업무일정 관리', menuLabel: '업무일정관리', icon: 'ti-calendar-event',
          permNote: '업무일정·일지 (manager 등급 = 팀장 역할, 다른 페이지의 manager와 의미가 다름)',
          roleDefaults: { user: 'edit', admin: 'admin' } },
        { key: 'task/resource-booking', label: '자원예약', menuLabel: '자원예약', icon: 'ti-door',
          permNote: '회의실·차량 예약 (자원 목록 자체는 설정 > 기준정보 관리의 "자원" 탭에서 등록)',
          roleDefaults: { user: 'edit', admin: 'edit' } },
      ],
    },
    {
      key: 'messenger', label: '메신저', icon: 'ti-message-circle', type: 'single',
      pages: [
        { key: 'messenger/messenger', label: '메신저', favLabel: '메신저', icon: 'ti-message-circle',
          permNote: '조직원과의 1:1·그룹 메시지 (파일 첨부 포함)',
          roleDefaults: { user: 'edit', admin: 'edit' } },
      ],
    },
    { type: 'divider' },
    {
      key: 'approval', label: '전자결재', icon: 'ti-certificate', type: 'group',
      pages: [
        { key: 'approval/draft', label: '기안 작성·내문서함', menuLabel: '기안 작성', icon: 'ti-file-pencil',
          permNote: '기안서 작성 및 본인이 작성한 문서함 조회',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'approval/doc-detail', label: '문서 상세', icon: 'ti-file-description',
          permNote: '문서함에서 클릭해 들어가는 상세 화면 (사이드바에 별도 노출 안 됨)',
          favoritable: false, hiddenFromMenu: true, roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'approval/inbox', label: '결재함', icon: 'ti-inbox',
          permNote: '본인에게 온 결재·참조·회람 문서 처리',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'approval/history', label: '전체 결재 이력', icon: 'ti-history',
          permNote: '의원 전체 결재 문서 검색·조회 (admin 전용, 감사·이력 확인용)',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
      ],
    },
    {
      key: 'hr', label: '인사관리', icon: 'ti-id-badge-2', type: 'single',
      pages: [
        { key: 'hr/personal-info', label: '개인신상정보', favLabel: '인사관리', menuLabel: '개인신상정보', icon: 'ti-id-badge-2',
          permNote: '직원 목록(그리드) — user는 본인 상세로 바로 이동, manager 이상은 의원 내 전 직원 목록/상세 조회·관리',
          roleDefaults: { user: 'edit', admin: 'admin' } },
        { key: 'hr/personal-info-detail', label: '개인신상정보 상세', icon: 'ti-id-badge-2',
          permNote: '개인신상정보 상세(탭) — 본인 것은 본인이, manager 이상은 누구든 조회/수정',
          favoritable: false, hiddenFromMenu: true, roleDefaults: { user: 'edit', admin: 'admin' } },
      ],
    },
    {
      key: 'program-request', label: '프로그램 요청', icon: 'ti-bug', type: 'group',
      pages: [
        { key: 'program-request/apply', label: '신청', favLabel: '프로그램 요청', icon: 'ti-pencil', favIcon: 'ti-bug',
          permNote: '프로그램 개선·오류 신고 신청 작성',
          roleDefaults: { user: 'user', admin: 'user' } },
        { key: 'program-request/history', label: '신청내역', favLabel: '프로그램 요청내역', icon: 'ti-list-check',
          permNote: '신청내역 (level: manager/admin = 전체 처리, user = 본인만)',
          roleDefaults: { user: 'user', admin: 'admin' } },
      ],
    },
    {
      key: 'committee-regulation', label: '위원회·규정', icon: 'ti-gavel', type: 'group',
      pages: [
        { key: 'committee/list', label: '위원회 관리', favLabel: '위원회', icon: 'ti-users-group',
          permNote: '위원회 목록·위원 명단·회의록 (level: manager 이상 등록·수정, admin 삭제) — 위원 중 "간사"로 계정 연동된 사람은 본인 위원회 회의록만 별도로 등록 가능',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'committee/detail', label: '위원회 상세', icon: 'ti-users-group',
          permNote: '위원회 상세(위원/회의록 탭) — 목록과 같은 committee/list 권한으로 자체 판단',
          favoritable: false, hiddenFromMenu: true, roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'regulation/list', label: '규정 관리', favLabel: '규정', icon: 'ti-file-text',
          permNote: '규정 목록·조항 편집·버전 배포 (level: manager 이상 등록·수정, admin 삭제)',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'regulation/detail', label: '규정 상세', icon: 'ti-file-text',
          permNote: '규정 상세(조항 편집/버전/출력) — 목록과 같은 regulation/list 권한으로 자체 판단',
          favoritable: false, hiddenFromMenu: true, roleDefaults: { user: '접근불가', admin: 'admin' } },
      ],
    },
    { type: 'divider', id: 'sbDividerSettings' },
    {
      key: 'settings', label: '설정', icon: 'ti-settings', type: 'group', lockableGroup: true,
      pages: [
        { key: 'master/org', label: '부서·사용자 관리', favLabel: '부서·사용자 관리', menuLabel: '부서·사용자 관리', icon: 'ti-building-hospital', favIcon: 'ti-users',
          permNote: '의원·부서·사용자 (manager 이상만 등록/수정). 초대코드 발급은 플랫폼 관리자 전용으로 이관됨 — 이 화면에서는 발급 불가',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'master/supply', label: '기준정보 관리', menuLabel: '기준정보 관리', icon: 'ti-package',
          permNote: '자재·거래처·자원(회의실·차량) 기준정보 (manager 이상만 등록/수정)',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'leave/leave-admin', label: '연차 정책 관리', menuLabel: '연차 정책', icon: 'ti-beach',
          permNote: '전체 부서 연차 현황 조회 및 정책 설정 (인사담당자/admin 전용)',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'approval/lines', label: '결재 양식 관리', menuLabel: '양식 관리', permNote: '결재 양식 관리 (기본값: admin만 접근) — 결재선은 기안 작성 화면에서 직접 지정만 사용',
          icon: 'ti-forms', favoritable: false,
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { type: 'subdivider' },
        { key: 'master/notice', label: '공지사항', favLabel: '공지사항 관리', icon: 'ti-speakerphone',
          permNote: '공지사항 (admin 전용 — 등급 조정 불가)',
          roleDefaults: { user: '접근불가', admin: 'admin' } },
        { key: 'master/syslog', label: '시스템 로그', icon: 'ti-terminal-2', favoritable: false,
          permNote: '시스템 로그 (admin 전용 — 등급 조정 불가)',
          roleDefaults: { admin: 'admin' } },
      ],
    },
  ];

  function allPages() {
    var out = [];
    GROUPS.forEach(function (g) {
      if (g.type === 'divider') return;
      (g.pages || []).forEach(function (p) {
        if (p.type === 'subdivider') return;
        out.push({ page: p, group: g });
      });
    });
    return out;
  }

  /** permissions.js가 쓰는 { user:{key:level}, admin:{key:level} } 형태로 변환.
   *  org_members.role은 이제 user/admin 두 가지뿐이다(예전엔 manager도 있었는데, 페이지별
   *  세부 권한(page_perms)과 이름이 겹쳐서 헷갈리는 원인이라 정리했다 — "이 사람이 이 페이지를
   *  얼마나 쓸 수 있는지"는 이제 오직 page_perms로만 정한다. 의원 대표 권한(admin) 자체는
   *  의원당 한 명으로 제한된다(DB 유니크 제약). */
  function buildRoleDefaults() {
    var out = { user: {}, admin: {} };
    allPages().forEach(function (entry) {
      var p = entry.page;
      var rd = p.roleDefaults || {};
      if (rd.user) out.user[p.key] = rd.user;
      if (rd.admin) out.admin[p.key] = rd.admin;
    });
    return out;
  }

  /** org.js 사용자별 개별 권한 편집 UI가 쓰는 [{app, pages:[{key,label,note}]}] 형태로 변환 */
  function buildPermissionGroups() {
    return GROUPS.filter(function (g) { return g.type !== 'divider'; }).map(function (g) {
      return {
        app: g.label,
        pages: (g.pages || [])
          .filter(function (p) { return p.type !== 'subdivider'; })
          .map(function (p) { return { key: p.key, label: p.label, note: p.permNote || '' }; }),
      };
    });
  }

  /** home.js 즐겨찾기 선택 목록이 쓰는 [{key, icon, label}] 형태로 변환 (favoritable !== false만) */
  function buildFavoritePages() {
    return allPages()
      .filter(function (entry) { return entry.page.favoritable !== false; })
      .map(function (entry) {
        var p = entry.page;
        return { key: p.key, icon: p.favIcon || p.icon, label: p.favLabel || p.label };
      });
  }

  /** app.html 브레드크럼이 쓰는 { key: {app, page} } 형태로 변환 */
  function buildMenuMeta() {
    var out = {};
    allPages().forEach(function (entry) {
      out[entry.page.key] = { app: entry.group.label, page: entry.page.label };
    });
    return out;
  }

  return {
    GROUPS: GROUPS,
    allPages: allPages,
    buildRoleDefaults: buildRoleDefaults,
    buildPermissionGroups: buildPermissionGroups,
    buildFavoritePages: buildFavoritePages,
    buildMenuMeta: buildMenuMeta,
  };
})();