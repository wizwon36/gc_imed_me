'use strict';

/* ── Tiptap 기반 리치 에디터 ──────────────────────────────────────────
 * 2026-07 CKEditor5 → Tiptap으로 교체.
 * 사유: ① CKEditor5는 GPL/상업 듀얼 라이선스라 상용 비공개 SaaS엔 상업 라이선스가
 *   필요한데(GPL판은 워터마크+법적 리스크), Tiptap 코어는 MIT라 그 문제가 없음.
 *   ② 표 셀 드래그 선택/컬럼 리사이즈 버그를 여러 번 우회해왔는데, Tiptap은
 *   ProseMirror 기반이라 이 계열 문제가 훨씬 적음.
 *
 * draft.js/lines.js와의 호환을 위해 아래 함수들의 이름/시그니처는 CKEditor 버전과
 * 동일하게 유지한다: createRichEditor, TABLE_PRESETS, insertTablePreset,
 * findCurrentTable, equalizeColumnWidths, equalizeRowHeights.
 *
 * Tiptap은 헤드리스(툴바 UI가 없음)라, CKEditor가 자동으로 만들어주던 툴바를
 * 여기서 직접 HTML로 그려서 편집 영역 위에 붙인다.
 *
 * 문서 편집에 필요한 기능은 CKEditor 대비 사실상 전부 갖췄다: 서식(굵게~형광펜/서식지우기),
 * 정렬/들여쓰기, 3종 목록(글머리·번호·할일), 표(프리셋·열폭/행높이 동일화·드래그 다중선택·
 * 행높이 드래그조절), 링크·이미지(리사이즈 핸들 포함)·인용·구분선·페이지나누기·특수문자,
 * 찾기&바꾸기, 소스보기, 글자수 카운터, 툴바 안내 패널까지 전부 이 파일 하나로 구현돼 있다.
 */

import {
  Editor, Extension, Node, mergeAttributes, Plugin, PluginKey, Decoration, DecorationSet, CellSelection, Selection, TableMap,
  StarterKit, Table, TableRow, TableHeader, TableCell,
  TextStyle, Color, FontFamily, FontSize, BackgroundColor, Underline, Subscript, Superscript,
  TextAlign, Highlight, Link, Image, Placeholder, CharacterCount, TaskList, TaskItem,
} from '../../libs/tiptap/tiptap.js';

var TIPTAP_VERSION = '3.x'; // assets/libs/tiptap/tiptap.js 번들과 항상 맞춰야 함

/** 기본 TableCell/TableHeader는 style 속성을 저장/복원하지 않는다.
 *  열 폭 동일화·행 높이 동일화에서 인라인 style="width:...;height:..."을
 *  직접 써넣어야 해서, style을 그대로 저장/렌더링하도록 확장한다. */
function withStyleAttr(BaseExtension) {
  return BaseExtension.extend({
    addAttributes: function() {
      return Object.assign({}, this.parent(), {
        style: {
          default: null,
          parseHTML: function(el) { return el.getAttribute('style'); },
          renderHTML: function(attrs) { return attrs.style ? { style: attrs.style } : {}; },
        },
        // 표 전체 정렬(왼쪽/가운데/오른쪽) 값을 이 셀에 저장한다 — 표(<table>) 자신은
        // resizable:true일 때 그 라이브러리 자신의 NodeView가 렌더링을 통째로 가져가면서
        // 표에 새로 추가한 커스텀 속성은 전부 무시해버리는 문제가 있었다(실제로 겪음 —
        // 표에 tableAlign을 넣어봐도 DOM에 아예 반영이 안 됨). 반면 셀은 표준 스키마
        // 렌더링을 그대로 쓰므로 커스텀 속성이 정상적으로 반영된다. 그래서 정렬 값 자체는
        // 표의 (첫 번째 행) 모든 셀에 저장해두고, 실제 마진 적용은 setupTableWidthResize의
        // ensureHandles에서 이 값을 읽어 wrapper에 넣어준다.
        tableAlign: {
          default: null,
          parseHTML: function(el) { return el.getAttribute('data-table-align'); },
          renderHTML: function(attrs) { return attrs.tableAlign ? { 'data-table-align': attrs.tableAlign } : {}; },
        },
      });
    },
  });
}
var TableCellStyled = withStyleAttr(TableCell);
var TableHeaderStyled = withStyleAttr(TableHeader);

/** 들여쓰기 — Tiptap 무료 패키지엔 없어서 직접 구현. paragraph/heading/listItem에
 *  indent(0~8단계) 전역 속성을 얹고, style="margin-left:Npx"로 렌더링한다. */
var INDENT_STEP = 24; // px
var Indent = Extension.create({
  name: 'indent',
  addGlobalAttributes: function() {
    return [{
      types: ['paragraph', 'heading', 'listItem'],
      attributes: {
        indent: {
          default: 0,
          parseHTML: function(el) {
            var m = /margin-left:\s*(\d+)px/.exec(el.getAttribute('style') || '');
            return m ? Math.round(Number(m[1]) / INDENT_STEP) : 0;
          },
          renderHTML: function(attrs) {
            return attrs.indent ? { style: 'margin-left:' + (attrs.indent * INDENT_STEP) + 'px' } : {};
          },
        },
      },
    }];
  },
  addCommands: function() {
    function changeIndent(delta) {
      return function(props) {
        var editor = props.editor, tr = props.tr, dispatch = props.dispatch;
        var applied = false;
        editor.state.doc.nodesBetween(editor.state.selection.from, editor.state.selection.to, function(node, pos) {
          if (['paragraph', 'heading', 'listItem'].indexOf(node.type.name) === -1) return;
          var cur = node.attrs.indent || 0;
          var next = Math.max(0, Math.min(8, cur + delta));
          if (next !== cur) {
            tr.setNodeMarkup(pos, undefined, Object.assign({}, node.attrs, { indent: next }));
            applied = true;
          }
        });
        if (applied && dispatch) dispatch(tr);
        return applied;
      };
    }
    return {
      indent: function() { return changeIndent(1); },
      outdent: function() { return changeIndent(-1); },
    };
  },
});

/** 찾기&바꾸기 — 공식 무료 확장이 없어서 ProseMirror Decoration으로 직접 구현.
 *  문서 안 텍스트 노드를 순회해서 매치 위치를 찾고, 하이라이트 데코레이션을 씌운다. */
var findReplacePluginKey = new PluginKey('findReplace');
var FindReplace = Extension.create({
  name: 'findReplace',
  addProseMirrorPlugins: function() {
    return [
      new Plugin({
        key: findReplacePluginKey,
        state: {
          init: function() { return { decorations: DecorationSet.empty, results: [], currentIndex: -1 }; },
          apply: function(tr, old) {
            var meta = tr.getMeta(findReplacePluginKey);
            if (meta) return meta;
            if (tr.docChanged) return { decorations: old.decorations.map(tr.mapping, tr.doc), results: old.results, currentIndex: old.currentIndex };
            return old;
          },
        },
        props: {
          decorations: function(state) { return findReplacePluginKey.getState(state).decorations; },
        },
      }),
    ];
  },
});

function findMatches(doc, term) {
  if (!term) return [];
  var results = [];
  var escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  var re = new RegExp(escaped, 'gi');
  doc.descendants(function(node, pos) {
    if (!node.isText) return;
    var m;
    re.lastIndex = 0;
    while ((m = re.exec(node.text))) {
      results.push({ from: pos + m.index, to: pos + m.index + m[0].length });
      if (m[0].length === 0) re.lastIndex++;
    }
  });
  return results;
}

/** 이미지 리사이즈 — 기본 Image 확장엔 크기 조절 UI가 없어서, 모서리에 드래그 핸들을
 *  붙인 커스텀 NodeView로 직접 구현. width는 노드 속성으로 저장되어 결과 HTML에도 반영된다. */

/** 표 전체 폭을 퍼센트로 저장하는 속성 — 드래그가 아니라 우클릭 메뉴에서 100/75/50/25%
 *  버튼을 클릭할 때만 값이 설정된다. 마우스 좌표를 다루는 코드가 전혀 없어서(클릭 → 트랜잭션
 *  한 번), 예전에 드래그 핸들에서 겪었던 문제(좌표 계산 오류, 다른 드래그 시스템과 충돌)가
 *  구조적으로 발생할 수 없다. */
/** 표 정렬(왼쪽/가운데/오른쪽) — 이미지처럼 margin-left/right로 구현한다. 표 전체 폭
 *  조절 때 겪었던 문제(ProseMirror 표 라이브러리가 매 렌더링마다 width/min-width를 자기
 *  colwidth 계산 기준으로 덮어씀)는 그 함수가 width 계열 속성만 건드리는 것이었고, margin은
 *  안 건드리므로 이 방식은 그 충돌과 무관하게 안전하다. */
var ResizableImage = Image.extend({
  addAttributes: function() {
    return Object.assign({}, this.parent(), {
      width: { default: null, renderHTML: function(attrs) { return attrs.width ? { width: attrs.width, style: 'width:' + attrs.width + 'px' } : {}; } },
      // 이미지는 Tiptap 기본값이 inline:false(블록 레벨 노드)라서, 문단의 정렬(text-align)
      // 버튼이 안 먹는다 — 그래서 이미지 전용 정렬 속성을 별도로 둔다. 블록 레벨 요소를
      // 좌/가운데/우측 정렬하는 표준 CSS 방식(margin-left/right:auto)을 그대로 이용한다.
      align: {
        default: 'left',
        parseHTML: function(el) {
          var style = el.getAttribute('style') || '';
          if (/margin-left:\s*auto/.test(style) && /margin-right:\s*auto/.test(style)) return 'center';
          if (/margin-left:\s*auto/.test(style)) return 'right';
          return 'left';
        },
        renderHTML: function(attrs) {
          var align = attrs.align || 'left';
          var m = align === 'center' ? 'margin-left:auto;margin-right:auto;display:table;'
            : align === 'right' ? 'margin-left:auto;margin-right:0;display:table;'
            : 'display:table;';
          return { style: m + (attrs.width ? 'width:' + attrs.width + 'px' : '') };
        },
      },
    });
  },
  addCommands: function() {
    var parentCommands = this.parent ? this.parent() : {};
    return Object.assign({}, parentCommands, {
      setImageAlign: function(align) {
        return function(props) {
          var state = props.state, tr = props.tr, dispatch = props.dispatch;
          var sel = state.selection;
          var pos = null;
          if (sel.node && sel.node.type.name === 'image') pos = sel.from;
          else {
            state.doc.nodesBetween(sel.from, sel.to, function(node, p) { if (node.type.name === 'image' && pos === null) pos = p; });
          }
          if (pos == null) return false;
          if (dispatch) {
            var node = tr.doc.nodeAt(pos);
            tr.setNodeMarkup(pos, undefined, Object.assign({}, node.attrs, { align: align }));
            dispatch(tr);
          }
          return true;
        };
      },
    });
  },
  addNodeView: function() {
    return function(props) {
      var node = props.node, getPos = props.getPos, editor = props.editor;
      var container = document.createElement('span');
      container.className = 'tt-img-wrap';
      var img = document.createElement('img');
      img.src = node.attrs.src;
      if (node.attrs.alt) img.alt = node.attrs.alt;
      if (node.attrs.width) img.style.width = node.attrs.width + 'px';
      container.appendChild(img);
      var handle = document.createElement('span');
      handle.className = 'tt-img-resize-handle';
      container.appendChild(handle);

      // display:table으로 두면 이미지 크기에 맞게 래퍼가 자동으로 좁혀지면서도(이미지에
      // 너비를 따로 안 줬을 때도 포함) margin:auto 정렬이 그대로 먹는다 — inline-block은
      // 얼핏 비슷해 보이지만 margin:auto로 가운데/우측 정렬이 안 되는 함정이 있다.
      function applyAlign(align) {
        container.style.display = 'table';
        if (align === 'center') { container.style.marginLeft = 'auto'; container.style.marginRight = 'auto'; }
        else if (align === 'right') { container.style.marginLeft = 'auto'; container.style.marginRight = '0'; }
        else { container.style.marginLeft = '0'; container.style.marginRight = 'auto'; }
      }
      applyAlign(node.attrs.align || 'left');

      var dragging = false, startX = 0, startWidth = 0;
      function onMove(e) {
        if (!dragging) return;
        img.style.width = Math.max(40, startWidth + (e.clientX - startX)) + 'px';
      }
      function onUp() {
        if (!dragging) return;
        dragging = false;
        document.body.style.cursor = '';
        if (typeof getPos === 'function') {
          var pos = getPos();
          var tr = editor.state.tr.setNodeMarkup(pos, undefined, Object.assign({}, node.attrs, { width: img.offsetWidth }));
          editor.view.dispatch(tr);
        }
      }
      handle.addEventListener('mousedown', function(e) {
        e.preventDefault();
        dragging = true; startX = e.clientX; startWidth = img.offsetWidth;
        document.body.style.cursor = 'nwse-resize';
      });
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);

      return {
        dom: container,
        update: function(updatedNode) {
          if (updatedNode.type.name !== 'image') return false;
          node = updatedNode;
          img.src = node.attrs.src;
          if (node.attrs.width) img.style.width = node.attrs.width + 'px';
          applyAlign(node.attrs.align || 'left');
          return true;
        },
        destroy: function() {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
        },
        selectNode: function() { container.classList.add('tt-img-selected'); },
        deselectNode: function() { container.classList.remove('tt-img-selected'); },
        stopEvent: function(e) { return e.target === handle; },
      };
    };
  },
});

/** 페이지 나누기 — CKEditor의 pageBreak와 동일한 개념. 편집 중엔 점선으로 표시되고,
 *  인쇄(@media print) 시 실제로 여기서 페이지가 나뉘도록 break-before:page를 건다. */
var PageBreak = Node.create({
  name: 'pageBreak',
  group: 'block',
  atom: true,
  parseHTML: function() { return [{ tag: 'div[data-page-break]' }]; },
  renderHTML: function() {
    return ['div', mergeAttributes({ 'data-page-break': '', class: 'apr-page-break' })];
  },
  addCommands: function() {
    var self = this;
    return {
      setPageBreak: function() {
        return function(props) { return props.commands.insertContent({ type: self.name }); };
      },
    };
  },
});

var FONT_FAMILIES = [
  { group: null, items: [{ value: '', label: '기본 서체' }] },
  { group: '시스템 (OS 내장)', items: [
    { value: '맑은 고딕, Malgun Gothic, sans-serif', label: '맑은 고딕' },
    { value: '나눔고딕, Nanum Gothic, sans-serif', label: '나눔고딕(시스템)' },
    { value: '바탕, Batang, serif', label: '바탕' },
    { value: '굴림, Gulim, sans-serif', label: '굴림' },
    { value: '돋움, Dotum, sans-serif', label: '돋움' },
  ] },
  { group: '고딕(산세리프)', items: [
    { value: 'Pretendard, sans-serif', label: 'Pretendard' },
    { value: '"Noto Sans KR", sans-serif', label: 'Noto Sans KR' },
    { value: '"Nanum Gothic", sans-serif', label: '나눔고딕' },
    { value: '"Gothic A1", sans-serif', label: 'Gothic A1' },
    { value: '"IBM Plex Sans KR", sans-serif', label: 'IBM Plex Sans KR' },
    { value: '"Gowun Dodum", sans-serif', label: '고운 돋움' },
  ] },
  { group: '명조(세리프)', items: [
    { value: '"Noto Serif KR", serif', label: 'Noto Serif KR' },
    { value: '"Nanum Myeongjo", serif', label: '나눔명조' },
    { value: '"Gowun Batang", serif', label: '고운 바탕' },
  ] },
  { group: '손글씨 · 장식', items: [
    { value: '"Do Hyeon", sans-serif', label: '도현체' },
    { value: '"Black Han Sans", sans-serif', label: '검은고딕' },
    { value: '"Jua", sans-serif', label: '주아체' },
    { value: '"Gaegu", cursive', label: '개구체' },
  ] },
  { group: '영문', items: [
    { value: 'Arial, Helvetica, sans-serif', label: 'Arial' },
    { value: 'Georgia, serif', label: 'Georgia' },
    { value: 'Times New Roman, Times, serif', label: 'Times New Roman' },
    { value: 'Courier New, Courier, monospace', label: 'Courier New' },
  ] },
];

var FONT_SIZES = [9, 10, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 36, 48];

var TOOLBAR_SPEC = [
  { cmd: 'undo', icon: 'ti-arrow-back-up', title: '실행 취소' },
  { cmd: 'redo', icon: 'ti-arrow-forward-up', title: '다시 실행' },
  'sep',
  { type: 'select', cmd: 'heading', title: '제목 스타일',
    options: [{ value: 'p', label: '본문' }, { value: '1', label: '제목 1' }, { value: '2', label: '제목 2' }, { value: '3', label: '제목 3' }] },
  { type: 'select', cmd: 'fontFamily', title: '글꼴', options: FONT_FAMILIES },
  { type: 'select', cmd: 'fontSize', title: '글자 크기',
    options: [{ value: '', label: '크기' }].concat(FONT_SIZES.map(function(n) { return { value: n + 'px', label: String(n) }; })) },
  'sep',
  { cmd: 'bold', icon: 'ti-bold', title: '굵게' },
  { cmd: 'italic', icon: 'ti-italic', title: '기울임' },
  { cmd: 'underline', icon: 'ti-underline', title: '밑줄' },
  { cmd: 'strike', icon: 'ti-strikethrough', title: '취소선' },
  { cmd: 'subscript', icon: 'ti-subscript', title: '아래 첨자' },
  { cmd: 'superscript', icon: 'ti-superscript', title: '위 첨자' },
  { cmd: 'removeFormat', icon: 'ti-clear-formatting', title: '서식 지우기' },
  'sep',
  { cmd: 'fontColor', icon: 'ti-letter-case', title: '글자색' },
  { cmd: 'bgColor', icon: 'ti-color-swatch', title: '배경색' },
  { cmd: 'highlight', icon: 'ti-highlight', title: '형광펜' },
  'sep',
  { cmd: 'alignLeft', icon: 'ti-align-left', title: '왼쪽 정렬' },
  { cmd: 'alignCenter', icon: 'ti-align-center', title: '가운데 정렬' },
  { cmd: 'alignRight', icon: 'ti-align-right', title: '오른쪽 정렬' },
  { cmd: 'alignJustify', icon: 'ti-align-justified', title: '양쪽 정렬' },
  { cmd: 'outdent', icon: 'ti-indent-decrease', title: '내어쓰기' },
  { cmd: 'indent', icon: 'ti-indent-increase', title: '들여쓰기' },
  'sep',
  { cmd: 'bulletList', icon: 'ti-list', title: '글머리 기호 목록' },
  { cmd: 'orderedList', icon: 'ti-list-numbers', title: '번호 매기기 목록' },
  { cmd: 'taskList', icon: 'ti-list-check', title: '할일 목록' },
  'sep',
  { cmd: 'link', icon: 'ti-link', title: '링크' },
  { cmd: 'image', icon: 'ti-photo', title: '이미지 삽입' },
  { cmd: 'insertTable', icon: 'ti-table', title: '표 삽입 (칸수 직접 선택)' },
  'sep',
  { cmd: 'blockquote', icon: 'ti-quote', title: '인용 단락' },
  { cmd: 'horizontalRule', icon: 'ti-minus', title: '구분선' },
  { cmd: 'pageBreak', icon: 'ti-page-break', title: '페이지 나누기' },
  { cmd: 'specialChars', icon: 'ti-omega', title: '특수 문자' },
  'sep',
  { cmd: 'sourceView', icon: 'ti-code', title: '소스 보기' },
  { cmd: 'findReplace', icon: 'ti-replace', title: '찾기 & 바꾸기' },
  { cmd: 'guide', icon: 'ti-help', title: '툴바 안내' },
];

var SPECIAL_CHARS = ['©', '®', '™', '€', '£', '¥', '§', '¶', '†', '‡', '•', '…', '‰', '±', '×', '÷', '≈', '≠', '≤', '≥', '∞', '√', '←', '→', '↑', '↓', '※', '★', '☆', '○', '●', '□', '■', '△', '▲'];

var TOOLBAR_GUIDE = [
  { label: '글자 서식', items: ['굵게/기울임/밑줄/취소선/첨자', '서식 지우기로 전부 초기화', '글자색·배경색·형광펜'] },
  { label: '문단', items: ['제목1~3/본문 전환', '정렬 4종', '들여쓰기/내어쓰기'] },
  { label: '목록', items: ['글머리 기호 · 번호 매기기 · 할일 목록'] },
  { label: '표 만들기', items: ['상단 "표 빠른 삽입"에서 프리셋 선택', '툴바의 표 아이콘으로 원하는 칸수(최대 8x8) 직접 선택'] },
  {
    label: '표 편집', items: [
      '표 안에 커서를 두면 그 위치에 편집 메뉴가 따로 뜬다',
      '셀 나누기: 합쳤던 셀이면 원상복구, 일반 셀이면 원하는 열x행 수로 새로 쪼갬',
      '행/열 추가·삭제 가능',
      '드래그로 셀을 여러 개 선택하면 셀 병합 · 열 폭 맞추기 · 행 높이 맞추기도 같이 뜬다',
      '행 아래 경계를 드래그하면 그 행만 높이 조절',
      '우클릭 메뉴의 "표 폭"에서 100/75/50/25% 중 선택 가능(마우스 올리면 펼쳐짐)',
      '우클릭 메뉴의 "표 정렬"에서 표 전체를 왼쪽/가운데/오른쪽 중 선택 가능',
      '표 오른쪽 아래 모서리에 마우스를 올리면 나오는 손잡이를 드래그하면 가로 폭과 세로 높이를 동시에 조절 가능',
    ],
  },
  { label: '기타', items: ['링크 · 이미지(모서리 드래그로 크기 조절) · 인용 단락 · 구분선 · 페이지 나누기', '특수 문자 삽입', '소스 보기로 HTML 직접 확인/수정', '찾기 & 바꾸기'] },
];

function renderSelectOptions(options) {
  // FONT_FAMILIES처럼 { group, items } 배열이면 <optgroup>으로, 아니면(단순 목록) 그냥 <option>으로.
  if (options.length && options[0].group !== undefined) {
    return options.map(function(g) {
      var opts = g.items.map(function(o) { return '<option value="' + o.value + '">' + o.label + '</option>'; }).join('');
      return g.group ? '<optgroup label="' + g.group + '">' + opts + '</optgroup>' : opts;
    }).join('');
  }
  return options.map(function(o) { return '<option value="' + o.value + '">' + o.label + '</option>'; }).join('');
}

function buildToolbarHtml() {
  var html = '<div class="tt-toolbar">';
  TOOLBAR_SPEC.forEach(function(item) {
    if (item === 'sep') { html += '<span class="tt-sep"></span>'; return; }
    if (item.type === 'select') {
      html += '<select class="tt-select" data-cmd="' + item.cmd + '" title="' + item.title + '">' +
        renderSelectOptions(item.options) +
        '</select>';
      return;
    }
    html += '<button type="button" class="tt-btn" data-cmd="' + item.cmd + '" title="' + item.title + '">' +
      '<i class="ti ' + item.icon + '"></i></button>';
  });
  html += '</div>';
  return html;
}

function runToolbarCmd(editor, cmd) {
  var c = editor.chain().focus();
  switch (cmd) {
    case 'undo': c.undo().run(); return;
    case 'redo': c.redo().run(); return;
    case 'bold': c.toggleBold().run(); return;
    case 'italic': c.toggleItalic().run(); return;
    case 'underline': c.toggleUnderline().run(); return;
    case 'strike': c.toggleStrike().run(); return;
    case 'subscript': c.toggleSubscript().run(); return;
    case 'superscript': c.toggleSuperscript().run(); return;
    case 'removeFormat': c.clearNodes().unsetAllMarks().run(); return;
    case 'highlight': c.toggleHighlight().run(); return;
    case 'alignLeft':
      editor.isActive('image') ? c.setImageAlign('left').run() : c.setTextAlign('left').run();
      return;
    case 'alignCenter':
      editor.isActive('image') ? c.setImageAlign('center').run() : c.setTextAlign('center').run();
      return;
    case 'alignRight':
      editor.isActive('image') ? c.setImageAlign('right').run() : c.setTextAlign('right').run();
      return;
    case 'alignJustify': c.setTextAlign('justify').run(); return; // 양쪽정렬은 이미지엔 의미가 없어 문단에만 적용
    case 'indent': c.indent().run(); return;
    case 'outdent': c.outdent().run(); return;
    case 'bulletList': c.toggleBulletList().run(); return;
    case 'orderedList': c.toggleOrderedList().run(); return;
    case 'taskList': c.toggleTaskList().run(); return;
    case 'blockquote': c.toggleBlockquote().run(); return;
    case 'horizontalRule': c.setHorizontalRule().run(); return;
    case 'pageBreak': c.setPageBreak().run(); return;
    case 'link': {
      var prev = editor.getAttributes('link').href || '';
      var url = prompt('링크 URL을 입력하세요 (비우면 링크 해제)', prev);
      if (url === null) return;
      if (url.trim() === '') { c.unsetLink().run(); return; }
      c.extendMarkRange('link').setLink({ href: url.trim() }).run();
      return;
    }
    // image/fontColor/bgColor/specialChars/sourceView/guide는 각자 전용 UI(파일창·컬러피커·
    // 패널)가 따로 있어서 createRichEditor의 클릭 핸들러에서 먼저 가로채 처리한다.
    default: return;
  }
}

function insertImageFromFile(editor, file) {
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function() {
    editor.chain().focus().setImage({ src: reader.result }).run();
  };
  reader.readAsDataURL(file);
}

/** 툴바 버튼/셀렉트를 현재 커서 위치의 서식에 맞춰 활성 표시로 갱신 */
function syncToolbarState(editor, toolbarEl) {
  toolbarEl.querySelectorAll('.tt-btn[data-cmd]').forEach(function(btn) {
    var cmd = btn.dataset.cmd;
    var activeMap = {
      bold: 'bold', italic: 'italic', underline: 'underline', strike: 'strike',
      subscript: 'subscript', superscript: 'superscript', highlight: 'highlight',
      bulletList: 'bulletList', orderedList: 'orderedList', taskList: 'taskList', blockquote: 'blockquote',
      alignLeft: { textAlign: 'left' }, alignCenter: { textAlign: 'center' },
      alignRight: { textAlign: 'right' }, alignJustify: { textAlign: 'justify' },
      link: 'link',
    };
    var spec = activeMap[cmd];
    var active = false;
    if (cmd === 'alignLeft' || cmd === 'alignCenter' || cmd === 'alignRight') {
      var wantAlign2 = cmd === 'alignLeft' ? 'left' : cmd === 'alignCenter' ? 'center' : 'right';
      if (editor.isActive('image')) {
        active = editor.isActive('image', { align: wantAlign2 }) || (wantAlign2 === 'left' && editor.isActive('image', { align: null }));
      } else {
        active = editor.isActive(spec);
      }
    } else if (spec) {
      active = typeof spec === 'string' ? editor.isActive(spec) : editor.isActive(spec);
    }
    btn.classList.toggle('is-active', !!active);
  });
  var headingSel = toolbarEl.querySelector('select[data-cmd="heading"]');
  if (headingSel) {
    var lvl = [1, 2, 3].find(function(l) { return editor.isActive('heading', { level: l }); });
    headingSel.value = lvl ? String(lvl) : 'p';
  }
  var fontSel = toolbarEl.querySelector('select[data-cmd="fontFamily"]');
  if (fontSel) fontSel.value = editor.getAttributes('textStyle').fontFamily || '';
  var sizeSel = toolbarEl.querySelector('select[data-cmd="fontSize"]');
  if (sizeSel) sizeSel.value = editor.getAttributes('textStyle').fontSize || '';
}

/** Tiptap 에디터 인스턴스를 표준 설정(플러그인/툴바/한글 라벨/행높이드래그 포함)으로 생성.
 *  el: 마운트할 DOM 요소(또는 id 문자열). initialData: 초기 HTML.
 *  반환값은 실제 Tiptap Editor 인스턴스에 getData()/setData()를 얹은 것 — 이러면
 *  draft.js/lines.js가 CKEditor 때 쓰던 editor.getData()/editor.setData() 호출을
 *  그대로 쓸 수 있다. */
async function createRichEditor(el, initialData) {
  var target = typeof el === 'string' ? document.getElementById(el) : el;
  var wrap = target.parentElement; // #aprEditorWrap 등 — 여기 맨 위에 툴바를 끼워 넣는다
  // 팝업 패널들(도움말/우클릭 메뉴 등)을 position:absolute로 여기(wrap) 기준으로 배치할
  // 것이므로, wrap 자신이 위치 기준점 역할을 하도록 relative를 준다. 이미 다른 값이
  // 지정돼 있으면(static이 아니면) 그대로 둔다.
  if (getComputedStyle(wrap).position === 'static') wrap.style.position = 'relative';

  var toolbarEl = document.createElement('div');
  toolbarEl.innerHTML = buildToolbarHtml();
  toolbarEl = toolbarEl.firstElementChild;
  wrap.insertBefore(toolbarEl, target);
  // 툴바 버튼을 누르는 순간 브라우저가 에디터를 blur시키면서 방금 만든(특히 표 셀 드래그)
  // 선택이 날아가는 문제 — mousedown 시점에 기본 동작을 막아서 blur 자체가 안 일어나게 한다.
  // select/input은 정상 동작(값 입력, 드롭다운 열기)이 필요하니 버튼에만 적용한다.
  toolbarEl.addEventListener('mousedown', function(e) { if (e.target.closest('.tt-btn')) e.preventDefault(); });

  target.classList.add('tt-editable');

  var editor = new Editor({
    element: target,
    content: initialData || '',
    extensions: [
      StarterKit.configure({ link: false, underline: false }), // Link/Underline은 아래서 별도 설정
      Underline, Subscript, Superscript,
      TextStyle, Color, FontFamily, FontSize, BackgroundColor,
      TextAlign.configure({ types: ['heading', 'paragraph'] }),
      Indent,
      Highlight,
      Link.configure({ openOnClick: false, autolink: true }),
      ResizableImage,
      FindReplace,
      RowResizeHoverPlugin,
      // lastColumnResizable:false로 꺼서 마지막 컬럼(=표 전체 폭)의 무제한 확장을 막아봤는데,
      // 그러면 마지막 컬럼은 정상적인 폭 조절(줄이기 등)까지도 아예 안 되는 부작용이 있었다.
      // 지금은 표가 용지보다 넓어지면(어떤 컬럼을 조절하든) 디바운스된 자동보정이 100%로
      // 되돌려주므로, 이 옵션을 꺼서 마지막 컬럼 자체를 막을 필요가 없어졌다 — 다시 켠다.
      Table.configure({ resizable: true, lastColumnResizable: true }),
      TableRow, TableHeaderStyled, TableCellStyled,
      TaskList, TaskItem.configure({ nested: true }),
      PageBreak,
      Placeholder.configure({ placeholder: '' }),
      CharacterCount,
    ],
  });

  // 글자수 카운터 — 원래 CKEditor의 WordCount 플러그인 표시를 대체
  var wcEl = document.createElement('div');
  wcEl.className = 'apr-wordcount';
  wrap.appendChild(wcEl);
  function renderWordCount() {
    var chars = editor.storage.characterCount.characters();
    var words = editor.storage.characterCount.words();
    wcEl.textContent = '글자 수: ' + chars.toLocaleString('ko-KR') + '  ·  단어 수: ' + words.toLocaleString('ko-KR');
  }
  editor.on('update', renderWordCount);
  renderWordCount();

  // 호환용 shim — CKEditor 스타일 API 이름 그대로 지원
  editor.getData = function() { return editor.getHTML(); };
  editor.setData = function(html) {
    // 표가 있던 문서에서 다른(표 있는) 문서로 바로 바꾸면, ProseMirror가 효율을 위해 이전
    // 표의 DOM 요소(및 그 표 라이브러리 자신이 내부적으로 들고 있는 컬럼 폭 상태)를 그대로
    // 재사용하려는 경우가 있다 — 새 콘텐츠에 폭 관련 값이 명시돼 있지 않으면, 그 재사용된
    // DOM에 이전 표의 폭이 그대로 남아서 "다른 양식인데 표 폭은 이전 것을 물려받는" 문제로
    // 이어졌다. 아예 빈 콘텐츠를 한 번 거쳐서 이전 문서 구조를 완전히 지운 다음 새 콘텐츠를
    // 넣으면, 재사용할 "이전 DOM" 자체가 없어서 이 문제가 원천 차단된다.
    editor.commands.setContent('', { emitUpdate: false });
    editor.commands.setContent(html || '', { emitUpdate: false });
    // setContent를 emitUpdate:false로 부르면 'update' 이벤트가 안 떠서, 그걸 구독해
    // 동작하는 표 폭 손잡이 동기화(syncTableHandles)가 양식을 바꿀 때마다 실행이 안 된다 —
    // 그러면 이전 양식에서 조절해둔 손잡이 wrapper 폭(DOM에 직접 넣은 값이라 ProseMirror가
    // 모르는 값)이 새 양식으로 바뀐 뒤에도 안 지워지고 남아있는 문제가 있었다. 여기서
    // 명시적으로 다시 불러서 새 콘텐츠 기준으로 재동기화한다(레이아웃이 아직 안 자리잡았을
    // 수 있어 약간의 지연 후 한 번 더).
    if (syncTableHandles) {
      syncTableHandles();
      setTimeout(syncTableHandles, 100);
    }
  };

  /* ── 찾기 & 바꾸기 ── */
  var searchPanel = document.createElement('div');
  searchPanel.className = 'tt-panel tt-search-panel';
  searchPanel.innerHTML =
    '<div class="tt-search-row">' +
      '<input type="text" class="tt-search-input" placeholder="찾을 내용" />' +
      '<span class="tt-search-count">0/0</span>' +
      '<button type="button" class="tt-btn" data-search-act="prev"><i class="ti ti-chevron-up"></i></button>' +
      '<button type="button" class="tt-btn" data-search-act="next"><i class="ti ti-chevron-down"></i></button>' +
      '<button type="button" class="tt-btn" data-search-act="close"><i class="ti ti-x"></i></button>' +
    '</div>' +
    '<div class="tt-search-row">' +
      '<input type="text" class="tt-replace-input" placeholder="바꿀 내용" />' +
      '<button type="button" class="btn btn-sm" data-search-act="replace">바꾸기</button>' +
      '<button type="button" class="btn btn-sm" data-search-act="replaceAll">모두 바꾸기</button>' +
    '</div>';
  searchPanel.style.display = 'none';
  wrap.appendChild(searchPanel);

  var searchInput = searchPanel.querySelector('.tt-search-input');
  var replaceInput = searchPanel.querySelector('.tt-replace-input');
  var searchCountEl = searchPanel.querySelector('.tt-search-count');
  var searchResults = [];
  var searchCurrentIndex = -1;

  function updateSearch(newIndex) {
    var term = searchInput.value;
    searchResults = findMatches(editor.state.doc, term);
    searchCurrentIndex = searchResults.length
      ? ((newIndex % searchResults.length) + searchResults.length) % searchResults.length
      : -1;
    var decos = searchResults.map(function(r, i) {
      return Decoration.inline(r.from, r.to, { class: i === searchCurrentIndex ? 'tt-search-current' : 'tt-search-match' });
    });
    editor.view.dispatch(editor.state.tr.setMeta(findReplacePluginKey, {
      decorations: DecorationSet.create(editor.state.doc, decos), results: searchResults, currentIndex: searchCurrentIndex,
    }));
    searchCountEl.textContent = searchResults.length ? (searchCurrentIndex + 1) + '/' + searchResults.length : '0/0';
    if (searchCurrentIndex !== -1) {
      var r = searchResults[searchCurrentIndex];
      editor.chain().setTextSelection({ from: r.from, to: r.to }).scrollIntoView().run();
    }
  }
  function clearSearch() {
    editor.view.dispatch(editor.state.tr.setMeta(findReplacePluginKey, { decorations: DecorationSet.empty, results: [], currentIndex: -1 }));
    searchResults = []; searchCurrentIndex = -1;
  }
  searchInput.addEventListener('input', function() { updateSearch(0); });
  searchPanel.addEventListener('click', function(e) {
    var b = e.target.closest('[data-search-act]');
    if (!b) return;
    var act = b.dataset.searchAct;
    if (act === 'prev') updateSearch(searchCurrentIndex - 1);
    else if (act === 'next') updateSearch(searchCurrentIndex + 1);
    else if (act === 'close') { clearSearch(); searchPanel.style.display = 'none'; }
    else if (act === 'replace') {
      if (searchCurrentIndex === -1) return;
      var r = searchResults[searchCurrentIndex];
      editor.view.dispatch(editor.state.tr.insertText(replaceInput.value, r.from, r.to));
      updateSearch(searchCurrentIndex);
    } else if (act === 'replaceAll') {
      if (!searchResults.length) return;
      var tr = editor.state.tr;
      for (var i = searchResults.length - 1; i >= 0; i--) tr.insertText(replaceInput.value, searchResults[i].from, searchResults[i].to);
      editor.view.dispatch(tr);
      updateSearch(0);
    }
  });

  /* ── 표 셀 플로팅 메뉴 — 상단 고정 버튼 대신, 표 안에 커서/선택이 있을 때만 그 위치 근처에
   *  떠서 병합·나누기·행/열 추가삭제를 보여준다. 좌클릭/드래그 때마다 뜨면 방해가 돼서
   *  실제 우클릭(contextmenu) 이벤트로만 연다 — 엑셀처럼 "필요한 셀(들)을 먼저 좌클릭/드래그로
   *  선택해두고, 그 위에서 우클릭하면 메뉴가 뜨는" 방식. 이러면 드래그 도중 계속 따라다니거나,
   *  마우스가 눌린 상태를 못 놓쳐서 생기던 여러 문제(이전에 시도했던 mouseup 안전장치 등)가
   *  전부 필요 없어진다 — 우클릭은 명시적인 단발성 이벤트라 훨씬 다루기 쉽다. */
  var CELL_MENU_SPEC = [
    { cmd: 'mergeCells', icon: 'ti-arrows-join', label: '셀 병합', multiOnly: true },
    { sep: true, multiOnly: true },
    { cmd: 'splitCell', icon: 'ti-arrows-split', label: '셀 나누기' },
    'sep',
    { cmd: 'addRowBefore', icon: 'ti-row-insert-top', label: '위에 행 추가' },
    { cmd: 'deleteRow', icon: 'ti-row-remove', label: '행 삭제' },
    { cmd: 'addColumnBefore', icon: 'ti-column-insert-left', label: '왼쪽에 열 추가' },
    { cmd: 'deleteColumn', icon: 'ti-column-remove', label: '열 삭제' },
    { sep: true, multiOnly: true },
    { cmd: 'equalizeCols', icon: 'ti-columns', label: '열 폭 맞추기', multiOnly: true },
    { cmd: 'equalizeRows', icon: 'ti-row-insert-top', label: '행 높이 맞추기', multiOnly: true },
    'sep',
    // 표 폭 4개 + 표 정렬 3개를 그냥 다 펼쳐놓으면 메뉴가 계속 길어지므로, 하나로 묶어서
    // 눌렀을 때만 펼쳐지는 서브메뉴로 넣는다.
    {
      submenuId: 'tableWidth', icon: 'ti-arrows-maximize', label: '표 폭',
      submenu: [
        { cmd: 'tableWidth100', label: '100%' },
        { cmd: 'tableWidth75', label: '75%' },
        { cmd: 'tableWidth50', label: '50%' },
        { cmd: 'tableWidth25', label: '25%' },
      ],
    },
    {
      submenuId: 'tableAlign', icon: 'ti-align-center', label: '표 정렬',
      submenu: [
        { cmd: 'tableAlignLeft', label: '왼쪽' },
        { cmd: 'tableAlignCenter', label: '가운데' },
        { cmd: 'tableAlignRight', label: '오른쪽' },
      ],
    },
  ];
  var cellMenu = document.createElement('div');
  cellMenu.className = 'tt-panel tt-cell-menu';
  cellMenu.innerHTML = CELL_MENU_SPEC.map(function(item) {
    if (item === 'sep') return '<span class="tt-cell-menu-sep"></span>';
    if (item.sep) return '<span class="tt-cell-menu-sep"' + (item.multiOnly ? ' data-multi-only="1"' : '') + '></span>';
    if (item.submenu) {
      // 서브메뉴 항목(<div class="tt-cell-submenu">)은 여기(cellMenu 안)에 안 두고
      // 아래에서 wrap에 직접 붙인다 — cellMenu에 걸린 overflow-y:auto(메뉴 길어질 때
      // 스크롤 나오게 하는 안전장치)가 플라이아웃까지 같이 잘라버려서 안 보이는 문제가
      // 있었다(실제로 겪음). 토글 버튼만 여기 두고, 실제 펼쳐지는 목록은 완전히 밖에서
      // position:fixed로 좌표를 직접 계산해 그린다.
      return '<div class="tt-cell-submenu-group">' +
        '<button type="button" class="tt-cell-menu-item tt-cell-submenu-toggle" data-submenu-toggle="' + item.submenuId + '">' +
        '<i class="ti ' + item.icon + '"></i><span>' + item.label + '</span>' +
        '<i class="ti ti-chevron-right tt-cell-submenu-chevron"></i></button>' +
        '</div>';
    }
    return '<button type="button" class="tt-cell-menu-item" data-table-cmd="' + item.cmd + '"' +
      (item.multiOnly ? ' data-multi-only="1"' : '') + '>' +
      '<i class="ti ' + item.icon + '"></i><span>' + item.label + '</span></button>';
  }).join('');
  cellMenu.style.display = 'none';
  wrap.appendChild(cellMenu);

  // 서브메뉴 플라이아웃들 — cellMenu 밖(wrap의 직접 자식)에 따로 만들어서 cellMenu의
  // overflow에 안 잘리게 한다.
  var submenuEls = {};
  CELL_MENU_SPEC.forEach(function(item) {
    if (!item.submenu) return;
    var el = document.createElement('div');
    el.className = 'tt-panel tt-cell-submenu';
    el.dataset.submenu = item.submenuId;
    el.innerHTML = item.submenu.map(function(sub) {
      return '<button type="button" class="tt-cell-menu-item tt-cell-submenu-item" data-table-cmd="' + sub.cmd + '">' +
        '<span>' + sub.label + '</span></button>';
    }).join('');
    el.style.display = 'none';
    wrap.appendChild(el);
    submenuEls[item.submenuId] = el;
  });

  function closeAllSubmenus() {
    Object.keys(submenuEls).forEach(function(id) {
      submenuEls[id].style.display = 'none';
      submenuEls[id].classList.remove('tt-flip-left');
    });
    wrap.querySelectorAll('.tt-cell-submenu-toggle.tt-open').forEach(function(b) { b.classList.remove('tt-open'); });
  }
  function openSubmenu(targetId) {
    var toggleBtn = cellMenu.querySelector('[data-submenu-toggle="' + targetId + '"]');
    var sub = submenuEls[targetId];
    if (!toggleBtn || !sub || sub.style.display !== 'none') return;
    closeAllSubmenus(); // 한 번에 하나만 펼쳐지게
    toggleBtn.classList.add('tt-open');
    // window.scrollY/X를 더하는 방식은 창 전체가 스크롤된다는 가정이 깔려있어서, 안쪽의
    // 특정 div가 스크롤되는 구조에서는 계산이 틀렸다(실제로 겪음). wrap과의 화면 좌표
    // 차이로 계산하면 어느 쪽이 스크롤되든 항상 정확하다.
    var btnRect = toggleBtn.getBoundingClientRect();
    var wrapRectForSub = wrap.getBoundingClientRect();
    sub.style.display = 'flex';
    sub.style.left = (btnRect.right - 4 - wrapRectForSub.left) + 'px';
    sub.style.top = (btnRect.top - 4 - wrapRectForSub.top) + 'px';
    // 화면 오른쪽 끝에 닿으면 자동으로 왼쪽에 뜨도록(셸 메뉴처럼) — 일단 오른쪽으로 그려서
    // 실제 크기를 잰 다음, 뷰포트 밖으로 나가면 반대쪽으로 다시 계산한다.
    var subRect = sub.getBoundingClientRect();
    if (subRect.right > window.innerWidth) {
      sub.style.left = (btnRect.left - subRect.width + 4 - wrapRectForSub.left) + 'px';
    }
  }
  // 마우스가 부모 항목(toggle)이나 그 플라이아웃(submenu) 중 어느 하나 위에 있는 동안은
  // 계속 열려있게 하고, 둘 다에서 벗어나면(약간의 유예 시간 후) 닫는다 — 부모→플라이아웃으로
  // 대각선 이동하는 짧은 순간에 마우스가 그 사이 빈 공간을 지나가도 안 닫히게 하기 위함이다.
  var closeTimer = null;
  function cancelClose() { if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; } }
  function scheduleClose() { closeTimer = setTimeout(function() { closeAllSubmenus(); }, 200); }
  cellMenu.querySelectorAll('.tt-cell-submenu-group').forEach(function(group) {
    var toggleBtn = group.querySelector('.tt-cell-submenu-toggle');
    var targetId = toggleBtn.dataset.submenuToggle;
    group.addEventListener('mouseenter', function() { cancelClose(); openSubmenu(targetId); });
    group.addEventListener('mouseleave', scheduleClose);
  });
  Object.keys(submenuEls).forEach(function(id) {
    submenuEls[id].addEventListener('mouseenter', cancelClose);
    submenuEls[id].addEventListener('mouseleave', scheduleClose);
    submenuEls[id].addEventListener('mousedown', function(e) { if (e.target.closest('.tt-cell-menu-item')) e.preventDefault(); });
    submenuEls[id].addEventListener('click', function(e) {
      var b = e.target.closest('.tt-cell-menu-item');
      if (!b) return;
      cellMenuHandleCommand(b.dataset.tableCmd);
    });
  });

  cellMenu.addEventListener('mousedown', function(e) { if (e.target.closest('.tt-cell-menu-item')) e.preventDefault(); });
  cellMenu.addEventListener('click', function(e) {
    var toggleBtn = e.target.closest('.tt-cell-submenu-toggle');
    if (toggleBtn) {
      // 터치 기기처럼 호버가 없는 환경을 위한 클릭 토글 — 이미 열려있으면 닫고, 아니면 연다.
      var targetId = toggleBtn.dataset.submenuToggle;
      var sub = submenuEls[targetId];
      if (sub.style.display !== 'none') closeAllSubmenus();
      else openSubmenu(targetId);
      return;
    }
    var b = e.target.closest('.tt-cell-menu-item');
    if (!b) return;
    cellMenuHandleCommand(b.dataset.tableCmd);
  });
  function cellMenuHandleCommand(cmd) {
    // equalizeCols/Rows는 chain 커맨드가 아니라 이 파일 아래쪽의 별도 함수(editor를 인자로 받음)라 따로 처리.
    if (cmd === 'equalizeCols') { equalizeColumnWidths(editor); cellMenu.style.display = 'none'; return; }
    if (cmd === 'equalizeRows') { equalizeRowHeights(editor); cellMenu.style.display = 'none'; return; }
    if (cmd === 'tableWidth100' || cmd === 'tableWidth75' || cmd === 'tableWidth50' || cmd === 'tableWidth25') {
      var pct = Number(cmd.replace('tableWidth', ''));
      scaleTableWidth(editor, pct);
      editor.view.focus();
      cellMenu.style.display = 'none';
      return;
    }
    if (cmd === 'tableAlignLeft' || cmd === 'tableAlignCenter' || cmd === 'tableAlignRight') {
      var alignVal = cmd === 'tableAlignLeft' ? 'left' : cmd === 'tableAlignCenter' ? 'center' : 'right';
      setTableAlignment(editor, alignVal);
      editor.view.focus();
      cellMenu.style.display = 'none';
      return;
    }
    if (cmd === 'splitCell') {
      // "셀 나누기"는 두 가지 의미로 다 쓰인다 — ① 예전에 합친 셀을 원래대로 되돌리기,
      // ② 합친 적 없는 일반 셀을 새로 여러 칸으로 쪼개기. ProseMirror 표준 splitCell은
      // ①만 지원해서, 지금 커서가 있는 셀이 실제로 합쳐진 상태(colspan/rowspan>1)인지
      // 먼저 확인해서 ①이면 표준 명령, 아니면 몇 칸으로 나눌지 물어보고 ②를 실행한다.
      var $c = editor.state.selection.$from;
      var curCellNode = null;
      for (var d = $c.depth; d > 0; d--) {
        var n = $c.node(d);
        if (n.type.name === 'tableCell' || n.type.name === 'tableHeader') { curCellNode = n; break; }
      }
      var isMerged = curCellNode && ((curCellNode.attrs.colspan || 1) > 1 || (curCellNode.attrs.rowspan || 1) > 1);
      if (isMerged) {
        editor.chain().focus().splitCell().run();
      } else {
        var colsInput = prompt('몇 개의 열로 나눌까요? (나누지 않으려면 1)', '2');
        if (colsInput === null) { cellMenu.style.display = 'none'; return; }
        var numCols = Math.max(1, Math.min(8, parseInt(colsInput, 10) || 1));
        var rowsInput = prompt('몇 개의 행으로 나눌까요? (나누지 않으려면 1)', '1');
        if (rowsInput === null) { cellMenu.style.display = 'none'; return; }
        var numRows = Math.max(1, Math.min(8, parseInt(rowsInput, 10) || 1));
        if (numCols < 2 && numRows < 2) { cellMenu.style.display = 'none'; return; } // 둘 다 1이면 나눌 게 없음
        if (numCols >= 2) splitCellIntoColumns(editor, numCols);
        if (numRows >= 2) splitCellIntoRows(editor, numRows); // 열 나누기가 커서를 첫 번째 새 셀로 되돌려놔서 이어서 호출해도 정확한 셀을 대상으로 함
      }
      cellMenu.style.display = 'none';
      return;
    }
    var chain = editor.chain().focus();
    if (typeof chain[cmd] === 'function') chain[cmd]().run();
    cellMenu.style.display = 'none';
  }

  /** 우클릭한 지점이 표 안이면 브라우저 기본 컨텍스트 메뉴 대신 이 메뉴를 그 자리에 띄운다.
   *  드래그로 이미 여러 셀을 선택해둔 상태에서 우클릭하면 그 다중 선택을 그대로 유지하고,
   *  단순히 셀 하나 위에서 우클릭한 거면(다중 선택 중이 아니면) 그 위치로 커서를 옮긴다. */
  // 우클릭도 결국 "마우스다운"이라, 그 순간 브라우저/ProseMirror가 기본 동작으로 선택을
  // 커서 위치로 정리해버리면서 — 드래그로 여러 셀을 선택해둔 상태에서 우클릭만 해도 그
  // 선택(CellSelection)이 사라져버리는 문제가 있었다. CellSelection은 실제 브라우저
  // 네이티브 선택(Range)이 아니라 ProseMirror 내부 개념이라, 우클릭의 기본 처리가 이걸
  // 존중하지 않고 그냥 클릭한 지점으로 커서를 옮겨버리는 것으로 보인다. 우클릭의 mousedown
  // 자체를 캡처 단계에서 막아서 이 기본 처리가 아예 일어나지 않게 한다(실제 커서/선택
  // 이동은 아래 contextmenu 핸들러가 필요할 때만 명시적으로 처리한다).
  document.addEventListener('mousedown', function(e) {
    if (e.button === 2 && target.contains(e.target)) e.preventDefault();
  }, true);

  document.addEventListener('contextmenu', function(e) {
    if (!target.contains(e.target)) { cellMenu.style.display = 'none'; return; } // 에디터 밖 우클릭 — 상관없음
    var posInfo = editor.view.posAtCoords({ left: e.clientX, top: e.clientY });
    var inTable = false;
    if (posInfo) {
      var $pos = editor.state.doc.resolve(posInfo.pos);
      for (var d = $pos.depth; d > 0; d--) { if ($pos.node(d).type.name === 'table') { inTable = true; break; } }
    }
    if (!inTable) { cellMenu.style.display = 'none'; return; } // 표 밖 — 기본 브라우저 메뉴 그대로 둔다
    e.preventDefault();
    closeAllSubmenus(); // 메뉴를 열 때마다 서브메뉴는 항상 닫힌 상태로 시작
    hideAllPanels(cellMenu);
    if (!(editor.state.selection instanceof CellSelection)) {
      // setTextSelection은 내부적으로 TextSelection.create()를 그대로 쓰는데, 이건 정확히
      // "텍스트 콘텐츠 안쪽" 위치만 받는다 — 우클릭 좌표가 셀 경계(문단이 아니라 셀 자체의
      // 경계)에 걸리면 콘솔에 경고가 뜨고 커서 위치도 애매해진다. Selection.near()는 그
      // 근처의 실제로 유효한 위치를 스스로 찾아주는 안전한 방식이라 이걸로 대신한다.
      var $clickPos = editor.state.doc.resolve(posInfo.pos);
      var tr = editor.state.tr.setSelection(Selection.near($clickPos));
      editor.view.dispatch(tr);
    }
    var sel = editor.state.selection;
    var isMulti = false;
    if (sel instanceof CellSelection) {
      var n = 0;
      sel.forEachCell(function() { n++; });
      isMulti = n > 1;
    }
    cellMenu.querySelectorAll('[data-multi-only]').forEach(function(btn) {
      btn.style.display = isMulti ? '' : 'none';
    });
    // 메뉴 항목이 늘어나면서(표 폭 옵션 추가 등) 화면 아래로 넘쳐 잘리는 경우가 생겼다 —
    // 일단 화면에 보이는 상태로 만들어 실제 크기를 잰 다음, 뷰포트 밖으로 나가면 반대쪽
    // (위쪽/왼쪽)에 뜨도록 좌표를 보정한다.
    cellMenu.style.top = '0px';
    cellMenu.style.left = '0px';
    cellMenu.style.visibility = 'hidden';
    cellMenu.style.display = '';
    var menuRect = cellMenu.getBoundingClientRect();
    cellMenu.style.visibility = '';
    var top = e.clientY + 4;
    var left = e.clientX;
    if (top + menuRect.height > window.innerHeight) top = Math.max(4, window.innerHeight - menuRect.height - 4);
    if (left + menuRect.width > window.innerWidth) left = Math.max(4, window.innerWidth - menuRect.width - 4);
    // window.scrollY를 더하는 방식은 창 전체가 스크롤된다는 가정이 깔려있어서, 안쪽의
    // 특정 div가 스크롤되는 구조에서는 계산이 틀렸다(실제로 겪음) — wrap 기준 상대좌표로
    // 바꾼다(어느 쪽이 스크롤되든 항상 정확).
    var wrapRectForMenu = wrap.getBoundingClientRect();
    cellMenu.style.top = (top - wrapRectForMenu.top) + 'px';
    cellMenu.style.left = (left - wrapRectForMenu.left) + 'px';
  });

  /* ── 표 삽입 그리드 피커 — 마우스로 몇 x 몇 칸인지 직접 골라서 넣는다 ── */
  var TABLE_PICKER_MAX = 8; // 최대 8x8까지
  var tablePicker = document.createElement('div');
  tablePicker.className = 'tt-panel tt-table-picker';
  var pickerGridHtml = '';
  for (var pr = 1; pr <= TABLE_PICKER_MAX; pr++) {
    for (var pc = 1; pc <= TABLE_PICKER_MAX; pc++) {
      pickerGridHtml += '<span class="tt-table-picker-cell" data-r="' + pr + '" data-c="' + pc + '"></span>';
    }
  }
  tablePicker.innerHTML =
    '<div class="tt-table-picker-grid" style="grid-template-columns:repeat(' + TABLE_PICKER_MAX + ',1fr);">' + pickerGridHtml + '</div>' +
    '<div class="tt-table-picker-label">표 삽입</div>';
  tablePicker.style.display = 'none';
  wrap.appendChild(tablePicker);
  var tablePickerLabel = tablePicker.querySelector('.tt-table-picker-label');
  tablePicker.addEventListener('mouseover', function(e) {
    var cell = e.target.closest('.tt-table-picker-cell');
    if (!cell) return;
    var r = Number(cell.dataset.r), c = Number(cell.dataset.c);
    tablePicker.querySelectorAll('.tt-table-picker-cell').forEach(function(el) {
      el.classList.toggle('is-hover', Number(el.dataset.r) <= r && Number(el.dataset.c) <= c);
    });
    tablePickerLabel.textContent = r + ' x ' + c + ' 표';
  });
  tablePicker.addEventListener('click', function(e) {
    var cell = e.target.closest('.tt-table-picker-cell');
    if (!cell) return;
    var rows = Number(cell.dataset.r), cols = Number(cell.dataset.c);
    editor.chain().focus().insertTable({ rows: rows, cols: cols, withHeaderRow: true }).run();
    tablePicker.style.display = 'none';
  });

  /* ── 특수 문자 패널 ── */
  var charsPanel = document.createElement('div');
  charsPanel.className = 'tt-panel tt-chars-panel';
  charsPanel.innerHTML = SPECIAL_CHARS.map(function(ch) { return '<button type="button" class="tt-char-btn">' + ch + '</button>'; }).join('');
  charsPanel.style.display = 'none';
  wrap.appendChild(charsPanel);
  charsPanel.addEventListener('click', function(e) {
    var b = e.target.closest('.tt-char-btn');
    if (!b) return;
    editor.chain().focus().insertContent(b.textContent).run();
    charsPanel.style.display = 'none';
  });

  /* ── 툴바 안내 패널 ── */
  var guidePanel = document.createElement('div');
  guidePanel.className = 'tt-panel tt-guide-panel';
  guidePanel.innerHTML = TOOLBAR_GUIDE.map(function(g) {
    return '<div class="tt-guide-group"><b>' + g.label + '</b><span>' + g.items.join(' · ') + '</span></div>';
  }).join('');
  guidePanel.style.display = 'none';
  wrap.appendChild(guidePanel);

  /* ── 소스 보기(HTML 직접 편집) ── */
  var sourceArea = document.createElement('textarea');
  sourceArea.className = 'tt-source-view';
  sourceArea.style.display = 'none';
  wrap.appendChild(sourceArea);
  var sourceMode = false;
  function toggleSourceView() {
    sourceMode = !sourceMode;
    if (sourceMode) {
      sourceArea.value = editor.getHTML();
      target.style.display = 'none';
      sourceArea.style.display = '';
    } else {
      editor.commands.setContent(sourceArea.value || '');
      sourceArea.style.display = 'none';
      target.style.display = '';
    }
    toolbarEl.querySelector('.tt-btn[data-cmd="sourceView"]').classList.toggle('is-active', sourceMode);
  }

  /* ── 글자색/배경색 — 네이티브 컬러피커(input[type=color]) ──
   * 예전엔 크기 1px + opacity:0인 input을 툴바 아무 데나(wrap) 붙여놓고 버튼 클릭 시
   * .click()으로 여는 방식이었는데, 최근 브라우저들은 악용 방지 차원에서 이렇게 지나치게
   * 숨겨진(거의 안 보이는) input에 대해 네이티브 컬러피커 열기 자체를 조용히 거부하는
   * 경우가 있다(자동 테스트/jsdom으로는 이 제약을 재현할 수 없어서 코드만 봐선 멀쩡해
   * 보였다). 그래서 버튼 자신의 크기와 위치에 정확히 겹치는 투명 오버레이로 바꾼다 —
   * 이게 커스텀 스타일 입힌 네이티브 입력요소를 만드는 표준적이고 안전한 방식이다. */
  var fontColorBtnEl = toolbarEl.querySelector('[data-cmd="fontColor"]');
  var fontColorInput = document.createElement('input');
  fontColorInput.type = 'color';
  fontColorInput.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; opacity:0; cursor:pointer; border:none; padding:0; margin:0;';
  fontColorInput.addEventListener('input', function() { editor.chain().focus().setColor(fontColorInput.value).run(); });
  if (fontColorBtnEl) {
    fontColorBtnEl.style.position = 'relative';
    fontColorBtnEl.appendChild(fontColorInput);
  } else {
    wrap.appendChild(fontColorInput); // 혹시 버튼을 못 찾으면 예전 방식으로라도 동작은 하게
  }

  var bgColorBtnEl = toolbarEl.querySelector('[data-cmd="bgColor"]');
  var bgColorInput = document.createElement('input');
  bgColorInput.type = 'color';
  bgColorInput.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; opacity:0; cursor:pointer; border:none; padding:0; margin:0;';
  bgColorInput.addEventListener('input', function() { editor.chain().focus().setBackgroundColor(bgColorInput.value).run(); });
  if (bgColorBtnEl) {
    bgColorBtnEl.style.position = 'relative';
    bgColorBtnEl.appendChild(bgColorInput);
  } else {
    wrap.appendChild(bgColorInput);
  }

  function openPanelUnder(panel, btn) {
    var r = btn.getBoundingClientRect();
    var wrapRect = wrap.getBoundingClientRect();
    // window.scrollY를 더하는 방식은 "창 전체가 스크롤된다"는 가정이 깔려있어서, 안쪽의
    // 특정 div가 스크롤되는 구조(실제로 이 앱이 이런 구조였음)에서는 window.scrollY가
    // 항상 0이라 계산이 틀렸었다(실제로 겪음). 대신 버튼과 wrap의 화면 좌표 차이를 쓰면,
    // 어느 쪽이 스크롤되는 구조든 상관없이 항상 정확하다 — 같은 순간에 잰 두 좌표의 차는
    // 공통으로 걸린 스크롤 변형이 자동으로 상쇄되기 때문이다.
    panel.style.top = (r.bottom - wrapRect.top + 4) + 'px';
    panel.style.left = (Math.min(r.left - wrapRect.left, window.innerWidth - 300)) + 'px';
    panel.style.display = '';
  }

  var ALL_PANELS = [charsPanel, guidePanel, searchPanel, tablePicker, cellMenu];
  function hideAllPanels(except) {
    ALL_PANELS.forEach(function(p) { if (p !== except) p.style.display = 'none'; });
  }

  // 툴바 클릭/변경 이벤트
  toolbarEl.addEventListener('click', function(e) {
    var btn = e.target.closest('.tt-btn');
    if (!btn) return;
    var cmd = btn.dataset.cmd;
    if (cmd === 'image') { editor._imageFileInput.click(); return; }
    // fontColor/bgColor는 이제 버튼 위에 정확히 겹치는 투명 오버레이(input[type=color])가
    // 클릭을 직접 받아서 네이티브 컬러피커를 스스로 연다 — 여기서 또 .click()을 호출하면
    // 중복으로 열리려고 시도할 수 있어 뺐다.
    if (cmd === 'insertTable') {
      hideAllPanels(tablePicker);
      tablePicker.style.display === 'none' ? openPanelUnder(tablePicker, btn) : (tablePicker.style.display = 'none');
      return;
    }
    if (cmd === 'specialChars') {
      hideAllPanels(charsPanel);
      charsPanel.style.display === 'none' ? openPanelUnder(charsPanel, btn) : (charsPanel.style.display = 'none');
      return;
    }
    if (cmd === 'guide') {
      hideAllPanels(guidePanel);
      guidePanel.style.display === 'none' ? openPanelUnder(guidePanel, btn) : (guidePanel.style.display = 'none');
      return;
    }
    if (cmd === 'findReplace') {
      hideAllPanels(searchPanel);
      if (searchPanel.style.display === 'none') { openPanelUnder(searchPanel, btn); searchInput.focus(); }
      else { clearSearch(); searchPanel.style.display = 'none'; }
      return;
    }
    if (cmd === 'sourceView') { hideAllPanels(null); toggleSourceView(); return; }
    runToolbarCmd(editor, cmd);
  });
  toolbarEl.addEventListener('change', function(e) {
    var sel = e.target.closest('.tt-select');
    if (!sel) return;
    if (sel.dataset.cmd === 'heading') {
      var v = sel.value;
      if (v === 'p') editor.chain().focus().setParagraph().run();
      else editor.chain().focus().setHeading({ level: Number(v) }).run();
    } else if (sel.dataset.cmd === 'fontFamily') {
      if (sel.value) editor.chain().focus().setFontFamily(sel.value).run();
      else editor.chain().focus().unsetFontFamily().run();
    } else if (sel.dataset.cmd === 'fontSize') {
      if (sel.value) editor.chain().focus().setFontSize(sel.value).run();
      else editor.chain().focus().unsetFontSize().run();
    }
  });

  // 이미지 삽입용 숨김 파일 input — base64로 바로 삽입(서버 업로드 없이 CKEditor Base64UploadAdapter와 동일 방식)
  var imgInput = document.createElement('input');
  imgInput.type = 'file';
  imgInput.accept = 'image/*';
  imgInput.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;opacity:0;';
  imgInput.addEventListener('change', function() {
    insertImageFromFile(editor, imgInput.files && imgInput.files[0]);
    imgInput.value = '';
  });
  wrap.appendChild(imgInput);
  editor._imageFileInput = imgInput;

  document.addEventListener('click', function(e) {
    if (!charsPanel.contains(e.target) && !e.target.closest('.tt-btn[data-cmd="specialChars"]')) charsPanel.style.display = 'none';
    if (!guidePanel.contains(e.target) && !e.target.closest('.tt-btn[data-cmd="guide"]')) guidePanel.style.display = 'none';
    if (!searchPanel.contains(e.target) && !e.target.closest('.tt-btn[data-cmd="findReplace"]')) searchPanel.style.display = 'none';
    if (!tablePicker.contains(e.target) && !e.target.closest('.tt-btn[data-cmd="insertTable"]')) tablePicker.style.display = 'none';
    if (!cellMenu.contains(e.target)) cellMenu.style.display = 'none';
  });

  editor.on('selectionUpdate', function() { syncToolbarState(editor, toolbarEl); });
  editor.on('transaction', function() { syncToolbarState(editor, toolbarEl); });
  syncToolbarState(editor, toolbarEl);

  setupRowResize(editor);
  var syncTableHandles = setupTableWidthResize(editor);
  return editor;
}

/* ── 표 프리셋 ── */
var TABLE_PRESETS = {
  items: '<table><tbody>' +
    '<tr><th>품목명</th><th>규격</th><th>수량</th><th>단가</th><th>금액</th><th>비고</th></tr>' +
    '<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>' +
    '<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>' +
    '</tbody></table>',
  infogrid: '<table><tbody>' +
    '<tr><th>항목</th><td></td><th>항목</th><td></td></tr>' +
    '<tr><th>항목</th><td></td><th>항목</th><td></td></tr>' +
    '</tbody></table>',
  expense: '<table><tbody>' +
    '<tr><th>항목</th><th>금액</th><th>비고</th></tr>' +
    '<tr><td></td><td></td><td></td></tr>' +
    '<tr><td></td><td></td><td></td></tr>' +
    '<tr><td><strong>합계</strong></td><td></td><td></td></tr>' +
    '</tbody></table>',
};

function insertTablePreset(editor, key) {
  if (!editor) return;
  if (key === 'grid33') {
    editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: false }).run();
    return;
  }
  var html = TABLE_PRESETS[key];
  if (!html) return;
  editor.chain().focus().insertContent(html).run();
}

/** 현재 커서가 들어있는 표 노드를 찾는다 (없으면 null).
 *  반환: { node, pos } — pos는 표 노드 시작 위치(ProseMirror 문서 좌표, 표 여는 태그 바로 앞). */
function findCurrentTable(editor) {
  if (!editor) return null;
  var $pos = editor.state.selection.$from;
  for (var d = $pos.depth; d > 0; d--) {
    if ($pos.node(d).type.name === 'table') {
      return { node: $pos.node(d), pos: $pos.before(d) };
    }
  }
  return null;
}

/** 일반(합친 적 없는) 셀도 원하는 칸수로 나눈다. ProseMirror 표준 splitCell 명령은
 *  "이미 합쳐진 셀을 원상복구"만 하는데, 여기서는 그것과 별개로 "이 셀 자체를 N칸으로
 *  쪼개기"를 지원한다. 표는 모든 행의 칸 수가 맞아야 하는 격자 구조라, 이 셀만 쪼개면
 *  다른 행들과 칸 수가 안 맞게 되므로 — 같은 열 위치에 있는 다른 모든 행의 셀들 colspan을
 *  (n-1)만큼 늘려서 전체 격자를 다시 맞춰준다. */
function splitCellIntoColumns(editor, numCols) {
  if (!editor || !(numCols >= 2)) return;
  var table = findCurrentTable(editor);
  if (!table) return;
  var tableStart = table.pos + 1;
  var map = TableMap.get(table.node);

  var $cursor = editor.state.selection.$from;
  var cellPos = null;
  for (var d = $cursor.depth; d > 0; d--) {
    var n = $cursor.node(d);
    if (n.type.name === 'tableCell' || n.type.name === 'tableHeader') { cellPos = $cursor.before(d); break; }
  }
  if (cellPos == null) return;
  var cellRelPos = cellPos - tableStart;
  var idx = map.map.indexOf(cellRelPos);
  if (idx === -1) return;
  var col = idx % map.width;
  var row = Math.floor(idx / map.width);

  var tr = editor.state.tr;
  var alreadyAdjusted = {}; // rowspan으로 여러 행이 같은 셀을 가리킬 수 있어 중복 조정 방지

  for (var r = 0; r < map.height; r++) {
    if (r === row) continue;
    var relAtColStart = map.map[r * map.width + col];
    if (alreadyAdjusted[relAtColStart]) continue;
    alreadyAdjusted[relAtColStart] = true;
    var absPos = tableStart + relAtColStart;
    var otherNode = tr.doc.nodeAt(absPos);
    if (!otherNode) continue;
    var newColspan = (otherNode.attrs.colspan || 1) + (numCols - 1);
    tr.setNodeMarkup(absPos, undefined, Object.assign({}, otherNode.attrs, { colspan: newColspan, colwidth: null }));
  }

  var cellNode = tr.doc.nodeAt(cellPos);
  if (!cellNode) return;
  var cellType = cellNode.type;
  var emptyParaType = cellType.contentMatch.defaultType;
  var newCells = [];
  for (var i = 0; i < numCols; i++) {
    var content = i === 0 ? cellNode.content : (emptyParaType ? emptyParaType.create() : cellNode.content);
    newCells.push(cellType.create(Object.assign({}, cellNode.attrs, { colspan: 1, colwidth: null }), content));
  }
  tr.replaceWith(cellPos, cellPos + cellNode.nodeSize, newCells);
  // 커서를 명시적으로 "방금 나눈 첫 번째 새 셀" 안으로 되돌린다 — 안 그러면 이 셀 전체를
  // 통째로 교체(replaceWith)한 여파로 ProseMirror가 선택 위치를 엉뚱한(주로 바로 다음) 셀로
  // 옮겨버려서, 이어서 "행으로도 나누기"를 호출하면 의도한 셀이 아니라 다른 셀이 나뉘는
  // 문제가 있었다.
  tr.setSelection(Selection.near(tr.doc.resolve(cellPos + 2)));
  editor.view.dispatch(tr);
}

/** splitCellIntoColumns와 같은 원리로 행(세로) 방향으로 나눈다. 현재 셀은 그대로 두고
 *  그 아래로 새 행을 (n-1)개 끼워 넣어서, 같은 열 위치에 새 셀을 하나씩 추가한다. 이 행에
 *  있는 "다른" 셀들(나누는 셀의 열 범위 밖)은 rowspan을 (n-1)만큼 늘려서 새로 끼워진
 *  행들까지 계속 덮도록 한다. */
function splitCellIntoRows(editor, numRows) {
  if (!editor || !(numRows >= 2)) return;
  var table = findCurrentTable(editor);
  if (!table) return;
  var tableStart = table.pos + 1;
  var map = TableMap.get(table.node);

  var $cursor = editor.state.selection.$from;
  var cellPos = null;
  for (var d = $cursor.depth; d > 0; d--) {
    var n = $cursor.node(d);
    if (n.type.name === 'tableCell' || n.type.name === 'tableHeader') { cellPos = $cursor.before(d); break; }
  }
  if (cellPos == null) return;
  var cellRelPos = cellPos - tableStart;
  var idx = map.map.indexOf(cellRelPos);
  if (idx === -1) return;
  var col = idx % map.width;
  var row = Math.floor(idx / map.width);

  var tr = editor.state.tr;
  var cellNode = tr.doc.nodeAt(cellPos);
  if (!cellNode) return;
  var cellType = cellNode.type;
  var colspan = cellNode.attrs.colspan || 1;

  var alreadyAdjusted = {};
  for (var c = 0; c < map.width; c++) {
    if (c >= col && c < col + colspan) continue; // 나누는 셀 자신의 열 범위는 건너뜀
    var relAtRow = map.map[row * map.width + c];
    if (relAtRow == null) continue;
    var absPos = tableStart + relAtRow;
    if (alreadyAdjusted[absPos]) continue;
    alreadyAdjusted[absPos] = true;
    var otherNode = tr.doc.nodeAt(absPos);
    if (!otherNode) continue;
    var newRowspan = (otherNode.attrs.rowspan || 1) + (numRows - 1);
    tr.setNodeMarkup(absPos, undefined, Object.assign({}, otherNode.attrs, { rowspan: newRowspan }));
  }

  // 현재 행의 끝 위치(=바로 다음 행이 시작하는 위치) 계산 — 그 자리에 새 행들을 끼워 넣는다.
  var rowStartPos = tableStart;
  for (var i = 0; i < row; i++) rowStartPos += table.node.child(i).nodeSize;
  var rowEndPos = rowStartPos + table.node.child(row).nodeSize;

  var rowType = table.node.child(row).type;
  var emptyParaType2 = cellType.contentMatch.defaultType;
  var newRows = [];
  for (var k = 0; k < numRows - 1; k++) {
    var newCell = cellType.create(
      Object.assign({}, cellNode.attrs, { rowspan: 1, colspan: colspan }),
      emptyParaType2 ? emptyParaType2.create() : undefined
    );
    newRows.push(rowType.create(null, [newCell]));
  }
  tr.insert(rowEndPos, newRows);
  editor.view.dispatch(tr);
}

function mergeStyle(existingStyle, prop, value) {
  var styles = {};
  (existingStyle || '').split(';').forEach(function(part) {
    var kv = part.split(':');
    if (kv.length === 2 && kv[0].trim()) styles[kv[0].trim()] = kv[1].trim();
  });
  styles[prop] = value;
  return Object.keys(styles).map(function(k) { return k + ':' + styles[k]; }).join(';');
}

/** 스타일 문자열에서 특정 속성만 제거(나머지는 그대로 유지). 표 폭 조절(colwidth 방식)로
 *  넘어가면서, 예전 방식(셀 자체에 style="width:N%")으로 저장된 문서들엔 이 옛 스타일이
 *  colwidth와 같이 남아있게 되는데, 실제 브라우저에서는 이 둘이 서로 다른 값을 주장하면서
 *  충돌해 표가 원하는 만큼 안 늘어나거나 줄어드는 것처럼 보일 수 있다(jsdom은 이 상호작용을
 *  재현하지 못해서 코드 테스트만으론 못 잡았다). 그래서 컬럼 폭을 colwidth로 새로 정할 때,
 *  그 셀 자신의 옛 width 스타일은 지워서 애매함을 없앤다. */
function removeStyleProp(existingStyle, prop) {
  var styles = {};
  (existingStyle || '').split(';').forEach(function(part) {
    var kv = part.split(':');
    if (kv.length === 2 && kv[0].trim() && kv[0].trim() !== prop) styles[kv[0].trim()] = kv[1].trim();
  });
  var keys = Object.keys(styles);
  return keys.length ? keys.map(function(k) { return k + ':' + styles[k]; }).join(';') : null;
}

/** 표 안 모든 열의 폭을 동일하게 맞춤 — 각 셀에 style="width:N%"를 직접 써넣는다.
 *  (table-layout:fixed 렌더링 CSS와 짝이 맞아야 실제로 균등해진다.) */
/** 표 전체 폭을 퍼센트로 맞춘다 — ProseMirror 표 라이브러리의 컬럼 리사이즈 기능(resizable:true)이
 *  켜져 있으면, 그 라이브러리 자신의 전용 NodeView가 트랜잭션마다 표의 width/min-width를
 *  "각 셀의 colwidth 속성 합"을 기준으로 직접 다시 계산해서 덮어써버린다(실제로 겪은 문제 —
 *  커스텀 속성으로 style="width:.."을 넣어봐도 바로 그 다음 렌더링에서 지워짐). 그래서 별도
 *  속성을 새로 만드는 대신, 그 라이브러리가 실제로 읽는 colwidth 자체를 비례해서 조정한다 —
 *  이러면 그 라이브러리 자신의 로직과 충돌하지 않고, 오히려 그 계산 결과가 내가 원하는 값이
 *  되도록 입력을 맞춰주는 셈이라 안전하다. */
/** 표의 각 행 높이를 지정된 절대값(px) 배열로 맞춘다. 드래그 중 매번 "지금" DOM에서 다시
 *  측정해서 배율을 곱하면, 이전 호출에서 이미 반영된 값 위에 또 곱해지면서 오차가 누적된다
 *  — 그래서 드래그 시작 시점의 원래 높이를 한 번만 재고, 그 원본 기준으로 계산한 절대
 *  목표값을 여기 넘기는 방식으로 쓴다. */
function setTableRowHeights(editor, explicitTablePos, targetHeightsPx) {
  var tblNode = editor.state.doc.nodeAt(explicitTablePos);
  if (!tblNode || tblNode.type.name !== 'table') return false;
  var tr = editor.state.tr;
  var offset = 1;
  tblNode.forEach(function(rowNode, rowRelOffset, rowIndex) {
    var newPx = Math.max(20, Math.round(targetHeightsPx[rowIndex] || 30));
    var cellOffset = offset + 1;
    rowNode.forEach(function(cellNode) {
      var cellPos = explicitTablePos + cellOffset;
      var freshCell = tr.doc.nodeAt(cellPos);
      if (freshCell) {
        var newStyle = mergeStyle(freshCell.attrs.style, 'height', newPx + 'px');
        tr.setNodeMarkup(cellPos, undefined, Object.assign({}, freshCell.attrs, { style: newStyle }));
      }
      cellOffset += cellNode.nodeSize;
    });
    offset += rowNode.nodeSize;
  });
  editor.view.dispatch(tr);
  return true;
}

/** 표 정렬(왼쪽/가운데/오른쪽) — 표 자신에게는 못 저장하므로(위 withStyleAttr 설명 참고),
 *  첫 행의 모든 셀에 tableAlign 값을 똑같이 써넣는다. 실제 마진 적용은
 *  setupTableWidthResize의 ensureHandles가 이 값을 셀에서 읽어 wrapper에 넣어준다. */
function setTableAlignment(editor, align) {
  var table = findCurrentTable(editor);
  if (!table) return false;
  var tr = editor.state.tr;
  var firstRow = table.node.child(0);
  var offset = table.pos + 2; // +1: 첫 행 자신의 위치, +1 더: 그 행의 내용(첫 셀) 시작
  firstRow.forEach(function(cellNode) {
    var pos = offset;
    var fresh = tr.doc.nodeAt(pos);
    if (fresh) tr.setNodeMarkup(pos, undefined, Object.assign({}, fresh.attrs, { tableAlign: align }));
    offset += cellNode.nodeSize;
  });
  editor.view.dispatch(tr);
  return true;
}

function scaleTableWidth(editor, targetPct, explicitTablePos) {
  var table;
  if (explicitTablePos != null) {
    var tblNode = editor.state.doc.nodeAt(explicitTablePos);
    if (!tblNode || tblNode.type.name !== 'table') return false;
    table = { node: tblNode, pos: explicitTablePos };
  } else {
    table = findCurrentTable(editor);
  }
  if (!table) return false;
  var tableDom = editor.view.nodeDOM(table.pos);
  if (tableDom && tableDom.tagName !== 'TABLE') tableDom = tableDom.querySelector ? tableDom.querySelector('table') : null;
  if (!tableDom) return false;

  var wrapperEl = tableDom.closest('.tableWrapper') || tableDom.parentElement;
  var paperEl = wrapperEl ? wrapperEl.parentElement : null;
  var paperWidthPx = paperEl ? paperEl.getBoundingClientRect().width : tableDom.getBoundingClientRect().width;
  if (!paperWidthPx) return false;
  var targetTotalPx = paperWidthPx * (targetPct / 100);

  // 이전엔 "첫 번째 행"의 셀들만 보고 계산했는데, 사용자가 실제로 리사이즈한 게 다른
  // 행(예: rowspan/colspan 헤더 아래에 있는 세부 행)이면 그 행의 폭 정보가 반영이 안 돼서,
  // 첫 행 기준으로 다시 스케일할 때 표 구조가 어긋나는(예: 열 하나가 사라진 것처럼 보이는)
  // 문제가 있었다(실제로 겪음). 그래서 TableMap으로 표 전체를 보고, "원자 컬럼"(더 이상
  // 안 쪼개지는 실제 격자 열) 하나하나의 폭을 모든 행에서 찾아서 확정한 다음, 표의 모든
  // 셀(모든 행)에 그 확정된 값을 일관되게 반영한다.
  var map = TableMap.get(table.node);
  var tableStart = table.pos + 1;

  var atomWidths = new Array(map.width).fill(null);
  var seenForWidth = {};
  for (var idx = 0; idx < map.map.length; idx++) {
    var relPos = map.map[idx];
    if (relPos == null || seenForWidth[relPos]) continue;
    seenForWidth[relPos] = true;
    var absPos = tableStart + relPos;
    var cellNode = editor.state.doc.nodeAt(absPos);
    if (!cellNode) continue;
    var colspan = cellNode.attrs.colspan || 1;
    var startCol = idx % map.width;
    var perColWidths;
    if (cellNode.attrs.colwidth && cellNode.attrs.colwidth.length === colspan && cellNode.attrs.colwidth.every(Boolean)) {
      perColWidths = cellNode.attrs.colwidth.slice();
    } else {
      var cellDom = editor.view.nodeDOM(absPos);
      var cellPx = cellDom && cellDom.getBoundingClientRect ? cellDom.getBoundingClientRect().width : null;
      var per = cellPx ? Math.max(25, Math.round(cellPx / colspan)) : 100;
      perColWidths = [];
      for (var w = 0; w < colspan; w++) perColWidths.push(per);
    }
    for (var ci = 0; ci < colspan; ci++) {
      var col = startCol + ci;
      // colspan=1인 셀에서 나온 값이 더 정확하다(콜스팬 셀은 균등 분배로 근사한 값이라
      // 부정확할 수 있음) — colspan=1 값이 있으면 그걸로 덮어써서 우선시킨다.
      if (atomWidths[col] == null || colspan === 1) atomWidths[col] = perColWidths[ci];
    }
  }
  for (var ac = 0; ac < atomWidths.length; ac++) { if (atomWidths[ac] == null) atomWidths[ac] = 100; }

  var currentTotalPx = atomWidths.reduce(function(a, b) { return a + b; }, 0);
  if (!currentTotalPx) return false;
  var scale = targetTotalPx / currentTotalPx;
  var newAtomWidths = atomWidths.map(function(w) {
    // ProseMirror 표 라이브러리 자신이 컬럼 폭의 실제 렌더링 최소값을 25px로 강제한다
    // (prosemirror-tables의 cellMinWidth 기본값) — 계산-실제화면 불일치 방지를 위해 맞춘다.
    return Math.max(25, Math.round(w * scale));
  });

  var tr = editor.state.tr;
  var seenForWrite = {};
  for (var idx2 = 0; idx2 < map.map.length; idx2++) {
    var relPos2 = map.map[idx2];
    if (relPos2 == null || seenForWrite[relPos2]) continue;
    seenForWrite[relPos2] = true;
    var absPos2 = tableStart + relPos2;
    var node2 = tr.doc.nodeAt(absPos2);
    if (!node2) continue;
    var colspan2 = node2.attrs.colspan || 1;
    var startCol2 = idx2 % map.width;
    var newWidths2 = [];
    for (var cj = 0; cj < colspan2; cj++) newWidths2.push(newAtomWidths[startCol2 + cj]);
    var cleanedStyle2 = removeStyleProp(node2.attrs.style, 'width'); // 옛 style="width:N%"와 충돌 방지
    tr.setNodeMarkup(absPos2, undefined, Object.assign({}, node2.attrs, { colwidth: newWidths2, style: cleanedStyle2 }));
  }
  editor.view.dispatch(tr);
  return true;
}

function equalizeColumnWidths(editor) {
  var table = findCurrentTable(editor);
  if (!table) { alert('표 안에 커서를 놓은 상태에서 눌러주세요.'); return; }
  try {
    var columnCount = 0;
    table.node.forEach(function(row) {
      var rowCols = 0;
      row.forEach(function(cell) { rowCols += cell.attrs.colspan || 1; });
      columnCount = Math.max(columnCount, rowCols);
    });
    if (!columnCount) return;

    var tr = editor.state.tr;
    table.node.descendants(function(node, relPos) {
      if (node.type.name !== 'tableCell' && node.type.name !== 'tableHeader') return;
      var colspan = node.attrs.colspan || 1;
      var pct = (100 / columnCount * colspan).toFixed(2) + '%';
      var newStyle = mergeStyle(node.attrs.style, 'width', pct);
      tr.setNodeMarkup(table.pos + 1 + relPos, undefined, Object.assign({}, node.attrs, { style: newStyle }));
    });
    editor.view.dispatch(tr);
  } catch (e) {
    console.error('[rich-editor] 열 폭 동일화 실패:', e);
    alert('열 폭을 맞추는 중 문제가 발생했습니다.');
  }
}

/** 표 안 모든 행의 높이를 동일하게(가장 큰 행 기준) 맞춤 — 실제 렌더링된 DOM 높이를
 *  측정해서(행높이 드래그 조절과 같은 방식) 각 셀에 style="height:Npx"를 써넣는다. */
function equalizeRowHeights(editor) {
  var table = findCurrentTable(editor);
  if (!table) { alert('표 안에 커서를 놓은 상태에서 눌러주세요.'); return; }
  try {
    var domInfo = editor.view.domAtPos(table.pos + 1);
    var tableDom = domInfo && domInfo.node && domInfo.node.closest ? domInfo.node.closest('table') : null;
    if (!tableDom) { var wrapDom = editor.view.nodeDOM(table.pos); tableDom = wrapDom && wrapDom.querySelector ? wrapDom.querySelector('table') || wrapDom : wrapDom; }
    if (!tableDom || !tableDom.querySelectorAll) return;
    var rows = Array.prototype.slice.call(tableDom.querySelectorAll(':scope > tbody > tr, :scope > tr'));
    if (!rows.length) return;
    var maxHeight = Math.max.apply(null, rows.map(function(tr2) { return tr2.getBoundingClientRect().height; }));
    var newHeight = Math.round(maxHeight) + 'px';

    var tr = editor.state.tr;
    table.node.descendants(function(node, relPos) {
      if (node.type.name !== 'tableCell' && node.type.name !== 'tableHeader') return;
      var newStyle = mergeStyle(node.attrs.style, 'height', newHeight);
      tr.setNodeMarkup(table.pos + 1 + relPos, undefined, Object.assign({}, node.attrs, { style: newStyle }));
    });
    editor.view.dispatch(tr);
  } catch (e) {
    console.error('[rich-editor] 행 높이 동일화 실패:', e);
    alert('행 높이를 맞추는 중 문제가 발생했습니다.');
  }
}

/* ── 표 행 높이 드래그 조절 — Tiptap(ProseMirror) 표에도 CKEditor 때와 동일한 방식으로 직접 구현 ──
 * 호버 표시를 처음엔 DOM에 classList.add()로 직접 붙였는데, ProseMirror는 트랜잭션이 발생할
 * 때마다(예: resizable:true 켠 뒤로 컬럼 리사이즈 쪽에서 마우스만 움직여도 훨씬 자주 발생)
 * 자기가 관리하는 표 DOM을 다시 그리면서 자기가 모르는 외부 클래스는 지워버린다 — 그래서
 * 클래스가 순간적으로 붙었다가 바로 사라져서 폴링으로 확인하면 항상 안 붙어있는 것처럼
 * 보였다. Decoration은 ProseMirror 자신의 렌더링 시스템 일부라 재렌더링에도 안 지워진다. */
var rowResizeHoverPluginKey = new PluginKey('rowResizeHover');
var RowResizeHoverPlugin = Extension.create({
  name: 'rowResizeHover',
  addProseMirrorPlugins: function() {
    return [
      new Plugin({
        key: rowResizeHoverPluginKey,
        state: {
          init: function() { return DecorationSet.empty; },
          apply: function(tr, old) {
            var meta = tr.getMeta(rowResizeHoverPluginKey);
            if (meta !== undefined) return meta;
            return old.map(tr.mapping, tr.doc);
          },
        },
        props: {
          decorations: function(state) { return rowResizeHoverPluginKey.getState(state); },
        },
      }),
    ];
  },
});
function setRowResizeHoverDecoration(editorInstance, rowPos) {
  var deco = DecorationSet.empty;
  if (rowPos != null) {
    var $rowPos = editorInstance.state.doc.resolve(rowPos + 1); // 행 내부로 한 칸 들어가서 resolve
    var tableDepth = null;
    for (var d = $rowPos.depth; d > 0; d--) { if ($rowPos.node(d).type.name === 'table') { tableDepth = d; break; } }
    if (tableDepth != null) {
      var tableNode = $rowPos.node(tableDepth);
      var tableStart = $rowPos.before(tableDepth) + 1;
      var map = TableMap.get(tableNode);

      // rowPos가 표 안에서 몇 번째 행(rowIndex)인지 계산
      var rowIndex = -1, acc = 0;
      for (var r = 0; r < tableNode.childCount; r++) {
        if (tableStart + acc === rowPos) { rowIndex = r; break; }
        acc += tableNode.child(r).nodeSize;
      }

      if (rowIndex !== -1) {
        var decorations = [];
        var seen = {};
        for (var c = 0; c < map.width; c++) {
          var relPos = map.map[rowIndex * map.width + c];
          if (relPos == null || seen[relPos]) continue;
          seen[relPos] = true;
          var absPos = tableStart + relPos;
          var cellNode = editorInstance.state.doc.nodeAt(absPos);
          if (!cellNode) continue;
          // 이 셀이 "시작하는" 행 인덱스(map.map에서 이 relPos가 처음 나오는 위치로 역산)를 구해서,
          // 그 시작 행 + rowspan - 1이 지금 호버 중인 행과 정확히 같을 때만(=이 셀의 병합이
          // 실제로 여기서 끝날 때만) 표시선을 넣는다 — 위 행에서 시작해 아래로 뻗어나가다가
          // 정확히 이 행에서 끝나는 rowspan 셀(예: "구분")도 이렇게 하면 정확히 잡힌다.
          var cellRowIndex = Math.floor(map.map.indexOf(relPos) / map.width);
          var rowspan = cellNode.attrs.rowspan || 1;
          if (cellRowIndex + rowspan - 1 === rowIndex) {
            decorations.push(Decoration.node(absPos, absPos + cellNode.nodeSize, { class: 'apr-row-resize-hover-cell' }));
          }
        }
        if (decorations.length) deco = DecorationSet.create(editorInstance.state.doc, decorations);
      }
    }
  }
  editorInstance.view.dispatch(editorInstance.state.tr.setMeta(rowResizeHoverPluginKey, deco));
}

function setupRowResize(editorInstance) {
  var editableEl = editorInstance.view.dom;
  var dragging = null;
  var EDGE = 3; // 경계 바로 근처(위로 3px, 아래로 2px)에서만 반응하도록 최대한 좁힌다 —
                // 병합 셀 중간이 우연히 어느 한쪽 경계의 허용범위에 걸리는 걸 최대한 방지
  var currentHoverRowPos = null;

  function cellsOf(tr) { return tr ? Array.prototype.slice.call(tr.querySelectorAll(':scope > td, :scope > th')) : []; }

  /** 마우스 좌표에서 "그 지점이 속한 표 행"을 찾는다. 캐싱 없이 매번 새로 querySelectorAll
   *  해서 항상 그 순간 기준 최신 DOM만 본다 — 이전에 posAtCoords(ProseMirror 문서 좌표)로
   *  찾는 방식을 썼었는데, 마우스가 정확히 경계선 위에 있을 때 그게 "위 행"인지 "아래 행"인지
   *  애매하게 해석되면서(대개 아래 행으로 잡힘) 정작 원하는 위 행의 rect.bottom과 안 맞아
   *  호버가 아예 안 잡히는 문제가 있었다. 실제 화면에 그려진 좌표(getBoundingClientRect)로
   *  직접 비교하는 게 훨씬 명확하고 확실하다. */
  // <tr> 자신의 bounding rect를 그대로 쓰면, rowspan 셀이 섞여있을 때 브라우저가 그 행의
  // 경계를 실제 화면 위치보다 아래로 계산하는 경우가 있었다(실제로 겪은 문제 — "구분"처럼
  // rowspan=2인 셀이 있으면 그 셀 중간에서도 행 경계로 잘못 인식됨). 그래서 <tr> 자체가
  // 아니라, 이 행에서 실제로 "끝나는"(rowspan<=1인) 셀들의 실제 화면 좌표만 보고 이 행의
  // 진짜 아래쪽 경계를 계산한다. 호버 감지(findRowAt)와 드래그 시작 확인(mousedown) 둘
  // 다 이 공통 함수를 써야 한다 — 전에는 mousedown 쪽에 tr.getBoundingClientRect()를
  // 그대로 쓰는 별도 계산이 남아있어서, 호버는 고쳐졌는데 그 재확인 단계에서 똑같은 문제가
  // 되살아났었다.
  // TableMap을 이용해서, 이 행에서 실제로 "끝나는" 셀들만(자기 자신이든, 위 행에서 시작해
  // 이 행에서 끝나는 rowspan 셀이든) 정확히 찾아서, 그 셀들의 실제 화면 범위(X, Y)만으로
  // 판정한다. 이전엔 좌우 범위를 "표 전체 너비"로 넉넉하게 잡아서, "구분"처럼 위 행에서
  // 시작해 훨씬 아래까지 이어지는 병합 셀의 열 범위 아래에서도, Y좌표만 우연히 다른 행의
  // 경계와 가까우면(허용범위 문제가 아니라 X범위 자체가 뚫려있어서) 걸리는 문제가 있었다.
  // 이제 "구분"이 차지하는 열은 그 셀이 실제로 끝나는 행이 아닌 한 감지 대상에서 아예 빠진다.
  function getRowBoundaryInfo(rowEl) {
    var rowPos;
    try { rowPos = editorInstance.view.posAtDOM(rowEl, 0) - 1; } catch (err) { return null; }
    var $rowPos = editorInstance.state.doc.resolve(rowPos + 1);
    var tableDepth = null;
    for (var d = $rowPos.depth; d > 0; d--) { if ($rowPos.node(d).type.name === 'table') { tableDepth = d; break; } }
    if (tableDepth == null) return null;
    var tableNode = $rowPos.node(tableDepth);
    var tableStart = $rowPos.before(tableDepth) + 1;
    var map = TableMap.get(tableNode);

    var rowIndex = -1, acc = 0;
    for (var r = 0; r < tableNode.childCount; r++) {
      if (tableStart + acc === rowPos) { rowIndex = r; break; }
      acc += tableNode.child(r).nodeSize;
    }
    if (rowIndex === -1) return null;

    var ranges = [];
    var rowBottom = null;
    var seen = {};
    for (var c = 0; c < map.width; c++) {
      var relPos = map.map[rowIndex * map.width + c];
      if (relPos == null || seen[relPos]) continue;
      seen[relPos] = true;
      var absPos = tableStart + relPos;
      var cellNode = editorInstance.state.doc.nodeAt(absPos);
      if (!cellNode) continue;
      var cellRowIndex = Math.floor(map.map.indexOf(relPos) / map.width);
      var rowspan = cellNode.attrs.rowspan || 1;
      if (cellRowIndex + rowspan - 1 !== rowIndex) continue; // 이 행에서 안 끝나는 셀은 건너뜀
      var cellDom = editorInstance.view.nodeDOM(absPos);
      if (!cellDom || !cellDom.getBoundingClientRect) continue;
      var cr = cellDom.getBoundingClientRect();
      ranges.push({ left: cr.left, right: cr.right });
      if (rowBottom === null || cr.bottom > rowBottom) rowBottom = cr.bottom;
    }
    if (rowBottom === null || !ranges.length) return null;
    // rowTop은 "이 행에서 끝나는 셀"이 아니라 "이 행에 직접 속한 셀"(위 행에서 이어온 게
    // 아니라 이 행 자신에서 시작하는 셀) 기준으로 잡는다 — rowspan으로 더 아래까지 이어지는
    // 셀이어도, 이 행에서 "시작"하는 거라면 그 top은 여전히 이 행의 진짜 위쪽 경계다.
    var directCells = rowEl.querySelectorAll(':scope > td, :scope > th');
    var rowTop = null;
    for (var dc = 0; dc < directCells.length; dc++) {
      var dcr = directCells[dc].getBoundingClientRect();
      if (rowTop === null || dcr.top < rowTop) rowTop = dcr.top;
    }
    if (rowTop === null) rowTop = rowBottom;
    return { top: rowTop, bottom: rowBottom, height: rowBottom - rowTop, ranges: ranges };
  }
  function findRowAt(clientX, clientY) {
    var rows = editableEl.querySelectorAll('table tr');
    for (var i = 0; i < rows.length; i++) {
      var info = getRowBoundaryInfo(rows[i]);
      if (!info) continue;
      // 표의 마지막 행이면, 그 오른쪽 끝은 "표 폭 조절 손잡이"가 있는 자리와 겹친다 — 그
      // 구역에서까지 행 높이 표시선이 나오면 손잡이가 선 끝의 점처럼 보여서 구분이 안 된다.
      // 그래서 마지막 행에 한해, 가장 오른쪽 범위의 끝에서 24px은 감지 대상에서 뺀다.
      var isLastRow = rows[i].parentElement && rows[i] === rows[i].parentElement.lastElementChild;
      var inXRange = info.ranges.some(function(range, idx) {
        var right = range.right;
        if (isLastRow && idx === info.ranges.length - 1) right -= 24;
        return clientX >= range.left && clientX <= right;
      });
      if (inXRange && clientY > info.bottom - EDGE && clientY <= info.bottom + 2) {
        return rows[i];
      }
    }
    return null;
  }
  function rowPosOf(tr) {
    try { return editorInstance.view.posAtDOM(tr, 0) - 1; } catch (err) { return null; }
  }

  editableEl.addEventListener('mousemove', function(e) {
    if (dragging) return;
    var tr = findRowAt(e.clientX, e.clientY);
    var newHoverRowPos = tr ? rowPosOf(tr) : null;
    if (newHoverRowPos !== currentHoverRowPos) {
      currentHoverRowPos = newHoverRowPos;
      setRowResizeHoverDecoration(editorInstance, currentHoverRowPos);
    }
    // .style.cursor = '...'는 브라우저가 contenteditable 안의 실제 텍스트 위에서 자기
    // 기본 I-beam 커서를 우선시해버리는 경우가 있어서 안 먹힐 때가 있다 — setProperty로
    // !important를 줘서 확실히 이기게 한다.
    if (tr) editableEl.style.setProperty('cursor', 'row-resize', 'important');
    else editableEl.style.removeProperty('cursor');
  });
  editableEl.addEventListener('mouseleave', function() {
    if (dragging) return;
    currentHoverRowPos = null;
    setRowResizeHoverDecoration(editorInstance, null);
    editableEl.style.removeProperty('cursor');
  });
  editableEl.addEventListener('mousedown', function(e) {
    // 표 오른쪽 아래 모서리에 있는 "표 폭 조절 손잡이"를 누른 거라면, 이 손잡이가 정확히
    // 마지막 행의 아래 경계와 같은 자리라 행 높이 리사이즈가 자기 것으로 착각해 가로채버린다
    // — editableEl에 캡처 단계로 걸려있어서 조상인 이 리스너가 손잡이(자손)보다 먼저 실행돼,
    // stopPropagation()을 부르면 손잡이 쪽 리스너엔 이벤트가 아예 도달을 못 했다. 그래서
    // 클릭 대상이 그 손잡이(또는 그 자손)면 여기서는 아예 손대지 않고 넘겨준다.
    if (e.target.closest('.tt-table-resize-handle')) return;
    var tr = findRowAt(e.clientX, e.clientY);
    if (!tr) return;
    var rowInfo = getRowBoundaryInfo(tr);
    if (!rowInfo) return;
    var rowPos = rowPosOf(tr);
    if (rowPos == null) return;
    var cells = cellsOf(tr);
    // 셀의 ProseMirror 문서 위치를 지금(아직 DOM이 멀쩡한 mousedown 시점)에 미리 계산해서
    // 저장해둔다 — mouseup 시점에 DOM 참조로 다시 찾으려 하면, 그 사이에 다른 이유(예: 컬럼
    // 리사이즈 호버 데코레이션)로 화면이 다시 그려져서 그 DOM 노드가 무효화(stale)돼 있을 수
    // 있고, 그러면 posAtDOM이 위치를 못 찾아 "-1 out of range" 에러가 난다.
    var cellPositions = cells.map(function(c) {
      try { return editorInstance.view.posAtDOM(c, 0); } catch (err) { return -1; }
    });
    dragging = { rowPos: rowPos, cellPositions: cellPositions, startY: e.clientY, startHeight: rowInfo.height, lastHeight: Math.round(rowInfo.height) };
    e.preventDefault();
    // 캡처 단계에서 여기까지 왔고 실제로 행 경계를 잡은 게 맞으면, 버블링 단계에 있는
    // ProseMirror 자체 mousedown 핸들러(표 셀 드래그 선택 시작 로직)로 이 이벤트가 넘어가지
    // 못하게 막는다 — 안 그러면 행 높이를 드래그하는 도중에 ProseMirror가 동시에 "셀 선택
    // 드래그"로도 착각해서 자기 mousemove 리스너를 같이 걸고, 마우스가 다음 행으로 넘어가는
    // 순간 셀 선택 트랜잭션을 쏴서 화면(DOM)을 다시 그려버린다 — 그러면 내가 잡고 있던 tr/td
    // DOM 요소가 통째로 교체되면서 그 이후 스타일 변경이 화면에 반영이 안 되는 것처럼 보인다.
    e.stopPropagation();
  }, true); // true = 캡처 단계 — ProseMirror의 자체 핸들러(버블링 단계)보다 먼저 실행돼야 위 stopPropagation이 의미가 있다
  /** 저장된 셀 위치들에 실제로 height 스타일을 적용한다 — 드래그 도중(계속 호출됨)과
   *  드래그가 끝나는 순간(mouseup, 한 번 더 확정) 양쪽에서 똑같이 이 함수를 쓴다.
   *  DOM을 직접 건드리지 않고 항상 정식 트랜잭션(setNodeMarkup)으로 반영하는 이유 —
   *  DOM에 직접 건드리면 다른 이유로 화면이 다시 그려질 때(예: 컬럼 리사이즈 호버 갱신)
   *  ProseMirror가 자기가 모르는 그 변경을 지워버려서, 드래그 중엔 안 움직이는 것처럼 보이다가
   *  마우스를 뗐을 때만 갑자기 반영된 것처럼 보이는 문제가 있었다. */
  function applyRowHeight(cellPositions, heightPx) {
    var view = editorInstance.view;
    var tr = editorInstance.state.tr;
    var changed = false;
    cellPositions.forEach(function(pos) {
      if (pos == null || pos < 0) return;
      var resolved = tr.doc.resolve(pos);
      var depth = resolved.depth;
      while (depth > 0 && resolved.node(depth).type.name !== 'tableCell' && resolved.node(depth).type.name !== 'tableHeader') depth--;
      if (depth === 0) return;
      var cellPos = resolved.before(depth);
      var cellNode = resolved.node(depth);
      var newStyle = mergeStyle(cellNode.attrs.style, 'height', heightPx + 'px');
      tr.setNodeMarkup(cellPos, undefined, Object.assign({}, cellNode.attrs, { style: newStyle }));
      changed = true;
    });
    if (changed) view.dispatch(tr);
  }

  document.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    var newHeight = Math.max(24, Math.round(dragging.startHeight + (e.clientY - dragging.startY)));
    if (newHeight === dragging.lastHeight) return; // 값이 안 바뀌었으면 트랜잭션을 굳이 또 안 쏜다
    dragging.lastHeight = newHeight;
    applyRowHeight(dragging.cellPositions, newHeight);
  });
  document.addEventListener('mouseup', function() {
    if (!dragging) return;
    var cellPositions = dragging.cellPositions;
    var finalHeight = dragging.lastHeight;
    dragging = null;
    currentHoverRowPos = null;
    setRowResizeHoverDecoration(editorInstance, null);
    editableEl.style.removeProperty('cursor');
    try {
      applyRowHeight(cellPositions, finalHeight); // 드래그 중 마지막 값으로 한 번 더 확정
    } catch (err) {
      console.warn('[rich-editor] 행 높이를 저장 데이터에 반영하지 못했습니다:', err);
    }
  });
}

/* ── 표 전체 크기 조절(드래그 핸들) ──
 * 이전 두 번의 시도는 매 mousemove마다 마우스 좌표와 모든 표의 getBoundingClientRect를
 * 비교해서 손잡이를 동적으로 만들었다 지웠다 하는 방식이었다 — 그런데 이 "좌표 근사"
 * 자체가 실제 화면 레이아웃(여백, 스크롤 위치 등)에 따라 계속 어긋났다. 이미지 크기 조절은
 * 처음부터 문제가 없었는데, 이미지는 좌표 근사가 아니라 "항상 존재하는 실제 DOM 요소를
 * CSS :hover로만 보이고 안 보이고 결정"하는 방식이라 브라우저의 정확한 히트테스트에 기댈 수
 * 있었다. 그래서 이번엔 이미지와 똑같은 방식으로 만든다 — 매 표마다 손잡이 span을 실제로
 * 한 번만 만들어서 계속 붙여두고(내용이 바뀔 때마다 새 표가 있으면 추가), 보이고 안 보이고는
 * CSS :hover에 맡긴다. */
function setupTableWidthResize(editorInstance) {
  var editableEl = editorInstance.view.dom;
  var dragging = null; // 여러 표가 있어도 한 번에 하나만 드래그하므로 공유 상태 하나면 충분
  var overflowCheckTimer = null; // 용지 초과 자동보정을 디바운스하기 위한 타이머

  function onHandleMouseDown(e) {
    var wrapper = e.currentTarget.parentElement;
    var tableDom = wrapper ? wrapper.querySelector("table") : null;
    if (!tableDom) return;
    var pos;
    try { pos = editorInstance.view.posAtDOM(tableDom, 0) - 1; } catch (err) { return; }
    var rect = tableDom.getBoundingClientRect();
    var paperEl = wrapper.parentElement;
    var paperWidth = (paperEl ? paperEl.getBoundingClientRect().width : 0) || rect.width;
    var startPct = paperWidth ? (rect.width / paperWidth) * 100 : 100;
    // 세로 방향(높이)도 이미지 리사이즈처럼 같이 조절되게 — 드래그 시작 시점의 각 행 높이를
    // 미리 재둔다(드래그 도중 매번 다시 재면 이전 호출에서 이미 바뀐 값 위에 또 배율을
    // 곱하는 셈이라 오차가 누적되기 때문에, 항상 이 "원본" 기준으로 절대값을 계산한다).
    var rowDoms = tableDom.querySelectorAll(':scope > tbody > tr, :scope > tr');
    var startRowHeights = Array.prototype.map.call(rowDoms, function(r) { return r.getBoundingClientRect().height || 30; });
    var startTotalHeight = startRowHeights.reduce(function(a, b) { return a + b; }, 0);
    dragging = {
      tablePos: pos, startX: e.clientX, startY: e.clientY,
      paperWidth: paperWidth, startPct: startPct, lastPct: startPct, pendingPct: startPct,
      startRowHeights: startRowHeights, startTotalHeight: startTotalHeight, pendingHeightScale: 1,
    };
    e.preventDefault();
    e.stopPropagation();
  }

  function ensureHandles() {
    var wrappers = editableEl.querySelectorAll(".tableWrapper");
    wrappers.forEach(function(wrapper) {
      // CSS만으로(fit-content 등) wrapper를 표의 실제 너비에 맞추려 했는데, table-layout:fixed
      // 표에서는 이게 기대만큼 안 먹혀서 손잡이가 표에서 떨어진 빈 공간에 뜨는 문제가 있었다
      // — 그래서 매번 JS로 표의 실제 렌더링 너비를 재서 wrapper에 직접 그 값을 못박는다.
      // 다만 이 값을 표 크기 그대로(제한 없이) 넣으면, 표 자신에게 걸어둔 CSS
      // max-width:100%가 "부모(=이 wrapper) 기준 100%"로 계산되는데 그 부모 자체가 표를
      // 따라 한없이 커져버려서 그 안전장치가 사실상 무력화되는 문제가 있었다(실제로 겪음).
      // 그래서 wrapper 자체는 용지 폭을 절대 못 넘게 막는다.
      var tableEl = wrapper.querySelector('table');
      var paperElForCap = wrapper.parentElement;
      var paperWidthCap = paperElForCap ? paperElForCap.getBoundingClientRect().width : null;
      // 표 정렬 — data-table-align 값은 표 자신이 아니라 (그 라이브러리가 무시하지 않는)
      // 첫 번째 셀에 저장돼 있다(위 withStyleAttr/setTableAlignment 설명 참고). 그 값을
      // 읽어서 wrapper(표 라이브러리가 안 건드리는 요소)에 마진으로 반영한다.
      if (tableEl) {
        var firstCellEl = tableEl.querySelector('td, th');
        var alignVal = (firstCellEl && firstCellEl.getAttribute('data-table-align')) || 'left';
        if (alignVal === 'center') { wrapper.style.marginLeft = 'auto'; wrapper.style.marginRight = 'auto'; }
        else if (alignVal === 'right') { wrapper.style.marginLeft = 'auto'; wrapper.style.marginRight = '0'; }
        else { wrapper.style.marginLeft = '0'; wrapper.style.marginRight = 'auto'; }
      }
      if (tableEl) {
        var tableW = tableEl.getBoundingClientRect().width;
        if (tableW) {
          var cappedW = paperWidthCap ? Math.min(tableW, paperWidthCap) : tableW;
          wrapper.style.width = Math.round(cappedW) + 'px';
        }
      }
      // 표 자체가(컬럼 리사이즈 등 어떤 방식으로든) 용지보다 넓어졌으면 100% 폭으로 자동
      // 되돌린다 — 다만 이걸 매 update마다 "즉시" 실행하면, 드래그가 아직 진행 중인
      // 도중에도 개입하게 되어 ProseMirror 표 라이브러리 자신의 드래그 추적 상태(내부적으로
      // "드래그 시작 시점 폭" 등을 기억하며 계산함)와 실시간으로 서로 값을 주고받으며
      // 충돌해서, 오히려 표 구조가 깨지는(예: 열이 사라지거나 엉뚱하게 넓어짐) 문제가
      // 있었다(실제로 겪음). 그래서 즉시 보정하지 않고, 일정 시간(300ms) 동안 더 이상
      // 변화가 없을 때(=드래그가 완전히 끝났다고 볼 수 있을 때)만 한 번 보정한다.
      if (tableEl && paperWidthCap) {
        if (overflowCheckTimer) clearTimeout(overflowCheckTimer);
        overflowCheckTimer = setTimeout(function() {
          overflowCheckTimer = null;
          var freshTableEl = wrapper.querySelector('table');
          if (!freshTableEl) return;
          var curTableW = freshTableEl.getBoundingClientRect().width;
          var freshPaperEl = wrapper.parentElement;
          var freshPaperWidth = freshPaperEl ? freshPaperEl.getBoundingClientRect().width : null;
          if (!freshPaperWidth || curTableW <= freshPaperWidth + 1) return;
          var tPos;
          try { tPos = editorInstance.view.posAtDOM(freshTableEl, 0) - 1; } catch (err) { tPos = null; }
          if (tPos != null) scaleTableWidth(editorInstance, 100, tPos);
        }, 300);
      }
      if (wrapper.querySelector(":scope > .tt-table-resize-handle")) return;
      wrapper.style.position = "relative";
      var handle = document.createElement("span");
      handle.className = "tt-table-resize-handle";
      handle.contentEditable = "false";
      handle.addEventListener("mousedown", onHandleMouseDown, true);
      wrapper.appendChild(handle);
    });
  }

  var pendingFrame = null;
  document.addEventListener("mousemove", function(e) {
    if (!dragging) return;
    var deltaX = e.clientX - dragging.startX;
    var deltaPct = dragging.paperWidth ? (deltaX / dragging.paperWidth) * 100 : 0;
    dragging.pendingPct = Math.max(20, Math.min(100, dragging.startPct + deltaPct));

    var deltaY = e.clientY - dragging.startY;
    var heightScale = dragging.startTotalHeight > 0 ? Math.max(0.3, (dragging.startTotalHeight + deltaY) / dragging.startTotalHeight) : 1;
    dragging.pendingHeightScale = heightScale;

    // 마우스 좌표 계산 자체는 가볍지만, 실제로 반영하는 쪽(특히 폭 조절)은 표 라이브러리가
    // 컬럼폭이 바뀔 때마다 표 전체를 다시 계산하는 무거운 작업이다 — mousemove는 초당
    // 수십~백 번씩 발생할 수 있어서, 매번 그 무거운 반영을 다 하면 오히려 밀려서 반응이
    // 느려진 것처럼 보인다(세로/행 높이는 셀에 직접 스타일만 넣는 가벼운 작업이라 이 문제가
    // 없었다). requestAnimationFrame으로 "실제 반영"은 화면이 그려지는 시점당 한 번만
    // 하도록 묶어서, 그 사이 여러 번 들어온 mousemove는 마지막 값만 반영되게 한다.
    if (pendingFrame) return;
    pendingFrame = requestAnimationFrame(function() {
      pendingFrame = null;
      if (!dragging) return;
      if (dragging.pendingPct !== dragging.lastPct) {
        dragging.lastPct = dragging.pendingPct;
        scaleTableWidth(editorInstance, dragging.pendingPct, dragging.tablePos);
      }
      var targetHeights = dragging.startRowHeights.map(function(h) { return h * dragging.pendingHeightScale; });
      setTableRowHeights(editorInstance, dragging.tablePos, targetHeights);
    });
  });
  document.addEventListener("mouseup", function() {
    if (!dragging) return;
    // 대기 중인 프레임(requestAnimationFrame)이 아직 안 돌았는데 여기서 그냥 취소만
    // 해버리면, 마우스를 뗀 마지막 위치의 값이 반영도 안 된 채 버려진다 — 빠르게 드래그하고
    // 바로 놓으면(다음 프레임이 돌기 전에 mouseup이 먼저 옴) 최종 크기가 실제 마우스를 놓은
    // 자리와 다르게 남는 문제가 있었다. 취소하기 전에 마지막 값을 먼저 확정 반영한다.
    if (pendingFrame) {
      cancelAnimationFrame(pendingFrame);
      pendingFrame = null;
      if (dragging.pendingPct !== dragging.lastPct) {
        scaleTableWidth(editorInstance, dragging.pendingPct, dragging.tablePos);
      }
      var finalHeights = dragging.startRowHeights.map(function(h) { return h * dragging.pendingHeightScale; });
      setTableRowHeights(editorInstance, dragging.tablePos, finalHeights);
    }
    dragging = null;
  });

  ensureHandles();
  setTimeout(ensureHandles, 100); // 초기 로드 시점엔 레이아웃/폰트가 아직 안 자리잡았을 수 있어 한 번 더
  editorInstance.on("update", ensureHandles);
  return ensureHandles; // setData()처럼 emitUpdate:false로 콘텐츠를 바꿔서 'update' 이벤트가
                         // 안 뜨는 경로에서도, 이 함수를 밖에서 직접 다시 불러 동기화할 수 있게
}


export {
  createRichEditor,
  TABLE_PRESETS,
  insertTablePreset,
  findCurrentTable,
  equalizeColumnWidths,
  equalizeRowHeights,
};