/**
 * assets/js/core/ai-chat.js
 * 앱 셸(app.html)에 떠 있는 AI 어시스턴트 위젯 — 일정 등록/사용법 안내/자재 검색을
 * 자연어로 처리한다. 실제 처리는 ai-assistant Edge Function(Gemini function calling)에서
 * 한다 — 이 파일은 UI와 메시지 송수신만 담당한다.
 */
(function () {
  var _history = []; // [{role:'user'|'assistant', content:string}] — 최근 대화 맥락 유지용
  var _sending = false;
  var _currentUser = null; // 플랫폼 관리자 미리보기 시 org_id를 서버에 같이 넘기기 위해 보관
  var _toggleJustDragged = false; // 드래그 직후 발생하는 click을 "열기/닫기"로 처리하지 않기 위한 플래그

  function initAiChat(user) {
    _currentUser = user || null;
    var toggle  = document.getElementById('aiChatToggle');
    var panel   = document.getElementById('aiChatPanel');
    var closeBtn= document.getElementById('aiChatClose');
    var input   = document.getElementById('aiChatInput');
    var sendBtn = document.getElementById('aiChatSend');
    if (!toggle || !panel) return;

    initDraggableToggle(toggle, panel);

    toggle.addEventListener('click', function () {
      if (_toggleJustDragged) { _toggleJustDragged = false; return; } // 드래그 끝에 발생한 클릭은 무시
      panel.classList.toggle('is-open');
      if (panel.classList.contains('is-open')) {
        positionPanelNearToggle(toggle, panel);
        input.focus();
      }
    });
    closeBtn.addEventListener('click', function () { panel.classList.remove('is-open'); });
    sendBtn.addEventListener('click', sendMessage);
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });
  }

  /** 화면 어디로 옮겨져도 패널이 화면 밖으로 나가지 않도록, 버튼 위치를 기준으로
   *  위/아래·좌/우를 자동으로 뒤집어 붙여준다. */
  function positionPanelNearToggle(toggle, panel) {
    var margin = 12, gap = 12;
    var rect = toggle.getBoundingClientRect();
    var panelW = panel.offsetWidth || 360;
    var panelH = panel.offsetHeight || 520;

    var spaceBelow = window.innerHeight - rect.bottom;
    var openBelow = spaceBelow >= panelH + gap || rect.top < panelH + gap;
    var top = openBelow ? (rect.bottom + gap) : (rect.top - panelH - gap);
    top = Math.min(Math.max(margin, top), Math.max(margin, window.innerHeight - panelH - margin));

    var spaceRight = window.innerWidth - rect.left;
    var left = spaceRight >= panelW + margin ? rect.left : (rect.right - panelW);
    left = Math.min(Math.max(margin, left), Math.max(margin, window.innerWidth - panelW - margin));

    panel.style.left = left + 'px';
    panel.style.top = top + 'px';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
  }

  /** 토글 버튼을 자유롭게 드래그해서 옮길 수 있게 한다. 위치는 localStorage에 저장해서
   *  다음 방문 때도 그대로 유지된다(사용자가 옮긴 적 없으면 CSS 기본 위치 그대로 둔다). */
  function initDraggableToggle(toggle, panel) {
    var STORAGE_KEY = 'aiChatTogglePos';
    var margin = 8;
    var dragging = false, moved = false;
    var hasCustomPosition = false; // 사용자가 실제로 옮긴 적이 있을 때만 true — 그 전까진 CSS 기본 위치(우측 하단) 그대로 둔다
    var startX, startY, startLeft, startTop;

    function clamp(left, top) {
      var maxLeft = Math.max(margin, window.innerWidth - toggle.offsetWidth - margin);
      var maxTop = Math.max(margin, window.innerHeight - toggle.offsetHeight - margin);
      return {
        left: Math.min(Math.max(margin, left), maxLeft),
        top: Math.min(Math.max(margin, top), maxTop),
      };
    }

    function applyPosition(left, top, save) {
      var pos = clamp(left, top);
      hasCustomPosition = true;
      toggle.style.left = pos.left + 'px';
      toggle.style.top = pos.top + 'px';
      toggle.style.right = 'auto';
      toggle.style.bottom = 'auto';
      if (panel.classList.contains('is-open')) positionPanelNearToggle(toggle, panel);
      if (save) {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(pos)); } catch (e) { /* 저장 실패는 무시 */ }
      }
    }

    // 이전에 옮긴 적이 있으면 그 위치를 복원 — 없으면 CSS의 기본(우측 하단) 위치를 그대로 둔다.
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var saved = JSON.parse(raw);
        if (typeof saved.left === 'number' && typeof saved.top === 'number') applyPosition(saved.left, saved.top, false);
      }
    } catch (e) { /* 저장된 값이 깨졌으면 기본 위치로 */ }

    toggle.addEventListener('pointerdown', function (e) {
      dragging = true; moved = false;
      var rect = toggle.getBoundingClientRect();
      startX = e.clientX; startY = e.clientY;
      startLeft = rect.left; startTop = rect.top;
      toggle.setPointerCapture(e.pointerId);
    });

    toggle.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var dx = e.clientX - startX, dy = e.clientY - startY;
      if (!moved && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) { moved = true; toggle.classList.add('is-dragging'); }
      if (moved) applyPosition(startLeft + dx, startTop + dy, false);
    });

    function endDrag(e) {
      if (!dragging) return;
      dragging = false;
      toggle.classList.remove('is-dragging');
      if (moved) {
        var rect = toggle.getBoundingClientRect();
        applyPosition(rect.left, rect.top, true);
        _toggleJustDragged = true; // 바로 이어서 뜨는 click 이벤트가 패널을 여닫지 않도록
      }
    }
    toggle.addEventListener('pointerup', endDrag);
    toggle.addEventListener('pointercancel', endDrag);

    // 창 크기가 바뀌어 버튼이 화면 밖으로 나가면 다시 안쪽으로 당겨준다(옮긴 적 있을 때만).
    window.addEventListener('resize', function () {
      if (!hasCustomPosition) return;
      var rect = toggle.getBoundingClientRect();
      applyPosition(rect.left, rect.top, false);
    });
  }

  function addMessage(text, who) {
    var box = document.getElementById('aiChatMessages');
    if (!box) return null;
    var div = document.createElement('div');
    div.className = 'ai-chat-msg ai-chat-msg--' + who;
    div.textContent = text;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
    return div;
  }

  async function sendMessage() {
    if (_sending) return;
    var input = document.getElementById('aiChatInput');
    var sendBtn = document.getElementById('aiChatSend');
    var text = (input.value || '').trim();
    if (!text) return;

    addMessage(text, 'user');
    input.value = '';
    _sending = true;
    sendBtn.disabled = true;
    var loadingEl = addMessage('생각하는 중...', 'loading');

    try {
      var { data, error } = await supabaseClient.functions.invoke('ai-assistant', {
        body: { message: text, history: _history, org_id: _currentUser?.org_id || '' },
      });
      if (loadingEl) loadingEl.remove();

      if (error) {
        var detail = '';
        try {
          // supabaseClient.functions.invoke()는 4xx/5xx 응답을 FunctionsHttpError로 감싸는데,
          // error.message는 "Edge Function returned a non-2xx status code"라는 뭉뚱그린
          // 문구뿐이다 — 실제로 서버가 보낸 JSON 본문은 error.context(Response 객체)에서
          // 따로 읽어야 한다.
          if (error.context && typeof error.context.json === 'function') {
            var body = await error.context.json();
            detail = body && body.error ? body.error : '';
          }
        } catch (_e) { /* 본문 파싱 실패 시 아래 기본 메시지로 대체 */ }
        addMessage('죄송해요, 오류가 발생했어요: ' + (detail || error.message), 'bot');
        return;
      }
      if (data && data.error) {
        addMessage('죄송해요, ' + data.error, 'bot');
        return;
      }
      var reply = (data && data.reply) || '죄송해요, 답변을 받지 못했어요.';
      addMessage(reply, 'bot');
      _history.push({ role: 'user', content: text });
      _history.push({ role: 'assistant', content: reply });

      // 일정이 등록된 경우, 지금 업무일정 화면을 보고 있다면 새로고침해서 바로 보이게 한다.
      if (data && data.action && data.action.type === 'create_task') {
        var frame = document.getElementById('shellFrame');
        if (frame && /task\/task-manager/.test(frame.src) && typeof frame.contentWindow?.location?.reload === 'function') {
          frame.contentWindow.location.reload();
        }
      }
      // 페이지 이동 요청 — 앱 셸의 기존 navigate() 함수를 그대로 사용한다.
      // action.query가 있으면(예: 장비 검색 결과가 많아 목록 화면으로 넘기는 경우)
      // 그 화면의 필터로 그대로 전달한다 — navigate()의 네 번째 인자(extraQuery)가 이미
      // 쿼리스트링으로 바꿔서 iframe src에 붙여주는 역할을 한다.
      if (data && data.action && data.action.type === 'navigate' && typeof window.navigate === 'function') {
        window.navigate(data.action.page, undefined, undefined, data.action.query || undefined);
      }
      // 연차 신청 후, 결재함/전자결재/인사기록(연차관리 탭) 화면을 보고 있다면 새로고침
      if (data && data.action && data.action.type === 'create_leave_request') {
        var frame2 = document.getElementById('shellFrame');
        if (frame2 && /(hr\/personal-info-detail|approval\/inbox|approval\/draft)/.test(frame2.src) && typeof frame2.contentWindow?.location?.reload === 'function') {
          frame2.contentWindow.location.reload();
        }
      }
    } catch (e) {
      if (loadingEl) loadingEl.remove();
      addMessage('죄송해요, 오류가 발생했어요: ' + e.message, 'bot');
    } finally {
      _sending = false;
      sendBtn.disabled = false;
      input.focus();
    }
  }

  window.initAiChat = initAiChat;
})();
