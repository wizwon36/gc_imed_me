let currentEquipmentId = '';
let currentEquipmentData = null;
let detailPermission = { canView: false, canEdit: false, canDelete: false, isAdmin: false, isAppAdmin: false };

function getCurrentUser() {
  // Supabase 세션에서 동기적으로 현재 유저 반환
  // auth.getSession()은 async라 직접 호출 불가 — _cachedUser 사용
  return window._detailCurrentUser || null;
}

async function initCurrentUser() {
  const session = await auth.requireAuth();
  if (!session) return null;
  const user = await auth.getSession();
  window._detailCurrentUser = user;
  return user;
}

async function getEquipmentPermissionContext() {
  const user = getCurrentUser();
  if (!user || !user.email) {
    return { canView: false, canEdit: false, canDelete: false, isAdmin: false, isAppAdmin: false };
  }

  // isAdmin은 "의원 스코프(전체 의원 조회 가능 여부)"만을 의미한다 — 페이지별 조회/수정/삭제
  // 권한은 아래 PagePerms(=마스터 관리 > 사용자 화면에서 관리자가 설정한 page_perms)로만 판단한다.
  const role = String(user.role || '').trim().toLowerCase();
  const isAdmin = role === 'admin';

  if (!window.PagePerms) {
    return { canView: false, canEdit: false, canDelete: false, isAdmin: isAdmin, isAppAdmin: false };
  }

  return {
    canView:    window.PagePerms.canAccess(user, 'equipment/detail'),
    canEdit:    window.PagePerms.atLeast(user, 'equipment/form', 'edit'),
    canDelete:  window.PagePerms.atLeast(user, 'equipment/form', 'admin'),
    isAdmin:    isAdmin,
    isAppAdmin: window.PagePerms.atLeast(user, 'equipment/detail', 'admin'),
  };
}

function safeValue(value) {
  return escapeHtml(value || '-');
}

function formatDisplayDate(value) {
  const raw = String(value || '').trim();
  if (!raw) return '-';
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  // "YYYY-MM-DDT..." 앞 10자리를 그대로 잘라 쓰면 timestamptz의 UTC 날짜가 그대로 나와서,
  // 자정~오전 9시(KST) 사이 값은 하루 전 날짜로 잘못 표시된다. 반드시 Date로 파싱해서
  // 로컬(KST) 기준으로 다시 계산해야 한다.
  const parsed = new Date(raw);
  if (!isNaN(parsed.getTime())) {
    const yyyy = parsed.getFullYear();
    const mm = String(parsed.getMonth() + 1).padStart(2, '0');
    const dd = String(parsed.getDate()).padStart(2, '0');
    return yyyy + '-' + mm + '-' + dd;
  }

  return raw;
}

function formatDisplayDateTime(value) {
  const raw = String(value || '').trim();
  if (!raw) return '-';

  const isoMatch = raw.match(/^(\d{4}-\d{2}-\d{2})[T\s](\d{2}:\d{2})/);
  if (isoMatch) {
    return isoMatch[1] + ' ' + isoMatch[2];
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  const parsed = new Date(raw);
  if (!isNaN(parsed.getTime())) {
    const yyyy = parsed.getFullYear();
    const mm = String(parsed.getMonth() + 1).padStart(2, '0');
    const dd = String(parsed.getDate()).padStart(2, '0');
    const hh = String(parsed.getHours()).padStart(2, '0');
    const mi = String(parsed.getMinutes()).padStart(2, '0');
    return yyyy + '-' + mm + '-' + dd + ' ' + hh + ':' + mi;
  }

  return raw;
}

function safeNumber(value) {
  if (value === null || value === undefined || value === '') return '-';
  return formatNumber(value);
}

function invalidateDashboardSessionCacheSafe() {
  try {
    if (typeof window.invalidateDashboardSessionCache === 'function') {
      window.invalidateDashboardSessionCache();
    }
  } catch (error) {}
}

function applyActionVisibility() {
  const editBtn = qs('#editEquipmentBtn');
  const deleteBtn = qs('#deleteBtn');
  const addHistoryBtn = qs('#addHistoryBtn');
  const addInventoryBtn = qs('#addInventoryBtn');
  const printLabelBtn = qs('#printLabelBtn');

  const isDeleted =
    String((currentEquipmentData && currentEquipmentData.deleted_yn) || 'N')
      .trim()
      .toUpperCase() === 'Y';

  // ★ user이면 본인 소속 팀 장비만 수정/이력/재고 버튼 표시
  // app:admin이면 타 팀 장비도 수정/이력/재고 버튼 표시
  const currentUser = getCurrentUser();
  const isAdmin = detailPermission.isAdmin;
  const isAppAdmin = detailPermission.isAppAdmin;
  const canEditThisItem = detailPermission.canEdit && (
    isAdmin ||
    isAppAdmin ||
    (
      currentEquipmentData &&
      currentUser &&
      String(currentEquipmentData.team_code || '').trim() === String(currentUser.team_code || '').trim()
    )
  );

  if (editBtn) editBtn.style.display = canEditThisItem && !isDeleted ? '' : 'none';
  if (deleteBtn) deleteBtn.style.display = detailPermission.canDelete ? '' : 'none';
  if (addHistoryBtn) addHistoryBtn.style.display = canEditThisItem && !isDeleted ? '' : 'none';
  if (addInventoryBtn) addInventoryBtn.style.display = canEditThisItem && !isDeleted ? '' : 'none';
  const eclLinkBtn = qs('#eclLinkBtn');
  if (eclLinkBtn) eclLinkBtn.style.display = detailPermission.canEdit && !isDeleted ? '' : 'none';
  const isMobile = window.innerWidth <= 768;
  if (printLabelBtn) printLabelBtn.style.display = (detailPermission.canView && !isMobile) ? '' : 'none';

  if (typeof applyTopActionsColClass === 'function') applyTopActionsColClass();
}

function buildEquipmentDetailUrl(equipmentId) {
  return CONFIG.SITE_BASE_URL + '/pages/equipment/public-detail.html?id=' + encodeURIComponent(equipmentId);
}

function renderDetailSkeleton() {
  const detailInfoGrid = qs('#detailInfoGrid');
  const qrBox = qs('#qrBox');
  const qrText = qs('#qrText');
  const photoImg = qs('#detailPhotoImage');
  const photoEmpty = qs('#detailPhotoEmpty');

  if (detailInfoGrid) {
    detailInfoGrid.innerHTML = '';
  }

  if (qrBox) {
    qrBox.innerHTML = '';
  }

  if (qrText) {
    qrText.innerHTML = '';
  }

  if (photoImg) {
    photoImg.src = '';
    photoImg.classList.add('is-hidden');
  }

  if (photoEmpty) {
    photoEmpty.classList.remove('is-hidden');
    photoEmpty.textContent = '불러오는 중...';
  }
}

function renderSectionLoading(areaSelector, countSelector) {
  const area = qs(areaSelector);
  const countEl = qs(countSelector);

  if (countEl) countEl.textContent = '불러오는 중...';
  if (area) {
    area.innerHTML = '<div class="empty-box">불러오는 중...</div>';
  }
}

function renderSectionError(areaSelector, countSelector, message) {
  const area = qs(areaSelector);
  const countEl = qs(countSelector);

  if (countEl) countEl.textContent = '로드 실패';
  if (area) {
    area.innerHTML =
      '<div class="empty-box">' +
      escapeHtml(message || '불러오기에 실패했습니다.') +
      '</div>';
  }
}

function renderHero(item) {
  const heroEquipmentName = qs('#heroEquipmentName');
  const heroEquipmentId = qs('#heroEquipmentId');
  const badge = qs('#heroStatusBadge');

  if (heroEquipmentName) heroEquipmentName.textContent = item.equipment_name || '장비명';
  if (heroEquipmentId) heroEquipmentId.textContent = item.equipment_id || '-';

  if (badge) {
    badge.textContent = statusLabel(item.status);
    badge.className = 'status-badge ' + statusClass(item.status);
  }
}

function renderPhoto(item) {
  const imgEl = qs('#detailPhotoImage');
  const emptyEl = qs('#detailPhotoEmpty');
  const openBtn = qs('#photoOpenBtn');
  const deleteBtn = qs('#photoDeleteBtn');

  if (!imgEl || !emptyEl) return;

  const inlineUrl = String((item && item.photo_inline_url) || '').trim();
  const directUrl = String((item && item.photo_url) || '').trim();
  const finalUrl = inlineUrl || directUrl;
  const hasPhoto = !!finalUrl;

  imgEl.onerror = function() {
    imgEl.src = '';
    imgEl.classList.add('is-hidden');
    emptyEl.classList.remove('is-hidden');
    emptyEl.textContent = '사진을 불러오지 못했습니다. 네트워크 또는 파일 접근 경로를 확인하세요.';
    if (openBtn) openBtn.style.display = 'none';
    if (deleteBtn) deleteBtn.style.display = 'none';
  };

  imgEl.onload = function() {
    emptyEl.classList.add('is-hidden');
  };

  if (hasPhoto) {
    imgEl.src = finalUrl;
    imgEl.classList.remove('is-hidden');
    emptyEl.classList.add('is-hidden');
    emptyEl.textContent = '등록된 사진이 없습니다.';
  } else {
    imgEl.src = '';
    imgEl.classList.add('is-hidden');
    emptyEl.classList.remove('is-hidden');
    emptyEl.textContent = '등록된 사진이 없습니다.';
  }

  if (openBtn) {
    openBtn.style.display = hasPhoto ? '' : 'none';
  }

  if (deleteBtn) {
    deleteBtn.style.display = hasPhoto && detailPermission.canEdit ? '' : 'none';
  }
}

function getCurrentPhotoUrl() {
  if (!currentEquipmentData) return '';
  return String(currentEquipmentData.photo_inline_url || currentEquipmentData.photo_url || '').trim();
}

function openPhotoInNewWindow() {
  const imageUrl = getCurrentPhotoUrl();
  if (!imageUrl) {
    showMessage('열 수 있는 사진이 없습니다.', 'error');
    return;
  }

  const win = window.open('', '_blank');
  if (!win) {
    showMessage('새 창을 열 수 없습니다. 팝업 차단을 확인해주세요.', 'error');
    return;
  }

  const title = escapeHtml((currentEquipmentData && currentEquipmentData.equipment_name) || '장비 사진');

  win.document.open();
  win.document.write(
    '<!DOCTYPE html>' +
    '<html lang="ko">' +
    '<head>' +
      '<meta charset="UTF-8">' +
      '<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
      '<title>' + title + '</title>' +
      '<style>' +
        'html,body{margin:0;padding:0;background:#111;height:100%;}' +
        'body{display:flex;align-items:center;justify-content:center;}' +
        'img{max-width:100vw;max-height:100vh;object-fit:contain;display:block;}' +
      '</style>' +
    '</head>' +
    '<body>' +
      '<img src="' + imageUrl + '" alt="' + title + '">' +
    '</body>' +
    '</html>'
  );
  win.document.close();
}

async function deleteCurrentPhoto() {
  if (!detailPermission.canEdit) {
    showMessage('사진을 삭제할 권한이 없습니다.', 'error');
    return;
  }

  if (!currentEquipmentId) {
    showMessage('장비 정보가 없습니다.', 'error');
    return;
  }

  const confirmed = confirm('현재 등록된 장비 사진을 삭제하시겠습니까?');
  if (!confirmed) return;

  const user = getCurrentUser();
  const userEmail = (user && user.email) || '';

  try {
    showGlobalLoading('장비 사진을 삭제하는 중...');
    // 사진 경로 가져와서 Storage 삭제
    const { data: eq } = await supabaseClient
      .from('equipments').select('photo_path').eq('id', currentEquipmentId).single();
    if (eq && eq.photo_path) {
      await supabaseClient.storage.from('equipment-photos').remove([eq.photo_path]);
    }
    await supabaseClient.from('equipments')
      .update({ photo_url: '', photo_path: '' }).eq('id', currentEquipmentId);

    await loadEquipmentCore(currentEquipmentId, userEmail, { resetSkeleton: false });
    invalidateDashboardSessionCacheSafe();
    showMessage('장비 사진이 삭제되었습니다.', 'success');
  } catch (error) {
    showMessage(error.message || '장비 사진 삭제 중 오류가 발생했습니다.', 'error');
  } finally {
    if (typeof hideGlobalLoading === 'function') {
      hideGlobalLoading();
    }
  }
}

async function deleteCurrentEquipment() {
  if (!detailPermission.canDelete) {
    showMessage('장비를 폐기할 권한이 없습니다.', 'error');
    return;
  }

  if (!currentEquipmentId) {
    showMessage('장비 정보가 없습니다.', 'error');
    return;
  }

  const confirmed = confirm('이 장비를 폐기하시겠습니까? 폐기 후 목록에서 제외됩니다.');
  if (!confirmed) return;

  const user = getCurrentUser();
  const userEmail = (user && user.email) || '';

  try {
    showGlobalLoading('장비를 폐기하는 중...');
    const { error: delErr } = await supabaseClient
      .from('equipments')
      .update({ deleted_yn: 'Y' })
      .eq('id', currentEquipmentId);
    if (delErr) throw new Error(delErr.message);

    invalidateDashboardSessionCacheSafe();
    alert('장비가 폐기되었습니다.');
    parent.shellNavigate?.('equipment/list');
  } catch (error) {
    showMessage(error.message || '장비 폐기 중 오류가 발생했습니다.', 'error');
  } finally {
    if (typeof hideGlobalLoading === 'function') {
      hideGlobalLoading();
    }
  }
}

function bindPhotoActionButtons() {
  const openBtn = qs('#photoOpenBtn');
  const deleteBtn = qs('#photoDeleteBtn');

  if (openBtn) {
    openBtn.onclick = openPhotoInNewWindow;
  }

  if (deleteBtn) {
    deleteBtn.onclick = deleteCurrentPhoto;
  }
}

function renderQrCode(equipmentId) {
  const qrBox = qs('#qrBox');
  const qrText = qs('#qrText');

  if (!qrBox || !qrText) return;

  const qrValue = buildEquipmentDetailUrl(equipmentId);
  qrBox.innerHTML = '';
  qrText.textContent = 'QR 스캔 시 장비 상세 페이지로 이동';
  qrText.title = qrValue;

  if (typeof QRCode === 'function') {
    new QRCode(qrBox, {
      text: qrValue,
      width: 180,
      height: 180
    });
  } else {
    qrBox.innerHTML =
      'QR 라이브러리를 불러오지 못했습니다.<br>아래 링크로 접근하세요.<br>' +
      escapeHtml(qrValue);
  }
}

function renderDetailInfo(item) {
  const detailInfoGrid = qs('#detailInfoGrid');
  if (!detailInfoGrid) return;

  const fields = [
    { label: '장비번호',      value: item.equipment_id },
    { label: '장비명',        value: item.equipment_name },
    { label: '모델명',        value: item.model_name },
    { label: '소속 의원',     value: item.clinic_name },
    { label: '소속 부서',     value: item.team_name },
    { label: '사용부서',      value: item.department },
    { label: '제조사',        value: item.manufacturer },
    { label: '시리얼번호',    value: item.serial_no },
    { label: '제조일자',      value: formatDisplayDate(item.manufacture_date) },
    { label: '취득일자',      value: formatDisplayDate(item.purchase_date) },
    { label: '구매처',        value: item.vendor ? item.vendor + (item.vendor_biz_no ? ' (' + item.vendor_biz_no + ')' : '') : item.vendor },
    { label: '취득가액',      value: safeNumber(item.acquisition_cost) },
    { label: '업체 담당자',   value: item.manager_name },
    { label: '업체 연락처',   value: item.manager_phone },
    { label: '유지보수 종료', value: formatDisplayDate(item.maintenance_end_date) },
    { label: '심평원 등록여부', value: item.hira_registered ? '등록됨' : '미등록' },
    { label: '심평원 바코드번호', value: item.hira_barcode_no || '-' },
    { label: '현재 상태',     value: item.status, isStatus: true },
    { label: '현재 위치',     value: item.location },
    { label: '현재 사용자',   value: item.current_user },
    { label: '등록일시',      value: formatDisplayDateTime(item.created_at) },
    { label: '수정일시',      value: formatDisplayDateTime(item.updated_at) },
    { label: '비고',          value: item.memo || '-', wide: true }
  ];

  function buildInfoCell(field) {
    let valueHtml;
    if (field.isStatus) {
      valueHtml = '<span class="status-badge ' + statusClass(field.value) + '">' +
        escapeHtml(statusLabel(field.value)) + '</span>';
    } else {
      const display = (field.value === null || field.value === undefined || field.value === '')
        ? '-' : field.value;
      valueHtml = nl2br(display);
    }
    return (
      '<div class="info-cell">' +
        '<div class="info-cell-label">' + escapeHtml(field.label) + '</div>' +
        '<div class="info-cell-value">' + valueHtml + '</div>' +
      '</div>'
    );
  }

  // 2단 구성 — 일반 필드는 두 개씩 한 줄에, 홀수로 남는 마지막 하나는 1단으로,
  // 비고는 맨 마지막에 wide(전체폭)로 분리해 공간을 넉넉히 확보한다.
  const normalFields = fields.filter(function(f) { return !f.wide; });
  const wideFields   = fields.filter(function(f) { return f.wide; });

  const rows = [];
  for (let i = 0; i < normalFields.length; i += 2) {
    const pair = normalFields.slice(i, i + 2);
    if (pair.length === 2) {
      rows.push('<div class="info-row">' + pair.map(buildInfoCell).join('') + '</div>');
    } else {
      rows.push('<div class="info-row info-row--single">' + buildInfoCell(pair[0]) + '</div>');
    }
  }
  wideFields.forEach(function(f) {
    rows.push('<div class="info-row info-row--wide">' + buildInfoCell(f) + '</div>');
  });

  detailInfoGrid.innerHTML = rows.join('');
}

function buildHistoryActionButtons(item) {
  if (!detailPermission.canEdit) return '';

  // 등록자 본인 또는 admin / isAppAdmin만 수정/완료 처리 가능
  // (예전엔 window.auth.getSession()을 await 없이 호출해서 Promise 객체 자체가 담기는 바람에
  //  본인 여부 판정이 항상 실패했고, 설령 await 했더라도 이메일과 UUID(histories.created_by)를
  //  비교하는 구조라 관리자가 아니면 어차피 버튼이 절대 안 떴다. 페이지 초기화 시 이미 캐싱해둔
  //  getCurrentUser()로 UUID를 바로 꺼내 UUID끼리 비교한다.)
  const currentUser  = getCurrentUser();
  const currentUid   = String((currentUser && currentUser.id) || '').trim();
  const createdBy    = String(item.created_by || '').trim();
  const isOwner      = currentUid && createdBy && currentUid === createdBy;
  const isAdmin      = detailPermission.isAdmin;
  const isAppAdmin   = detailPermission.isAppAdmin;

  if (!isOwner && !isAdmin && !isAppAdmin) return '';

  const buttons = [];
  const historyId  = item.id || '';
  const equipmentId = item.equipment_id || currentEquipmentId || '';

  if (String(item.result_status || '') !== 'COMPLETED') {
    buttons.push(
      '<button type="button" class="btn btn-light btn-sm js-edit-history" ' +
        'data-history-id="' + escapeHtml(historyId) + '" ' +
        'data-status="' + escapeHtml(item.result_status) + '">' +
        '수정</button>'
    );
  }

  if (String(item.history_type || '') === 'REPAIR' && String(item.result_status || '') === 'IN_PROGRESS') {
    buttons.push(
      '<button type="button" class="btn btn-primary btn-sm js-complete-history" data-history-id="' +
        escapeHtml(historyId) +
        '" data-equipment-id="' +
        escapeHtml(equipmentId) +
        '">완료 처리</button>'
    );
  }

  return buttons.length
    ? '<div class="timeline-actions">' + buttons.join('') + '</div>'
    : '';
}

function renderHistories(items) {
  const area = qs('#historyArea');
  const countText = qs('#historyCountText');
  const list = Array.isArray(items) ? items : [];

  if (countText) countText.textContent = formatNumber(list.length) + '건';
  if (!area) return;

  const hasAction = detailPermission.canEdit;
  const colCount = hasAction ? 5 : 4;

  const rows = list.length
    ? list.map(function(item) {
        const actionBtns = buildHistoryActionButtons(item);
        const typeLabel   = escapeHtml(historyTypeLabel(item.history_type));
        const dateLabel   = safeValue(formatDisplayDate(item.work_date));
        const statusBadge = '<span class="timeline-badge ' + ResultStatusClass(item.result_status) + '">' +
          escapeHtml(resultStatusLabel(item.result_status)) + '</span>';
        const desc = escapeHtml(item.description || '-');

        return (
          '<tr class="sec-tbl-row">' +
            '<td class="sec-tbl-cell" style="white-space:nowrap;font-size:11px;color:#6b7280;">' + dateLabel + '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--left">' +
              '<span class="sec-tbl-main">' + typeLabel + '</span>' +
            '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--center">' + statusBadge + '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--grow">' + desc + '</td>' +
            (hasAction ? '<td class="sec-tbl-cell sec-tbl-cell--action">' +
              (actionBtns || (String(item.result_status) === 'COMPLETED'
                ? '<span class="timeline-badge badge-green" style="font-size:10px;">완료</span>'
                : '')) +
            '</td>' : '') +
          '</tr>'
        );
      }).join('')
    : '<tr class="sec-tbl-row sec-tbl-row--empty"><td class="sec-tbl-cell sec-tbl-cell--empty" colspan="' + colCount + '">등록된 이력이 없습니다.</td></tr>';

  area.innerHTML =
    '<table class="sec-tbl">' +
      '<thead class="sec-tbl-head"><tr>' +
        '<th class="sec-tbl-th" style="width:76px">날짜</th>' +
        '<th class="sec-tbl-th" style="width:70px">구분</th>' +
        '<th class="sec-tbl-th sec-tbl-th--center" style="width:60px">상태</th>' +
        '<th class="sec-tbl-th">내용</th>' +
        (hasAction ? '<th class="sec-tbl-th sec-tbl-th--center" style="width:72px">처리</th>' : '') +
      '</tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
    '</table>';

  if (list.length) bindHistoryActionButtons();
}

function renderInventoryLogs(items) {
  const area = qs('#inventoryArea');
  const countText = qs('#inventoryCountText');
  const list = Array.isArray(items) ? items : [];

  if (countText) countText.textContent = formatNumber(list.length) + '건';
  if (!area) return;

  const rows = list.length
    ? list.map(function(item) {
        const statusLabel = escapeHtml(conditionStatusLabel(item.status_at_check));
        const dateLabel   = safeValue(formatDisplayDate(item.checked_at));
        const checker     = escapeHtml(item.checked_by_name || item.checked_by || '-');
        const dept        = escapeHtml(item.department_at_check || '-');
        const qrYn        = item.qr_scan_yn === 'Y' ? '✓' : '-';

        return (
          '<tr class="sec-tbl-row">' +
            '<td class="sec-tbl-cell" style="white-space:nowrap;font-size:11px;color:#6b7280;">' + dateLabel + '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--center">' +
              '<span class="sec-tbl-main" style="font-size:12px;">' + statusLabel + '</span>' +
            '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--center">' + checker + '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--grow">' + dept + '</td>' +
            '<td class="sec-tbl-cell sec-tbl-cell--center">' + qrYn + '</td>' +
          '</tr>'
        );
      }).join('')
    : '<tr class="sec-tbl-row sec-tbl-row--empty"><td class="sec-tbl-cell sec-tbl-cell--empty" colspan="5">등록된 재고조사 이력이 없습니다.</td></tr>';

  area.innerHTML =
    '<table class="sec-tbl">' +
      '<thead class="sec-tbl-head"><tr>' +
        '<th class="sec-tbl-th" style="width:76px">날짜</th>' +
        '<th class="sec-tbl-th sec-tbl-th--center" style="width:60px">상태</th>' +
        '<th class="sec-tbl-th sec-tbl-th--center" style="width:64px">점검자</th>' +
        '<th class="sec-tbl-th">부서</th>' +
        '<th class="sec-tbl-th sec-tbl-th--center" style="width:36px">QR</th>' +
      '</tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
    '</table>';
}

async function loadHistorySection(equipmentId, userEmail) {
  try {
    renderSectionLoading('#historyArea', '#historyCountText');

    const { data: histRows, error: histErr } = await supabaseClient
      .from('histories')
      .select('*')
      .eq('equipment_id', equipmentId)
      .order('work_date', { ascending: false });
    if (histErr) throw new Error(histErr.message);
    renderHistories(histRows || []);
  } catch (error) {
    renderSectionError('#historyArea', '#historyCountText', error.message || '이력 정보를 불러오지 못했습니다.');
  }
}

async function loadInventorySection(equipmentId, userEmail) {
  try {
    renderSectionLoading('#inventoryArea', '#inventoryCountText');

    const { data: invRows, error: invErr } = await supabaseClient
      .from('inventory_logs')
      .select('*')
      .eq('equipment_id', equipmentId)
      .order('checked_at', { ascending: false });
    if (invErr) throw new Error(invErr.message);
    renderInventoryLogs(invRows || []);
  } catch (error) {
    renderSectionError('#inventoryArea', '#inventoryCountText', error.message || '재고조사 이력을 불러오지 못했습니다.');
  }
}

async function loadEquipmentCore(equipmentId, userEmail, options) {
  const opts = options || {};
  const shouldResetSkeleton = opts.resetSkeleton === true;

  if (shouldResetSkeleton) {
    renderDetailSkeleton();
  }

  const { data: eqData, error: eqErr } = await supabaseClient
    .from('equipments')
    .select('*')
    .eq('id', equipmentId)
    .single();
  if (eqErr) throw new Error(eqErr.message);

  // equipment_id 호환 (ME-2026-0001)
  if (eqData) eqData.equipment_id = eqData.equipment_no || eqData.id;
  currentEquipmentData = eqData || {};
  window._currentEquipment = currentEquipmentData; // QC 패널에서 참조

  // 정도관리 탭 활성화/비활성화
  var qcTab = document.getElementById('detTabQc');
  if (qcTab) qcTab.disabled = !currentEquipmentData.qc_enabled;

  renderHero(currentEquipmentData);
  renderPhoto(currentEquipmentData);
  renderDetailInfo(currentEquipmentData);
  renderQrCode(currentEquipmentData.id); // QR에는 반드시 UUID(id) 사용
  applyActionVisibility();
  bindPhotoActionButtons();

  return currentEquipmentData;
}

async function reloadDetailSectionsOnly() {
  const user = getCurrentUser();
  const userEmail = (user && user.email) || '';
  if (!currentEquipmentId || !userEmail) return;

  await Promise.all([
    loadHistorySection(currentEquipmentId, userEmail),
    loadInventorySection(currentEquipmentId, userEmail)
  ]);
}

async function loadEquipmentDetail(options) {
  const opts = options || {};
  const forceReset = opts.forceReset === true;

  clearMessage();

  if (forceReset) {
    renderDetailSkeleton();
  }

  renderSectionLoading('#historyArea', '#historyCountText');
  renderSectionLoading('#inventoryArea', '#inventoryCountText');

  const id = getQueryParam('id') || currentEquipmentId;
  currentEquipmentId = id;

  if (!id) {
    throw new Error('장비 ID가 없습니다.');
  }

  const user = getCurrentUser();
  const userEmail = (user && user.email) || '';

  await loadEquipmentCore(id, userEmail, {
    resetSkeleton: forceReset
  });

  await Promise.all([
    loadHistorySection(id, userEmail),
    loadInventorySection(id, userEmail),
    loadLinkedContracts(id)
  ]);
}

function bindHistoryActionButtons() {
  document.querySelectorAll('.js-edit-history').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const historyId = this.getAttribute('data-history-id');
      const status = this.getAttribute('data-status');
  
      if (!historyId) return;
  
      if (status === 'COMPLETED') {
        alert('완료된 이력은 수정할 수 없습니다.');
        return;
      }
  
      openHistoryModal(historyId);
    });
  });

  document.querySelectorAll('.js-complete-history').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const historyId = this.getAttribute('data-history-id');
      const equipmentId = this.getAttribute('data-equipment-id') || currentEquipmentId;
      if (!historyId || !equipmentId) return;
      completeRepairHistory(historyId, equipmentId);
    });
  });
}

async function completeRepairHistory(historyId, equipmentId) {
  if (!detailPermission.canEdit) return;

  const confirmed = confirm('이 수리 이력을 완료 처리하시겠습니까? 장비 상태도 사용중으로 변경됩니다.');
  if (!confirmed) return;

  const user = getCurrentUser();
  const userEmail = (user && user.email) || '';

  try {
    showGlobalLoading('수리 이력을 완료 처리하는 중...');
    const { error: uhErr } = await supabaseClient
      .from('histories')
      .update({ result_status: 'COMPLETED' })
      .eq('id', historyId);
    if (uhErr) throw new Error(uhErr.message);
    // 장비 상태도 IN_USE로 업데이트
    await supabaseClient.from('equipments')
      .update({ status: 'IN_USE' }).eq('id', equipmentId);

    await loadEquipmentCore(currentEquipmentId, userEmail, { resetSkeleton: false });
    await reloadDetailSectionsOnly();
    invalidateDashboardSessionCacheSafe();
    alert('완료 처리되었습니다.');
  } catch (error) {
    showMessage(error.message || '완료 처리 중 오류가 발생했습니다.', 'error');
  } finally {
    if (typeof hideGlobalLoading === 'function') {
      hideGlobalLoading();
    }
  }
}

document.addEventListener('DOMContentLoaded', async function() {
  const user = await initCurrentUser();
  if (!user) return;

  ['qcDateFrom', 'qcDateTo', 'insp_date', 'insp_next_due', 'm_work_date'].forEach(mountCustomDateInput);

  try {
    if (typeof showGlobalLoading === 'function') {
      showGlobalLoading('상세 정보를 불러오는 중...');
    }

    detailPermission = await getEquipmentPermissionContext();

    if (!detailPermission.canView) {
      showMessage('장비 정보를 조회할 권한이 없습니다.', 'error');
      applyActionVisibility();
      return;
    }

    await loadEquipmentDetail({ forceReset: true });

    const backBtn = qs('#backToListBtn');
    if (backBtn) {
      backBtn.addEventListener('click', function() {
        parent.shellNavigate?.('equipment/list');
      });
    }

    const editBtn = qs('#editEquipmentBtn');
    if (editBtn) {
      editBtn.addEventListener('click', function() {
        parent.shellNavigate?.('equipment/form?id=' + currentEquipmentId);
      });
    }

    const addHistoryBtn = qs('#addHistoryBtn');
    if (addHistoryBtn) {
      addHistoryBtn.addEventListener('click', function() {
        openHistoryModal(null);
      });
    }

    const addInventoryBtn = qs('#addInventoryBtn');
    if (addInventoryBtn) {
      addInventoryBtn.addEventListener('click', function() {
        openInventoryModal();
      });
    }

    const deleteBtn = qs('#deleteBtn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', function() {
        deleteCurrentEquipment();
      });
    }

    const printLabelBtn = qs('#printLabelBtn');
    if (printLabelBtn) {
      printLabelBtn.addEventListener('click', function() {
        openLabelModal(currentEquipmentId);
      });
    }
  } catch (error) {
    showMessage(error.message || '상세 정보를 불러오지 못했습니다.', 'error');
  } finally {
    if (typeof hideGlobalLoading === 'function') {
      hideGlobalLoading();
    }
  }
});


// ================================================================
// 이력 모달
// ================================================================

var _historyModalMode = 'create'; // 'create' | 'edit'
var _historyModalId   = null;
var _historyModalData = null;

function openHistoryModal(historyId) {
  _historyModalMode = historyId ? 'edit' : 'create';
  _historyModalId   = historyId || null;
  _historyModalData = null;

  var modal = qs('#historyModal');
  var title = qs('#historyModalTitle');
  var submitBtn = qs('#historyModalSubmit');

  if (title) title.textContent = _historyModalMode === 'edit' ? '수리 / 점검 이력 수정' : '수리 / 점검 이력 등록';
  if (submitBtn) submitBtn.textContent = _historyModalMode === 'edit' ? '수정 저장' : '저장';

  // 폼 초기화
  historyModalSetField('m_history_type', '');
  historyModalSetField('m_work_date', todayYmd());
  historyModalSetField('m_requester', '');
  historyModalSetField('m_vendor_name', '');
  historyModalSetField('m_amount', '');
  historyModalSetField('m_result_status', '');
  historyModalSetField('m_update_equipment_status', '');
  historyModalSetField('m_description', '');
  historyModalHideMsg();

  if (modal) {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
  }

  if (_historyModalMode === 'edit' && historyId) {
    loadHistoryForModal(historyId);
  }
}

function closeHistoryModal() {
  var modal = qs('#historyModal');
  if (modal) {
    modal.classList.remove('is-open');
    if (modal.contains(document.activeElement)) document.body.focus();
    modal.setAttribute('aria-hidden', 'true');
  }
}

async function loadHistoryForModal(historyId) {
  var user = getCurrentUser();
  try {
    showGlobalLoading('이력 정보를 불러오는 중...');
    const { data: hItem, error: hErr } = await supabaseClient
      .from('histories').select('*').eq('id', historyId).single();
    if (hErr) throw new Error(hErr.message);
    var item = hItem || {};
    _historyModalData = item;
    historyModalSetField('m_history_type', item.history_type || '');
    historyModalSetField('m_work_date', item.work_date || '');
    historyModalSetField('m_requester', item.requester || '');
    historyModalSetField('m_vendor_name', item.vendor_name || '');
    historyModalSetField('m_amount', item.amount ? String(item.amount).replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '');
    historyModalSetField('m_result_status', item.result_status || '');
    historyModalSetField('m_description', item.description || '');
  } catch(e) {
    historyModalShowMsg(e.message || '이력 정보를 불러오지 못했습니다.', 'error');
  } finally {
    hideGlobalLoading();
  }
}

async function submitHistoryModal() {
  historyModalHideMsg();

  var historyType = historyModalGetField('m_history_type');
  var workDate    = historyModalGetField('m_work_date');
  var description = historyModalGetField('m_description');

  if (!historyType)  { historyModalShowMsg('이력 유형을 선택하세요.', 'error'); return; }
  if (!workDate)     { historyModalShowMsg('처리일자를 입력하세요.', 'error'); return; }
  if (!description)  { historyModalShowMsg('처리내용을 입력하세요.', 'error'); return; }

  var equipment = currentEquipmentData || {};
  var updateEquipmentStatus = historyModalGetField('m_update_equipment_status');

  var payload = {
    org_id:         auth.getCurrentOrgId(),
    equipment_id:   currentEquipmentId,
    history_type:   historyType,
    work_date:      workDate,
    requester:      historyModalGetField('m_requester'),
    vendor_name:    historyModalGetField('m_vendor_name'),
    amount:         historyModalGetField('m_amount').replace(/[^\d.-]/g, '') || null,
    result_status:  historyModalGetField('m_result_status'),
    description:    description,
    request_clinic_code: equipment.clinic_code || '',
    request_clinic_name: equipment.clinic_name || '',
    request_team_code:   equipment.team_code   || '',
    request_team_name:   equipment.team_name   || '',
    request_department:  equipment.department_display || equipment.department || ''
  };

  // edit 모드: id는 .eq() 조건으로 처리, payload에 불필요한 컬럼 없음

  var submitBtn = qs('#historyModalSubmit');
  try {
    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = '저장 중...'; }
    showGlobalLoading(_historyModalMode === 'edit' ? '이력을 수정하는 중...' : '이력을 저장하는 중...');

    if (_historyModalMode === 'edit' && _historyModalId) {
      const { error: e } = await supabaseClient
        .from('histories').update(payload).eq('id', _historyModalId);
      if (e) throw new Error(e.message);
    } else {
      const { data: { session } } = await supabaseClient.auth.getSession();
      payload.created_by = session?.user?.id || null;
      const { error: e } = await supabaseClient
        .from('histories').insert(payload);
      if (e) throw new Error(e.message);
    }

    closeHistoryModal();
    var user2 = getCurrentUser();
    var email2 = user2 && (user2.email || user2.user_email) || '';
    await loadHistorySection(currentEquipmentId, email2);
    if (updateEquipmentStatus) {
      await supabaseClient
        .from('equipments')
        .update({ status: updateEquipmentStatus })
        .eq('id', currentEquipmentId);
      await loadEquipmentCore(currentEquipmentId, email2, { resetSkeleton: false });
    }
  } catch(e) {
    historyModalShowMsg(e.message || '저장 중 오류가 발생했습니다.', 'error');
  } finally {
    hideGlobalLoading();
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = _historyModalMode === 'edit' ? '수정 저장' : '저장';
    }
  }
}

function historyModalSetField(id, val) {
  var el = qs('#' + id);
  if (el) el.value = val;
}
function historyModalGetField(id) {
  var el = qs('#' + id);
  return el ? el.value.trim() : '';
}
function historyModalShowMsg(msg, type) {
  var el = qs('#historyModalMsg');
  if (!el) return;
  el.textContent = msg;
  el.className = 'det-modal-msg det-modal-msg--' + (type || 'error');
  el.style.display = '';
}
function historyModalHideMsg() {
  var el = qs('#historyModalMsg');
  if (el) { el.style.display = 'none'; el.textContent = ''; }
}

// 로컬 날짜 헬퍼
function todayYmd() {
  var d = new Date();
  return d.getFullYear() + '-' +
    String(d.getMonth() + 1).padStart(2, '0') + '-' +
    String(d.getDate()).padStart(2, '0');
}

// ================================================================
// 재고조사 모달
// ================================================================

function openInventoryModal() {
  var modal = qs('#inventoryModal');
  var user = getCurrentUser();

  // 폼 초기화
  inventoryModalSetField('m_checked_at', getNowDateTime());
  inventoryModalSetField('m_checked_by', (user && (user.name || user.user_name)) || '');
  inventoryModalSetField('m_condition_status', '');
  inventoryModalSetField('m_qr_scan_yn', 'Y');
  inventoryModalSetField('m_memo', '');
  inventoryModalHideMsg();

  if (modal) {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
  }
}

function closeInventoryModal() {
  var modal = qs('#inventoryModal');
  if (modal) {
    modal.classList.remove('is-open');
    if (modal.contains(document.activeElement)) document.body.focus();
    modal.setAttribute('aria-hidden', 'true');
  }
}

async function submitInventoryModal() {
  inventoryModalHideMsg();

  var conditionStatus = inventoryModalGetField('m_condition_status');
  var checkedBy       = inventoryModalGetField('m_checked_by');

  if (!conditionStatus) { inventoryModalShowMsg('상태를 선택하세요.', 'error'); return; }
  if (!checkedBy)       { inventoryModalShowMsg('점검자를 입력하세요.', 'error'); return; }

  var user = getCurrentUser();
  var equipment = currentEquipmentData || {};

  var payload = {
    org_id:                auth.getCurrentOrgId(),
    equipment_id:          currentEquipmentId,
    checked_at:            inventoryModalGetField('m_checked_at') || new Date().toISOString(),
    checked_by_name:       checkedBy,
    clinic_code_at_check:  equipment.clinic_code || '',
    clinic_name_at_check:  equipment.clinic_name || '',
    team_code_at_check:    equipment.team_code   || '',
    team_name_at_check:    equipment.team_name   || '',
    department_at_check:   equipment.department_display || equipment.department || '',
    location_at_check:     equipment.location || '',
    status_at_check:       conditionStatus,
    qr_scan_yn:            inventoryModalGetField('m_qr_scan_yn') || 'N',
    memo:                  inventoryModalGetField('m_memo')
  };

  var submitBtn = qs('#inventoryModalSubmit');
  try {
    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = '저장 중...'; }
    showGlobalLoading('재고조사 이력을 저장하는 중...');

    const { data: { session: invSession } } = await supabaseClient.auth.getSession();
    payload.checked_by = invSession?.user?.id || null;
    const { error: ilErr } = await supabaseClient
      .from('inventory_logs').insert(payload);
    if (ilErr) throw new Error(ilErr.message);

    closeInventoryModal();
    var user2 = getCurrentUser();
    var email2 = user2 && (user2.email || user2.user_email) || '';
    await loadInventorySection(currentEquipmentId, email2);
  } catch(e) {
    inventoryModalShowMsg(e.message || '저장 중 오류가 발생했습니다.', 'error');
  } finally {
    hideGlobalLoading();
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '저장'; }
  }
}

function inventoryModalSetField(id, val) {
  var el = qs('#' + id);
  if (el) el.value = val;
}
function inventoryModalGetField(id) {
  var el = qs('#' + id);
  return el ? el.value.trim() : '';
}
function inventoryModalShowMsg(msg, type) {
  var el = qs('#inventoryModalMsg');
  if (!el) return;
  el.textContent = msg;
  el.className = 'det-modal-msg det-modal-msg--' + (type || 'error');
  el.style.display = '';
}
function inventoryModalHideMsg() {
  var el = qs('#inventoryModalMsg');
  if (el) { el.style.display = 'none'; el.textContent = ''; }
}

function getNowDateTime() {
  var now = new Date();
  return now.getFullYear() + '-' +
    String(now.getMonth() + 1).padStart(2, '0') + '-' +
    String(now.getDate()).padStart(2, '0') + ' ' +
    String(now.getHours()).padStart(2, '0') + ':' +
    String(now.getMinutes()).padStart(2, '0') + ':' +
    String(now.getSeconds()).padStart(2, '0');
}

// ================================================================
// 모달 이벤트 바인딩
// ================================================================

document.addEventListener('DOMContentLoaded', function() {
  // 이력 모달
  var hClose   = qs('#historyModalClose');
  var hCancel  = qs('#historyModalCancel');
  var hSubmit  = qs('#historyModalSubmit');
  var hBackdrop = qs('#historyModal .det-modal-backdrop');

  if (hClose)   hClose.addEventListener('click', closeHistoryModal);
  if (hCancel)  hCancel.addEventListener('click', closeHistoryModal);
  if (hSubmit)  hSubmit.addEventListener('click', submitHistoryModal);
  if (hBackdrop) hBackdrop.addEventListener('click', closeHistoryModal);

  // 금액 콤마 포맷
  var amountEl = qs('#m_amount');
  if (amountEl) {
    amountEl.addEventListener('input', function() {
      var raw = this.value.replace(/[^\d]/g, '');
      this.value = raw ? raw.replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '';
    });
  }

  // 재고조사 모달
  var iClose    = qs('#inventoryModalClose');
  var iCancel   = qs('#inventoryModalCancel');
  var iSubmit   = qs('#inventoryModalSubmit');
  var iBackdrop = qs('#inventoryModal .det-modal-backdrop');

  if (iClose)    iClose.addEventListener('click', closeInventoryModal);
  if (iCancel)   iCancel.addEventListener('click', closeInventoryModal);
  if (iSubmit)   iSubmit.addEventListener('click', submitInventoryModal);
  if (iBackdrop) iBackdrop.addEventListener('click', closeInventoryModal);
});


// ================================================================
// 라벨 출력 모달
// ================================================================

var _labelModalQrRendered = false;

function openLabelModal(equipmentId) {
  var modal   = qs('#labelModal');
  var data    = currentEquipmentData || {};

  // 필드 채우기
  setText('lm_equipment_name', data.equipment_name || '-');
  setText('lm_equipment_id',   data.equipment_id   || equipmentId || '-');
  setText('lm_model_name',     data.model_name     || '-');
  setText('lm_department',     data.department     || '-');
  setText('lm_location',       data.location       || '-');

  // 크기 초기화
  var sizeSelect = qs('#labelModalSizeSelect');
  if (sizeSelect) sizeSelect.value = 'size-90x48';
  _labelModalQrRendered = false;
  labelModalApplySize('size-90x48', equipmentId);

  if (modal) {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
  }
}

function closeLabelModal() {
  var modal = qs('#labelModal');
  if (modal) {
    modal.classList.remove('is-open');
    if (modal.contains(document.activeElement)) document.body.focus();
    modal.setAttribute('aria-hidden', 'true');
  }
}

function labelModalApplySize(sizeClass, equipmentId) {
  var label = qs('#labelModalDevice');
  if (label) {
    label.classList.remove('size-90x48', 'size-70x40', 'size-50x30');
    label.classList.add(sizeClass);
  }

  // 행 표시 제어
  var rowModel = qs('#lm_row_model');
  var rowDept  = qs('#lm_row_dept');
  var rowLoc   = qs('#lm_row_loc');
  if (rowModel) rowModel.style.display = sizeClass === 'size-50x30' ? 'none' : '';
  if (rowDept)  rowDept.style.display  = sizeClass === 'size-50x30' ? 'none' : '';
  if (rowLoc)   rowLoc.style.display   = (sizeClass === 'size-70x40' || sizeClass === 'size-50x30') ? 'none' : '';

  // QR 렌더링
  var qrEl = qs('#lm_qr');
  if (!qrEl) return;
  qrEl.innerHTML = '';

  var id  = equipmentId || currentEquipmentId;
  var url = (typeof CONFIG !== 'undefined' ? CONFIG.SITE_BASE_URL : '') +
            '/pages/equipment/public-detail.html?id=' + encodeURIComponent(id);
  var qrSize = sizeClass === 'size-70x40' ? 64 : sizeClass === 'size-50x30' ? 48 : 84;

  if (typeof QRCode !== 'undefined' && id) {
    new QRCode(qrEl, { text: url, width: qrSize, height: qrSize });
  }
}

function setText(id, val) {
  var el = qs('#' + id);
  if (el) el.textContent = val;
}

// 모달 이벤트 바인딩 (DOMContentLoaded에 추가)
document.addEventListener('DOMContentLoaded', function() {
  var lClose   = qs('#labelModalClose');
  var lBackdrop = qs('#labelModal .det-modal-backdrop');
  var lPrint   = qs('#labelModalPrintBtn');
  var lSize    = qs('#labelModalSizeSelect');

  if (lClose)    lClose.addEventListener('click', closeLabelModal);
  if (lBackdrop) lBackdrop.addEventListener('click', closeLabelModal);

  if (lSize) {
    lSize.addEventListener('change', function() {
      labelModalApplySize(this.value, currentEquipmentId);
    });
  }

  if (lPrint) {
    lPrint.addEventListener('click', function() {
      window.print();
    });
  }
});

/* ══════════════════════════════════════════════
   탭 전환
══════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.det-tabs .tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      if (btn.disabled) return;
      var tab = btn.dataset.tab;
      document.querySelectorAll('.det-tabs .tab-btn').forEach(function(b) { b.classList.remove('active'); });
      document.querySelectorAll('.det-tab-panel').forEach(function(p) { p.classList.remove('active'); });
      btn.classList.add('active');
      var panel = document.getElementById('detPanel-' + tab);
      if (panel) panel.classList.add('active');
      if (tab === 'qc') initQcPanel();
      if (tab === 'inspect') initInspectPanel();
    });
  });
});

/* ══════════════════════════════════════════════
   정도관리 — 2열 레이아웃
   좌: 검사항목 목록
   우: 항목 정보 바 + (편집 폼) + 측정그리드 + L-J 차트
══════════════════════════════════════════════ */
var _qcEqId      = null;
var _qcItems     = [];
var _selItem     = null;
var _qcMode      = 'view'; // 'view' | 'edit' | 'new'
var _qcCollapsedGroups = {}; // 검사항목 그룹 접힘 상태(그룹명 기준)
var _qcGrid      = null;   // 측정 데이터 그리드 (단 1개)
var _qcInited    = false;
var _qcCanManage = false; // admin이거나 그 장비 부서의 정도관리 담당자일 때만 true — 조회는 항상 가능
var _qcUserMap   = null;  // created_by(uuid) → 사용자 이름, 측정자 컬럼 표시용 (1회만 로드)

async function _getQcUserMap() {
  if (_qcUserMap) return _qcUserMap;
  _qcUserMap = {};
  try {
    var { data } = await supabaseClient.from('profiles').select('id, user_name');
    (data || []).forEach(function(u) { _qcUserMap[u.id] = u.user_name || ''; });
  } catch (e) { /* 실패해도 측정자 칸에 '-'만 뜨고 나머지는 정상 동작 */ }
  return _qcUserMap;
}

function _qcEsc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;'); }

/* ── 초기화 ──────────────────────────────────── */
function initQcPanel() {
  if (_qcInited) return;
  _qcInited = true;
  var eq = window._currentEquipment;
  if (!eq) return;
  _qcEqId = eq.id;

  // 정도관리 데이터 자체는 (장비 상세를 볼 수 있는 사람이면) 누구나 조회 가능하고,
  // 입력/수정/삭제(활성화 포함)만 admin이거나 "그 장비 부서의 정도관리 담당자"로 제한한다.
  var qcUser = getCurrentUser();
  _qcCanManage = !!(detailPermission.isAdmin ||
    (qcUser && qcUser.is_qc_manager && qcUser.team_code && eq.team_code && qcUser.team_code === eq.team_code));
  var canManageQc = _qcCanManage;

  var disabled  = document.getElementById('detQcDisabled');
  var qcContent = document.getElementById('detQcContent');

  if (!eq.qc_enabled) {
    if (disabled)  disabled.style.display  = '';
    if (qcContent) qcContent.style.display = 'none';
    var enableBtn = document.getElementById('detQcEnableBtn');
    if (enableBtn) {
      if (!canManageQc) {
        enableBtn.style.display = 'none';
        var hint = document.getElementById('detQcDisabled');
        if (hint) hint.insertAdjacentHTML('beforeend', '<div style="margin-top:8px;font-size:11px;color:#9ca3af;">정도관리 활성화는 담당자만 할 수 있습니다.</div>');
      } else {
        enableBtn.addEventListener('click', async function() {
          await supabaseClient.from('equipments').update({ qc_enabled: true }).eq('id', eq.id);
          eq.qc_enabled = true;
          window._currentEquipment.qc_enabled = true;
          disabled.style.display  = 'none';
          qcContent.style.display = 'flex';
          document.getElementById('detTabQc').disabled = false;
          _loadItems();
        });
      }
    }
    return;
  }

  if (disabled)  disabled.style.display  = 'none';
  if (qcContent) qcContent.style.display = 'flex';

  var addQcItemBtn = document.getElementById('addQcItemBtn');
  var addLjEntryBtn = document.getElementById('addLjEntryBtn');
  var qcItemEditBtn = document.getElementById('qcItemEditBtn');
  var qcItemDeleteBtn = document.getElementById('qcItemDeleteBtn');
  if (canManageQc) {
    if (addQcItemBtn) addQcItemBtn.addEventListener('click', _startNew);
    if (addLjEntryBtn) addLjEntryBtn.addEventListener('click', _addRow);
  } else {
    // 조회는 그대로 두고, 쓰기 관련 버튼만 숨긴다
    [addQcItemBtn, addLjEntryBtn, qcItemEditBtn, qcItemDeleteBtn].forEach(function(b) { if (b) b.style.display = 'none'; });
  }

  // 측정 데이터 조회 날짜 기본값 — 오늘부터 한 달 전까지
  // new Date().toISOString()은 UTC 기준이라 KST 자정~오전 9시 사이엔 "오늘"이 하루 전으로
  // 계산되는 버그가 있다. 로컬 타임존 기준으로 직접 조립해야 한다.
  var today = new Date();
  var monthAgo = new Date(today);
  monthAgo.setMonth(today.getMonth() - 1);
  var qFrom = document.getElementById('qcDateFrom');
  var qTo   = document.getElementById('qcDateTo');
  if (qFrom) qFrom.value = _localDateStr(monthAgo);
  if (qTo)   qTo.value   = _localDateStr(today);
  document.getElementById('qcDateSearchBtn')?.addEventListener('click', function() { _loadEntries(); });

  // 측정 데이터 그리드 딱 한 번만 생성
  _initEntryGrid();
  _loadItems();
}

/* ── 1열: 검사항목 목록 ─────────────────────── */
async function _loadItems() {
  var { data } = await supabaseClient.from('lj_items').select('*')
    .eq('equipment_id', _qcEqId).order('created_at', { ascending: true });
  _qcItems = data || [];
  var cnt = document.getElementById('qcItemCountText');
  if (cnt) cnt.textContent = _qcItems.length ? _qcItems.length + '건' : '';
  _renderList();
}

/* 그룹명 일괄 수정 — 이 장비 안에서 같은 group_name을 쓰는 항목 전체를 한 번에 바꾼다.
   (항목 하나씩 수정 폼에서 그룹을 고쳐도 되지만, 그룹 전체 이름을 바꿀 땐 매번 일일이
   고치면 오타로 그룹이 갈라질 위험이 있어 그룹 헤더에서 한 번에 바꾸는 방법을 제공한다.) */
window._renameGroup = async function(oldName) {
  var newName = prompt('그룹명을 수정합니다.', oldName);
  if (newName === null) return; // 취소
  newName = newName.trim();
  if (!newName) { showMessage('그룹명을 입력해 주세요.', 'warning'); return; }
  if (newName === oldName) return;

  var { error } = await supabaseClient.from('lj_items')
    .update({ group_name: newName })
    .eq('equipment_id', _qcEqId)
    .eq('group_name', oldName);
  if (error) { showMessage('그룹명 수정 실패: ' + error.message, 'error'); return; }
  showMessage('그룹명이 "' + newName + '"(으)로 수정됐습니다.', 'success');
  await _loadItems();
};

function _renderList() {
  var el = document.getElementById('qcItemList');
  if (!el) return;
  if (!_qcItems.length) {
    el.innerHTML = '<div style="padding:20px 12px;text-align:center;color:#9ca3af;font-size:11px;line-height:1.7;">등록된 검사항목이 없습니다.<br>+ 추가 버튼을 눌러<br>항목을 등록하세요.</div>';
    return;
  }

  // 그룹별로 묶어서 표시 (group_name 없으면 "미분류"). 그룹 순서는 항목이 처음 등장하는 순서를 따른다.
  var groupOrder = [];
  var groupMap = {};
  _qcItems.forEach(function(item) {
    var g = item.group_name || '';
    if (!groupMap[g]) { groupMap[g] = []; groupOrder.push(g); }
    groupMap[g].push(item);
  });

  function itemRow(item) {
    var sel = _selItem && _selItem.id === item.id;
    var isQ = item.item_type === 'quantitative';
    return '<div onclick="window._selectItem(\'' + item.id + '\')" style="' +
      'padding:10px 12px 10px 20px;cursor:pointer;border-bottom:1px solid #e5e7eb;' +
      'border-left:3px solid ' + (sel ? '#2563eb' : 'transparent') + ';' +
      'background:' + (sel ? '#eff6ff' : '#fff') + ';' +
      'transition:background 0.1s;">' +
      '<div style="font-size:12px;font-weight:600;color:#111827;margin-bottom:2px;">' + _qcEsc(item.item_name) + '</div>' +
      '<div style="font-size:10px;color:#9ca3af;">' +
        (isQ ? '정량' : '정성') +
        (item.unit ? ' · ' + _qcEsc(item.unit) : '') +
        (isQ && item.mean != null ? ' · Mean ' + Number(item.mean).toFixed(item.decimal_places||2) : '') +
      '</div>' +
    '</div>';
  }

  el.innerHTML = groupOrder.map(function(g) {
    var label = g ? _qcEsc(g) : '미분류';
    var renameBtn = g
      ? '<span class="qc-group-rename-btn" data-group="' + _qcEsc(g) + '" ' +
        'style="cursor:pointer;color:#9ca3af;padding:1px 4px;border-radius:4px;" title="그룹명 수정">✎</span>'
      : '';
    var collapsed = !!_qcCollapsedGroups[g];
    var header = '<div class="qc-group-header" data-group="' + _qcEsc(g) + '" style="position:sticky;top:0;z-index:1;padding:6px 12px;font-size:10px;font-weight:700;' +
      'color:#6b7280;background:#eef2f7;border-bottom:1px solid #e5e7eb;letter-spacing:0.02em;cursor:pointer;user-select:none;' +
      'display:flex;align-items:center;justify-content:space-between;gap:6px;">' +
      '<span><span style="display:inline-block;width:10px;font-size:9px;color:#9ca3af;">' + (collapsed ? '▸' : '▾') + '</span> ' +
        label + ' <span style="font-weight:400;color:#9ca3af;">(' + groupMap[g].length + ')</span></span>' +
      renameBtn +
      '</div>';
    var body = '<div style="display:' + (collapsed ? 'none' : '') + ';">' + groupMap[g].map(itemRow).join('') + '</div>';
    return header + body;
  }).join('');

  el.querySelectorAll('.qc-group-header').forEach(function(h) {
    h.addEventListener('click', function() {
      var g = h.getAttribute('data-group');
      _qcCollapsedGroups[g] = !_qcCollapsedGroups[g];
      _renderList();
    });
  });

  // 그룹명 수정 버튼 — onclick 인라인 문자열에 그룹명을 직접 넣으면 따옴표/괄호 등
  // 특수문자 이스케이프가 까다로워지므로, data 속성 + addEventListener로 안전하게 처리한다.
  el.querySelectorAll('.qc-group-rename-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      window._renameGroup(btn.getAttribute('data-group'));
    });
  });
}

window._selectItem = function(id) {
  _selItem = _qcItems.find(function(i) { return i.id === id; }) || null;
  _qcMode  = 'view';
  _renderList();
  _renderBar();
  _loadEntries();
};

/* ── 우: 항목 정보 바 & 편집 폼 ──────────────── */
function _renderBar() {
  var noSel = document.getElementById('detQcNoSelect');
  var selEl = document.getElementById('detQcSelected');
  var formWrap = document.getElementById('qcItemFormWrap');

  if (!_selItem && _qcMode !== 'new') {
    if (noSel) noSel.style.display = 'flex';
    if (selEl) selEl.style.display = 'none';
    return;
  }
  if (noSel) noSel.style.display = 'none';
  if (selEl) selEl.style.display = 'flex';

  var isEdit = (_qcMode === 'edit' || _qcMode === 'new');
  if (formWrap) formWrap.style.display = isEdit ? '' : 'none';

  // 항목 정보 바
  var barName = document.getElementById('qcBarName');
  var barMeta = document.getElementById('qcBarMeta');
  var editBtn = document.getElementById('qcItemEditBtn');
  var delBtn  = document.getElementById('qcItemDeleteBtn');

  if (_qcMode === 'new') {
    if (barName) barName.textContent = '새 검사항목';
    if (barMeta) barMeta.textContent = '';
    if (editBtn) editBtn.style.display = 'none';
    if (delBtn)  delBtn.style.display  = 'none';
  } else {
    var item = _selItem;
    var isQ  = item.item_type === 'quantitative';
    var dec  = item.decimal_places || 2;
    var meta = isQ ? '정량' : '정성';
    if (item.unit) meta += ' · ' + item.unit;
    if (isQ && item.mean != null && item.sd != null)
      meta += ' · Mean ' + Number(item.mean).toFixed(dec) + ' ± SD ' + Number(item.sd).toFixed(dec);
    if (barName) barName.textContent = item.item_name;
    if (barMeta) barMeta.textContent = meta;
    if (editBtn) editBtn.style.display = (isEdit || !_qcCanManage) ? 'none' : '';
    if (delBtn)  delBtn.style.display  = (isEdit || !_qcCanManage) ? 'none' : '';
  }

  // 편집 폼
  if (isEdit) _renderForm();
}

function _renderForm() {
  var body = document.getElementById('qcItemFormBody');
  if (!body) return;
  var item = _selItem || {};
  var isQ  = (item.item_type || 'quantitative') === 'quantitative';

  function inp(label, id, val, type, extra) {
    return '<div><div style="font-size:10px;color:#9ca3af;margin-bottom:3px;font-weight:600;">' + label + '</div>' +
      '<input id="' + id + '" type="' + (type||'text') + '" class="input" style="height:28px;font-size:11px;" value="' + _qcEsc(val??'') + '" ' + (extra||'') + '/></div>';
  }
  function sel(label, id, opts, selected, onchange) {
    return '<div><div style="font-size:10px;color:#9ca3af;margin-bottom:3px;font-weight:600;">' + label + '</div>' +
      '<select id="' + id + '" class="input" style="height:28px;font-size:11px;" onchange="' + (onchange||'') + '">' +
      opts.map(function(o){ return '<option value="'+o[0]+'"'+(o[0]===selected?' selected':'')+'>'+o[1]+'</option>'; }).join('') +
      '</select></div>';
  }

  // 이미 쓰인 그룹명들 — 새 항목 등록 시 오타 없이 기존 그룹 중 골라 쓸 수 있도록 datalist로 제공
  var groupNames = Array.from(new Set(_qcItems.map(function(i) { return i.group_name; }).filter(Boolean)));
  var groupDatalist = '<datalist id="qf_group_list">' +
    groupNames.map(function(g) { return '<option value="' + _qcEsc(g) + '"></option>'; }).join('') +
    '</datalist>';

  body.innerHTML =
    inp('항목명 *', 'qf_name', item.item_name, 'text', 'placeholder="예: Glucose"') +
    inp('그룹', 'qf_group', item.group_name, 'text', 'placeholder="예: Bio1 (601)" list="qf_group_list"') + groupDatalist +
    sel('유형', 'qf_type', [['quantitative','정량'],['qualitative','정성']], item.item_type||'quantitative', 'window._onQfType()') +
    inp('단위', 'qf_unit', item.unit, 'text', 'placeholder="mg/dL"') +
    '<div id="qf_q" style="display:' + (isQ?'contents':'none') + '">' +
      inp('Mean', 'qf_mean', item.mean, 'number', 'step="any" placeholder="0.00"') +
      inp('SD',   'qf_sd',   item.sd,   'number', 'step="any" placeholder="0.00"') +
      inp('소수점', 'qf_dec', item.decimal_places??2, 'number', 'min="0" max="6" style="height:28px;font-size:11px;width:80px;"') +
    '</div>' +
    '<div id="qf_l" style="display:' + (!isQ?'contents':'none') + '">' +
      inp('선택지(쉼표)', 'qf_preset', item.preset, 'text', 'placeholder="양성,음성"') +
      inp('예상값', 'qf_expected', item.expected_value, 'text', 'placeholder="음성"') +
    '</div>' +
    inp('메모', 'qf_memo', item.memo);
}

window._onQfType = function() {
  var t = document.getElementById('qf_type')?.value;
  var q = document.getElementById('qf_q');
  var l = document.getElementById('qf_l');
  if (q) q.style.display = t === 'quantitative' ? 'contents' : 'none';
  if (l) l.style.display = t === 'qualitative'  ? 'contents' : 'none';
};

var _prevSelItem = null; // 새 항목 추가 취소 시 복원용

function _startNew() {
  _prevSelItem = _selItem; // 현재 선택 항목 기억
  _selItem = null;
  _qcMode  = 'new';
  _renderList();
  _renderBar();
  if (_qcGrid) _qcGrid.setGridOption('rowData', []);
  var wrap = document.getElementById('ljChartWrap');
  if (wrap) wrap.innerHTML = '';
}

function editQcItem() { _qcMode = 'edit'; _renderBar(); }
window.editQcItem = editQcItem;

function cancelQcItem() {
  if (_qcMode === 'new' && _prevSelItem) {
    // 새 항목 추가 취소 → 이전 선택 항목으로 복원
    _selItem = _prevSelItem;
    _prevSelItem = null;
    _qcMode = 'view';
    _renderList();
    _renderBar();
    _loadEntries();
  } else if (_qcMode === 'new') {
    // 이전 선택 항목 없었으면 미선택 상태로
    _selItem = null;
    _prevSelItem = null;
    _qcMode = 'view';
    _renderList();
    document.getElementById('detQcNoSelect').style.display = 'flex';
    document.getElementById('detQcSelected').style.display = 'none';
  } else {
    // edit 모드 취소 → 보기 모드로
    _qcMode = 'view';
    _renderBar();
  }
}
window.cancelQcItem = cancelQcItem;

async function saveQcItem() {
  var name = document.getElementById('qf_name')?.value.trim();
  if (!name) { showMessage('항목명을 입력해 주세요.', 'warning'); return; }
  var type = document.getElementById('qf_type')?.value || 'quantitative';
  var isQ  = type === 'quantitative';
  var payload = {
    org_id:         auth.getCurrentOrgId(),
    equipment_id:   _qcEqId,
    item_name:      name,
    group_name:     document.getElementById('qf_group')?.value.trim() || '',
    item_type:      type,
    unit:           document.getElementById('qf_unit')?.value.trim() || '',
    memo:           document.getElementById('qf_memo')?.value.trim() || '',
    decimal_places: parseInt(document.getElementById('qf_dec')?.value) || 2,
    mean:    isQ ? (parseFloat(document.getElementById('qf_mean')?.value)||null)    : null,
    sd:      isQ ? (parseFloat(document.getElementById('qf_sd')?.value)||null)      : null,
    preset:  !isQ ? (document.getElementById('qf_preset')?.value.trim()||'')       : '',
    expected_value: !isQ ? (document.getElementById('qf_expected')?.value.trim()||'') : '',
    updated_at: new Date().toISOString(),
  };
  var res = _qcMode === 'new'
    ? await supabaseClient.from('lj_items').insert(payload).select().single()
    : await supabaseClient.from('lj_items').update(payload).eq('id', _selItem.id).select().single();
  if (res.error) { showMessage('저장 실패: ' + res.error.message, 'error'); return; }
  showMessage('저장됐습니다.', 'success');
  systemLog('EQUIPMENT_QC_ITEM_SAVE', '정도관리 검사항목 저장 (' + name + ')', { target_type: 'equipment', target_id: _qcEqId }).catch(() => {});
  _selItem = res.data;
  _qcMode  = 'view';
  await _loadItems();
  _renderBar();
  _loadEntries();
}
window.saveQcItem = saveQcItem;

async function deleteQcItem() {
  if (!_selItem) return;
  if (!confirm('"' + _selItem.item_name + '" 항목을 삭제하시겠습니까?\n측정 데이터도 모두 삭제됩니다.')) return;
  await supabaseClient.from('lj_entries').delete().eq('item_id', _selItem.id);
  await supabaseClient.from('lj_items').delete().eq('id', _selItem.id);
  showMessage('삭제됐습니다.', 'success');
  _selItem = null;
  _qcMode  = 'view';
  if (_qcGrid) _qcGrid.setGridOption('rowData', []);
  document.getElementById('ljChartWrap').innerHTML = '';
  document.getElementById('detQcNoSelect').style.display = 'flex';
  document.getElementById('detQcSelected').style.display = 'none';
  await _loadItems();
}
window.deleteQcItem = deleteQcItem;

/* ── Westgard 다중규칙 판정 ─────────────────────
   data: [{date, v}] 측정일 오름차순
   각 포인트마다 위반한 규칙 목록과 reject 여부를 반환 */
function _evalWestgard(data, mean, sd) {
  if (!sd) return data.map(function() { return { z: 0, violations: [], reject: false, warning: false }; });
  return data.map(function(d, i) {
    var z = (d.v - mean) / sd;
    var violations = [];

    if (Math.abs(z) > 3) violations.push('1_3s');
    else if (Math.abs(z) > 2) violations.push('1_2s');

    if (i > 0) {
      var z0 = (data[i-1].v - mean) / sd;
      if ((z > 2 && z0 > 2) || (z < -2 && z0 < -2)) violations.push('2_2s');
      if (Math.abs(z - z0) > 4) violations.push('R_4s');
    }
    if (i >= 3) {
      var last4 = [data[i-3], data[i-2], data[i-1], d].map(function(x) { return (x.v - mean) / sd; });
      if (last4.every(function(zz) { return zz > 1; }) || last4.every(function(zz) { return zz < -1; })) violations.push('4_1s');
    }
    if (i >= 9) {
      var last10 = data.slice(i-9, i+1).map(function(x) { return x.v - mean; });
      if (last10.every(function(dd) { return dd > 0; }) || last10.every(function(dd) { return dd < 0; })) violations.push('10x');
    }

    var rejectRules = violations.filter(function(v) { return v !== '1_2s'; });
    return { z: z, violations: violations, reject: rejectRules.length > 0, warning: violations.indexOf('1_2s') >= 0 && rejectRules.length === 0 };
  });
}


function _initEntryGrid() {
  var el = document.getElementById('qcEntryGrid');
  if (!el || _qcGrid) return;
  _qcGrid = agGrid.createGrid(el, {
    columnDefs: _entryColDefs(null),
    rowData: [],
    rowHeight: 34, headerHeight: 34,
    suppressCellFocus: false, suppressHorizontalScroll: true,
    stopEditingWhenCellsLoseFocus: true,
    defaultColDef: { sortable: false, resizable: true, suppressMovable: true,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center' } },
    overlayNoRowsTemplate: '<span style="color:#9ca3af;font-size:12px;">+ 입력 버튼으로 측정값을 추가하세요</span>',
    onGridReady: function(p) { requestAnimationFrame(function() { fitGridColumnsPinned(p.api, p.api.getColumnDefs()); }); },
  });
  // 컨테이너 너비 변경 시 컬럼 재조정
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(function() {
      if (_qcGrid) fitGridColumnsPinned(_qcGrid, _qcGrid.getColumnDefs());
    }).observe(el);
  }
}

function _entryColDefs(item) {
  var isQual = item && item.item_type === 'qualitative' && item.preset;
  return [
    { headerName: '측정일', field: 'date', width: 100,
      editable: function() { return _qcCanManage; }, singleClickEdit: true,
      cellEditor: 'agDateStringCellEditor',
      cellRenderer: function(p) {
        return p.value ? String(p.value).slice(0,10)
          : '<span style="color:#d1d5db;font-size:11px;">날짜 클릭</span>';
      }
    },
    { headerName: '측정값', field: 'value', width: 90,
      editable: function() { return _qcCanManage; }, singleClickEdit: true,
      cellEditor: isQual ? 'agSelectCellEditor' : 'agTextCellEditor',
      cellEditorParams: isQual ? { values: item.preset.split(',').map(function(s){return s.trim();}) } : {},
      cellStyle: function(p) {
        var base = { display:'flex', alignItems:'center', justifyContent:'flex-end', fontWeight:600 };
        if (p.data._reject) base.color = '#dc2626';
        else if (p.data._warning) base.color = '#d97706';
        return base;
      },
      cellRenderer: function(p) {
        return (p.value != null && p.value !== '') ? String(p.value)
          : '<span style="color:#d1d5db;font-size:11px;">값 클릭</span>';
      }
    },
    { headerName: '판정', width: 70, sortable: false,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center', fontSize:'10px', fontWeight:700 },
      cellRenderer: function(p) {
        if (!p.data._violations || !p.data._violations.length) return '<span style="color:#9ca3af;">-</span>';
        var color = p.data._reject ? '#dc2626' : '#d97706';
        return '<span style="color:' + color + ';" title="' + p.data._violations.join(', ') + '">' + p.data._violations[0] + (p.data._violations.length > 1 ? ' 외' : '') + '</span>';
      }
    },
    { headerName: '측정자', width: 90, sortable: false,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center', fontSize:'11px', color:'#6b7280' },
      cellRenderer: function(p) {
        var map = _qcUserMap || {};
        return _qcEsc(map[p.data.created_by] || '-');
      }
    },
    { headerName: '메모', field: 'memo', flex: 1, minWidth: 100,
      editable: function() { return _qcCanManage; }, singleClickEdit: true,
      headerClass: 'ag-left-header',
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'flex-start', color:'#6b7280' },
    },
    { headerName: '', flex: 0, width: 90, sortable: false,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center', gap:'4px' },
      cellRenderer: function(p) {
        if (!_qcCanManage) return '';
        var wrap = document.createElement('div');
        wrap.style.cssText = 'display:flex;gap:4px;';
        var s = document.createElement('button');
        s.className = 'tbl-btn'; s.textContent = '저장';
        // click 대신 mousedown — 편집 중인 셀이 있으면 click 이벤트의 첫 번째는
        // 포커스아웃(편집 종료) 처리에 먹혀서 버튼이 한 번에 안 눌리는 문제가 있음.
        // mousedown은 그 포커스아웃 처리보다 먼저 발생해서 항상 정상적으로 잡힘.
        s.addEventListener('mousedown', function(e) {
          e.preventDefault();
          // preventDefault가 mousedown의 기본 동작(포커스 이동으로 인한 blur)까지 막아버려서,
          // 편집 중이던 셀(예: 방금 입력한 메모)이 stopEditingWhenCellsLoseFocus로 커밋되기 전에
          // 저장이 실행되는 문제가 있었다. stopEditing()으로 먼저 강제 커밋한 뒤 저장한다.
          _qcGrid.stopEditing();
          window._saveEntry(p.node.data);
        });
        var d = document.createElement('button');
        d.className = 'tbl-btn tbl-btn--danger'; d.textContent = '삭제';
        d.addEventListener('mousedown', function(e) {
          e.preventDefault();
          _qcGrid.stopEditing();
          window._delEntry(p.node.data);
        });
        wrap.appendChild(s); wrap.appendChild(d);
        return wrap;
      }
    },
  ];
}

async function _loadEntries() {
  if (!_selItem || !_qcGrid) return;
  await _getQcUserMap();
  var dateFrom = document.getElementById('qcDateFrom')?.value || '';
  var dateTo   = document.getElementById('qcDateTo')?.value || '';

  // Westgard 판정(연속 포인트 규칙: 2_2s/R_4s/4_1s/10x)은 조회 날짜 범위와 무관하게
  // 항상 전체 이력 기준으로 계산해야 정확함 — 화면에는 필터된 구간만 보여주되,
  // 판정 자체는 전체 데이터를 기준으로 미리 계산해둔 뒤 그 결과만 잘라서 씀
  var { data: allData } = await supabaseClient.from('lj_entries').select('*')
    .eq('item_id', _selItem.id).order('date', { ascending: true });
  var allRows = allData || [];

  var item = _selItem;
  if (item.item_type === 'quantitative' && item.mean != null && item.sd) {
    var mean = parseFloat(item.mean), sd = parseFloat(item.sd);
    var numeric = allRows.map(function(r) { return { v: parseFloat(r.value) }; });
    var evals = _evalWestgard(numeric, mean, sd);
    allRows.forEach(function(r, i) {
      var ok = !isNaN(numeric[i].v);
      r._violations = ok ? evals[i].violations : [];
      r._reject     = ok ? evals[i].reject     : false;
      r._warning    = ok ? evals[i].warning    : false;
    });
  } else {
    allRows.forEach(function(r) { r._violations = []; r._reject = false; r._warning = false; });
  }

  // 화면 표시용 — 날짜 필터 적용 (판정 결과는 위에서 전체 기준으로 이미 계산된 걸 그대로 들고 있음)
  var rows = allRows.filter(function(r) {
    if (dateFrom && r.date < dateFrom) return false;
    if (dateTo   && r.date > dateTo)   return false;
    return true;
  });

  // 최근 측정의 판정을 헤더 배지로 표시 — 이것도 전체 이력 기준 마지막 건으로 표시
  var badge = document.getElementById('qcWestgardBadge');
  if (badge) {
    var last = allRows.length ? allRows[allRows.length - 1] : null;
    if (item.item_type !== 'quantitative' || item.mean == null || !item.sd) {
      badge.textContent = '';
    } else if (!last) {
      badge.innerHTML = '';
    } else if (last._reject) {
      badge.innerHTML = '<span style="color:#dc2626;">⚠ ' + last._violations.join(', ') + ' 위반 (Reject)</span>';
    } else if (last._warning) {
      badge.innerHTML = '<span style="color:#d97706;">△ 1_2s (경고)</span>';
    } else {
      badge.innerHTML = '<span style="color:#059669;">✓ 정상</span>';
    }
  }

  // 컬럼 업데이트 (항목 유형에 따라)
  _qcGrid.setGridOption('columnDefs', _entryColDefs(_selItem));
  // Westgard 판정(_violations/_reject/_warning)은 각 행에 이미 계산되어 붙어있으므로,
  // 화면에 보여줄 때만 최근 날짜가 위로 오도록 뒤집는다(연속 규칙 계산 자체는 위에서
  // 오름차순 그대로 수행했으니 뒤집어도 판정 결과에는 영향 없음).
  _qcGrid.setGridOption('rowData', rows.slice().reverse());
  fitGridColumnsPinned(_qcGrid, _qcGrid.getColumnDefs());
  _renderChart(_selItem, rows);
}

// new Date().toISOString()은 UTC 기준이라 KST 자정~오전 9시 사이엔 "오늘"이 하루 전으로
// 계산되는 버그가 있다. 날짜만 필요할 땐 항상 이 헬퍼로 로컬 타임존 기준으로 조립해야 한다.
function _localDateStr(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function _addRow() {
  if (!_qcCanManage) { showMessage('정도관리 담당자만 측정값을 입력할 수 있습니다.', 'warning'); return; }
  if (!_selItem || !_qcGrid) return;
  // 최근 날짜가 맨 위로 오도록 정렬해 보여주므로(아래 _loadEntries 참고),
  // 새로 추가하는 빈 입력행도 맨 위(addIndex: 0)에 꽂아야 자연스럽다.
  _qcGrid.applyTransaction({
    add: [{ id: null, item_id: _selItem.id, date: _localDateStr(new Date()), value: '', memo: '' }],
    addIndex: 0,
  });
}

window._saveEntry = async function(row) {
  if (!_qcCanManage) { showMessage('정도관리 담당자만 저장할 수 있습니다.', 'warning'); return; }
  if (!row.date || row.value === '' || row.value == null) {
    showMessage('날짜와 측정값을 입력해 주세요.', 'warning'); return;
  }
  var payload = { org_id: auth.getCurrentOrgId(), item_id: _selItem.id, date: row.date,
    value: String(row.value), memo: row.memo || '' };
  if (!row.id) payload.created_by = getCurrentUser()?.id || null; // 측정자는 최초 등록자 기준 — 수정 시에는 덮어쓰지 않음
  var res = row.id
    ? await supabaseClient.from('lj_entries').update(payload).eq('id', row.id)
    : await supabaseClient.from('lj_entries').insert(payload);
  if (res.error) { showMessage('저장 실패: ' + res.error.message, 'error'); return; }
  showMessage('저장됐습니다.', 'success');
  _loadEntries();
};

window._delEntry = async function(row) {
  if (!_qcCanManage) { showMessage('정도관리 담당자만 삭제할 수 있습니다.', 'warning'); return; }
  if (!row.id) { _qcGrid.applyTransaction({ remove: [row] }); return; }
  if (!confirm('이 측정 데이터를 삭제하시겠습니까?')) return;
  await supabaseClient.from('lj_entries').delete().eq('id', row.id);
  showMessage('삭제됐습니다.', 'success');
  _loadEntries();
};

/* ── L-J 차트 ────────────────────────────────── */
var _qcChartRO = null;       // ljChartWrap 크기 변화를 감지해서 다시 그리기 위한 ResizeObserver
var _qcLastChartArgs = null; // 마지막으로 그린 item/entries 캐시 (재측정 시 재사용)

function _renderChart(item, entries) {
  var wrap = document.getElementById('ljChartWrap');
  if (!wrap) return;
  _qcLastChartArgs = { item: item, entries: entries };

  // wrap의 실제 크기가 변할 때마다(탭 전환으로 처음 보이게 되는 순간 포함) 다시 그림.
  // 한 번만 wrap.clientWidth를 읽고 끝내면, 탭이 아직 숨겨져있거나 레이아웃이 다 안 잡힌
  // 시점에 측정된 작은 값이 그대로 굳어버려서 차트가 실제 패널보다 좁게 그려지는 문제가 있었음.
  if (!_qcChartRO && typeof ResizeObserver !== 'undefined') {
    _qcChartRO = new ResizeObserver(function() {
      if (_qcLastChartArgs) _drawChart(_qcLastChartArgs.item, _qcLastChartArgs.entries);
    });
    _qcChartRO.observe(wrap);
  }
  _drawChart(item, entries);
}

function _drawChart(item, entries) {
  var wrap = document.getElementById('ljChartWrap');
  if (!wrap) return;
  if (item.item_type !== 'quantitative' || !item.mean || !item.sd) {
    wrap.innerHTML = '<div style="height:100%;display:flex;align-items:center;justify-content:center;color:#9ca3af;font-size:11px;text-align:center;">' +
      (item.item_type !== 'quantitative' ? '정성 항목은 차트를 지원하지 않습니다.' : 'Mean과 SD를 입력하면 차트가 표시됩니다.') + '</div>';
    return;
  }
  var data = entries.map(function(e){return{date:e.date,v:parseFloat(e.value),reject:e._reject,warning:e._warning};}).filter(function(e){return!isNaN(e.v);});
  if (!data.length) {
    wrap.innerHTML = '<div style="height:100%;display:flex;align-items:center;justify-content:center;color:#9ca3af;font-size:11px;">측정 데이터를 입력하면 차트가 표시됩니다.</div>';
    return;
  }
  var mean=parseFloat(item.mean), sd=parseFloat(item.sd), dec=item.decimal_places||2;
  var rect=wrap.getBoundingClientRect();
  var W=Math.max(100, Math.floor(rect.width)), H=Math.max(80, Math.floor(rect.height));
  // 좌측 여백(축 라벨 자리)은 라벨 글자수에 맞춰 동적으로 계산 — 고정값(48px)을 쓰면
  // 라벨이 짧을 때 왼쪽이 필요 이상으로 넓어져서 그래프가 오른쪽으로 쏠려 보임
  var maxLabelLen = Math.max(
    Number(mean+3*sd).toFixed(dec).length,
    Number(mean-3*sd).toFixed(dec).length
  );
  var p={t:18, r:28, b:36, l: Math.max(28, 10 + maxLabelLen*5.5)};
  var cw=W-p.l-p.r, ch=H-p.t-p.b;
  var yMin=mean-3.5*sd, yMax=mean+3.5*sd;
  function Y(v){return p.t+ch-(v-yMin)/(yMax-yMin)*ch;}
  function X(i){return p.l+(data.length===1?cw/2:i/(data.length-1)*cw);}

  var bands=[[mean+2*sd,mean-2*sd,'#fffbeb'],[mean+3*sd,mean+2*sd,'#fff5f5'],[mean-2*sd,mean-3*sd,'#fff5f5']];
  var lines=[
    [mean+3*sd,'#ef4444','3,2'],[mean+2*sd,'#f59e0b','3,2'],[mean+sd,'#e2e8f0','2,2'],
    [mean,'#3b82f6',''],
    [mean-sd,'#e2e8f0','2,2'],[mean-2*sd,'#f59e0b','3,2'],[mean-3*sd,'#ef4444','3,2'],
  ];
  var lLabels=['+3SD','+2SD','+1SD','Mean','-1SD','-2SD','-3SD'];

  var svg=['<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'" style="font-size:10px;overflow:visible;">',
    '<rect width="'+W+'" height="'+H+'" fill="#fff"/>'];
  bands.forEach(function(b){
    svg.push('<rect x="'+p.l+'" y="'+Y(b[0])+'" width="'+cw+'" height="'+(Y(b[1])-Y(b[0]))+'" fill="'+b[2]+'"/>');
  });
  lines.forEach(function(l,i){
    var y=Y(l[0]), da=l[2]?'stroke-dasharray="'+l[2]+'"':'';
    svg.push('<line x1="'+p.l+'" y1="'+y+'" x2="'+(p.l+cw)+'" y2="'+y+'" stroke="'+l[1]+'" stroke-width="'+(lLabels[i]==='Mean'?2:1)+'" '+da+'/>');
    svg.push('<text x="'+(p.l-3)+'" y="'+(y+3.5)+'" text-anchor="end" fill="'+l[1]+'" font-size="9" font-weight="'+(lLabels[i]==='Mean'?700:400)+'">'+Number(l[0]).toFixed(dec)+'</text>');
  });
  if(data.length>1) svg.push('<polyline points="'+data.map(function(d,i){return X(i)+','+Y(d.v);}).join(' ')+'" fill="none" stroke="#3b82f6" stroke-width="1.5" stroke-linejoin="round"/>');
  data.forEach(function(d,i){
    var c = d.reject ? '#dc2626' : d.warning ? '#f59e0b' : '#3b82f6';
    var r = d.reject ? 4.5 : 3.5;
    svg.push('<circle cx="'+X(i)+'" cy="'+Y(d.v)+'" r="'+r+'" fill="'+c+'" stroke="#fff" stroke-width="1.5"/>');
  });
  var step=Math.max(1,Math.ceil(data.length/8));
  data.forEach(function(d,i){
    if(i%step!==0&&i!==data.length-1)return;
    // 맨 처음/맨 끝 라벨은 가운데정렬하면 차트 밖으로 튀어나가 잘리므로, 안쪽 방향으로 붙여서 정렬
    var anchor = i===0 ? 'start' : (i===data.length-1 ? 'end' : 'middle');
    svg.push('<text x="'+X(i)+'" y="'+(p.t+ch+13)+'" text-anchor="'+anchor+'" fill="#9ca3af" font-size="9">'+String(d.date).slice(5)+'</text>');
  });
  svg.push('<rect x="'+p.l+'" y="'+p.t+'" width="'+cw+'" height="'+ch+'" fill="none" stroke="#e5e7eb"/>');
  svg.push('</svg>');
  wrap.innerHTML=svg.join('');
}
/* ══════════════════════════════════════════════
   검사이력 — 일일점검·정기점검 (성적서 첨부, 합격/불합격)
   정도관리(lj_entries, 통계적 관리)와는 완전히 별개 — 단순 합격/불합격 기록.
══════════════════════════════════════════════ */
var _inspectGrid   = null;
var _inspectRows   = [];
var _inspectEditId = null;
var _inspectInited = false;
var _checklistItems = []; // 이 의원 공용 점검 체크리스트 항목 (org 전체 공용, 장비별 아님)

function openModal(id)  { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }

/* ══════════════════════════════════════════════
   연결된 계약 — 이 장비를 구매/유지보수 등으로 다루는 계약을 계약관리 모듈과 연결.
   contracts/detail.js의 "관련 계약" 기능과 완전히 같은 패턴(검색해서 연결, 메모, 해제)이며
   equipment_contract_links 테이블만 다르다(계약↔계약이 아니라 장비↔계약).
══════════════════════════════════════════════ */
const ECL_STATUS_LABEL = { ACTIVE: '진행중', EXPIRED: '만료', TERMINATED: '해지' };

async function loadLinkedContracts(equipmentId) {
  const wrap = document.getElementById('eclLinkList');
  if (!wrap) return;
  const { data: links, error } = await supabaseClient.from('equipment_contract_links')
    .select('id, note, contract_id').eq('equipment_id', equipmentId);
  if (error) { wrap.innerHTML = '<div class="ecl-link-empty">목록 로드 실패</div>'; return; }

  if (!links || !links.length) {
    wrap.innerHTML = '<div class="ecl-link-empty">연결된 계약이 없습니다.' +
      (detailPermission.canEdit ? ' "계약 연결" 버튼으로 추가하세요.' : '') + '</div>';
    return;
  }

  const { data: contracts } = await supabaseClient.from('contracts')
    .select('id, doc_no, counterparty_name, contract_title, contract_type, status')
    .in('id', links.map(l => l.contract_id));
  const byId = {};
  (contracts || []).forEach(c => { byId[c.id] = c; });

  wrap.innerHTML = links.map(l => {
    const c = byId[l.contract_id];
    if (!c) return '';
    return `
      <div class="ecl-link-row">
        <div class="ecl-link-main" data-contract-id="${c.id}" style="display:flex; align-items:center; gap:10px; cursor:pointer; min-width:0; overflow:hidden;">
          <code style="font-size:11px; flex-shrink:0;">${escapeHtml(c.doc_no || '-')}</code>
          <span style="font-size:12px; color:#374151; flex-shrink:0;">${escapeHtml(c.counterparty_name || '-')}</span>
          <span style="font-size:12px; color:#0f172a; font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(c.contract_title || '-')}</span>
          ${c.contract_type ? `<span style="font-size:11px; color:#9ca3af; flex-shrink:0;">· ${escapeHtml(c.contract_type)}</span>` : ''}
        </div>
        <div style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
          <span class="status-badge status-${escapeHtml(c.status)}">${ECL_STATUS_LABEL[c.status] || escapeHtml(c.status)}</span>
          ${detailPermission.canEdit ? `<button type="button" class="tbl-btn ecl-unlink-btn" data-link-id="${l.id}">연결 해제</button>` : ''}
        </div>
      </div>`;
  }).join('');

  wrap.querySelectorAll('.ecl-link-main').forEach(el => {
    el.addEventListener('click', () => {
      parent.shellNavigate && parent.shellNavigate('contracts/detail?id=' + el.dataset.contractId);
    });
  });
  wrap.querySelectorAll('.ecl-unlink-btn').forEach(btn => {
    btn.addEventListener('click', e => { e.stopPropagation(); unlinkContract(btn.dataset.linkId); });
  });
}

async function unlinkContract(linkId) {
  if (!confirm('이 계약과의 연결을 해제하시겠습니까? (계약 자체는 삭제되지 않습니다)')) return;
  showGlobalLoading('연결 해제 중...');
  try {
    const { error } = await supabaseClient.from('equipment_contract_links').delete().eq('id', linkId);
    if (error) throw new Error(error.message);
    await loadLinkedContracts(currentEquipmentId);
    showMessage('연결이 해제되었습니다.', 'success');
  } catch (e) {
    showMessage('연결 해제 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

let _eclPickGrid = null;
let _eclPickTarget = null;

function initEclPickGrid() {
  const cols = [
    { headerName: '문서번호', field: 'doc_no', width: 150,
      headerClass: 'ag-left-header', cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' },
      cellRenderer: p => '<code style="font-size:11px;">' + escapeHtml(p.value || '-') + '</code>' },
    { headerName: '거래상대방', field: 'counterparty_name', width: 150,
      headerClass: 'ag-left-header', cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' },
      valueFormatter: p => p.value || '-' },
    { headerName: '계약 건명', field: 'contract_title', flex: 1, minWidth: 160,
      headerClass: 'ag-left-header', cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' },
      valueFormatter: p => p.value || '-' },
    { headerName: '상태', field: 'status', width: 90, valueFormatter: p => ECL_STATUS_LABEL[p.value] || p.value || '-' },
    { headerName: '', width: 80, sortable: false, cellRenderer: p => {
        const btn = document.createElement('button');
        btn.className = 'tbl-btn'; btn.textContent = '연결';
        btn.onclick = e => { e.stopPropagation(); openEclNoteModal(p.data); };
        return btn;
      } },
  ];
  _eclPickGrid = createMgGrid('eclPickGrid', cols, [], {
    fit: true, noRowsText: '연결 가능한 계약이 없습니다.',
    onRowClick: data => openEclNoteModal(data),
  });
}

async function searchEclPick(keyword) {
  const { data: links } = await supabaseClient.from('equipment_contract_links')
    .select('contract_id').eq('equipment_id', currentEquipmentId);
  const excludeIds = new Set((links || []).map(l => l.contract_id));

  let q = supabaseClient.from('contracts').select('id, doc_no, counterparty_name, contract_title, status')
    .eq('org_id', getCurrentUser().org_id)
    .is('deleted_at', null)
    .order('created_at', { ascending: false }).limit(50);
  if (keyword) q = q.or('contract_title.ilike.%' + escapeIlikeKeyword(keyword) + '%,counterparty_name.ilike.%' + escapeIlikeKeyword(keyword) + '%,doc_no.ilike.%' + escapeIlikeKeyword(keyword) + '%');
  const { data, error } = await q;
  if (error) { showMessage('검색 실패: ' + error.message, 'error'); return; }
  updateMgGrid(_eclPickGrid, (data || []).filter(c => !excludeIds.has(c.id)));
}

function openEclNoteModal(row) {
  _eclPickTarget = row;
  document.getElementById('eclNoteTargetLabel').textContent =
    (row.doc_no || '-') + ' · ' + (row.counterparty_name || '-') + ' · ' + (row.contract_title || '-');
  document.getElementById('eclNoteInput').value = '';
  closeModal('eclPickModal');
  openModal('eclNoteModal');
  setTimeout(() => document.getElementById('eclNoteInput').focus(), 50);
}

async function confirmLinkContract() {
  if (!_eclPickTarget) return;
  const user = getCurrentUser();
  showGlobalLoading('연결 중...');
  try {
    const { error } = await supabaseClient.from('equipment_contract_links').insert({
      equipment_id: currentEquipmentId, contract_id: _eclPickTarget.id,
      note: document.getElementById('eclNoteInput').value.trim() || null,
      created_by: user.org_member_id,
    });
    if (error) throw new Error(error.message);
    closeModal('eclNoteModal');
    await loadLinkedContracts(currentEquipmentId);
    showMessage('연결되었습니다.', 'success');
  } catch (e) {
    showMessage('연결 실패: ' + e.message, 'error');
  } finally {
    hideGlobalLoading();
  }
}

function bindEclPicker() {
  const btn = document.getElementById('eclLinkBtn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    if (!_eclPickGrid) initEclPickGrid();
    openModal('eclPickModal');
    document.getElementById('eclPickSearch').value = '';
    searchEclPick('');
    setTimeout(() => document.getElementById('eclPickSearch').focus(), 50);
  });
  let debounceTimer;
  document.getElementById('eclPickSearch').addEventListener('input', function() {
    clearTimeout(debounceTimer);
    const kw = this.value;
    debounceTimer = setTimeout(() => searchEclPick(kw), 250);
  });
  document.getElementById('eclPickSearch').addEventListener('keydown', e => {
    if (e.key === 'Enter') { clearTimeout(debounceTimer); searchEclPick(e.target.value); }
  });
  document.getElementById('eclPickSearchBtn').addEventListener('click', () => {
    searchEclPick(document.getElementById('eclPickSearch').value);
  });
  document.getElementById('eclNoteConfirmBtn').addEventListener('click', confirmLinkContract);
}
document.addEventListener('DOMContentLoaded', bindEclPicker);

/* 검사이력 관리 가능 여부 — admin이거나, 그 장비 부서의 "장비담당자(is_equipment_manager)".
   정도관리 담당자(_qcCanManage)와는 별도 권한이다 — 부서 내 역할이 다를 수 있음. */
function canManageInspect() {
  var user = getCurrentUser();
  var eq = window._currentEquipment;
  if (!user || !eq) return false;
  if (detailPermission.isAdmin) return true;
  return !!(user.is_equipment_manager && user.team_code && eq.team_code && user.team_code === eq.team_code);
}

/* 체크리스트 "항목" 관리(추가/수정/삭제)는 admin 전용 — 장비담당자(is_equipment_manager)라도
   role이 user/manager면 불가. 의원 전체 공용 항목이라 부서 담당자에게 맡기면 서로 다른
   부서 기준이 뒤섞일 수 있어서 이렇게 좁혀뒀다. (체크 자체는 검사 등록 시 누구나 가능) */
function canManageChecklist() {
  var user = getCurrentUser();
  return !!(user && user.role === 'admin');
}

function _inspResultColor(r) { return r === '합격' ? '#16a34a' : '#dc2626'; }

// signed URL을 그냥 window.open()하면 브라우저가 (특히 이미지·PDF는) 새 탭에 "열기"만 하고
// 다운로드는 안 시켜준다. blob으로 직접 받아서 로컬 objectURL로 <a download>를 눌러줘야
// 실제로 파일 저장 창이 뜬다.
async function _forceDownload(url, filename) {
  try {
    var res = await fetch(url);
    var blob = await res.blob();
    var objectUrl = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename || '첨부파일';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function() { URL.revokeObjectURL(objectUrl); }, 5000);
  } catch (e) {
    showMessage('다운로드 실패: ' + e.message, 'error');
  }
}

async function initInspectPanel() {
  if (_inspectInited) return;
  _inspectInited = true;

  var addBtn = document.getElementById('addInspectBtn');
  if (addBtn) {
    addBtn.style.display = canManageInspect() ? '' : 'none';
    addBtn.addEventListener('click', function() { _openInspectModal(null); });
  }
  var manageBtn = document.getElementById('manageChecklistBtn');
  if (manageBtn) {
    manageBtn.style.display = canManageChecklist() ? '' : 'none';
    manageBtn.addEventListener('click', _openChecklistModal);
  }
  var configBtn = document.getElementById('configEquipChecklistBtn');
  if (configBtn) {
    configBtn.style.display = canManageInspect() ? '' : 'none';
    configBtn.addEventListener('click', _openEquipChecklistModal);
  }
  document.getElementById('equipChecklistSaveBtn')?.addEventListener('click', _saveEquipChecklistConfig);
  document.getElementById('addChecklistItemBtn')?.addEventListener('click', _addChecklistItem);
  document.getElementById('inspectModalSubmit')?.addEventListener('click', _saveInspect);
  document.getElementById('insp_file')?.addEventListener('change', function() {
    var f = this.files[0];
    var label = document.getElementById('insp_file_label');
    if (label) label.textContent = f ? f.name : '파일을 끌어다 놓거나 클릭하여 선택';
  });
  document.getElementById('insp_type')?.addEventListener('change', function() {
    var wrap = document.getElementById('insp_next_due_wrap');
    if (wrap) wrap.style.display = this.value === '정기점검' ? '' : 'none';
  });

  await _loadChecklistItems();
  await _loadInspectRows();
}

/* ── 체크리스트 항목 관리 ── */
async function _loadChecklistItems() {
  var { data, error } = await supabaseClient.from('equipment_checklist_items')
    .select('*').eq('org_id', auth.getCurrentOrgId()).eq('active', true).order('sort_order', { ascending: true });
  if (error) { showMessage('체크리스트 조회 실패: ' + error.message, 'error'); return; }
  _checklistItems = data || [];
}

function _openChecklistModal() {
  if (!canManageChecklist()) { showMessage('체크리스트 관리는 관리자만 할 수 있습니다.', 'warning'); return; }
  _renderChecklistItemRows();
  openModal('checklistModal');
}
function _closeChecklistModal() { closeModal('checklistModal'); }

function _renderChecklistItemRows() {
  var wrap = document.getElementById('checklistItemRows');
  if (!wrap) return;
  if (!_checklistItems.length) {
    wrap.innerHTML = '<div style="font-size:11px;color:#9ca3af;">등록된 항목이 없습니다. 아래에서 추가해 주세요.</div>';
    return;
  }
  wrap.innerHTML = '';
  _checklistItems.forEach(function(item) {
    var row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:6px;';
    var input = document.createElement('input');
    input.type = 'text'; input.value = item.label;
    input.style.cssText = 'flex:1;height:32px;border:1px solid #d1d5db;border-radius:6px;padding:0 8px;font-size:12.5px;';
    input.addEventListener('change', function() { _updateChecklistItem(item.id, input.value.trim()); });
    var del = document.createElement('button');
    del.className = 'btn btn-sm btn-danger'; del.textContent = '삭제';
    del.addEventListener('click', function() { _deleteChecklistItem(item.id); });
    row.appendChild(input); row.appendChild(del);
    wrap.appendChild(row);
  });
}

async function _addChecklistItem() {
  var input = document.getElementById('newChecklistItem');
  var label = (input?.value || '').trim();
  if (!label) return;
  var maxOrder = _checklistItems.reduce(function(m, it) { return Math.max(m, it.sort_order || 0); }, 0);
  var { error } = await supabaseClient.from('equipment_checklist_items').insert({
    org_id: auth.getCurrentOrgId(), label: label, sort_order: maxOrder + 1,
  });
  if (error) { showMessage('추가 실패: ' + error.message, 'error'); return; }
  input.value = '';
  await _loadChecklistItems();
  _renderChecklistItemRows();
}

async function _updateChecklistItem(id, label) {
  if (!label) return;
  await supabaseClient.from('equipment_checklist_items').update({ label: label }).eq('id', id);
  await _loadChecklistItems();
}

async function _deleteChecklistItem(id) {
  if (!confirm('이 체크리스트 항목을 삭제하시겠습니까? (기존 검사 기록에는 영향 없습니다)')) return;
  await supabaseClient.from('equipment_checklist_items').update({ active: false }).eq('id', id);
  await _loadChecklistItems();
  _renderChecklistItemRows();
}

/* ── 장비별 체크리스트 적용 설정 (전체 항목 중 이 장비에서 뺄 것만 고르는 opt-out 방식) ── */
function _openEquipChecklistModal() {
  if (!canManageInspect()) { showMessage('장비담당자만 설정할 수 있습니다.', 'warning'); return; }
  var wrap = document.getElementById('equipChecklistRows');
  if (!wrap) return;
  if (!_checklistItems.length) {
    wrap.innerHTML = '<div style="font-size:11px;color:#9ca3af;">등록된 체크리스트 항목이 없습니다. 먼저 "체크리스트 관리"에서 항목을 추가해 주세요.</div>';
  } else {
    var excluded = (window._currentEquipment && window._currentEquipment.checklist_excluded_ids) || [];
    wrap.innerHTML = '';
    _checklistItems.forEach(function(item) {
      var row = document.createElement('label');
      row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 4px;font-size:12.5px;color:#374151;cursor:pointer;border-bottom:1px solid #f3f4f6;';
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.dataset.itemId = item.id;
      cb.checked = excluded.indexOf(item.id) === -1; // 기본 켜짐(적용됨)
      var span = document.createElement('span');
      span.textContent = item.label;
      row.appendChild(cb); row.appendChild(span);
      wrap.appendChild(row);
    });
  }
  openModal('equipChecklistModal');
}
function _closeEquipChecklistModal() { closeModal('equipChecklistModal'); }

async function _saveEquipChecklistConfig() {
  var eq = window._currentEquipment;
  if (!eq) return;
  var wrap = document.getElementById('equipChecklistRows');
  var boxes = wrap ? wrap.querySelectorAll('input[type=checkbox]') : [];
  var excludedIds = Array.from(boxes).filter(function(cb) { return !cb.checked; }).map(function(cb) { return cb.dataset.itemId; });

  var { error } = await supabaseClient.from('equipments').update({ checklist_excluded_ids: excludedIds }).eq('id', eq.id);
  if (error) { showMessage('저장 실패: ' + error.message, 'error'); return; }
  eq.checklist_excluded_ids = excludedIds; // 화면에 바로 반영
  showMessage('이 장비의 체크리스트 설정이 저장됐습니다.', 'success');
  _closeEquipChecklistModal();
}

// 검사 등록/수정 모달의 체크리스트 영역 — existingResults가 있으면(수정) 그 당시 체크 상태를,
// 없으면(신규 등록) 전부 체크된 상태(=이상없음)로 기본값을 준다. 이상 있는 항목만 체크 해제하면 됨.
function _applicableChecklistItems() {
  var eq = window._currentEquipment;
  var excluded = (eq && eq.checklist_excluded_ids) || [];
  return _checklistItems.filter(function(item) { return excluded.indexOf(item.id) === -1; });
}

function _renderInspectChecklist(existingResults) {
  var wrap = document.getElementById('insp_checklist_wrap');
  if (!wrap) return;
  var items = _applicableChecklistItems();
  if (!items.length) {
    wrap.innerHTML = '<div style="font-size:11px;color:#9ca3af;">이 장비에 적용된 체크리스트 항목이 없습니다. "체크리스트 관리" 또는 "이 장비 체크리스트 설정"에서 확인해 주세요.</div>';
    return;
  }
  var checkedMap = {};
  (existingResults || []).forEach(function(r) { checkedMap[r.item_id] = !!r.checked; });
  var hasExisting = !!(existingResults && existingResults.length);

  wrap.style.cssText += 'display:grid;grid-template-columns:1fr 1fr;gap:6px 18px;';
  wrap.innerHTML = '';
  items.forEach(function(item) {
    var checkedVal = hasExisting ? !!checkedMap[item.id] : true; // 신규 등록 시 기본 "예"(이상없음)

    var row = document.createElement('div');
    row.className = 'insp-check-row';
    row.dataset.itemId = item.id;
    row.dataset.itemLabel = item.label;
    row.dataset.checked = checkedVal ? '1' : '0';
    row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 0;font-size:12.5px;color:#374151;';

    var span = document.createElement('span');
    span.textContent = item.label;
    span.style.cssText = 'flex:1;';

    var toggle = document.createElement('div');
    toggle.style.cssText = 'display:flex;border:1px solid #d1d5db;border-radius:6px;overflow:hidden;flex-shrink:0;';
    var yesBtn = document.createElement('button');
    yesBtn.type = 'button'; yesBtn.textContent = '예';
    var noBtn = document.createElement('button');
    noBtn.type = 'button'; noBtn.textContent = '아니오';
    [yesBtn, noBtn].forEach(function(b) {
      b.style.cssText = 'border:none;padding:4px 12px;font-size:11.5px;font-weight:700;cursor:pointer;background:#fff;color:#9ca3af;';
    });

    function refresh() {
      var isYes = row.dataset.checked === '1';
      yesBtn.style.background = isYes ? '#16a34a' : '#fff';
      yesBtn.style.color = isYes ? '#fff' : '#9ca3af';
      noBtn.style.background = !isYes ? '#dc2626' : '#fff';
      noBtn.style.color = !isYes ? '#fff' : '#9ca3af';
    }
    yesBtn.addEventListener('click', function() { row.dataset.checked = '1'; refresh(); });
    noBtn.addEventListener('click', function() { row.dataset.checked = '0'; refresh(); });
    refresh();

    toggle.appendChild(yesBtn); toggle.appendChild(noBtn);
    row.appendChild(span); row.appendChild(toggle);
    wrap.appendChild(row);
  });
}

function _collectChecklistResults() {
  var wrap = document.getElementById('insp_checklist_wrap');
  if (!wrap) return null;
  var rows = wrap.querySelectorAll('.insp-check-row');
  if (!rows.length) return null;
  return Array.from(rows).map(function(row) {
    return { item_id: row.dataset.itemId, label: row.dataset.itemLabel, checked: row.dataset.checked === '1' };
  });
}

async function _loadInspectRows() {
  var eq = window._currentEquipment;
  if (!eq) return;
  var { data, error } = await supabaseClient.from('equipment_inspections')
    .select('*').eq('equipment_id', eq.id).order('inspection_date', { ascending: false });
  if (error) { showMessage('검사 이력 조회 실패: ' + error.message, 'error'); return; }
  var userMap = await _getQcUserMap(); // 정도관리 측정자 조회용 캐시를 그대로 재사용
  _inspectRows = (data || []).map(function(r) {
    r._inspector_name = userMap[r.inspector_id] || '-';
    return r;
  });
  _renderInspectGrid();
}

function _renderInspectGrid() {
  var colDefs = [
    { headerName: '검사일', field: 'inspection_date', width: 100, flex: 0 },
    { headerName: '검사구분', field: 'inspection_type', width: 90, flex: 0 },
    { headerName: '결과', width: 80, flex: 0,
      cellRenderer: function(p) {
        var s = document.createElement('span');
        s.style.cssText = 'font-weight:700;color:' + _inspResultColor(p.data.result) + ';';
        s.textContent = p.data.result;
        return s;
      } },
    { headerName: '담당자', field: '_inspector_name', width: 90, flex: 0 },
    { headerName: '다음 예정일', field: 'next_due_date', width: 100, flex: 0, valueFormatter: function(p) { return p.value || '-'; } },
    { headerName: '메모', field: 'memo', flex: 1, minWidth: 120, headerClass: 'ag-left-header',
      cellStyle: { justifyContent: 'flex-start' }, valueFormatter: function(p) { return p.value || '-'; } },
    { headerName: '첨부', width: 90, flex: 0, sortable: false,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center' },
      cellRenderer: function(p) {
        if (!p.data.file_path) return '<span style="color:#d1d5db;">-</span>';
        var a = document.createElement('button');
        a.className = 'btn btn-sm';
        a.textContent = '다운로드';
        a.onclick = async function() {
          var url = await db.getSignedUrl('equipment-inspection-files', p.data.file_path, 3600);
          if (url) await _forceDownload(url, p.data.file_name || '첨부파일');
        };
        return a;
      } },
    { headerName: '', width: 128, flex: 0, sortable: false,
      cellStyle: { display:'flex', alignItems:'center', justifyContent:'center', gap:'4px' },
      cellRenderer: function(p) {
        var wrap = document.createElement('div');
        wrap.style.cssText = 'display:flex;gap:4px;';
        var pr = document.createElement('button');
        pr.className = 'tbl-btn'; pr.textContent = '출력';
        pr.onclick = function() { _printInspectSheet(p.data); };
        wrap.appendChild(pr);
        if (canManageInspect()) {
          var e = document.createElement('button');
          e.className = 'tbl-btn tbl-btn--primary'; e.textContent = '수정';
          e.onclick = function() { _openInspectModal(p.data); };
          var d = document.createElement('button');
          d.className = 'tbl-btn tbl-btn--danger'; d.textContent = '삭제';
          d.onclick = function() { _deleteInspect(p.data); };
          wrap.appendChild(e); wrap.appendChild(d);
        }
        return wrap;
      } },
  ];

  if (_inspectGrid) {
    _inspectGrid.setGridOption('columnDefs', colDefs);
    _inspectGrid.setGridOption('rowData', _inspectRows);
    fitGridColumnsPinned(_inspectGrid, colDefs);
  } else if (document.getElementById('inspectGrid')) {
    _inspectGrid = agGrid.createGrid(document.getElementById('inspectGrid'), {
      columnDefs: colDefs,
      rowData: _inspectRows,
      rowHeight: 34, headerHeight: 34,
      defaultColDef: { sortable: false, resizable: true, suppressMovable: true,
        cellStyle: { display:'flex', alignItems:'center', justifyContent:'center' } },
      overlayNoRowsTemplate: '<span style="color:#9ca3af;font-size:12px;">등록된 검사 이력이 없습니다.</span>',
      onGridReady: function(p) { requestAnimationFrame(function() { fitGridColumnsPinned(p.api, p.api.getColumnDefs()); }); },
    });
  }
}

function _openInspectModal(row) {
  if (!canManageInspect()) { showMessage('장비담당자만 검사를 등록할 수 있습니다.', 'warning'); return; }
  _inspectEditId = row ? row.id : null;
  document.getElementById('inspectModalTitle').textContent = row ? '검사 수정' : '검사 등록';
  document.getElementById('insp_type').value = row ? row.inspection_type : '일일점검';
  document.getElementById('insp_date').value = row ? row.inspection_date : _localDateStr(new Date());
  document.getElementById('insp_result').value = row ? row.result : '합격';
  document.getElementById('insp_next_due').value = row ? (row.next_due_date || '') : '';
  document.getElementById('insp_next_due_wrap').style.display =
    (row ? row.inspection_type : '일일점검') === '정기점검' ? '' : 'none';
  document.getElementById('insp_memo').value = row ? (row.memo || '') : '';
  document.getElementById('insp_file').value = '';
  document.getElementById('insp_file_label').textContent = '파일을 끌어다 놓거나 클릭하여 선택';
  document.getElementById('insp_file_current').textContent = row && row.file_name ? ('현재 첨부: ' + row.file_name) : '';
  _renderInspectChecklist(row ? row.checklist_results : null);
  openModal('inspectModal');
}

function _closeInspectModal() { closeModal('inspectModal'); }

async function _saveInspect() {
  if (!canManageInspect()) { showMessage('장비담당자만 검사를 등록할 수 있습니다.', 'warning'); return; }
  var eq = window._currentEquipment;
  var date = document.getElementById('insp_date').value;
  if (!date) { showMessage('검사일을 입력해주세요.', 'warning'); return; }

  var type = document.getElementById('insp_type').value;
  var payload = {
    org_id: auth.getCurrentOrgId(),
    equipment_id: eq.id,
    inspection_type: type,
    inspection_date: date,
    result: document.getElementById('insp_result').value,
    next_due_date: type === '정기점검' ? (document.getElementById('insp_next_due').value || null) : null,
    memo: document.getElementById('insp_memo').value.trim() || null,
    checklist_results: _collectChecklistResults(),
    updated_at: new Date().toISOString(),
  };

  var file = document.getElementById('insp_file').files[0];
  if (file) {
    try {
      var up = await db.uploadFile('equipment-inspection-files', file, eq.id);
      payload.file_path = up.path;
      payload.file_name = up.name;
    } catch (e) {
      showMessage('파일 업로드 실패: ' + e.message, 'error'); return;
    }
  }

  var res;
  if (_inspectEditId) {
    res = await supabaseClient.from('equipment_inspections').update(payload).eq('id', _inspectEditId);
  } else {
    payload.inspector_id = getCurrentUser()?.id || null;
    res = await supabaseClient.from('equipment_inspections').insert(payload);
  }
  if (res.error) { showMessage('저장 실패: ' + res.error.message, 'error'); return; }

  showMessage('저장되었습니다.', 'success');
  systemLog('EQUIPMENT_INSPECT_SAVE', (type) + ' 등록 (' + eq.equipment_name + ')', { target_type: 'equipment', target_id: eq.id }).catch(() => {});
  _closeInspectModal();
  await _loadInspectRows();
}

async function _deleteInspect(row) {
  if (!canManageInspect()) { showMessage('장비담당자만 삭제할 수 있습니다.', 'warning'); return; }
  if (!confirm(row.inspection_date + ' 검사 기록을 삭제하시겠습니까?')) return;
  var { error } = await supabaseClient.from('equipment_inspections').delete().eq('id', row.id);
  if (error) { showMessage('삭제 실패: ' + error.message, 'error'); return; }
  if (row.file_path) { try { await db.deleteFile('equipment-inspection-files', row.file_path); } catch (e) {} }
  await _loadInspectRows();
}

/* 점검표 출력 — 새 창에 인쇄용 문서를 그려서 바로 인쇄 대화상자를 띄운다. */
function _printInspectSheet(row) {
  var eq = window._currentEquipment || {};
  var userMap = _qcUserMap || {};
  var inspectorName = row._inspector_name || userMap[row.inspector_id] || '-';
  var checklist = row.checklist_results || [];

  var checklistRows = checklist.length
    ? checklist.map(function(c) {
        return '<tr>' +
          '<td style="padding:8px 10px;border:1px solid #d1d5db;">' + _qcEsc(c.label) + '</td>' +
          '<td style="padding:8px 10px;border:1px solid #d1d5db;text-align:center;font-weight:700;color:' + (c.checked ? '#16a34a' : '#dc2626') + ';">' + (c.checked ? '예' : '아니오') + '</td>' +
          '</tr>';
      }).join('')
    : '<tr><td colspan="2" style="padding:10px;border:1px solid #d1d5db;color:#9ca3af;text-align:center;">등록된 체크리스트 항목 없음</td></tr>';

  var html = '<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8"><title>' + _qcEsc(row.inspection_type) + ' 점검표</title>' +
    '<style>' +
    'body{font-family:"Malgun Gothic",sans-serif;padding:32px;color:#111827;}' +
    'h1{font-size:20px;text-align:center;margin-bottom:20px;border-bottom:2px solid #111827;padding-bottom:10px;}' +
    'table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:13px;}' +
    'td,th{border:1px solid #d1d5db;padding:8px 10px;}' +
    'th{background:#f8fafc;text-align:left;width:110px;color:#374151;}' +
    '.sign-area{margin-top:40px;display:flex;justify-content:flex-end;gap:40px;font-size:13px;}' +
    '.sign-box{text-align:center;}' +
    '.sign-line{margin-top:36px;border-top:1px solid #111827;width:140px;}' +
    '@media print{ .no-print{display:none;} }' +
    '</style></head><body>' +
    '<h1>' + _qcEsc(row.inspection_type) + ' 점검표</h1>' +
    '<table>' +
      '<tr><th>장비명</th><td>' + _qcEsc(eq.equipment_name || '-') + '</td><th>장비번호</th><td>' + _qcEsc(eq.equipment_no || '-') + '</td></tr>' +
      '<tr><th>검사일</th><td>' + _qcEsc(row.inspection_date) + '</td><th>검사구분</th><td>' + _qcEsc(row.inspection_type) + '</td></tr>' +
      '<tr><th>결과</th><td style="font-weight:700;color:' + _inspResultColor(row.result) + ';">' + _qcEsc(row.result) + '</td><th>검사자</th><td>' + _qcEsc(inspectorName) + '</td></tr>' +
      (row.next_due_date ? '<tr><th>다음 예정일</th><td colspan="3">' + _qcEsc(row.next_due_date) + '</td></tr>' : '') +
    '</table>' +
    '<table><thead><tr><th style="width:auto;">점검 항목</th><th style="width:120px;text-align:center;">결과</th></tr></thead><tbody>' + checklistRows + '</tbody></table>' +
    '<table><tr><th>메모</th><td>' + _qcEsc(row.memo || '-') + '</td></tr></table>' +
    '<div class="sign-area">' +
      '<div class="sign-box">점검자<div class="sign-line"></div></div>' +
      '<div class="sign-box">확인자<div class="sign-line"></div></div>' +
    '</div>' +
    '<div class="no-print" style="margin-top:30px;text-align:center;">' +
      '<button onclick="window.print()" style="padding:8px 20px;">인쇄</button>' +
    '</div>' +
    '</body></html>';

  var w = window.open('', '_blank', 'width=800,height=900');
  if (!w) { showMessage('팝업이 차단되었습니다. 팝업 허용 후 다시 시도해 주세요.', 'warning'); return; }
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(function() { w.print(); }, 300);
}