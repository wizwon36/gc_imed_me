/**
 * equipment/equipment-form.js
 * Supabase SDK 직접 호출 버전 — 등록/수정/사진 업로드
 */

'use strict';

let currentUser = null;
let editingId   = null;
let selectedPhotoFile = null;
let removePhotoRequested = false;
let _loadedEq = null; // 수정 중인 기존 장비 데이터 — 권한 범위 판단에 사용

/* 이 장비에 대해 어디까지 할 수 있는지 — 'full'(등록/수정/폐기 전부) | 'basic'(기본정보만) | 'none'
   - admin: 항상 full
   - 장비담당자(is_equipment_manager): 본인 부서 장비만 full, 다른 부서는 none
   - 그 외: equipment/form 페이지 권한이 edit 이상이면 basic (상태/폐기 변경 불가) */
function equipmentEditScope(teamCode) {
  if (!currentUser) return 'none';
  if (currentUser.role === 'admin') return 'full';
  if (currentUser.is_equipment_manager) {
    return (currentUser.team_code && teamCode && currentUser.team_code === teamCode) ? 'full' : 'none';
  }
  if (window.PagePerms && window.PagePerms.atLeast(currentUser, 'equipment/form', 'edit')) return 'basic';
  return 'none';
}

/* ── 유틸 ─────────────────────────────────── */
function qs(sel) { return document.querySelector(sel); }
function val(id) { return (document.getElementById(id)?.value || '').trim(); }
function setVal(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
function ts(v) { return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function openModal(id) { document.getElementById(id)?.classList.add('is-open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('is-open'); }

/* ══════════════════════════════════════════════
   구매처(거래처) 검색 콤보박스 — 계약등록 화면과 동일한 vendors 마스터 연동.
   자유텍스트 대신 vendors(사업자번호 기준)에서 골라서 선택하고, 목록에 없으면
   "+" 버튼으로 그 자리에서 등록해서 바로 선택할 수 있다.
══════════════════════════════════════════════ */
let vendorsList = [];
let ctVendorEditingId = null;

function findVendorById(id) { return vendorsList.find(v => v.id === id); }
function vendorLabel(v) {
  return v.vendor_name + (v.biz_no ? ' (' + v.biz_no + ')' : '') + (v.is_current !== 'Y' ? ' / 구 상호' : '');
}

async function loadVendorsList() {
  const { data, error } = await supabaseClient.from('vendors')
    .select('id, vendor_code, vendor_name, biz_no, ceo_name, phone, email, address, credit_terms, bank_name, account_number, active, is_current, memo')
    .eq('org_id', currentUser.org_id).eq('active', 'Y').order('vendor_name');
  if (error) { showMessage && showMessage('거래처 목록 로드 실패: ' + error.message, 'error'); return; }
  vendorsList = data || [];
}

function renderVendorComboList(query) {
  const list = document.getElementById('vendorComboList');
  const q = (query || '').trim().toLowerCase();
  const filtered = !q ? vendorsList : vendorsList.filter(v =>
    v.vendor_name.toLowerCase().includes(q) || (v.biz_no || '').replace(/-/g, '').includes(q.replace(/-/g, ''))
  );
  if (!filtered.length) {
    list.innerHTML = '<div class="ct-combo-empty">검색 결과가 없습니다. "+" 버튼으로 등록해 주세요.</div>';
  } else {
    const sorted = filtered.slice().sort((a, b) => (b.is_current === 'Y') - (a.is_current === 'Y'));
    list.innerHTML = sorted.slice(0, 50).map(v => `<div class="ct-combo-item" data-id="${v.id}">${ts(vendorLabel(v))}</div>`).join('');
    list.querySelectorAll('.ct-combo-item').forEach(item => {
      item.addEventListener('mousedown', e => {
        e.preventDefault();
        setVendor(item.dataset.id);
        list.style.display = 'none';
      });
    });
  }
  list.style.display = 'block';
}

function bindVendorCombo() {
  const input = document.getElementById('val-vendor-search');
  input.addEventListener('focus', () => renderVendorComboList(input.value));
  input.addEventListener('input', () => {
    setVal('val-vendor', '');
    document.getElementById('ctVendorEditBtn').style.display = 'none';
    document.getElementById('ctVendorBizNoHint').textContent = '';
    renderVendorComboList(input.value);
  });
  input.addEventListener('blur', () => {
    setTimeout(() => { document.getElementById('vendorComboList').style.display = 'none'; }, 150);
  });
  document.getElementById('ctVendorNewBtn').addEventListener('click', () => openCtVendorModal('new'));
  document.getElementById('ctVendorEditBtn').addEventListener('click', () => openCtVendorModal('edit'));
  document.getElementById('ctVendorSaveBtn').addEventListener('click', saveCtVendorQuick);
  bindBizNoAutoDash('cv_biz_no');
}

function setVendor(vendorId) {
  const v = findVendorById(vendorId);
  setVal('val-vendor', v ? v.id : '');
  document.getElementById('val-vendor-search').value = v ? vendorLabel(v) : '';
  document.getElementById('ctVendorEditBtn').style.display = v ? '' : 'none';
  document.getElementById('ctVendorBizNoHint').textContent = v && !v.biz_no ? '⚠ 사업자번호가 등록되지 않은 거래처입니다.' : '';
  if (v) document.getElementById('ctVendorLegacyNotice').style.display = 'none';
}

// 기존 장비 불러오기(수정) 시 구매처 선택 상태를 복원한다. vendor_id가 없으면(마스터 연동
// 이전에 등록된 장비) 텍스트만 있던 예전 자료이므로 안내문구만 띄운다.
async function applyVendorFromRecord(eq) {
  document.getElementById('ctVendorLegacyNotice').style.display = 'none';
  if (eq.vendor_id) {
    let v = findVendorById(eq.vendor_id);
    if (!v) {
      const { data } = await supabaseClient.from('vendors').select('id, vendor_code, vendor_name, biz_no, ceo_name, phone, email, address, credit_terms, bank_name, account_number, active, is_current, memo').eq('id', eq.vendor_id).maybeSingle();
      if (data) { vendorsList = vendorsList.concat([data]); v = data; }
    }
    if (v) { setVendor(v.id); return; }
  }
  setVendor('');
  if (eq.vendor) {
    document.getElementById('val-vendor-search').value = '';
    const notice = document.getElementById('ctVendorLegacyNotice');
    notice.textContent = `⚠ 예전 방식(텍스트)으로 저장된 구매처입니다: "${eq.vendor}". 사업자번호 기준으로 다시 연결하려면 위 검색창에서 같은 거래처를 선택하거나, 없으면 "+"로 등록해주세요.`;
    notice.style.display = '';
  }
}

function openCtVendorModal(mode) {
  if (mode === 'edit') {
    const v = findVendorById(val('val-vendor'));
    if (!v) return;
    ctVendorEditingId = v.id;
    document.getElementById('ctVendorModalTitle').innerHTML = '<i class="ti ti-building-store"></i> 거래처 수정';
    setVal('cv_vendor_name', v.vendor_name);
    setVal('cv_biz_no', v.biz_no);
    setVal('cv_ceo_name', v.ceo_name);
    setVal('cv_phone', v.phone);
  } else {
    ctVendorEditingId = null;
    document.getElementById('ctVendorModalTitle').innerHTML = '<i class="ti ti-building-store"></i> 거래처 등록';
    const draft = document.getElementById('val-vendor-search').value.trim();
    setVal('cv_vendor_name', draft);
    setVal('cv_biz_no', ''); setVal('cv_ceo_name', ''); setVal('cv_phone', '');
  }
  openModal('ctVendorModal');
}
window.openCtVendorModal = openCtVendorModal;

function bindBizNoAutoDash(inputId) {
  const el = document.getElementById(inputId);
  if (!el) return;
  el.addEventListener('input', () => {
    const digits = el.value.replace(/[^0-9]/g, '').slice(0, 10);
    let formatted = digits;
    if (digits.length > 5) formatted = digits.slice(0, 3) + '-' + digits.slice(3, 5) + '-' + digits.slice(5);
    else if (digits.length > 3) formatted = digits.slice(0, 3) + '-' + digits.slice(3);
    el.value = formatted;
  });
}

async function saveCtVendorQuick() {
  const vendorName = val('cv_vendor_name');
  if (!vendorName) { showMessage('거래처명을 입력해주세요.', 'warning'); return; }
  const bizNo = val('cv_biz_no');
  if (!bizNo) { showMessage('사업자번호를 입력해주세요.', 'warning'); return; }

  const btn = document.getElementById('ctVendorSaveBtn');
  btn.disabled = true;
  try {
    let dupQuery = supabaseClient.from('vendors').select('id, vendor_name, is_current, active').eq('org_id', currentUser.org_id).eq('biz_no', bizNo);
    if (ctVendorEditingId) dupQuery = dupQuery.neq('id', ctVendorEditingId);
    const { data: dupRows } = await dupQuery;
    if (dupRows && dupRows.length) {
      const dup = dupRows.find(v => v.is_current === 'Y') || dupRows[0];
      const proceed = confirm(
        `이미 등록된 사업자번호입니다: "${dup.vendor_name}"(${bizNo}).\n\n` +
        `상호가 바뀐 것이 맞다면 계속 진행해 새 이름을 대표 상호로 등록할 수 있습니다(기존 "${dup.vendor_name}"은(는) 구 상호로 자동 전환됩니다).\n` +
        `사업자번호를 잘못 입력했거나 이미 있는 거래처를 찾는 것이라면 취소하고 검색창에서 다시 선택해주세요.\n\n` +
        `계속 등록하시겠습니까?`
      );
      if (!proceed) { btn.disabled = false; return; }
    }

    const payload = {
      vendor_name: vendorName, biz_no: bizNo,
      ceo_name: val('cv_ceo_name'), phone: val('cv_phone'),
      updated_at: new Date().toISOString(),
    };

    let vendorId = ctVendorEditingId;
    if (ctVendorEditingId) {
      const { error } = await supabaseClient.from('vendors').update(payload).eq('id', ctVendorEditingId);
      if (error) throw new Error(error.message);
      systemLog('VENDOR_UPDATE', '거래처 수정(장비등록 화면) — ' + vendorName, { target_type: 'vendors', target_id: ctVendorEditingId }).catch(() => {});
    } else {
      const { data: codeData } = await supabaseClient.rpc('generate_vendor_code', { p_org_id: currentUser.org_id });
      const insertPayload = Object.assign({
        org_id: currentUser.org_id,
        vendor_code: codeData || 'VEND-' + Date.now().toString().slice(-6),
        active: 'Y', is_current: 'Y',
      }, payload);
      const { data: inserted, error } = await supabaseClient.from('vendors').insert(insertPayload).select('id').single();
      if (error) throw new Error(error.message);
      vendorId = inserted.id;
      systemLog('VENDOR_CREATE', '거래처 등록(장비등록 화면) — ' + vendorName, { target_type: 'vendors', target_id: vendorId }).catch(() => {});
    }

    if (payload.biz_no) {
      await supabaseClient.from('vendors').update({ is_current: 'N' }).eq('org_id', currentUser.org_id).eq('biz_no', payload.biz_no).neq('id', vendorId);
    }

    await loadVendorsList();
    setVendor(vendorId);
    closeModal('ctVendorModal');
  } catch (e) {
    showMessage(e.message || '거래처 저장 실패', 'error');
  } finally {
    btn.disabled = false;
  }
}
window.saveCtVendorQuick = saveCtVendorQuick;

/* ── 사진 UI ───────────────────────────────── */
function initPhotoUi() {
  const input     = qs('#photoInput');
  const removeBtn = qs('#removePhotoBtn');

  input?.addEventListener('change', e => {
    const file = e.target.files?.[0];
    if (!file) return;
    selectedPhotoFile = file;
    removePhotoRequested = false;
    const reader = new FileReader();
    reader.onload = ev => renderPhotoPreview(ev.target.result);
    reader.readAsDataURL(file);
  });

  removeBtn?.addEventListener('click', () => {
    selectedPhotoFile = null;
    removePhotoRequested = true;
    renderPhotoPreview('');
  });
}

function renderPhotoPreview(src) {
  const preview   = qs('#photoPreviewImage');
  const empty     = qs('#photoPreviewEmpty');
  const removeBtn = qs('#removePhotoBtn');
  const dropzone  = qs('#photoDropzone');
  const fileInfo  = qs('#photoFileInfo');

  if (preview) {
    preview.src = src || '';
    preview.classList.toggle('is-hidden', !src);
    preview.style.display = src ? '' : 'none';
  }
  if (empty)     empty.style.display     = src ? 'none' : '';
  if (removeBtn) removeBtn.style.display = src ? ''     : 'none';
  // 파일이 선택됐을 때(src=dataURL)는 드롭존 숨김, 기존 저장 URL이면 드롭존 유지
  if (dropzone && src && src.startsWith('data:')) dropzone.style.display = 'none';
  if (dropzone && !src) dropzone.style.display = '';
  // 파일명 info는 드롭존과 같이 표시
  if (fileInfo && !src) fileInfo.style.display = 'none';
}

/* ── 폼 로드 (수정 모드) ───────────────────── */
async function loadEquipment(id) {
  const { data, error } = await supabaseClient
    .from('equipments')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw new Error(error.message);
  return data;
}

function fillForm(eq) {
  setVal('equipment_name',       eq.equipment_name);
  setVal('model_name',           eq.model_name);
  setVal('manufacturer',        eq.manufacturer);
  setVal('manufacture_date',     eq.manufacture_date);
  setVal('purchase_date',        eq.purchase_date);
  setVal('serial_no',            eq.serial_no);
  setVal('acquisition_cost',     eq.acquisition_cost ?? '');
  setVal('maintenance_end_date',  eq.maintenance_end_date);
  document.getElementById('hira_registered').value = eq.hira_registered ? 'true' : 'false';
  setVal('hira_barcode_no',      eq.hira_barcode_no);
  // clinic_name, team_name은 select option에서 읽으므로 별도 세팅 불필요
  setVal('department_preview',   eq.department);
  setVal('location',            eq.location);
  document.getElementById('qc_enabled').value = eq.qc_enabled ? 'true' : 'false';
  setVal('current_user',     eq.current_user_name);
  setVal('status',              eq.status);
  setVal('memo',                eq.memo);
  setVal('manager_name',         eq.manager_name);
  setVal('manager_phone',        eq.manager_phone);

  // select 값 세팅 (의원/부서)
  const clinicSel = document.getElementById('clinic_code');
  const teamSel   = document.getElementById('team_code');

  if (clinicSel && eq.clinic_code) {
    const clinicOpt = Array.from(clinicSel.options).find(o => o.value === eq.clinic_code);
    if (clinicOpt) {
      clinicSel.value = eq.clinic_code;
      clinicSel.dispatchEvent(new Event('change'));  // fillDeptSelect 실행 (동기)
    }
  }

  if (teamSel && eq.team_code) {
    const trySetTeam = () => {
      const teamOpt = Array.from(teamSel.options).find(o => o.value === eq.team_code);
      if (teamOpt) {
        teamSel.value = eq.team_code;
        teamSel.dispatchEvent(new Event('change'));  // team_name hidden 세팅
        return true;
      }
      return false;
    };
    if (!trySetTeam()) {
      // fillDeptSelect가 아직 안 됐으면 재시도
      setTimeout(trySetTeam, 150);
    }
  }

  if (eq.photo_url) renderPhotoPreview(eq.photo_url);
}

/* ── 저장 ──────────────────────────────────── */
async function saveEquipment() {
  const selectedTeamCode = (function() { const s = document.getElementById('team_code'); return s ? s.value : ''; })();
  const targetTeamCode = editingId ? (_loadedEq?.team_code || selectedTeamCode) : selectedTeamCode;
  const scope = equipmentEditScope(targetTeamCode);

  if (!editingId) {
    // 신규 등록은 "전체 권한"(admin 또는 해당 부서 장비담당자)만 — 기본정보 수정 권한만으론 등록 불가.
    if (scope !== 'full') {
      alert('장비 등록은 장비담당자 또는 관리자만 할 수 있습니다.');
      return;
    }
  } else if (scope === 'none') {
    alert('이 장비를 수정할 권한이 없습니다. (다른 부서 담당 장비이거나, 저장 권한이 없습니다)');
    return;
  }
  if (scope !== 'full') {
    // 기본정보 수정 권한만 있는 경우 상태(폐기 등) 값은 원래 값 그대로 강제 — DB 트리거에서도 동일하게 막힘(이중 방어).
    const statusSel = document.getElementById('status');
    if (statusSel && _loadedEq) statusSel.value = _loadedEq.status;
  }
  const { data: { session } } = await supabaseClient.auth.getSession();

  const payload = {
    org_id:               currentUser.org_id,
    equipment_name:       val('equipment_name'),
    model_name:           val('model_name'),
    manufacturer:         val('manufacturer'),
    manufacture_date:     val('manufacture_date') || null,
    purchase_date:        val('purchase_date') || null,
    serial_no:            val('serial_no'),
    vendor_id:            (function() { const v = findVendorById(val('val-vendor')); return v ? v.id : null; })(),
    vendor:               (function() { const v = findVendorById(val('val-vendor')); return v ? v.vendor_name : val('val-vendor-search'); })(),
    vendor_biz_no:        (function() { const v = findVendorById(val('val-vendor')); return v ? (v.biz_no || null) : null; })(),
    acquisition_cost:     val('acquisition_cost') ? Number(val('acquisition_cost')) : null,
    maintenance_end_date: val('maintenance_end_date') || null,
    hira_registered:      document.getElementById('hira_registered')?.value === 'true',
    hira_barcode_no:      val('hira_barcode_no') || null,
    clinic_code:          (function() { const s = document.getElementById('clinic_code'); return s ? s.value : ''; })(),
    clinic_name:          (function() { const s = document.getElementById('clinic_code'); return s && s.selectedIndex > 0 ? s.options[s.selectedIndex].textContent.trim() : ''; })(),
    team_code:            (function() { const s = document.getElementById('team_code'); return s ? s.value : ''; })(),
    team_name:            (function() { const s = document.getElementById('team_code'); return s && s.selectedIndex > 0 ? s.options[s.selectedIndex].textContent.trim() : ''; })(),
    department:           val('department_preview'),
    location:             val('location'),
    qc_enabled:           document.getElementById('qc_enabled')?.value === 'true',
    current_user_name:    val('current_user'),
    status:               val('status') || CONFIG.EQUIPMENT_STATUS.IN_USE,
    memo:                 val('memo'),
    manager_name:         val('manager_name'),
    manager_phone:        val('manager_phone'),
  };

  if (!payload.equipment_name) throw new Error('장비명은 필수입니다.');

  let equipmentId = editingId;

  if (editingId) {
    // 수정
    const { error } = await supabaseClient
      .from('equipments')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', editingId);
    if (error) throw new Error(error.message);
  } else {
    // 등록 — equipment_no 자동 생성
    payload.created_by = session?.user?.id || null;
    payload.deleted_yn = 'N';

    const { data: seqData } = await supabaseClient.rpc('generate_equipment_id', { p_org_id: currentUser.org_id });
    if (seqData) payload.equipment_no = seqData;

    const { data, error } = await supabaseClient
      .from('equipments')
      .insert(payload)
      .select()
      .single();
    if (error) throw new Error(error.message);
    equipmentId = data.id;
  }

  // 사진 처리
  if (removePhotoRequested && editingId) {
    const { data: eq } = await supabaseClient
      .from('equipments').select('photo_path').eq('id', editingId).single();
    if (eq?.photo_path) await db.deletePhoto(eq.photo_path);
    await supabaseClient.from('equipments')
      .update({ photo_url: '', photo_path: '' }).eq('id', editingId);
  }

  if (selectedPhotoFile && equipmentId) {
    const { path, url } = await db.uploadPhoto(selectedPhotoFile, equipmentId);
    await supabaseClient.from('equipments')
      .update({ photo_url: url, photo_path: path }).eq('id', equipmentId);
  }

  return equipmentId;
}

/* ── 초기화 ────────────────────────────────── */
async function init() {
  ['manufacture_date', 'purchase_date', 'maintenance_end_date'].forEach(mountCustomDateInput);
  var session = await auth.requireAuth();
  if (!session) return;
  currentUser = await auth.getSession(); // role/page_perms가 담긴 실제 프로필
  await loadVendorsList();
  bindVendorCombo();

  // 페이지 진입은 접근불가만 아니면 누구나 가능하다. 다만 이 페이지는 등록/수정 폼
  // 그 자체라 "읽기 전용"이 딱히 의미가 없으므로, edit 미달이면 들어오게는 해주고
  // 모든 입력을 비활성화 + 저장 버튼을 숨겨서 조회만 되게 한다 (URL 직접 진입 방어).
  if (!window.PagePerms || !window.PagePerms.canAccess(currentUser, 'equipment/form')) {
    alert('접근할 수 없습니다.');
    parent.shellNavigate?.('equipment/list');
    return;
  }
  var canEditEquipment = window.PagePerms.atLeast(currentUser, 'equipment/form', 'edit');
  if (!canEditEquipment) {
    document.querySelectorAll('#equipmentForm input, #equipmentForm select, #equipmentForm textarea')
      .forEach(function(el) { el.disabled = true; });
    document.getElementById('ctVendorNewBtn').style.display = 'none';
    document.getElementById('ctVendorEditBtn').style.display = 'none';
    var saveBtn = document.getElementById('saveBtn') || document.querySelector('#equipmentForm button[type="submit"]');
    if (saveBtn) saveBtn.style.display = 'none';
  }

  initPhotoUi();

  // 상태 옵션
  const statusSel = document.getElementById('status');
  if (statusSel) {
    const STATUS_LABEL = CONFIG.EQUIPMENT_STATUS_LABEL || {};
    statusSel.innerHTML = Object.entries(STATUS_LABEL)
      .map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
  }

  // 의원 select — clinics 테이블에서 로드
  const clinicSel = document.getElementById('clinic_code');
  const teamSel   = document.getElementById('team_code');

  const { data: clinicRows } = await supabaseClient
    .from('clinics').select('clinic_code, clinic_name').eq('id', currentUser.org_id).eq('is_active', true).order('sort_order');
  const { data: deptRows } = await supabaseClient
    .from('departments').select('dept_code, dept_name, clinic_id, clinics!departments_clinic_id_fkey(clinic_code)').eq('org_id', currentUser.org_id).eq('active', 'Y').order('sort_order');

  if (clinicSel) {
    // 조직=의원이 항상 1:1이라 "의원 선택" 자체가 의미가 없다 — 이 의원 하나로 자동
    // 세팅하고 select는 잠가둔다(레이아웃은 그대로, 조작만 막는 방식).
    var myClinic = (clinicRows || [])[0] || null;
    clinicSel.innerHTML = myClinic
      ? `<option value="${myClinic.clinic_code}">${myClinic.clinic_name}</option>`
      : '<option value="">의원 정보 없음</option>';
    clinicSel.value = myClinic ? myClinic.clinic_code : '';
    clinicSel.disabled = true;
  }

  function fillDeptSelect(el, rows, clinicCode) {
    if (!el) return;
    const filtered = clinicCode
      ? (rows || []).filter(d => d.clinics && d.clinics.clinic_code === clinicCode)
      : (rows || []);
    el.innerHTML = '<option value="">부서 선택</option>' +
      filtered.map(d => `<option value="${d.dept_code}">${d.dept_name}</option>`).join('');
  }
  fillDeptSelect(teamSel, deptRows, clinicSel?.value || '');

  // 부서 변경 시 team_name은 저장 시 select option에서 직접 읽음 (별도 hidden 불필요)

  // 수정 모드 확인
  const params = new URLSearchParams(location.search);
  editingId = params.get('id') || null;
  const fromList = params.get('from') === 'list';

  if (editingId) {
    document.querySelector('h2, .page-title')?.textContent !== undefined &&
      (document.querySelector('h2, .page-title').textContent = '장비 수정');
    const btnText = document.getElementById('submitButtonText');
    if (btnText) btnText.textContent = '장비 수정';
    const cancelBtn = qs('#cancelBtn');
    if (cancelBtn) cancelBtn.innerHTML = fromList
      ? '<i class="ti ti-arrow-left"></i> 목록으로'
      : '<i class="ti ti-arrow-left"></i> 상세로';
    showGlobalLoading('장비 정보를 불러오는 중...');
    try {
      const eq = await loadEquipment(editingId);
      _loadedEq = eq;
      fillForm(eq);
      await applyVendorFromRecord(eq);
      var scope = equipmentEditScope(eq.team_code);
      if (scope !== 'full') {
        var statusFieldEl = document.getElementById('status');
        if (statusFieldEl) {
          statusFieldEl.disabled = true;
          statusFieldEl.title = '상태(폐기 등) 변경은 장비담당자만 가능합니다.';
        }
      }
      if (scope === 'none') {
        alert('이 장비를 조회할 권한만 있고, 수정 권한은 없습니다.');
        qs('#saveBtn')?.setAttribute('disabled', 'disabled');
      }
    } catch (e) {
      alert('장비 정보를 불러오지 못했습니다: ' + e.message);
      return;
    } finally {
      hideGlobalLoading();
    }
  }

  // 저장 버튼
  qs('#saveBtn')?.addEventListener('click', async () => {
    const btn = qs('#saveBtn');
    btn.disabled = true;
    btn.textContent = '저장 중...';
    try {
      const id = await saveEquipment();
      systemLog(editingId ? 'EQUIPMENT_UPDATE' : 'EQUIPMENT_CREATE', editingId ? '장비 정보 수정' : '장비 등록', { target_type: 'equipment', target_id: id }).catch(() => {});
      alert(editingId ? '장비 정보가 수정됐습니다.' : '장비가 등록됐습니다.');
      if (fromList) parent.shellNavigate?.('equipment/list');
      else parent.shellNavigate?.(`equipment/detail?id=${id}`);
    } catch (e) {
      alert('저장 실패: ' + e.message);
      btn.disabled = false;
      btn.textContent = '저장';
    }
  });

  // 취소 버튼
  qs('#cancelBtn')?.addEventListener('click', () => {
    if (editingId && !fromList) parent.shellNavigate?.(`equipment/detail?id=${editingId}`);
    else parent.shellNavigate?.('equipment/list');
  });
}

function initEquipmentForm() { init(); }
document.addEventListener('DOMContentLoaded', init);