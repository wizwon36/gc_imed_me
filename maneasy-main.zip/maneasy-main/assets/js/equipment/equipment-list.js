var _gridInstance = null; // AG Grid 인스턴스

var equipmentListState = {
  user: null,
  totalCount: 0,
  loading: false,
  canEdit: false,
  isAdmin: false,
  isAppAdmin: false,
  userClinicCode: '',
  userTeamCode: '',
  userScope: null,     // ★ equipment 앱 scope: 'all' | 'clinic' | 'team' | null (로드 전)
  _initialLoad: true   // ★ 최초 로딩 여부 — URL params 직접 사용
};

function el(selector) {
  return document.querySelector(selector);
}

function getListQueryParams() {
  var params = new URLSearchParams(location.search);

  return {
    keyword: params.get('keyword') || '',
    clinic_code: params.get('clinic_code') || '',
    team_code: params.get('team_code') || '',
    team_suffix: params.get('team_suffix') || '',
    status: params.get('status') || '',
    manufacturer: params.get('manufacturer') || ''
  };
}

function setListQueryParams(next) {
  var url = new URL(location.href);
  var key;

  for (key in next) {
    if (!Object.prototype.hasOwnProperty.call(next, key)) continue;

    if (next[key] === '' || next[key] === null || next[key] === undefined) {
      url.searchParams.delete(key);
    } else {
      url.searchParams.set(key, String(next[key]));
    }
  }

  history.replaceState({}, '', url.toString());
}

function setValue(id, value) {
  var target = document.getElementById(id);
  if (!target) return;
  target.value = value == null ? '' : value;
}

function getValue(id) {
  var target = document.getElementById(id);
  return target ? String(target.value || '').trim() : '';
}

function formatNumberLocal(value) {
  var num = Number(value || 0);
  return Number.isFinite(num) ? num.toLocaleString('ko-KR') : '0';
}

function formatDisplayDate(value) {
  var raw = String(value || '').trim();
  var dateOnlyMatch;
  var parsed;
  var yyyy;
  var mm;
  var dd;

  if (!raw) return '-';

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    return raw;
  }

  // "YYYY-MM-DDT..." 앞 10자리를 그대로 잘라 쓰면 timestamptz의 UTC 날짜가 그대로 나와서,
  // 자정~오전 9시(KST) 사이 값은 하루 전 날짜로 잘못 표시된다. 반드시 Date로 파싱해서
  // 로컬(KST) 기준으로 다시 계산해야 한다.
  parsed = new Date(raw);
  if (!isNaN(parsed.getTime())) {
    yyyy = parsed.getFullYear();
    mm = String(parsed.getMonth() + 1).padStart(2, '0');
    dd = String(parsed.getDate()).padStart(2, '0');
    return yyyy + '-' + mm + '-' + dd;
  }

  return raw;
}

function getCurrentFilters() {
  return {
    keyword: getValue('keyword'),
    clinic_code: getValue('clinic_code'),
    team_code: getValue('team_code'),
    team_suffix: getValue('team_suffix') || '',
    status: getValue('status'),
    qc_filter: getValue('qc_filter'),
    hira_filter: getValue('hira_filter'),
    manufacturer: getValue('manufacturer')
  };
}

var EQUIPMENT_LIST_CACHE_KEY = 'gc_imed_equipment_list_state';

function saveListState() {
  try {
    sessionStorage.setItem(EQUIPMENT_LIST_CACHE_KEY, JSON.stringify({
      filters: getCurrentFilters(),
      ts:      Date.now()
    }));
  } catch(e) {}
}

function loadListState() {
  try {
    var raw = sessionStorage.getItem(EQUIPMENT_LIST_CACHE_KEY);
    if (!raw) return null;
    var state = JSON.parse(raw);
    if (Date.now() - state.ts > 30 * 60 * 1000) {
      sessionStorage.removeItem(EQUIPMENT_LIST_CACHE_KEY);
      return null;
    }
    return state;
  } catch(e) { return null; }
}

function clearListState() {
  try { sessionStorage.removeItem(EQUIPMENT_LIST_CACHE_KEY); } catch(e) {}
}

function fillStatusFilterOptions() {
  var target = document.getElementById('status');
  if (!target) return;

  target.innerHTML =
    '<option value="">전체 상태</option>' +
    '<option value="IN_USE">사용중</option>' +
    '<option value="REPAIRING">수리중</option>' +
    '<option value="INSPECTING">점검중</option>' +
    '<option value="STORED">보관</option>' +
    '<option value="DISPOSED">폐기</option>';
}

function renderListSummary() {
  var summaryEl = document.getElementById('listSummary');
  var total;

  if (!summaryEl) return;

  total = formatNumberLocal(equipmentListState.totalCount || 0);
  summaryEl.textContent = '검색 결과 ' + total + '건';
}

/* ── 카드 (모바일용) ── */
function buildEquipmentCard(item) {
  var leftActions = '';
  var rightActions = '';

  leftActions += '<a class="btn" href="detail.html?id=' + encodeURIComponent(item.equipment_id || '') + '">상세</a>';

    leftActions += '<button class="btn btn-primary" onclick="openEditForm(\'' + escapeHtml(item.equipment_id || '') + '\')">수정</button>';

  rightActions = window.innerWidth > 768
    ? '<button class="btn" onclick="openListLabelModal(\'' + escapeHtml(item.equipment_id || '') + '\')">라벨출력</button>'
    : '';

  return (
    '<article class="equipment-card">' +
      '<div class="equipment-card-head">' +
        '<div class="equipment-card-title-wrap">' +
          '<h3 class="equipment-card-title">' + escapeHtml(item.equipment_name || '-') + '</h3>' +
          '<div class="equipment-card-sub">' + escapeHtml(item.equipment_id || '') + '</div>' +
        '</div>' +
        '<span class="status-badge ' + statusClass(item.status || '') + '">' +
          escapeHtml(statusLabel(item.status || '')) +
        '</span>' +
      '</div>' +
      '<div class="equipment-card-grid">' +
        '<div class="equipment-card-row">' +
          '<span class="equipment-card-label">모델명</span>' +
          '<span class="equipment-card-value">' + escapeHtml(item.model_name || '-') + '</span>' +
        '</div>' +
        '<div class="equipment-card-row">' +
          '<span class="equipment-card-label">부서</span>' +
          '<span class="equipment-card-value">' + escapeHtml((item.clinic_name || '') + (item.clinic_name && item.team_name ? ' / ' : '') + (item.team_name || '') || '-') + '</span>' +
        '</div>' +
        '<div class="equipment-card-row">' +
          '<span class="equipment-card-label">제조사</span>' +
          '<span class="equipment-card-value">' + escapeHtml(item.manufacturer || '-') + '</span>' +
        '</div>' +
        '<div class="equipment-card-row">' +
          '<span class="equipment-card-label">시리얼</span>' +
          '<span class="equipment-card-value">' + escapeHtml(item.serial_no || '-') + '</span>' +
        '</div>' +
        '<div class="equipment-card-row">' +
          '<span class="equipment-card-label">위치</span>' +
          '<span class="equipment-card-value">' + escapeHtml(item.location || '-') + '</span>' +
        '</div>' +
        '<div class="equipment-card-row">' +
          '<span class="equipment-card-label">유지보수 종료</span>' +
          '<span class="equipment-card-value">' + escapeHtml(formatDisplayDate(item.maintenance_end_date || '')) + '</span>' +
        '</div>' +
      '</div>' +
      '<div class="equipment-card-actions">' +
        leftActions +
        rightActions +
      '</div>' +
    '</article>'
  );
}

/* ── 테이블 행 (PC용) ── */
function buildEquipmentRow(item) {
  var actions = '';

  actions += '<a class="tbl-btn" href="detail.html?id=' + encodeURIComponent(item.equipment_id || '') + '">상세</a>';

    actions += '<button class="tbl-btn tbl-btn--primary" onclick="openEditForm(\'' + escapeHtml(item.equipment_id || '') + '\')">수정</button>';

  if (window.innerWidth > 768) {
    actions += '<button class="tbl-btn" onclick="openListLabelModal(\'' + escapeHtml(item.equipment_id || '') + '\')">라벨</button>';
  }

  return (
    '<tr class="equipment-tbl-row">' +
      '<td class="equipment-tbl-cell equipment-tbl-cell--name">' + escapeHtml(item.equipment_name || '-') + '</td>' +
      '<td class="equipment-tbl-cell equipment-tbl-cell--id">' + escapeHtml(item.equipment_id || '-') + '</td>' +
      '<td class="equipment-tbl-cell">' + escapeHtml(item.model_name || '-') + '</td>' +
      '<td class="equipment-tbl-cell">' + escapeHtml(item.clinic_name || '-') + '</td>' +
      '<td class="equipment-tbl-cell">' + escapeHtml(item.team_name   || '-') + '</td>' +
      '<td class="equipment-tbl-cell">' + escapeHtml(item.manufacturer || '-') + '</td>' +
      '<td class="equipment-tbl-cell equipment-tbl-cell--serial">' + escapeHtml(item.serial_no || '-') + '</td>' +
      '<td class="equipment-tbl-cell">' + escapeHtml(item.location || '-') + '</td>' +
      '<td class="equipment-tbl-cell equipment-tbl-cell--status">' +
        '<span class="status-badge ' + statusClass(item.status || '') + '">' +
          escapeHtml(statusLabel(item.status || '')) +
        '</span>' +
      '</td>' +
      '<td class="equipment-tbl-cell equipment-tbl-cell--actions">' +
        '<div class="equipment-tbl-actions">' + actions + '</div>' +
      '</td>' +
    '</tr>'
  );
}



function getStatusBadge(status) {
  var map = {
    'IN_USE':     { cls: 'is-in-use',     label: '사용중' },
    'REPAIRING':  { cls: 'is-repairing',  label: '수리중' },
    'INSPECTING': { cls: 'is-inspecting', label: '점검중' },
    'STORED':     { cls: 'is-stored',     label: '보관' },
    'DISPOSED':   { cls: 'is-disposed',   label: '폐기' },
  };
  var s = map[status] || { cls: 'is-stored', label: status || '—' };
  return '<span class="status-badge ' + s.cls + '">' + s.label + '</span>';
}

function getHiraBadge(registered) {
  return registered
    ? '<span class="status-badge is-in-use">등록</span>'
    : '<span class="status-badge is-disposed">미등록</span>';
}

function getActionButtons(item) {
  var displayId = escapeHtml(item.equipment_id || '');  // ME-2026-0001
  var uuid      = escapeHtml(item._uuid || item.id || '');  // UUID (상세/수정 이동용)
  var btns = '<button class="tbl-btn" onclick="saveListState();parent.shellNavigate(\'equipment/detail?id=' + uuid + '\')">상세</button>';
  if (equipmentListState.canEdit) {
    btns += '<button class="tbl-btn tbl-btn--primary" onclick="saveListState();openEditForm(\'' + uuid + '\')">수정</button>';
  }
  btns += '<button class="tbl-btn" onclick="openListLabelModal(\'' + displayId + '\')">라벨</button>';
  return btns;
}

function renderEquipmentList(items) {
  var el = document.getElementById('equipmentGrid');
  if (!el) return;
  items = Array.isArray(items) ? items : [];

  // 컬럼 정의
  var columnDefs = [
    { headerName: '장비명', field: 'equipment_name', flex: 1, minWidth: 120,
      headerClass: 'ag-left-header',
      cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'flex-start' },
      cellRenderer: function(p) {
        return '<span class="tab-name">' + escapeHtml(p.value || '—') + '</span>';
      }
    },
    { headerName: '모델명', field: 'model_name', width: 130 },
    { headerName: '의원', field: 'clinic_name', width: 100,
      cellRenderer: function(p) { return escapeHtml(p.value || '—'); }
    },
    { headerName: '부서', field: 'team_name', width: 90,
      cellRenderer: function(p) { return escapeHtml(p.value || '—'); }
    },
    { headerName: '제조사', field: 'manufacturer', width: 120,
      cellRenderer: function(p) {
        var v = p.value || '';
        return v ? '<span class="tab-mfr">' + escapeHtml(v) + '</span>' : '<span style="color:#9ca3af">—</span>';
      }
    },
    { headerName: '시리얼', field: 'serial_no', width: 140,
      cellRenderer: function(p) {
        return '<span class="tab-id">' + escapeHtml(p.value || '—') + '</span>';
      }
    },
    { headerName: '납품처', field: 'vendor', width: 110,
      cellRenderer: function(p) {
        return p.value ? escapeHtml(p.value) : '<span style="color:#9ca3af">—</span>';
      }
    },
    { headerName: '구매일', field: 'purchase_date', width: 100,
      cellRenderer: function(p) {
        return p.value ? escapeHtml(p.value) : '<span style="color:#9ca3af">—</span>';
      }
    },
    { headerName: '유지보수만료', field: 'maintenance_end_date', width: 110,
      cellRenderer: function(p) {
        var v = p.value || '';
        if (!v) return '<span style="color:#9ca3af">—</span>';
        var days = Math.ceil((new Date(v) - new Date()) / 86400000);
        var color = days <= 30 ? '#b91c1c' : days <= 60 ? '#c2410c' : '#374151';
        return '<span style="color:' + color + '">' + escapeHtml(v) + '</span>';
      }
    },
    { headerName: '위치', field: 'location', width: 130 },
    { headerName: '심평원 등록', field: 'hira_registered', width: 100,
      cellRenderer: function(p) { return getHiraBadge(p.value); }
    },
    { headerName: '상태', field: 'status', width: 80,
      cellRenderer: function(p) { return getStatusBadge(p.value); }
    },
    { headerName: '액션', field: 'equipment_id', width: 140, sortable: false,
      cellRenderer: function(p) {
        return '<div style="display:flex;gap:4px;align-items:center;">' + getActionButtons(p.data) + '</div>';
      }
    }
  ];

  // 기본 컬럼 설정
  var defaultColDef = {
    sortable: true,
    resizable: true,
    suppressMovable: true,
    headerClass: 'ag-center-header',
    cellStyle: { display: 'flex', alignItems: 'center', justifyContent: 'center' },
  };

  if (_gridInstance) {
    _gridInstance.setGridOption('rowData', items);
    return;
  }

  var gridOptions = {
    columnDefs: columnDefs,
    defaultColDef: defaultColDef,
    rowData: items,
    rowHeight: 35,
    headerHeight: 35,
    suppressPaginationPanel: true,
    suppressScrollOnNewData: true,
    suppressHorizontalScroll: true,
    suppressCellFocus: true,
    overlayNoRowsTemplate: '<span style="color:#9ca3af;font-size:12px;">조회된 장비가 없습니다.</span>',
    onGridReady: function(params) {
      params.api.sizeColumnsToFit();
      window.addEventListener('resize', function() {
        if (_gridInstance) _gridInstance.sizeColumnsToFit();
      });
    }
  };

  _gridInstance = agGrid.createGrid(el, gridOptions);


}

// ★ 개별 장비에 대해 수정 가능 여부 판단
// equipment/form 권한이 없으면 애초에 수정 자체가 불가하고,
// 권한이 있어도(admin 스코프가 아니면) 본인 소속 팀 장비만 수정 가능
function canEditItem(item) {
  if (!equipmentListState.canEdit) return false;
  if (equipmentListState.isAdmin) return true;
  var itemTeamCode = String(item.team_code || '').trim();
  var userTeamCode = equipmentListState.userTeamCode;
  return !!userTeamCode && itemTeamCode === userTeamCode;
}

function applyListPermissionUi() {
  var createBtn = document.getElementById('createEquipmentBtn');
  if (createBtn) createBtn.style.display = equipmentListState.canEdit ? '' : 'none';

  var exportBtn = document.getElementById('exportExcelBtn');
  if (exportBtn) exportBtn.style.display = '';

  if (typeof applyTopActionsColClass === 'function') applyTopActionsColClass();
}

function buildListRequestParams(filters) {
  var base = {
    request_user_email: equipmentListState.user && equipmentListState.user.email ? equipmentListState.user.email : '',
    keyword:      filters.keyword,
    clinic_code:  filters.clinic_code,
    team_code:    filters.team_code,
    team_suffix:  filters.team_suffix,
    status:       filters.status,
    qc_filter:    filters.qc_filter,
    hira_filter:  filters.hira_filter,
    manufacturer: filters.manufacturer,
    include_total: 'Y'
  };
  return base;
}

function syncListQueryParams(filters) {
  setListQueryParams({
    keyword: filters.keyword,
    clinic_code: filters.clinic_code,
    team_code: filters.team_code,
    status: filters.status,
    manufacturer: filters.manufacturer
  });
}

async function loadEquipmentList() {
  var filters;
  var requestParams;

  if (equipmentListState.loading) return;

  equipmentListState.loading = true;
  try {
    if (typeof clearMessage === 'function') clearMessage();
    if (typeof showGlobalLoading === 'function') {
      showGlobalLoading('장비 목록을 불러오는 중...');
    }

    if (equipmentListState._initialLoad) {
      var urlParams = getListQueryParams();
      // URL에 필터 없으면 scope에 따라 기본 필터 세팅
      // scope='all' → 필터 강제 없음 (전체 조회)
      // scope='clinic' → 소속 의원만 고정
      // scope='team' / null(로드 전) → 소속 의원+팀 고정 (보수적 처리)
      if (!urlParams.clinic_code && !urlParams.keyword && !urlParams.status) {
        var scope = equipmentListState.userScope;
        if (scope === 'all') {
          // 필터 강제 없음 — 전체 조회
        } else if (scope === 'clinic') {
          urlParams.clinic_code = equipmentListState.userClinicCode || '';
        } else {
          // 'team' 또는 아직 scope 미확정(null) → 보수적으로 의원+팀 고정
          urlParams.clinic_code = equipmentListState.userClinicCode || '';
          urlParams.team_code   = equipmentListState.userTeamCode   || '';
        }
      }
      filters = urlParams;
    } else {
      filters = getCurrentFilters();
    }
    equipmentListState._initialLoad = false;
    requestParams = buildListRequestParams(filters);

    // Supabase SDK 직접 호출 — 매번 새로 체이닝을 만들어야 fetchAllRows가 페이지마다 재사용 가능
    var buildEquipQuery = function() {
      var sbQuery = supabaseClient
        .from('equipments')
        .select('*', { count: 'exact' })
        .eq('org_id', equipmentListState.user.org_id)
        .eq('deleted_yn', 'N');

      if (requestParams.status)     sbQuery = sbQuery.eq('status', requestParams.status);
      if (requestParams.qc_filter === 'Y') sbQuery = sbQuery.is('qc_enabled', true);
      if (requestParams.qc_filter === 'N') sbQuery = sbQuery.is('qc_enabled', false);
      if (requestParams.hira_filter === 'Y') sbQuery = sbQuery.is('hira_registered', true);
      if (requestParams.hira_filter === 'N') sbQuery = sbQuery.is('hira_registered', false);
      if (requestParams.clinic_code) sbQuery = sbQuery.eq('clinic_code', requestParams.clinic_code);
      if (requestParams.team_code)   sbQuery = sbQuery.eq('team_code', requestParams.team_code);
      if (requestParams.team_suffix) sbQuery = sbQuery.eq('team_code', requestParams.team_suffix);
      if (requestParams.keyword) {
        var kw = requestParams.keyword;
        sbQuery = sbQuery.or(
          'equipment_name.ilike.%' + kw + '%,' +
          'model_name.ilike.%' + kw + '%,' +
          'serial_no.ilike.%' + kw + '%,' +
          'clinic_name.ilike.%' + kw + '%,' +
          'team_name.ilike.%' + kw + '%,' +
          'location.ilike.%' + kw + '%'
        );
      }
      return sbQuery.order('created_at', { ascending: false });
    };

    var sbResult = await fetchAllRows(buildEquipQuery);

    var totalCount = sbResult.count || 0;

    var rows = (sbResult.data || []).map(function(r) {
      r.equipment_id = r.equipment_no || r.id;  // 표시용: ME-2026-0001
      r._uuid        = r.id;                    // 상세이동용: UUID
      r.qr_value     = r.equipment_no || r.id;
      return r;
    });

    equipmentListState.totalCount = totalCount;

    renderEquipmentList(rows);
    renderListSummary();
    syncListQueryParams(filters);
  } catch (error) {
    if (typeof showMessage === 'function') {
      showMessage(error.message || '장비 목록을 불러오는 중 오류가 발생했습니다.', 'error');
    } else {
      console.error(error);
    }
  } finally {
    equipmentListState.loading = false;
    if (typeof hideGlobalLoading === 'function') {
      hideGlobalLoading();
    }
  }
}


function bindListEvents() {
  var searchForm = document.getElementById('searchForm');
  var resetBtn = document.getElementById('resetFilterBtn');

  if (searchForm) {
    searchForm.addEventListener('submit', async function(event) {
      event.preventDefault();
      await loadEquipmentList();
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', async function() {
      setValue('keyword', '');
      // ★ admin이 아니면 의원 선택 초기화 안 함 (고정)
      if (equipmentListState.isAdmin) {
        setValue('clinic_code', '');
        setValue('team_code', '');
        if (window.orgSelect) {
          window.orgSelect.fillSelectOptions(
            document.getElementById('team_code'),
            [],
            { emptyText: '의원을 먼저 선택하세요' }
          );
          document.getElementById('team_code').disabled = true;
        }
      } else {
        // ★ user: 초기화 시 팀을 본인 소속 팀으로 복원 (의원은 disabled 유지, 팀은 변경 가능)
        setValue('team_code', equipmentListState.userTeamCode || '');
        if (window.orgSelect) {
          var teamElReset = document.getElementById('team_code');
          window.orgSelect.fillSelectOptions(
            teamElReset,
            window.orgSelect.getFilteredTeams(equipmentListState.userClinicCode),
            { emptyText: '전체 팀' }
          );
          teamElReset.value = equipmentListState.userTeamCode || '';
          teamElReset.disabled = false;
        }
      }
      setValue('status', '');
      setValue('manufacturer', '');
      setValue('qc_filter', '');
      setValue('hira_filter', '');
      var teamSufResetEl = document.getElementById('team_suffix');
      if (teamSufResetEl && !teamSufResetEl.disabled) setValue('team_suffix', '');

      await loadEquipmentList();
    });
  }
}

function statusLabelForExport(value) {
  var map = {
    IN_USE: '사용중',
    REPAIRING: '수리중',
    INSPECTING: '점검중',
    STORED: '보관',
    DISPOSED: '폐기'
  };
  return map[String(value || '').trim()] || (value || '');
}

async function exportEquipmentExcel() {
  var exportBtn = document.getElementById('exportExcelBtn');

  if (!window.XLSX) {
    showMessage('엑셀 라이브러리를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요.', 'error');
    return;
  }

  var filters = getCurrentFilters();
  var userEmail = equipmentListState.user && equipmentListState.user.email
    ? equipmentListState.user.email : '';

  try {
    if (exportBtn) {
      exportBtn.disabled = true;
      exportBtn.textContent = '다운로드 중...';
    }
    showGlobalLoading('장비 데이터를 불러오는 중...');

    var buildExportQuery = function() {
      var sbExport = supabaseClient.from('equipments').select('*', { count: 'exact' }).eq('org_id', equipmentListState.user.org_id).eq('deleted_yn', 'N');
      if (filters.status)     sbExport = sbExport.eq('status', filters.status);
      if (filters.clinic_code) sbExport = sbExport.eq('clinic_code', filters.clinic_code);
      if (filters.team_code)   sbExport = sbExport.eq('team_code', filters.team_code);
      if (filters.team_suffix) sbExport = sbExport.eq('team_code', filters.team_suffix);
      if (filters.keyword) {
        var kw = filters.keyword;
        sbExport = sbExport.or('equipment_name.ilike.%' + escapeIlikeKeyword(kw) + '%,model_name.ilike.%' + escapeIlikeKeyword(kw) + '%,serial_no.ilike.%' + escapeIlikeKeyword(kw) + '%');
      }
      return sbExport.order('created_at', { ascending: false });
    };
    var exportResult = await fetchAllRows(buildExportQuery);

    var data = (exportResult.data || []).map(function(r) {
      r.equipment_id = r.equipment_no || r.id;
      r._uuid        = r.id;
      r.qr_value     = r.equipment_no || r.id;
      return r;
    });

    if (!data.length) {
      showMessage('다운로드할 데이터가 없습니다.', 'error');
      return;
    }

    var headers = [
      '장비번호', '장비명', '모델명', '제조사', '시리얼번호',
      '의원', '부서', '현재위치', '현재상태',
      '담당자', '연락처', '구매처', '취득가액',
      '취득일자', '제조일자', '유지보수종료일', '현재사용자', '비고', '등록일시'
    ];

    // 컬럼 유형 (0-based index) — headers/rows 배열 순서: ...11:구매처, 12:취득가액, 13:취득일자, 14:제조일자, 15:유지보수종료일, 16:현재사용자...
    var COL_NUM  = new Set([12]);         // 취득가액
    var COL_DATE = new Set([13, 14, 15]); // 취득일자, 제조일자, 유지보수종료일

    var toDateOnly = function(v) { return v ? String(v).substring(0, 10) : ''; };

    var rows = data.map(function(item) {
      return [
        item.equipment_id || '',
        item.equipment_name || '',
        item.model_name || '',
        item.manufacturer || '',
        item.serial_no || '',
        item.clinic_name || '',
        item.team_name || '',
        item.location || '',
        statusLabelForExport(item.status),
        item.manager_name || '',
        item.manager_phone || '',
        item.vendor || '',
        item.acquisition_cost !== '' && item.acquisition_cost !== null && item.acquisition_cost !== undefined
          ? Number(item.acquisition_cost) : '',
        toDateOnly(item.purchase_date),
        toDateOnly(item.manufacture_date),
        toDateOnly(item.maintenance_end_date),
        item.current_user || '',
        item.memo || '',
        item.created_at || ''
      ];
    });

    // ── 스타일 정의 ──────────────────────────────────────────────
    var FONT_BASE   = { name: '맑은 고딕', sz: 10 };
    var FONT_HEADER = { name: '맑은 고딕', sz: 10, bold: true, color: { rgb: '1F3864' } };
    var FILL_HEADER = { patternType: 'solid', fgColor: { rgb: 'B8CCE4' } };
    var BORDER = {
      top:    { style: 'thin', color: { rgb: 'BFBFBF' } },
      bottom: { style: 'thin', color: { rgb: 'BFBFBF' } },
      left:   { style: 'thin', color: { rgb: 'BFBFBF' } },
      right:  { style: 'thin', color: { rgb: 'BFBFBF' } }
    };
    var ALIGN_LEFT   = { horizontal: 'left',   vertical: 'center' };
    var ALIGN_CENTER = { horizontal: 'center', vertical: 'center' };
    var ALIGN_RIGHT  = { horizontal: 'right',  vertical: 'center' };
    var FMT_NUM  = '#,##0';
    var FMT_DATE = 'yyyy-mm-dd';

    // ── 워크시트 수동 생성 ───────────────────────────────────────
    var ws = {};
    var totalCols = headers.length;
    var totalRows = rows.length + 1;

    // 헤더 행
    headers.forEach(function(h, c) {
      var addr = window.XLSX.utils.encode_cell({ r: 0, c: c });
      ws[addr] = {
        v: h, t: 's',
        s: { font: FONT_HEADER, fill: FILL_HEADER, border: BORDER, alignment: ALIGN_CENTER }
      };
    });

    // 데이터 행
    rows.forEach(function(row, r) {
      row.forEach(function(val, c) {
        var addr   = window.XLSX.utils.encode_cell({ r: r + 1, c: c });
        var isNum  = COL_NUM.has(c);
        var isDate = COL_DATE.has(c);

        var cell = {
          v: val,
          t: isNum && val !== '' ? 'n' : 's',
          s: {
            font:      FONT_BASE,
            border:    BORDER,
            alignment: isNum ? ALIGN_RIGHT : isDate ? ALIGN_CENTER : ALIGN_LEFT
          }
        };

        if (isNum && val !== '') { cell.z = FMT_NUM; cell.s.numFmt = FMT_NUM; }
        // 날짜는 문자열(yyyy-mm-dd)로 저장 — numFmt 지정 시 손상 오류 발생

        ws[addr] = cell;
      });
    });

    ws['!ref']  = window.XLSX.utils.encode_range({ r: 0, c: 0 }, { r: totalRows - 1, c: totalCols - 1 });
    ws['!cols'] = [
      { wch: 14 }, { wch: 20 }, { wch: 16 }, { wch: 14 }, { wch: 16 },
      { wch: 20 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 8 },
      { wch: 10 }, { wch: 14 }, { wch: 14 }, { wch: 12 },
      { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 10 }, { wch: 20 }, { wch: 18 }
    ];
    ws['!rows'] = Array(totalRows).fill({ hpt: 18 });

    var wb = window.XLSX.utils.book_new();
    window.XLSX.utils.book_append_sheet(wb, ws, '장비대장');

    var now = new Date();
    var dateStr = now.getFullYear() +
      String(now.getMonth() + 1).padStart(2, '0') +
      String(now.getDate()).padStart(2, '0');
    var fileName = '장비대장_' + dateStr + '.xlsx';

    window.XLSX.writeFile(wb, fileName);

  } catch (error) {
    showMessage(error.message || '엑셀 다운로드 중 오류가 발생했습니다.', 'error');
  } finally {
    if (exportBtn) {
      exportBtn.disabled = false;
      exportBtn.textContent = '엑셀 다운로드';
    }
    hideGlobalLoading(true);
  }
}

// 동기 초기화 — 상태/UI 기본 세팅 (API 호출 없음)
function initListFiltersSync() {
  var query = getListQueryParams();
  fillStatusFilterOptions();
  setValue('keyword', query.keyword || '');
  setValue('status', query.status || '');
  setValue('manufacturer', query.manufacturer || '');
}


// departments 테이블 기반 부서 필터 채우기
function populateDeptFilter(el, deptRows, clinicCode, query) {
  if (!el) return;
  var filtered = clinicCode
    ? (deptRows || []).filter(function(d) { return d.clinics && d.clinics.clinic_code === clinicCode; })
    : (deptRows || []);
  var opts = '<option value="">전체 부서</option>';
  filtered.forEach(function(d) {
    // 특정 의원으로 좁혀지지 않은 상태(전체 의원)에서는 같은 부서명이 의원마다 반복돼
    // 어느 의원 소속인지 구분이 안 되므로, 이때만 의원명을 괄호로 같이 표기한다.
    var label = clinicCode ? d.dept_name : (d.dept_name + (d.clinics && d.clinics.clinic_name ? ' (' + d.clinics.clinic_name + ')' : ''));
    opts += '<option value="' + escapeHtml(d.dept_code) + '">' + escapeHtml(label) + '</option>';
  });
  el.innerHTML = opts;
  el.disabled = false;
  if (query && query.team_suffix) el.value = query.team_suffix;
}

// 비동기 초기화 — clinics/departments 테이블에서 필터 UI 세팅
async function initListFiltersAsync() {
  var query     = getListQueryParams();
  var clinicEl  = document.getElementById('clinic_code');
  var teamSufEl = document.getElementById('team_suffix');
  var teamEl    = document.getElementById('team_code');

  // clinics 테이블에서 로드
  var { data: clinicRows } = await supabaseClient
    .from('clinics')
    .select('clinic_code, clinic_name')
    .eq('id', equipmentListState.user.org_id)
    .eq('is_active', true)
    .order('sort_order', { ascending: true });

  // departments 테이블에서 로드
  var { data: deptRows } = await supabaseClient
    .from('departments')
    .select('dept_code, dept_name, clinic_id, clinics!departments_clinic_id_fkey(clinic_code, clinic_name)')
    .eq('org_id', equipmentListState.user.org_id)
    .eq('active', 'Y')
    .order('sort_order', { ascending: true });

  var clinics = (clinicRows || []).map(function(r) {
    return { code_value: r.clinic_code, code_name: r.clinic_name };
  });

  if (teamEl) teamEl.value = '';

  // ── 의원 select ──────────────────────────────────────────────
  // 조직=의원이 항상 1:1이라 "전체 의원" 같은 선택지 자체가 의미가 없다 — role과 상관없이
  // 이 의원 하나로 자동 세팅하고 select는 잠가둔다(레이아웃은 그대로, 조작만 막는 방식).
  if (clinicEl) {
    var myClinic = clinics[0] || null;
    clinicEl.innerHTML = myClinic
      ? '<option value="' + escapeHtml(myClinic.code_value) + '">' + escapeHtml(myClinic.code_name) + '</option>'
      : '<option value="">의원 정보 없음</option>';
    clinicEl.value = myClinic ? myClinic.code_value : '';
    clinicEl.disabled = true;
  }
  equipmentListState.userScope = 'clinic';

  // ── 부서 select: departments 테이블 기준(이 의원 소속 부서 전체 — role 상관없이 동일) ──
  if (teamSufEl) {
    var deptScopeClinic = clinics[0] ? clinics[0].code_value : '';
    populateDeptFilter(teamSufEl, deptRows, deptScopeClinic, query);
  }
}


document.addEventListener('DOMContentLoaded', async function() {
  try {
    if (typeof showGlobalLoading === 'function') {
      showGlobalLoading('장비 목록 화면을 준비하는 중...');
    }

    if (window.auth && typeof window.auth.requireAuth === 'function') {
      await window.auth.requireAuth(); // 로그인 게이트 — 세션 없으면 여기서 로그인 페이지로 리다이렉트됨
      equipmentListState.user = await window.auth.getSession(); // role/clinic_code/team_code가 담긴 실제 프로필
    }

    if (!equipmentListState.user) {
      if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
      return;
    }

    // ★ admin 여부(전체 의원 조회용 scope 판단) 및 소속 의원/팀 코드 세팅
    // 주의: 여기서의 isAdmin은 "의원 스코프(전체 조회 가능 여부)"만을 의미하며,
    // 페이지별 조회/수정 권한과는 별개다 — 그건 아래 PagePerms로 판단한다.
    var userRole = String(equipmentListState.user.role || '').trim().toLowerCase();
    equipmentListState.isAdmin = (userRole === 'admin');
    equipmentListState.userClinicCode = String(equipmentListState.user.clinic_code || '').trim();
    equipmentListState.userTeamCode   = String(equipmentListState.user.team_code   || '').trim();

    // 페이지 접근 권한 — '접근불가'면 아예 못 들어오게 막는다
    if (!window.PagePerms || !window.PagePerms.canAccess(equipmentListState.user, 'equipment/list')) {
      if (typeof hideGlobalLoading === 'function') hideGlobalLoading();
      if (typeof showMessage === 'function') showMessage('이 페이지에 접근할 권한이 없습니다.', 'error');
      return;
    }

    // 장비 등록/수정(equipment/form)에 edit 이상 권한이 있어야 목록에서 수정·등록 버튼 노출
    equipmentListState.canEdit    = window.PagePerms.atLeast(equipmentListState.user, 'equipment/form', 'edit');
    equipmentListState.isAppAdmin = window.PagePerms.atLeast(equipmentListState.user, 'equipment/list', 'admin');

    applyListPermissionUi();
    initListFiltersSync();
    bindListEvents();

    var isReload = window.performance &&
      window.performance.getEntriesByType &&
      window.performance.getEntriesByType('navigation')[0] &&
      window.performance.getEntriesByType('navigation')[0].type === 'reload';
    if (isReload) clearListState();

    var cached = loadListState();
    // cached 복원은 initListFiltersAsync(scope 확정) 이후에 적용
    // scope 확정이 _initialLoad 필터링보다 먼저 일어나야 하므로
    // initListFiltersAsync 완료 후 loadEquipmentList 실행
    await initListFiltersAsync();

    if (cached && cached.filters) {
      var f = cached.filters;
      if (f.keyword)     setValue('keyword',    f.keyword);
      if (f.status)      setValue('status',     f.status);
      if (f.qc_filter)   setValue('qc_filter',  f.qc_filter);
      if (f.hira_filter) setValue('hira_filter', f.hira_filter);
      if (f.manufacturer) setValue('manufacturer', f.manufacturer);
      if (f.clinic_code) {
        var clinicEl2 = document.getElementById('clinic_code');
        if (clinicEl2 && !clinicEl2.disabled) setValue('clinic_code', f.clinic_code);
      }
      if (f.team_code) {
        var teamEl2 = document.getElementById('team_code');
        if (teamEl2 && !teamEl2.disabled) setValue('team_code', f.team_code);
      }
      if (f.team_suffix) {
        var teamSufEl2 = document.getElementById('team_suffix');
        if (teamSufEl2 && !teamSufEl2.disabled) setValue('team_suffix', f.team_suffix);
      }
      equipmentListState._initialLoad = false;
    }

    await loadEquipmentList();

    var exportBtn = document.getElementById('exportExcelBtn');
    if (exportBtn) {
      exportBtn.addEventListener('click', exportEquipmentExcel);
    }
  } catch (error) {
    if (typeof showMessage === 'function') {
      showMessage(error.message || '화면 초기화 중 오류가 발생했습니다.', 'error');
    } else {
      console.error(error);
    }
  } finally {
    if (typeof hideGlobalLoading === 'function') hideGlobalLoading(true);
    document.body.classList.add('page-ready');
  }
});

// ================================================================
// 라벨 일괄 출력
// ================================================================

var bulkSelectedIds = new Set();

function initBulkLabelFeature() {
  var bulkBtn    = document.getElementById('bulkLabelBtn');
  var checkAllEl = document.getElementById('bulkCheckAll');

  if (!bulkBtn) return;

  // 라벨 일괄 출력 버튼 클릭 → 오버레이 인쇄
  bulkBtn.addEventListener('click', function() {
    if (!bulkSelectedIds.size) return;
    var ids        = Array.from(bulkSelectedIds);
    var sizeClass  = getSelectedLabelSizeForBulk();
    var layoutSelect = document.getElementById('bulkLayoutSelect');
    var layout     = layoutSelect ? layoutSelect.value : '';
    printLabelsOverlay(ids, sizeClass, layout);
  });

  // 검수확인서 일괄 출력 버튼
  var certBtn = document.getElementById('bulkInspectionCertBtn');
  if (certBtn) {
    certBtn.addEventListener('click', async function() {
      if (!bulkSelectedIds.size) return;
      var ids = Array.from(bulkSelectedIds);

      try {
        showGlobalLoading('장비 정보를 불러오는 중...');

        var user = equipmentListState.user;
        var userEmail = (user && user.email) ? user.email : '';

        var items = await Promise.all(
          ids.map(function(id) {
            return supabaseClient
              .from('equipments')
              .select('*')
              .eq('id', id)
              .single()
              .then(function(r) { return r.data || {}; });
          })
        );

        if (typeof generateInspectionCertPDF === 'function') {
          // 구매처 동일 여부 체크
          var vendors = [...new Set(items.map(function(e) { return String(e.vendor || '').trim(); }).filter(Boolean))];

          if (vendors.length > 1) {
            alert('⚠️ 선택한 장비의 구매처가 다릅니다.\n\n' +
              vendors.join(', ') +
              '\n\n검수확인서는 구매처가 동일한 장비만 함께 출력할 수 있습니다.');
            return;
          }

          generateInspectionCertPDF(items);
        }
      } catch (error) {
        showMessage(error.message || '장비 정보를 불러오는 중 오류가 발생했습니다.', 'error');
      } finally {
        hideGlobalLoading();
      }
    });
  }

  // 사이즈 변경 시 격자 옵션 갱신
  var sizeSelectEl = document.getElementById('bulkLabelSizeSelect');
  if (sizeSelectEl) sizeSelectEl.addEventListener('change', updateLayoutOptions);

  // 전체 선택 체크박스 (헤더)
  document.addEventListener('change', function(e) {
    if (e.target.id !== 'bulkCheckAll') return;
    var checks = document.querySelectorAll('.bulk-item-check');
    checks.forEach(function(cb) {
      cb.checked = e.target.checked;
      var id = cb.dataset.id;
      if (e.target.checked) bulkSelectedIds.add(id);
      else bulkSelectedIds.delete(id);
    });
    updateBulkUI();
  });

  // 개별 체크박스 이벤트 위임
  var listEl = document.getElementById('equipmentList');
  if (listEl) {
    listEl.addEventListener('change', function(e) {
      if (!e.target.classList.contains('bulk-item-check')) return;
      var id = e.target.dataset.id;
      if (e.target.checked) bulkSelectedIds.add(id);
      else bulkSelectedIds.delete(id);

      // 헤더 전체선택 체크박스 상태 동기화
      var checkAll = document.getElementById('bulkCheckAll');
      if (checkAll) {
        var allChecks = document.querySelectorAll('.bulk-item-check');
        var checkedCount = document.querySelectorAll('.bulk-item-check:checked').length;
        checkAll.checked = allChecks.length > 0 && checkedCount === allChecks.length;
        checkAll.indeterminate = checkedCount > 0 && checkedCount < allChecks.length;
      }

      updateBulkUI();
    });
  }
}

function updateBulkUI() {
  var btn                 = document.getElementById('bulkLabelBtn');
  var countEl             = document.getElementById('bulkLabelCount');
  var sizeSelect          = document.getElementById('bulkLabelSizeSelect');
  var layoutSelect        = document.getElementById('bulkLayoutSelect');
  var certBtn             = document.getElementById('bulkInspectionCertBtn');
  var certCountEl         = document.getElementById('bulkInspectionCertCount');
  var count               = bulkSelectedIds.size;

  if (btn)          btn.style.display          = count > 0 ? '' : 'none';
  if (sizeSelect)   sizeSelect.style.display   = count > 0 ? '' : 'none';
  if (layoutSelect) layoutSelect.style.display = count > 0 ? '' : 'none';
  if (countEl)      countEl.textContent        = count;
  if (certBtn)      certBtn.style.display      = (count > 0 && equipmentListState.isAppAdmin) ? '' : 'none';
  if (certCountEl)  certCountEl.textContent    = count;
}

function updateLayoutOptions() {
  var sizeSelect   = document.getElementById('bulkLabelSizeSelect');
  var layoutSelect = document.getElementById('bulkLayoutSelect');
  if (!layoutSelect || !sizeSelect) return;

  var size = sizeSelect.value;
  if (size === 'size-70x40') {
    layoutSelect.innerHTML =
      '<option value="2x6">격자 — 2×6 (12칸)</option>';
  } else {
    layoutSelect.innerHTML =
      '<option value="2x5">격자 — 2×5 (10칸)</option>';
  }
}

function getSelectedLabelSizeForBulk() {
  var sizeSelect = document.getElementById('bulkLabelSizeSelect');
  return sizeSelect ? sizeSelect.value : 'size-90x48';
}

// 목록 렌더링 후 체크 상태 초기화
var _origRenderEquipmentList = renderEquipmentList;
renderEquipmentList = function(items) {
  // 현재 페이지 데이터 저장 (일괄 출력용)
  equipmentListState.currentItems = Array.isArray(items) ? items : [];

  _origRenderEquipmentList(items);
  bulkSelectedIds.clear();
  updateBulkUI();
  var checkAll = document.getElementById('bulkCheckAll');
  if (checkAll) { checkAll.checked = false; checkAll.indeterminate = false; }
};

document.addEventListener('DOMContentLoaded', function() {
  // 기존 DOMContentLoaded 이후 초기화
  setTimeout(initBulkLabelFeature, 100);
});

// ================================================================
// 라벨 인쇄 오버레이 (페이지 이동 없이 직접 출력)
// ================================================================

var GRID_SPECS_LIST = {
  '2x5': { cols: 2, rows: 5, colGap: '3mm', rowGap: '2mm', padT: '10mm', padS: '8mm' },
  '2x6': { cols: 2, rows: 6, colGap: '3mm', rowGap: '1mm', padT: '7mm',  padS: '8mm' }
};

function buildLabelHtmlForList(item, sizeClass, qrId) {
  var showLocation = sizeClass !== 'size-70x40' && sizeClass !== 'size-50x30';
  var showModel    = sizeClass !== 'size-50x30';
  var showDept     = sizeClass !== 'size-50x30';
  var sc           = sizeClass.replace('size-', ''); // '90x48', '70x40', '50x30'

  return (
    '<div class="prlabel prlabel--' + sc + '">' +
      '<div class="prlabel-body">' +
        '<div class="prlabel-hospital">' + escapeHtml(item.clinic_name || '') + '</div>' +
        '<div class="prlabel-title">' + escapeHtml(item.equipment_name || '-') + '</div>' +
        '<div class="prlabel-rows">' +
          '<div class="prlabel-row">' +
            '<span class="prlabel-key">관리번호</span>' +
            '<span class="prlabel-id">' + escapeHtml(item.equipment_id || '-') + '</span>' +
          '</div>' +
          (showModel ? '<div class="prlabel-row"><span class="prlabel-key">모델명</span><span class="prlabel-val">' + escapeHtml(item.model_name || '-') + '</span></div>' : '') +
          (showDept  ? '<div class="prlabel-row"><span class="prlabel-key">사용부서</span><span class="prlabel-val">' + escapeHtml(item.department || '-') + '</span></div>' : '') +
          (showLocation ? '<div class="prlabel-row"><span class="prlabel-key">위치</span><span class="prlabel-val">' + escapeHtml(item.location || '-') + '</span></div>' : '') +
        '</div>' +
      '</div>' +
      '<div class="prlabel-qr" id="' + escapeHtml(qrId) + '"></div>' +
    '</div>'
  );
}


function printLabelsOverlay(ids, sizeClass, layout) {
  var allItems = equipmentListState.currentItems || [];
  var items = ids.map(function(id) {
    return allItems.find(function(i) { return i.equipment_id === id; }) ||
      { equipment_id: id, equipment_name: id, model_name: '', department: '', location: '', qr_value: id };
  });

  var prev = document.getElementById('printLabelOverlay');
  if (prev) prev.remove();

  var overlay = document.createElement('div');
  overlay.id = 'printLabelOverlay';

  var isGrid  = !!(layout && GRID_SPECS_LIST[layout]);
  var spec    = isGrid ? GRID_SPECS_LIST[layout] : null;
  var perPage = spec ? spec.cols * spec.rows : 1;
  var pagesHtml = '';

  if (isGrid) {
    for (var p = 0; p < items.length; p += perPage) {
      var pageItems = items.slice(p, p + perPage);
      while (pageItems.length < perPage) pageItems.push(null);

      var cells = pageItems.map(function(item, cellIdx) {
        if (!item) return '<div class="plabel-empty"></div>';
        var qrId = 'pqr-g-' + p + '-' + cellIdx;
        return buildLabelHtmlForList(item, sizeClass, qrId);
      }).join('');

      pagesHtml += (
        '<div class="plabel-page plabel-page--grid" style="' +
          'grid-template-columns:repeat(' + spec.cols + ',auto);' +
          'gap:' + spec.rowGap + ' ' + spec.colGap + ';' +
          'padding:' + spec.padT + ' ' + spec.padS + ';' +
        '">' + cells + '</div>'
      );
    }
  } else {
    pagesHtml = items.map(function(item, idx) {
      var qrId = 'pqr-s-' + idx;
      return '<div class="plabel-page plabel-page--single">' +
        buildLabelHtmlForList(item, sizeClass, qrId) +
      '</div>';
    }).join('');
  }

  overlay.innerHTML = pagesHtml;
  document.body.appendChild(overlay);

  var baseUrl = (typeof CONFIG !== 'undefined' ? CONFIG.SITE_BASE_URL : '') +
                '/pages/equipment/public-detail.html?id=';
  var qrSize = sizeClass === 'size-70x40' ? 64 : sizeClass === 'size-50x30' ? 48 : 84;

  items.forEach(function(item, idx) {
    if (!item) return;
    var qrId = isGrid
      ? ('pqr-g-' + (Math.floor(idx / perPage) * perPage) + '-' + (idx % perPage))
      : ('pqr-s-' + idx);
    var qrEl = document.getElementById(qrId);
    if (!qrEl) return;
    var qrValue = item.equipment_id || '';
    if (qrValue && typeof QRCode !== 'undefined') {
      new QRCode(qrEl, { text: baseUrl + encodeURIComponent(qrValue), width: qrSize, height: qrSize });
    }
  });

  setTimeout(function() {
    window.print();
    setTimeout(function() {
      var el = document.getElementById('printLabelOverlay');
      if (el) el.remove();
    }, 500);
  }, 400);
}


// ================================================================
// 장비목록 단건 라벨 출력 모달
// ================================================================

function openListLabelModal(equipmentId) {
  // 현재 로드된 데이터에서 장비 찾기
  var items = equipmentListState.currentItems || [];
  var item  = items.find(function(i) { return i.equipment_id === equipmentId; });

  // 기존 오버레이 제거
  var prev = document.getElementById('listLabelModalOverlay');
  if (prev) prev.remove();

  // 오버레이 생성
  var overlay = document.createElement('div');
  overlay.id  = 'listLabelModalOverlay';
  overlay.className = 'list-label-modal-overlay';
  overlay.innerHTML = (
    '<div class="list-label-modal-backdrop"></div>' +
    '<div class="list-label-modal-dialog">' +
      '<div class="list-label-modal-head">' +
        '<div class="list-label-modal-head-left">' +
          '<div class="list-label-modal-icon"><i class="ti ti-tag"></i></div>' +
          '<div>' +
            '<div class="list-label-modal-title">라벨 출력</div>' +
            '<div class="list-label-modal-subtitle">QR 포함 장비 식별 라벨을 인쇄합니다</div>' +
          '</div>' +
        '</div>' +
        '<button type="button" class="list-label-modal-close" id="listLabelClose"><i class="ti ti-x"></i></button>' +
      '</div>' +
      '<div class="list-label-modal-body">' +
        '<div class="label-modal-toolbar">' +
          '<label class="form-label" style="margin:0;white-space:nowrap;">라벨 크기</label>' +
          '<select id="listLabelSizeSelect" class="input" style="width:140px;height:30px;font-size:12px;">' +
            '<option value="size-90x48" selected>90 × 48 mm</option>' +
            '<option value="size-70x40">70 × 40 mm</option>' +
            '<option value="size-50x30">50 × 30 mm</option>' +
          '</select>' +
          '<button type="button" class="btn btn-sm btn-primary" id="listLabelPrintBtn">' +
            '<i class="ti ti-printer"></i> 인쇄' +
          '</button>' +
        '</div>' +
        '<div class="label-modal-preview">' +
          '<div class="label-sheet-wrap">' +
            '<div class="device-label size-90x48" id="listLabelDevice">' +
              '<div class="device-label-main">' +
                '<div class="label-hospital" id="llm_hospital">-</div>' +
                '<div class="label-title" id="llm_name">-</div>' +
                '<div class="label-info-block">' +
                  '<div class="label-row label-row-emphasis">' +
                    '<div class="label-key">관리번호</div>' +
                    '<div class="label-value label-value-id" id="llm_id">-</div>' +
                  '</div>' +
                  '<div class="label-row" id="llm_row_model">' +
                    '<div class="label-key">모델명</div>' +
                    '<div class="label-value" id="llm_model">-</div>' +
                  '</div>' +
                  '<div class="label-row" id="llm_row_dept">' +
                    '<div class="label-key">사용부서</div>' +
                    '<div class="label-value" id="llm_dept">-</div>' +
                  '</div>' +
                  '<div class="label-row" id="llm_row_loc">' +
                    '<div class="label-key">위치</div>' +
                    '<div class="label-value" id="llm_loc">-</div>' +
                  '</div>' +
                '</div>' +
              '</div>' +
              '<div class="qr-panel"><div id="llm_qr" class="label-qr-box"></div></div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>'
  );

  document.body.appendChild(overlay);

  // 데이터 채우기
  function setT(id, val) { var el = document.getElementById(id); if (el) el.textContent = val || '-'; }
  setT('llm_hospital', item && item.clinic_name);
  setT('llm_name',  item && item.equipment_name);
  setT('llm_id',    item && item.equipment_id || equipmentId);
  setT('llm_model', item && item.model_name);
  setT('llm_dept',  item && item.department);
  setT('llm_loc',   item && item.location);

  listLabelApplySize('size-90x48', equipmentId);

  // 이벤트
  document.getElementById('listLabelClose').addEventListener('click', closeListLabelModal);
  overlay.querySelector('.list-label-modal-backdrop').addEventListener('click', closeListLabelModal);

  document.getElementById('listLabelSizeSelect').addEventListener('change', function() {
    listLabelApplySize(this.value, equipmentId);
  });

  document.getElementById('listLabelPrintBtn').addEventListener('click', function() {
    window.print();
  });

  setTimeout(function() { overlay.classList.add('is-open'); }, 10);
}

function closeListLabelModal() {
  var overlay = document.getElementById('listLabelModalOverlay');
  if (overlay) overlay.remove();
}

function listLabelApplySize(sizeClass, equipmentId) {
  var label = document.getElementById('listLabelDevice');
  if (label) {
    label.classList.remove('size-90x48', 'size-70x40', 'size-50x30');
    label.classList.add(sizeClass);
  }
  var rowModel = document.getElementById('llm_row_model');
  var rowDept  = document.getElementById('llm_row_dept');
  var rowLoc   = document.getElementById('llm_row_loc');
  if (rowModel) rowModel.style.display = sizeClass === 'size-50x30' ? 'none' : '';
  if (rowDept)  rowDept.style.display  = sizeClass === 'size-50x30' ? 'none' : '';
  if (rowLoc)   rowLoc.style.display   = (sizeClass === 'size-70x40' || sizeClass === 'size-50x30') ? 'none' : '';

  var qrEl = document.getElementById('llm_qr');
  if (!qrEl) return;
  qrEl.innerHTML = '';

  var url = (typeof CONFIG !== 'undefined' ? CONFIG.SITE_BASE_URL : '') +
            '/pages/equipment/public-detail.html?id=' + encodeURIComponent(equipmentId);
  var qrSize = sizeClass === 'size-70x40' ? 64 : sizeClass === 'size-50x30' ? 48 : 84;

  if (typeof QRCode !== 'undefined' && equipmentId) {
    new QRCode(qrEl, { text: url, width: qrSize, height: qrSize });
  }
}


// 장비 수정 진입 — 목록에서만 호출, 저장/취소 후 목록으로 복귀
function openEditForm(equipmentId) {
  try {
    if (window.parent && window.parent.shellNavigate) {
      window.parent.shellNavigate('equipment/form', '', false, { id: equipmentId, from: 'list' });
    } else {
      location.href = 'form.html?id=' + encodeURIComponent(equipmentId);
    }
  } catch(e) {
    location.href = 'form.html?id=' + encodeURIComponent(equipmentId);
  }
}
